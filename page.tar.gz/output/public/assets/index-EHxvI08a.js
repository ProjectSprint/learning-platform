import{W as t}from"./main-C1pqQcoI.js";const{withContext:e}=t({key:"text"}),o=e("p");o.displayName="Text";export{o as T};
