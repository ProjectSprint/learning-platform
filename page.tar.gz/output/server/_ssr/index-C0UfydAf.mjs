import { j as jsxRuntimeExports, r as reactExports } from "../_libs/react.mjs";
import { d as useNavigate } from "../_libs/@tanstack/react-router.mjs";
import { u as useDragEngine } from "./use-drag-engine-CAadIO0l.mjs";
import { G as GameProvider, u as useGameDispatch, a as useGameState, b as useTerminalInput, c as useTerminalEngine, r as resolvePhase, e as GameShell, P as PlayCanvas, I as InventoryDrawer, T as TerminalLayout, f as TerminalInput, g as TerminalView } from "./question-ast-DxRXheAC.mjs";
import { m as markNetworkingQuestionComplete, b as getNextQuestionPath } from "./module-progress-CKDPPitT.mjs";
import { F as Flex, B as Box, T as Text } from "../_libs/@chakra-ui/react.mjs";
import "../_libs/@babel/runtime.mjs";
import "../_libs/tiny-warning.mjs";
import "../_libs/@tanstack/router-core.mjs";
import "../_libs/@tanstack/store.mjs";
import "../_libs/@tanstack/history.mjs";
import "../_libs/tiny-invariant.mjs";
import "node:stream/web";
import "node:stream";
import "../_libs/react-dom.mjs";
import "util";
import "crypto";
import "async_hooks";
import "stream";
import "../_libs/isbot.mjs";
import "../_libs/@tanstack/react-store.mjs";
import "../_libs/use-sync-external-store.mjs";
import "../_libs/gsap.mjs";
import "../_libs/@iconify/react.mjs";
import "../_libs/lucide-react.mjs";
import "../_libs/@ark-ui/react.mjs";
import "../_libs/@zag-js/carousel.mjs";
import "../_libs/@zag-js/anatomy.mjs";
import "../_libs/@zag-js/types.mjs";
import "../_libs/@zag-js/core.mjs";
import "../_libs/@zag-js/utils.mjs";
import "../_libs/@zag-js/dom-query.mjs";
import "../_libs/@zag-js/checkbox.mjs";
import "../_libs/@zag-js/focus-visible.mjs";
import "../_libs/@zag-js/react.mjs";
import "../_libs/@zag-js/color-picker.mjs";
import "../_libs/@zag-js/color-utils.mjs";
import "../_libs/@zag-js/popper.mjs";
import "../_libs/@floating-ui/dom.mjs";
import "../_libs/@floating-ui/core.mjs";
import "../_libs/@floating-ui/utils.mjs";
import "../_libs/@zag-js/dismissable.mjs";
import "../_libs/@zag-js/interact-outside.mjs";
import "../_libs/@zag-js/combobox.mjs";
import "../_libs/@zag-js/collection.mjs";
import "../_libs/@zag-js/auto-resize.mjs";
import "../_libs/@zag-js/listbox.mjs";
import "../_libs/@zag-js/radio-group.mjs";
import "../_libs/@zag-js/tooltip.mjs";
import "../_libs/@zag-js/presence.mjs";
import "../_libs/@pandacss/is-valid-prop.mjs";
import "../_libs/@zag-js/switch.mjs";
import "../_libs/@zag-js/splitter.mjs";
import "../_libs/@zag-js/slider.mjs";
import "../_libs/@zag-js/select.mjs";
import "../_libs/@zag-js/rating-group.mjs";
import "../_libs/@zag-js/popover.mjs";
import "../_libs/@zag-js/menu.mjs";
import "../_libs/@zag-js/rect-utils.mjs";
import "../_libs/@zag-js/file-upload.mjs";
import "../_libs/@zag-js/editable.mjs";
import "../_libs/@zag-js/dialog.mjs";
import "../_libs/@zag-js/accordion.mjs";
import "../_libs/@zag-js/clipboard.mjs";
import "../_libs/@zag-js/avatar.mjs";
import "../_libs/@zag-js/collapsible.mjs";
import "../_libs/@zag-js/hover-card.mjs";
import "../_libs/@zag-js/number-input.mjs";
import "../_libs/@internationalized/number.mjs";
import "../_libs/@zag-js/pin-input.mjs";
import "../_libs/@zag-js/progress.mjs";
import "../_libs/@zag-js/qr-code.mjs";
import "../_libs/@zag-js/scroll-area.mjs";
import "../_libs/@zag-js/tags-input.mjs";
import "../_libs/@zag-js/live-region.mjs";
import "../_libs/@zag-js/tree-view.mjs";
import "../_libs/@emotion/is-prop-valid.mjs";
import "../_libs/@emotion/memoize.mjs";
import "../_libs/@emotion/serialize.mjs";
import "../_libs/@emotion/hash.mjs";
import "../_libs/@emotion/unitless.mjs";
import "../_libs/@emotion/use-insertion-effect-with-fallbacks.mjs";
import "../_libs/@emotion/utils.mjs";
import "../_libs/@emotion/react.mjs";
import "../_libs/@emotion/cache.mjs";
import "../_libs/@emotion/sheet.mjs";
import "../_libs/@emotion/weak-memoize.mjs";
import "../_libs/stylis.mjs";
const QUESTION_ID = "networking";
const QUESTION_TITLE = "🏡 Setup your home connection!";
const QUESTION_DESCRIPTION = "Try to connect two of this PC using Router!";
const TERMINAL_PROMPT = "How can you check that PC-1 is connected to PC-2?";
const TERMINAL_INTRO_ENTRIES = [
  {
    id: "intro-dhcp-1",
    type: "output",
    content: "Available commands:",
    timestamp: 0
  },
  {
    id: "intro-dhcp-2",
    type: "output",
    content: "- ping pc-2",
    timestamp: 1
  },
  {
    id: "intro-dhcp-3",
    type: "output",
    content: "- ping <pc-2-ip>",
    timestamp: 2
  }
];
const INVENTORY_ITEMS = [
  {
    id: "pc-1",
    type: "pc",
    name: "PC-1",
    allowedPlaces: ["inventory", "networking-canvas"],
    icon: { icon: "twemoji:laptop-computer" },
    behavior: "connectable"
  },
  {
    id: "pc-2",
    type: "pc",
    name: "PC-2",
    allowedPlaces: ["inventory", "networking-canvas"],
    icon: { icon: "twemoji:laptop-computer" },
    behavior: "connectable"
  },
  {
    id: "router-1",
    type: "router",
    name: "Router",
    allowedPlaces: ["inventory", "networking-canvas"],
    icon: { icon: "streamline-flex-color:router-wifi-network" },
    behavior: "connectable"
  },
  {
    id: "cable-1",
    type: "cable",
    name: "Cable",
    allowedPlaces: ["inventory", "networking-canvas"],
    icon: { icon: "mdi:ethernet-cable", color: "#2596be" },
    behavior: "connectable"
  },
  {
    id: "cable-2",
    type: "cable",
    name: "Cable",
    allowedPlaces: ["inventory", "networking-canvas"],
    icon: { icon: "mdi:ethernet-cable", color: "#2596be" },
    behavior: "connectable"
  }
];
const INVENTORY_GROUPS = [
  {
    id: "default",
    title: "Inventory",
    visible: true,
    items: INVENTORY_ITEMS
  }
];
const CANVAS_CONFIG = {
  id: "networking-canvas",
  columns: 5,
  rows: 1,
  maxItems: 6
};
const PRIVATE_IP_RANGES = [
  /^10\./,
  /^172\.(1[6-9]|2\d|3[01])\./,
  /^192\.168\./
];
const isValidIP = (ip) => {
  const parts = ip.split(".");
  if (parts.length !== 4) return false;
  return parts.every((part) => {
    const num = Number.parseInt(part, 10);
    return !Number.isNaN(num) && num >= 0 && num <= 255;
  });
};
const parseIP = (ip) => {
  const parts = ip.split(".").map((p) => Number.parseInt(p, 10));
  return (parts[0] << 24 >>> 0) + (parts[1] << 16) + (parts[2] << 8) + parts[3];
};
const calculateRange = (startIP, endIP) => {
  return parseIP(endIP) - parseIP(startIP) + 1;
};
const getContextualHint = (state) => {
  const {
    placedItems,
    connections,
    router,
    connectedPcIds,
    routerConfigured,
    dhcpEnabled,
    startIp,
    endIp,
    routerSettingsOpen,
    pc1HasIp,
    pc2HasIp
  } = state;
  const pcCount = placedItems.filter((item) => item.type === "pc").length;
  const routerCount = placedItems.filter(
    (item) => item.type === "router"
  ).length;
  const hasPcToPcConnection = connections.some((c) => {
    const fromItem = placedItems.find(
      (item) => item.blockX === c.from.x && item.blockY === c.from.y
    );
    const toItem = placedItems.find(
      (item) => item.blockX === c.to.x && item.blockY === c.to.y
    );
    return fromItem?.type === "pc" && toItem?.type === "pc";
  });
  const hasRouterToRouterConnection = connections.some((c) => {
    const fromItem = placedItems.find(
      (item) => item.blockX === c.from.x && item.blockY === c.from.y
    );
    const toItem = placedItems.find(
      (item) => item.blockX === c.to.x && item.blockY === c.to.y
    );
    return fromItem?.type === "router" && toItem?.type === "router";
  });
  const cableCountByDevice = /* @__PURE__ */ new Map();
  for (const conn of connections) {
    const fromItem = placedItems.find(
      (item) => item.blockX === conn.from.x && item.blockY === conn.from.y
    );
    const toItem = placedItems.find(
      (item) => item.blockX === conn.to.x && item.blockY === conn.to.y
    );
    if (fromItem) {
      cableCountByDevice.set(
        fromItem.id,
        (cableCountByDevice.get(fromItem.id) || 0) + 1
      );
    }
    if (toItem) {
      cableCountByDevice.set(
        toItem.id,
        (cableCountByDevice.get(toItem.id) || 0) + 1
      );
    }
  }
  const hasDuplicateCableOnPC = Array.from(cableCountByDevice.entries()).some(
    ([id, count]) => {
      const item = placedItems.find((p) => p.id === id);
      return item?.type === "pc" && count > 1;
    }
  );
  if (pcCount > 2) {
    return "❌ Only 2 PCs needed - remove the extra one";
  }
  if (routerCount > 1) {
    return "❌ Only 1 router needed - remove the extra one";
  }
  if (hasPcToPcConnection) {
    return "❌ PCs can't connect directly - connect them to the router instead";
  }
  if (hasRouterToRouterConnection) {
    return "❌ Both cable ends are on the router - connect one end to a PC";
  }
  if (hasDuplicateCableOnPC) {
    return "❌ This PC already has a cable - connect the other PC instead";
  }
  if (routerSettingsOpen && startIp && endIp) {
    if (!isValidIP(startIp)) {
      return "❌ Invalid start IP - each number must be between 0-255";
    }
    if (!isValidIP(endIp)) {
      return "❌ Invalid end IP - each number must be between 0-255";
    }
    if (parseIP(startIp) > parseIP(endIp)) {
      return "❌ Start IP must be lower than End IP";
    }
    if (calculateRange(startIp, endIp) < 2) {
      return "❌ Range too small - you need at least 2 addresses for 2 PCs";
    }
  }
  if (placedItems.length === 0) {
    return "Drag a PC from inventory to any slot to start";
  }
  if (pcCount === 1 && !router) {
    return "Add the second PC to another slot";
  }
  if (pcCount === 2 && !router) {
    return "Place the router in the middle slot to connect both PCs";
  }
  if (router && pcCount === 2 && connections.length === 0) {
    return "Connect PC-1 to the router using a cable";
  }
  if (connections.length === 1 && connectedPcIds.size === 1) {
    const connectedPcId = Array.from(connectedPcIds)[0];
    const otherPc = connectedPcId === "pc-1" ? "PC-2" : "PC-1";
    return `Connect ${otherPc} to the router with the second cable`;
  }
  if (connections.length === 2 && connectedPcIds.size === 2 && !routerSettingsOpen && !routerConfigured) {
    return "⚠️ Physically connected but not working! Click the router to configure DHCP";
  }
  if (routerSettingsOpen && !dhcpEnabled) {
    return "Enable DHCP so the router can assign IP addresses";
  }
  if (routerSettingsOpen && dhcpEnabled && !startIp) {
    return "Set the start IP address (e.g., 192.168.1.100)";
  }
  if (routerSettingsOpen && dhcpEnabled && startIp && !endIp) {
    return "Set the end IP address (e.g., 192.168.1.200)";
  }
  if (routerSettingsOpen && dhcpEnabled && startIp && endIp && !routerConfigured) {
    return "Click 'Save' to activate DHCP";
  }
  if (routerConfigured && pc1HasIp && pc2HasIp) {
    return "🎉 Network configured! Both PCs can now communicate";
  }
  if (router && !placedItems.find((item) => item.type === "router" && item.blockX === 2) && connections.length === 0) {
    return "💡 Tip: Put the router in the center slot for easier connections";
  }
  return "";
};
const INVENTORY_TOOLTIPS = {
  cable: {
    content: "Ethernet cables connect devices in a network, enabling data transfer between computers and routers.",
    seeMoreHref: "https://www.google.com/search?q=what+is+ethernet+cable"
  },
  router: {
    content: "A router connects multiple devices in a network and directs traffic between them.",
    seeMoreHref: "https://www.google.com/search?q=what+is+a+router"
  }
};
const getNetworkingItemLabel = (itemType) => {
  switch (itemType) {
    case "pc":
      return "PC";
    case "router":
      return "Router";
    case "cable":
      return "Cable";
    default:
      return itemType.charAt(0).toUpperCase() + itemType.slice(1);
  }
};
const getNetworkingStatusMessage = (placedItem) => {
  if (placedItem.type === "router") {
    if (placedItem.status === "warning") {
      return "needs configuration";
    }
    if (placedItem.status === "success") {
      return "configured";
    }
    return null;
  }
  if (placedItem.type === "pc") {
    const ip = typeof placedItem.data?.ip === "string" ? placedItem.data.ip : null;
    if (ip) {
      return ip;
    }
    if (placedItem.status === "warning") {
      return "no ip";
    }
    return null;
  }
  return null;
};
const validateIpAddress = (input) => {
  if (!input) {
    return null;
  }
  const ipPattern = /^(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})$/;
  const match = input.match(ipPattern);
  if (!match) {
    return "Invalid format. Use 192.168.1.100";
  }
  const octets = [match[1], match[2], match[3], match[4]].map(
    (s) => Number.parseInt(s, 10)
  );
  if (octets.some((n) => n < 0 || n > 255)) {
    return "Each number must be 0-255.";
  }
  if (!PRIVATE_IP_RANGES.some((range) => range.test(input))) {
    return "Use a private IP range.";
  }
  return null;
};
const validateEndIp = (input, allValues) => {
  const baseError = validateIpAddress(input);
  if (baseError) {
    return baseError;
  }
  const startIp = allValues.startIp;
  if (!startIp || !input) {
    return null;
  }
  const parseIp = (ip) => {
    const parts = ip.split(".").map((p) => Number.parseInt(p, 10));
    return (parts[0] << 24 >>> 0) + (parts[1] << 16) + (parts[2] << 8) + parts[3];
  };
  const startNum = parseIp(startIp);
  const endNum = parseIp(input);
  if (endNum < startNum) {
    return "End IP must be greater than start IP.";
  }
  if (endNum - startNum + 1 < 2) {
    return "Range must have at least 2 addresses.";
  }
  return null;
};
const buildRouterConfigModal = (deviceId, currentConfig) => ({
  id: `router-config-${deviceId}`,
  title: "Router configuration",
  content: [
    {
      kind: "field",
      field: {
        id: "dhcpEnabled",
        kind: "checkbox",
        label: "Enable DHCP",
        defaultValue: typeof currentConfig.dhcpEnabled === "boolean" ? currentConfig.dhcpEnabled : false,
        helpLink: {
          label: "What is DHCP?",
          href: "https://www.google.com/search?q=what+is+DHCP"
        }
      }
    },
    {
      kind: "field",
      field: {
        id: "startIp",
        kind: "text",
        label: "Start IP",
        placeholder: "192.168.1.100",
        defaultValue: typeof currentConfig.startIp === "string" ? currentConfig.startIp : "",
        validate: validateIpAddress
      }
    },
    {
      kind: "field",
      field: {
        id: "endIp",
        kind: "text",
        label: "End IP",
        placeholder: "192.168.1.200",
        defaultValue: typeof currentConfig.endIp === "string" ? currentConfig.endIp : "",
        validate: validateEndIp
      }
    }
  ],
  actions: [
    {
      id: "cancel",
      label: "Cancel",
      variant: "ghost",
      closesModal: true,
      validate: false
    },
    {
      id: "save",
      label: "Save",
      variant: "primary",
      async onClick({ values, dispatch }) {
        const dhcpEnabled = !!values.dhcpEnabled;
        const startIp = String(values.startIp ?? "");
        const endIp = String(values.endIp ?? "");
        dispatch({
          type: "CONFIGURE_DEVICE",
          payload: {
            deviceId,
            config: { dhcpEnabled, startIp, endIp }
          }
        });
      }
    }
  ]
});
const buildPcConfigModal = (deviceId, currentConfig) => {
  const ip = typeof currentConfig.ip === "string" ? currentConfig.ip : "Not assigned";
  return {
    id: `pc-config-${deviceId}`,
    title: "PC configuration",
    content: [
      {
        kind: "field",
        field: {
          id: "ip",
          kind: "readonly",
          label: "IP Address",
          value: ip
        }
      }
    ],
    actions: [
      {
        id: "close",
        label: "Close",
        variant: "primary",
        closesModal: true,
        validate: false
      }
    ]
  };
};
const buildSuccessModal = (title, message, actionLabel, onAction) => ({
  id: "success",
  title,
  content: [
    {
      kind: "text",
      text: message
    }
  ],
  actions: [
    {
      id: "primary",
      label: actionLabel,
      variant: "primary",
      validate: false,
      closesModal: true,
      onClick: onAction ? () => onAction() : void 0
    }
  ]
});
const isValidIp = (ip) => {
  const parts = ip.split(".");
  if (parts.length !== 4) return false;
  return parts.every((part) => {
    const num = Number.parseInt(part, 10);
    return !Number.isNaN(num) && num >= 0 && num <= 255 && part === String(num);
  });
};
const isPrivateIp = (ip) => {
  return PRIVATE_IP_RANGES.some((range) => range.test(ip));
};
const parseIpRangeBase = (startIp) => {
  if (!startIp || !isValidIp(startIp) || !isPrivateIp(startIp)) {
    return null;
  }
  const octets = startIp.split(".").map((value) => Number.parseInt(value, 10));
  return `${octets[0]}.${octets[1]}.${octets[2]}`;
};
const buildNetworkSnapshot = (placedItems, connections) => {
  const byCoord = /* @__PURE__ */ new Map();
  placedItems.forEach((item) => {
    byCoord.set(`${item.blockX}-${item.blockY}`, item);
  });
  const router = placedItems.find((item) => item.type === "router");
  const pc1 = placedItems.find((item) => item.id === "pc-1");
  const pc2 = placedItems.find((item) => item.id === "pc-2");
  const cables = placedItems.filter((item) => item.type === "cable");
  const connectedPcIds = /* @__PURE__ */ new Set();
  const connectedCableIds = /* @__PURE__ */ new Set();
  cables.forEach((cable) => {
    const left = byCoord.get(`${cable.blockX - 1}-${cable.blockY}`);
    const right = byCoord.get(`${cable.blockX + 1}-${cable.blockY}`);
    const up = byCoord.get(`${cable.blockX}-${cable.blockY - 1}`);
    const down = byCoord.get(`${cable.blockX}-${cable.blockY + 1}`);
    const neighbors = [left, right, up, down].filter(Boolean);
    const hasRouter = neighbors.some((n) => n.type === "router");
    const hasPc = neighbors.some((n) => n.type === "pc");
    if (hasRouter && hasPc) {
      connectedCableIds.add(cable.id);
      for (const pc of neighbors.filter((n) => n.type === "pc")) {
        connectedPcIds.add(pc.id);
      }
    }
  });
  if (router) {
    connections.forEach((connection) => {
      const from = byCoord.get(`${connection.from.x}-${connection.from.y}`);
      const to = byCoord.get(`${connection.to.x}-${connection.to.y}`);
      if (!from || !to) {
        return;
      }
      if (from.id === router.id && to.type === "pc") {
        connectedPcIds.add(to.id);
      }
      if (to.id === router.id && from.type === "pc") {
        connectedPcIds.add(from.id);
      }
    });
  }
  return { router, pc1, pc2, cables, connectedPcIds, connectedCableIds };
};
const useNetworkState = ({ dragEngine }) => {
  const state = useGameState();
  const dispatch = useGameDispatch();
  const network = reactExports.useMemo(
    () => buildNetworkSnapshot(state.canvas.placedItems, state.canvas.connections),
    [state.canvas.connections, state.canvas.placedItems]
  );
  const routerConfig = network.router?.data ?? {};
  const dhcpEnabled = routerConfig.dhcpEnabled === true;
  const startIp = typeof routerConfig.startIp === "string" ? routerConfig.startIp : null;
  const endIp = typeof routerConfig.endIp === "string" ? routerConfig.endIp : null;
  const hasValidIpRange = startIp !== null && endIp !== null && isValidIp(startIp) && isValidIp(endIp) && isPrivateIp(startIp) && isPrivateIp(endIp);
  const ipBase = dhcpEnabled && hasValidIpRange ? parseIpRangeBase(startIp) : null;
  const routerConfigured = Boolean(ipBase && dhcpEnabled && hasValidIpRange);
  const pc1Connected = Boolean(
    network.pc1 && network.connectedPcIds.has("pc-1")
  );
  const pc2Connected = Boolean(
    network.pc2 && network.connectedPcIds.has("pc-2")
  );
  const pc1HasIp = typeof network.pc1?.data?.ip === "string";
  const pc2HasIp = typeof network.pc2?.data?.ip === "string";
  const pc2Ip = typeof network.pc2?.data?.ip === "string" ? network.pc2.data.ip : null;
  const routerSettingsOpen = state.overlay.activeModal?.id?.startsWith("router-config") ?? false;
  reactExports.useEffect(() => {
    if (state.question.status === "completed") {
      return;
    }
    const connectedPcs = [network.pc1, network.pc2].filter(
      (pc) => Boolean(pc && network.connectedPcIds.has(pc.id))
    );
    const desiredIps = /* @__PURE__ */ new Map();
    if (routerConfigured && startIp) {
      const startOctets = startIp.split(".").map((s) => Number.parseInt(s, 10));
      const baseOctets = startOctets.slice(0, 3);
      const startLastOctet = startOctets[3];
      const sorted = [...connectedPcs].sort((a, b) => a.id.localeCompare(b.id));
      sorted.forEach((pc, index) => {
        const assignedLastOctet = startLastOctet + index;
        if (assignedLastOctet <= 255) {
          desiredIps.set(pc.id, `${baseOctets.join(".")}.${assignedLastOctet}`);
        }
      });
    }
    if (network.router) {
      const desiredRouterStatus = routerConfigured ? "success" : "warning";
      if (network.router.status !== desiredRouterStatus) {
        dispatch({
          type: "CONFIGURE_DEVICE",
          payload: {
            deviceId: network.router.id,
            config: {
              status: desiredRouterStatus
            }
          }
        });
      }
    }
    network.cables.forEach((cable) => {
      const isConnected = network.connectedCableIds.has(cable.id);
      const desiredStatus = isConnected ? "success" : "warning";
      if (cable.status !== desiredStatus) {
        dispatch({
          type: "CONFIGURE_DEVICE",
          payload: {
            deviceId: cable.id,
            config: {
              status: desiredStatus
            }
          }
        });
      }
    });
    [network.pc1, network.pc2].forEach((pc) => {
      if (!pc) {
        return;
      }
      const shouldHaveIp = routerConfigured && network.connectedPcIds.has(pc.id);
      const desiredIp = shouldHaveIp ? desiredIps.get(pc.id) ?? null : null;
      const currentIp = typeof pc.data?.ip === "string" ? pc.data.ip : null;
      const desiredStatus = desiredIp ? "success" : "warning";
      if (currentIp !== desiredIp || pc.status !== desiredStatus) {
        dispatch({
          type: "CONFIGURE_DEVICE",
          payload: {
            deviceId: pc.id,
            config: {
              ip: desiredIp,
              status: desiredStatus
            }
          }
        });
      }
    });
  }, [
    dispatch,
    startIp,
    network.cables,
    network.connectedCableIds,
    network.connectedPcIds,
    network.pc1,
    network.pc2,
    network.router,
    routerConfigured,
    state.question.status
  ]);
  reactExports.useEffect(() => {
    if (!dragEngine) return;
    if (state.question.status === "completed") return;
    if (dragEngine.progress.status === "pending" && network.router && network.connectedPcIds.size > 0) {
      dragEngine.start();
    }
    if (dragEngine.progress.status !== "finished" && network.router && pc1HasIp && pc2HasIp) {
      dragEngine.finish();
    }
  }, [
    dragEngine,
    network.router,
    network.connectedPcIds,
    pc1HasIp,
    pc2HasIp,
    state.question.status
  ]);
  return {
    network,
    routerConfig,
    dhcpEnabled,
    startIp,
    endIp,
    ipBase,
    routerConfigured,
    routerSettingsOpen,
    pc1Connected,
    pc2Connected,
    pc1HasIp,
    pc2HasIp,
    pc2Ip,
    placedItems: state.canvas.placedItems,
    connections: state.canvas.connections,
    dragProgress: dragEngine?.progress ?? { status: "pending" }
  };
};
const useNetworkingTerminal = ({
  pc2Ip,
  onQuestionComplete
}) => {
  const dispatch = useGameDispatch();
  const state = useGameState();
  const handleCommand = reactExports.useCallback(
    (input, helpers) => {
      if (state.question.status === "completed") return;
      if (state.phase !== "terminal") {
        helpers.writeOutput("Error: Terminal is not ready yet.", "error");
        return;
      }
      const normalized = input.trim().toLowerCase();
      const parts = normalized.split(/\s+/);
      if (parts[0] !== "ping") {
        helpers.writeOutput("Error: Unknown command.", "error");
        return;
      }
      if (parts.length < 2) {
        helpers.writeOutput("Error: Missing target.", "error");
        return;
      }
      const target = parts[1];
      const isValidTarget = target === "pc-2" || pc2Ip && target === pc2Ip;
      if (isValidTarget && pc2Ip) {
        helpers.writeOutput(
          `Reply from ${pc2Ip}: bytes=32 time<1ms TTL=64`,
          "output"
        );
        dispatch({
          type: "OPEN_MODAL",
          payload: buildSuccessModal(
            "Question complete",
            "You connected two computers and verified their connection using ping.",
            "Next question",
            onQuestionComplete
          )
        });
        helpers.finishEngine();
        dispatch({ type: "COMPLETE_QUESTION" });
        return;
      }
      helpers.writeOutput(`Error: Unknown target "${target}".`, "error");
    },
    [dispatch, onQuestionComplete, pc2Ip, state.phase, state.question.status]
  );
  return handleCommand;
};
const DHCP_SPEC_BASE = {
  meta: {
    id: QUESTION_ID,
    title: QUESTION_TITLE,
    description: QUESTION_DESCRIPTION
  },
  init: {
    kind: "multi",
    payload: {
      questionId: QUESTION_ID,
      canvases: { [CANVAS_CONFIG.id]: CANVAS_CONFIG },
      inventoryGroups: INVENTORY_GROUPS,
      terminal: {
        visible: false,
        prompt: TERMINAL_PROMPT,
        history: TERMINAL_INTRO_ENTRIES
      },
      phase: "setup",
      questionStatus: "in_progress"
    }
  },
  phaseRules: [
    {
      kind: "set",
      when: { kind: "eq", key: "questionStatus", value: "completed" },
      to: "completed"
    },
    {
      kind: "set",
      when: { kind: "eq", key: "dragStatus", value: "finished" },
      to: "terminal"
    },
    {
      kind: "set",
      when: { kind: "eq", key: "dragStatus", value: "started" },
      to: "playing"
    }
  ],
  labels: {
    getItemLabel: getNetworkingItemLabel,
    getStatusMessage: getNetworkingStatusMessage
  }
};
const DhcpQuestion = ({ onQuestionComplete }) => {
  return /* @__PURE__ */ jsxRuntimeExports.jsx(GameProvider, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(NetworkingGame, { onQuestionComplete }) });
};
const NetworkingGame = ({
  onQuestionComplete
}) => {
  const dispatch = useGameDispatch();
  const state = useGameState();
  const initializedRef = reactExports.useRef(false);
  const terminalInput = useTerminalInput();
  const isCompleted = state.question.status === "completed";
  const dragEngine = useDragEngine();
  const networkState = useNetworkState({ dragEngine });
  const handleNetworkingCommand = useNetworkingTerminal({
    pc2Ip: networkState.pc2Ip,
    onQuestionComplete
  });
  useTerminalEngine({
    onCommand: handleNetworkingCommand
  });
  const itemClickHandlers = reactExports.useMemo(
    () => ({
      router: ({ item }) => {
        const placedItem = state.canvas.placedItems.find(
          (entry) => entry.id === item.id
        );
        const currentConfig = placedItem?.data ?? {};
        dispatch({
          type: "OPEN_MODAL",
          payload: buildRouterConfigModal(item.id, currentConfig)
        });
      },
      pc: ({ item }) => {
        const placedItem = state.canvas.placedItems.find(
          (entry) => entry.id === item.id
        );
        const currentConfig = placedItem?.data ?? {};
        dispatch({
          type: "OPEN_MODAL",
          payload: buildPcConfigModal(item.id, currentConfig)
        });
      }
    }),
    [dispatch, state.canvas.placedItems]
  );
  const spec = reactExports.useMemo(
    () => ({
      ...DHCP_SPEC_BASE,
      handlers: {
        onCommand: handleNetworkingCommand,
        onItemClickByType: itemClickHandlers,
        isItemClickableByType: { router: true, pc: true }
      }
    }),
    [handleNetworkingCommand, itemClickHandlers]
  );
  reactExports.useEffect(() => {
    if (initializedRef.current) {
      return;
    }
    initializedRef.current = true;
    dispatch({
      type: "INIT_MULTI_CANVAS",
      payload: spec.init.payload
    });
  }, [dispatch, spec.init.payload]);
  reactExports.useEffect(() => {
    const context = {
      dragStatus: dragEngine.progress.status,
      questionStatus: state.question.status
    };
    const resolved = resolvePhase(
      spec.phaseRules,
      context,
      state.phase,
      "setup"
    );
    if (state.phase !== resolved.nextPhase) {
      dispatch({ type: "SET_PHASE", payload: { phase: resolved.nextPhase } });
    }
  }, [
    dispatch,
    dragEngine.progress.status,
    spec.phaseRules,
    state.phase,
    state.question.status
  ]);
  const contextualHint = reactExports.useMemo(
    () => getContextualHint({
      placedItems: networkState.placedItems,
      connections: networkState.connections,
      router: networkState.network.router,
      pc1: networkState.network.pc1,
      pc2: networkState.network.pc2,
      connectedPcIds: networkState.network.connectedPcIds,
      routerConfigured: networkState.routerConfigured,
      dhcpEnabled: networkState.dhcpEnabled,
      startIp: networkState.startIp,
      endIp: networkState.endIp,
      routerSettingsOpen: networkState.routerSettingsOpen,
      pc1HasIp: networkState.pc1HasIp,
      pc2HasIp: networkState.pc2HasIp
    }),
    [
      networkState.placedItems,
      networkState.connections,
      networkState.network.router,
      networkState.network.pc1,
      networkState.network.pc2,
      networkState.network.connectedPcIds,
      networkState.routerConfigured,
      networkState.dhcpEnabled,
      networkState.startIp,
      networkState.endIp,
      networkState.routerSettingsOpen,
      networkState.pc1HasIp,
      networkState.pc2HasIp
    ]
  );
  const handlePlacedItemClick = reactExports.useCallback(
    (item) => {
      const handler = spec.handlers.onItemClickByType[item.type];
      if (handler) {
        handler({ item });
      }
    },
    [spec.handlers.onItemClickByType]
  );
  const isItemClickable = reactExports.useCallback(
    (item) => spec.handlers.isItemClickableByType[item.type] === true,
    [spec.handlers.isItemClickableByType]
  );
  return /* @__PURE__ */ jsxRuntimeExports.jsx(GameShell, { getItemLabel: spec.labels.getItemLabel, children: /* @__PURE__ */ jsxRuntimeExports.jsxs(
    Flex,
    {
      direction: "column",
      px: { base: 4, md: 12, lg: 24 },
      py: { base: 4, md: 6 },
      children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs(Box, { textAlign: "left", mb: 4, children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            Text,
            {
              fontSize: { base: "2xl", md: "4xl" },
              fontWeight: "bold",
              color: "gray.50",
              children: QUESTION_TITLE
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsx(Text, { fontSize: { base: "sm", md: "md" }, color: "gray.400", children: QUESTION_DESCRIPTION })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(Box, { flex: "1", children: /* @__PURE__ */ jsxRuntimeExports.jsx(
          PlayCanvas,
          {
            getItemLabel: spec.labels.getItemLabel,
            getStatusMessage: spec.labels.getStatusMessage,
            onPlacedItemClick: handlePlacedItemClick,
            isItemClickable
          }
        ) }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(InventoryDrawer, { tooltips: INVENTORY_TOOLTIPS }),
        contextualHint && /* @__PURE__ */ jsxRuntimeExports.jsx(
          Box,
          {
            bg: "gray.800",
            border: "1px solid",
            borderColor: "gray.700",
            borderRadius: "md",
            px: 4,
            py: 2,
            textAlign: "center",
            mb: 4,
            children: /* @__PURE__ */ jsxRuntimeExports.jsx(Text, { fontSize: "sm", color: "gray.100", children: contextualHint })
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          TerminalLayout,
          {
            visible: state.terminal.visible,
            focusRef: terminalInput.inputRef,
            view: /* @__PURE__ */ jsxRuntimeExports.jsx(
              TerminalView,
              {
                history: state.terminal.history,
                prompt: state.terminal.prompt,
                isCompleted
              }
            ),
            input: /* @__PURE__ */ jsxRuntimeExports.jsx(
              TerminalInput,
              {
                value: terminalInput.value,
                onChange: terminalInput.onChange,
                onKeyDown: terminalInput.onKeyDown,
                inputRef: terminalInput.inputRef,
                placeholder: isCompleted ? "Terminal disabled" : "Type a command",
                disabled: isCompleted
              }
            )
          }
        )
      ]
    }
  ) });
};
const DhcpQuestionRoute = () => {
  const navigate = useNavigate();
  const handleQuestionComplete = () => {
    markNetworkingQuestionComplete("dhcp");
    const nextPath = getNextQuestionPath("dhcp");
    void navigate({
      to: nextPath ?? "/questions/networking"
    });
  };
  return /* @__PURE__ */ jsxRuntimeExports.jsx(DhcpQuestion, { onQuestionComplete: handleQuestionComplete });
};
export {
  DhcpQuestionRoute as component
};
