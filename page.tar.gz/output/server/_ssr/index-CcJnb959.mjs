import { j as jsxRuntimeExports, r as reactExports } from "../_libs/react.mjs";
import { d as useNavigate } from "../_libs/@tanstack/react-router.mjs";
import { G as GameProvider, u as useGameDispatch, a as useGameState, b as useTerminalInput, c as useTerminalEngine, r as resolvePhase, e as GameShell, P as PlayCanvas, g as TerminalView, I as InventoryDrawer, T as TerminalLayout, f as TerminalInput, h as useAllCanvases } from "./question-ast-DxRXheAC.mjs";
import { m as markNetworkingQuestionComplete, b as getNextQuestionPath } from "./module-progress-CKDPPitT.mjs";
import { F as Flex, B as Box, T as Text } from "../_libs/@chakra-ui/react.mjs";
import "../_libs/@babel/runtime.mjs";
import "../_libs/tiny-warning.mjs";
import "../_libs/@tanstack/router-core.mjs";
import "../_libs/@tanstack/store.mjs";
import "../_libs/@tanstack/history.mjs";
import "../_libs/tiny-invariant.mjs";
import "node:stream/web";
import "node:stream";
import "../_libs/react-dom.mjs";
import "util";
import "crypto";
import "async_hooks";
import "stream";
import "../_libs/isbot.mjs";
import "../_libs/@tanstack/react-store.mjs";
import "../_libs/use-sync-external-store.mjs";
import "../_libs/gsap.mjs";
import "../_libs/@iconify/react.mjs";
import "../_libs/lucide-react.mjs";
import "../_libs/@ark-ui/react.mjs";
import "../_libs/@zag-js/carousel.mjs";
import "../_libs/@zag-js/anatomy.mjs";
import "../_libs/@zag-js/types.mjs";
import "../_libs/@zag-js/core.mjs";
import "../_libs/@zag-js/utils.mjs";
import "../_libs/@zag-js/dom-query.mjs";
import "../_libs/@zag-js/checkbox.mjs";
import "../_libs/@zag-js/focus-visible.mjs";
import "../_libs/@zag-js/react.mjs";
import "../_libs/@zag-js/color-picker.mjs";
import "../_libs/@zag-js/color-utils.mjs";
import "../_libs/@zag-js/popper.mjs";
import "../_libs/@floating-ui/dom.mjs";
import "../_libs/@floating-ui/core.mjs";
import "../_libs/@floating-ui/utils.mjs";
import "../_libs/@zag-js/dismissable.mjs";
import "../_libs/@zag-js/interact-outside.mjs";
import "../_libs/@zag-js/combobox.mjs";
import "../_libs/@zag-js/collection.mjs";
import "../_libs/@zag-js/auto-resize.mjs";
import "../_libs/@zag-js/listbox.mjs";
import "../_libs/@zag-js/radio-group.mjs";
import "../_libs/@zag-js/tooltip.mjs";
import "../_libs/@zag-js/presence.mjs";
import "../_libs/@pandacss/is-valid-prop.mjs";
import "../_libs/@zag-js/switch.mjs";
import "../_libs/@zag-js/splitter.mjs";
import "../_libs/@zag-js/slider.mjs";
import "../_libs/@zag-js/select.mjs";
import "../_libs/@zag-js/rating-group.mjs";
import "../_libs/@zag-js/popover.mjs";
import "../_libs/@zag-js/menu.mjs";
import "../_libs/@zag-js/rect-utils.mjs";
import "../_libs/@zag-js/file-upload.mjs";
import "../_libs/@zag-js/editable.mjs";
import "../_libs/@zag-js/dialog.mjs";
import "../_libs/@zag-js/accordion.mjs";
import "../_libs/@zag-js/clipboard.mjs";
import "../_libs/@zag-js/avatar.mjs";
import "../_libs/@zag-js/collapsible.mjs";
import "../_libs/@zag-js/hover-card.mjs";
import "../_libs/@zag-js/number-input.mjs";
import "../_libs/@internationalized/number.mjs";
import "../_libs/@zag-js/pin-input.mjs";
import "../_libs/@zag-js/progress.mjs";
import "../_libs/@zag-js/qr-code.mjs";
import "../_libs/@zag-js/scroll-area.mjs";
import "../_libs/@zag-js/tags-input.mjs";
import "../_libs/@zag-js/live-region.mjs";
import "../_libs/@zag-js/tree-view.mjs";
import "../_libs/@emotion/is-prop-valid.mjs";
import "../_libs/@emotion/memoize.mjs";
import "../_libs/@emotion/serialize.mjs";
import "../_libs/@emotion/hash.mjs";
import "../_libs/@emotion/unitless.mjs";
import "../_libs/@emotion/use-insertion-effect-with-fallbacks.mjs";
import "../_libs/@emotion/utils.mjs";
import "../_libs/@emotion/react.mjs";
import "../_libs/@emotion/cache.mjs";
import "../_libs/@emotion/sheet.mjs";
import "../_libs/@emotion/weak-memoize.mjs";
import "../_libs/stylis.mjs";
const QUESTION_ID = "tcp-fragmentation";
const QUESTION_TITLE = "📄 Deliver message.txt";
const QUESTION_DESCRIPTION = "Large files must be split, ordered, and delivered reliably. Build the missing TCP pieces to get message.txt across.";
const TERMINAL_PROMPT = "Connection closed. Use the terminal to inspect the exchange.";
const CANVAS_ORDER = ["splitter", "internet", "server"];
const CANVAS_CONFIGS = {
  splitter: {
    id: "tcp-splitter",
    title: "Content Splitter",
    stateKey: "splitter",
    columns: 1,
    rows: 1,
    maxItems: 1
  },
  internet: {
    id: "tcp-internet",
    title: "Internet",
    stateKey: "internet",
    columns: 3,
    rows: 1,
    maxItems: 3
  },
  server: {
    id: "tcp-server",
    title: "Server",
    stateKey: "server",
    columns: 3,
    rows: 4,
    maxItems: 12
  }
};
const INVENTORY_GROUP_IDS = {
  files: "files",
  split: "split",
  tcpTools: "tcp-tools",
  received: "received"
};
const FILE_ITEM_ID = "message-file-1";
const NOTES_FILE_ITEM_ID = "notes-file-1";
const FILE_INVENTORY_ITEMS = [
  {
    id: FILE_ITEM_ID,
    type: "message-file",
    name: "message.txt",
    allowedPlaces: ["inventory", "internet", "splitter"],
    icon: { icon: "mdi:file-document-outline", color: "#93C5FD" },
    data: { tcpState: "ready" }
  }
];
const NOTES_FILE_ITEM = {
  id: NOTES_FILE_ITEM_ID,
  type: "notes-file",
  name: "notes.txt",
  allowedPlaces: ["inventory", "internet", "splitter"],
  icon: { icon: "mdi:file-document-outline", color: "#60A5FA" },
  data: { tcpState: "ready" }
};
const MESSAGE_PACKET_IDS = [
  "split-packet-1",
  "split-packet-2",
  "split-packet-3"
];
const NOTES_PACKET_IDS = [
  "notes-packet-1",
  "notes-packet-2",
  "notes-packet-3",
  "notes-packet-4",
  "notes-packet-5",
  "notes-packet-6"
];
const MESSAGE_PACKET_ITEMS = MESSAGE_PACKET_IDS.map(
  (packetId, index) => ({
    id: packetId,
    type: "split-packet",
    name: "Fragment",
    allowedPlaces: ["inventory", "internet", "server"],
    icon: { icon: "mdi:package-variant", color: "#A3A3A3" },
    data: {
      seq: index + 1,
      seqEnabled: false,
      tcpState: "idle",
      fileKey: "message"
    }
  })
);
const NOTES_PACKET_ITEMS = NOTES_PACKET_IDS.map(
  (packetId, index) => ({
    id: packetId,
    type: "split-packet",
    name: `Packet #${index + 1}`,
    allowedPlaces: ["inventory", "internet", "server"],
    icon: { icon: "mdi:package-variant", color: "#38BDF8" },
    data: {
      seq: index + 1,
      seqEnabled: true,
      tcpState: "idle",
      fileKey: "notes"
    }
  })
);
const TCP_TOOL_ITEMS = {
  syn: {
    id: "syn-flag-1",
    type: "syn-flag",
    name: "SYN",
    allowedPlaces: ["inventory", "internet", "server"],
    icon: { icon: "mdi:flag-outline", color: "#FBBF24" },
    data: { tcpState: "idle" }
  },
  ack: {
    id: "ack-flag-1",
    type: "ack-flag",
    name: "ACK",
    allowedPlaces: ["inventory", "internet", "server"],
    icon: { icon: "mdi:flag", color: "#10B981" },
    data: { tcpState: "idle" }
  },
  fin: {
    id: "fin-flag-1",
    type: "fin-flag",
    name: "FIN",
    allowedPlaces: ["inventory", "internet", "server"],
    icon: { icon: "mdi:flag-remove", color: "#F97316" },
    data: { tcpState: "idle" }
  }
};
const SYSTEM_PACKET_ITEMS = {
  synAck: {
    id: "syn-ack-flag-1",
    type: "syn-ack-flag",
    name: "SYN-ACK",
    allowedPlaces: ["inventory", "internet"],
    icon: { icon: "mdi:flag-checkered", color: "#F59E0B" },
    data: { tcpState: "idle" }
  },
  finAck: {
    id: "fin-ack-flag-1",
    type: "fin-ack-flag",
    name: "FIN-ACK",
    allowedPlaces: ["inventory", "internet"],
    icon: { icon: "mdi:flag-remove-outline", color: "#FB923C" },
    data: { tcpState: "idle" }
  }
};
const MTU_HELP_LINK = "https://en.wikipedia.org/wiki/Maximum_transmission_unit";
const getContextualHint = (state) => {
  const {
    phase,
    splitterVisible,
    connectionActive,
    sequenceEnabled,
    lossScenarioActive,
    receivedCount,
    waitingCount,
    connectionClosed
  } = state;
  if (phase === "mtu") {
    return "Drag message.txt to the Internet to send it.";
  }
  if (phase === "splitter" && splitterVisible) {
    return "The file is too big. Drop it onto the Content Splitter.";
  }
  if (phase === "split-send") {
    return "Send a fragment through the Internet and see how the server responds.";
  }
  if (phase === "syn") {
    return "The server rejected the fragment. Send a SYN to start the handshake.";
  }
  if (phase === "syn-wait") {
    return "SYN sent. Wait for the SYN-ACK response.";
  }
  if (phase === "ack") {
    return "SYN-ACK received. Send an ACK to complete the connection.";
  }
  if (phase === "connected" && !lossScenarioActive) {
    if (waitingCount > 0) {
      return "The server is waiting for the missing packet. Send it next.";
    }
    if (receivedCount === 0) {
      return "Send the numbered packets through the Internet.";
    }
    return "Try sending packets out of order to see them buffered for ordering.";
  }
  if (phase === "notes") {
    return "notes.txt is ready. Drop it onto the Content Splitter.";
  }
  if (phase === "loss") {
    return "Send the notes.txt packets through the Internet. Packet #2 will go missing.";
  }
  if (phase === "resend") {
    return "Duplicate ACKs detected. Resend the missing packet.";
  }
  if (phase === "closing" && !connectionClosed) {
    return "Send FIN to close the connection cleanly.";
  }
  if (phase === "terminal") {
    return "Use `tcpdump` in the terminal to inspect the exchange.";
  }
  if (!connectionActive && sequenceEnabled) {
    return "Connection lost. Re-establish before sending data.";
  }
  return "";
};
const INVENTORY_TOOLTIPS = {
  "message-file": {
    content: "A large file that must be split into smaller packets before it can travel across the network.",
    seeMoreHref: "https://en.wikipedia.org/wiki/Packet_(information_technology)"
  },
  "notes-file": {
    content: "Another file that needs to be split into packets before it can traverse the network.",
    seeMoreHref: "https://en.wikipedia.org/wiki/Packet_(information_technology)"
  },
  "split-packet": {
    content: "A fragment of the original file. It must be delivered in order to reassemble the message.",
    seeMoreHref: "https://en.wikipedia.org/wiki/Transmission_Control_Protocol#Reliable_delivery"
  },
  "syn-flag": {
    content: "SYN starts a TCP handshake to establish a connection.",
    seeMoreHref: "https://en.wikipedia.org/wiki/Transmission_Control_Protocol#Connection_establishment"
  },
  "ack-flag": {
    content: "ACK completes the handshake so data can flow.",
    seeMoreHref: "https://en.wikipedia.org/wiki/Transmission_Control_Protocol#Connection_establishment"
  },
  "fin-flag": {
    content: "FIN closes a TCP connection cleanly after data transfer.",
    seeMoreHref: "https://en.wikipedia.org/wiki/Transmission_Control_Protocol#Connection_termination"
  }
};
const packetStateMessages = {
  idle: { label: "Ready" },
  "in-transit": { label: "Sending..." },
  received: { label: "Received" },
  buffered: { label: "Buffered for ordering" },
  lost: { label: "Lost!" },
  processing: { label: "Processing..." },
  rejected: { label: "Rejected" }
};
const fileStateMessages = {
  ready: { label: "Ready" },
  rejected: { label: "Too large" }
};
const flagStateMessages = {
  idle: { label: "Ready" },
  "in-transit": { label: "Sending..." },
  received: { label: "Arrived" }
};
const getTcpItemLabel = (itemType) => {
  switch (itemType) {
    case "message-file":
      return "message.txt";
    case "notes-file":
      return "notes.txt";
    case "split-packet":
      return "Packet";
    case "syn-flag":
      return "SYN";
    case "syn-ack-flag":
      return "SYN-ACK";
    case "ack-flag":
      return "ACK";
    case "ack-packet":
      return "ACK";
    case "fin-flag":
      return "FIN";
    case "fin-ack-flag":
      return "FIN-ACK";
    default:
      return itemType.charAt(0).toUpperCase() + itemType.slice(1);
  }
};
const getTcpStatusMessage = (placedItem) => {
  const { type, data } = placedItem;
  const tcpState = typeof data?.tcpState === "string" ? data.tcpState : "idle";
  if (type === "message-file" || type === "notes-file") {
    const stateMessage = fileStateMessages[tcpState]?.label ?? "Ready";
    const fileLabel = type === "notes-file" ? "notes.txt" : "message.txt";
    return `${fileLabel} ${stateMessage}`;
  }
  if (type === "split-packet") {
    const seq = typeof data?.seq === "number" ? data.seq : void 0;
    const seqEnabled = data?.seqEnabled === true;
    const stateMessage = packetStateMessages[tcpState]?.label ?? "Ready";
    if (seqEnabled && typeof seq === "number") {
      return `Packet #${seq} ${stateMessage}`;
    }
    return stateMessage;
  }
  if (type === "ack-packet") {
    const ack = typeof data?.ack === "number" ? data.ack : void 0;
    const stateMessage = flagStateMessages[tcpState]?.label ?? "Arrived";
    return ack ? `ACK ${ack} ${stateMessage}` : `ACK ${stateMessage}`;
  }
  if (type === "syn-ack-flag" && data?.direction === "server-to-client" && tcpState === "in-transit") {
    return "Receiving";
  }
  if (type === "syn-flag" || type === "syn-ack-flag" || type === "ack-flag" || type === "fin-flag" || type === "fin-ack-flag") {
    return flagStateMessages[tcpState]?.label ?? "Ready";
  }
  return null;
};
const closeAction = () => ({
  id: "close",
  label: "Close",
  variant: "primary",
  closesModal: true,
  validate: false
});
const buildText = (text) => ({
  kind: "text",
  text
});
const buildLink = (text, href) => ({
  kind: "link",
  text,
  href
});
const buildMtuModal = () => ({
  id: "mtu-limit",
  title: "🚧 MTU Limit Reached",
  content: [
    buildText(
      "message.txt is too large to fit in a single network packet."
    ),
    buildText(
      "Networks enforce an MTU (Maximum Transmission Unit) which caps packet size."
    ),
    buildText("We need to split the file before it can travel."),
    buildLink("What is MTU?", MTU_HELP_LINK)
  ],
  actions: [closeAction()]
});
const buildSynIntroModal = () => ({
  id: "syn-intro",
  title: "🟡 Start the Handshake (SYN)",
  content: [
    buildText(
      "The server rejected the fragments because no TCP connection exists yet."
    ),
    buildText(
      "Send a SYN to request a connection and sync a starting sequence number."
    ),
    buildText("If the server agrees, it responds with SYN-ACK.")
  ],
  actions: [closeAction()]
});
const buildSynAckModal = (onContinue) => ({
  id: "syn-ack-received",
  title: "✅ SYN-ACK Received",
  content: [
    buildText(
      "The server accepted your SYN and replied with SYN-ACK."
    ),
    buildText(
      "That means it is ready and has shared its own sequence number."
    )
  ],
  actions: [
    {
      id: "continue",
      label: "OK",
      variant: "primary",
      validate: false,
      closesModal: !onContinue,
      onClick: onContinue ? () => onContinue() : void 0
    }
  ]
});
const buildAckIntroModal = () => ({
  id: "ack-intro",
  title: "✅ Send ACK",
  content: [
    buildText(
      "ACK confirms the server's SYN-ACK and completes the handshake."
    ),
    buildText("Send the ACK so the connection opens and data can flow.")
  ],
  actions: [
    {
      id: "ack",
      label: "Send ACK",
      variant: "primary",
      validate: false,
      closesModal: true
    }
  ]
});
const buildHandshakeCompleteModal = () => ({
  id: "handshake-complete",
  title: "🔗 Connection Established",
  content: [
    buildText(
      "Connection established! During the handshake, both sides agreed on a starting sequence number."
    ),
    buildText(
      "Now your packets will be numbered so the server can order and verify them."
    )
  ],
  actions: [closeAction()]
});
const buildHolBlockingModal = () => ({
  id: "hol-blocking",
  title: "⏳ Head-of-Line Blocking",
  content: [
    buildText(
      "That packet arrived out of order. The server won't reject it."
    ),
    buildText(
      "It buffers the packet, waits for the missing one, then reorders the stream to rebuild the file."
    )
  ],
  actions: [closeAction()]
});
const buildPacketLossModal = () => ({
  id: "packet-loss",
  title: "💨 Packets Lost",
  content: [
    buildText(
      "Packet #2 vanished in the internet. Real networks can be unreliable, so packets sometimes disappear."
    ),
    buildText("The server is waiting for the missing packet.")
  ],
  actions: [closeAction()]
});
const buildDuplicateAckModal = (missingSeq) => ({
  id: "duplicate-acks",
  title: "🔁 Duplicate ACKs",
  content: [
    buildText(
      `The server keeps repeating ACK ${missingSeq}. It still needs packet #${missingSeq}.`
    ),
    buildText(
      `Three duplicate ACKs signal loss, so resend packet #${missingSeq} now.`
    )
  ],
  actions: [closeAction()]
});
const buildCloseConnectionModal = () => ({
  id: "close-connection",
  title: "👋 Close the Connection",
  content: [
    buildText(
      "The transfer is complete. Send FIN so both sides can close the connection cleanly."
    )
  ],
  actions: [closeAction()]
});
const buildSuccessModal = (onQuestionComplete) => ({
  id: "tcp-success",
  title: "✅ Delivery Complete",
  content: [
    buildText("You handled MTU limits, ordering, loss, and the handshake."),
    buildText("TCP turned unreliable delivery into a reliable stream.")
  ],
  actions: [
    {
      id: "primary",
      label: "Next question",
      variant: "primary",
      validate: false,
      closesModal: true,
      onClick: onQuestionComplete ? () => onQuestionComplete() : void 0
    }
  ]
});
const INTERNET_TRAVEL_MS = 2e3;
const SERVER_PROCESS_MS = 3e3;
const SERVER_REJECT_DELAY_MS = 2e3;
const MESSAGE_REJECT_DELAY_MS = 2e3;
const ASSEMBLE_DELAY_MS = 2e3;
const BUFFER_RELEASE_DELAY_MS = 4e3;
const BUFFER_STEP_DELAY_MS = 2e3;
const LOSS_FADE_MS = 700;
const MESSAGE_SEQUENCES = [1, 2, 3];
const NOTES_SEQUENCES = [1, 2, 3, 4, 5, 6];
const LOSS_PACKET_SEQ = 2;
const getSeq = (item) => typeof item.data?.seq === "number" ? item.data.seq : void 0;
const getFileKey = (data) => data?.fileKey === "notes" ? "notes" : "message";
const getPacketColor = (fileKey, seqEnabled) => {
  if (fileKey === "notes") {
    return seqEnabled ? "#38BDF8" : "#60A5FA";
  }
  return seqEnabled ? "#FACC15" : "#A3A3A3";
};
const formatPacketList = (seqs) => {
  if (seqs.length === 0) return "";
  if (seqs.length === 1) {
    return `packet #${seqs[0]}`;
  }
  const sorted = [...seqs].sort((a, b) => a - b);
  const isRange = sorted[sorted.length - 1] - sorted[0] + 1 === sorted.length;
  if (isRange) {
    return `packets #${sorted[0]}-${sorted[sorted.length - 1]}`;
  }
  return `packets ${sorted.map((seq) => `#${seq}`).join(", ")}`;
};
const useTcpState = () => {
  const state = useGameState();
  const canvases = useAllCanvases();
  const dispatch = useGameDispatch();
  const [phase, setPhase] = reactExports.useState("mtu");
  const [splitterVisible, setSplitterVisible] = reactExports.useState(false);
  const [serverStatus, setServerStatus] = reactExports.useState("🔴 Disconnected");
  const [connectionActive, setConnectionActive] = reactExports.useState(false);
  const [connectionClosed, setConnectionClosed] = reactExports.useState(false);
  const [sequenceEnabled, setSequenceEnabled] = reactExports.useState(false);
  const [lossScenarioActive, setLossScenarioActive] = reactExports.useState(false);
  const [receivedSeqs, setReceivedSeqs] = reactExports.useState([]);
  const [waitingSeqs, setWaitingSeqs] = reactExports.useState([]);
  const [serverLog, setServerLog] = reactExports.useState([]);
  const canvasesRef = reactExports.useRef(canvases);
  const connectionActiveRef = reactExports.useRef(false);
  const lossScenarioRef = reactExports.useRef(false);
  const bufferReleaseTimerRef = reactExports.useRef(
    null
  );
  const assembleActiveRef = reactExports.useRef(false);
  const timersRef = reactExports.useRef(/* @__PURE__ */ new Set());
  const receivedSeqsRef = reactExports.useRef(/* @__PURE__ */ new Set());
  const waitingSeqsRef = reactExports.useRef(/* @__PURE__ */ new Set());
  const serverLogSequenceRef = reactExports.useRef(0);
  const lastAckNumberRef = reactExports.useRef(null);
  const duplicateAckCountRef = reactExports.useRef(0);
  const allowPacket2Ref = reactExports.useRef(false);
  const duplicateAckModalSeqRef = reactExports.useRef(null);
  const resendTargetSeqRef = reactExports.useRef(null);
  const modalShownRef = reactExports.useRef({
    mtu: false,
    synIntro: false,
    synAck: false,
    ackIntro: false,
    handshake: false,
    holBlocking: false,
    packetLoss: false,
    closeConnection: false
  });
  reactExports.useEffect(() => {
    canvasesRef.current = canvases;
  }, [canvases]);
  reactExports.useEffect(() => {
    connectionActiveRef.current = connectionActive;
  }, [connectionActive]);
  reactExports.useEffect(() => {
    lossScenarioRef.current = lossScenarioActive;
  }, [lossScenarioActive]);
  const registerTimer = reactExports.useCallback((timerId) => {
    timersRef.current.add(timerId);
  }, []);
  reactExports.useEffect(() => {
    return () => {
      for (const timerId of Array.from(timersRef.current)) {
        clearTimeout(timerId);
      }
    };
  }, []);
  const getInventoryGroupItems = reactExports.useCallback(
    (id) => state.inventory.groups.find((group) => group.id === id)?.items ?? [],
    [state.inventory.groups]
  );
  const updateInventoryGroup = reactExports.useCallback(
    (id, updates) => {
      dispatch({
        type: "UPDATE_INVENTORY_GROUP",
        payload: { id, ...updates }
      });
    },
    [dispatch]
  );
  const ensureInventoryItems = reactExports.useCallback(
    (id, items, visible = true) => {
      const existing = getInventoryGroupItems(id);
      const map = new Map(existing.map((item) => [item.id, item]));
      for (const item of items) {
        map.set(item.id, item);
      }
      updateInventoryGroup(id, {
        visible,
        items: Array.from(map.values())
      });
    },
    [getInventoryGroupItems, updateInventoryGroup]
  );
  const updateSplitInventory = reactExports.useCallback(
    (updater) => {
      const items = getInventoryGroupItems(INVENTORY_GROUP_IDS.split);
      if (items.length === 0) return;
      updateInventoryGroup(INVENTORY_GROUP_IDS.split, {
        items: items.map(
          (item) => item.type === "split-packet" ? updater(item) : item
        )
      });
    },
    [getInventoryGroupItems, updateInventoryGroup]
  );
  const findItemLocationLatest = reactExports.useCallback((itemId) => {
    for (const [key, canvas] of Object.entries(canvasesRef.current)) {
      const item = canvas.placedItems.find((entry) => entry.id === itemId);
      if (item) return { stateKey: key, item };
    }
    return null;
  }, []);
  const findEmptyBlockLatest = reactExports.useCallback((stateKey) => {
    const canvas = canvasesRef.current[stateKey];
    if (!canvas) return null;
    for (let y = 0; y < canvas.blocks.length; y += 1) {
      for (let x = 0; x < canvas.blocks[y].length; x += 1) {
        if (canvas.blocks[y][x].status === "empty") {
          return { blockX: x, blockY: y };
        }
      }
    }
    return null;
  }, []);
  const removeItem = reactExports.useCallback(
    (item, stateKey) => {
      dispatch({
        type: "REMOVE_ITEM",
        payload: { stateKey, blockX: item.blockX, blockY: item.blockY }
      });
    },
    [dispatch]
  );
  const updateItemIfNeeded = reactExports.useCallback(
    (item, stateKey, updates) => {
      const nextStatus = typeof updates.status === "string" ? updates.status : item.status;
      const { status: _, ...dataUpdates } = updates;
      let needsUpdate = nextStatus !== item.status;
      for (const [key, value] of Object.entries(dataUpdates)) {
        if (item.data?.[key] !== value) {
          needsUpdate = true;
          break;
        }
      }
      if (!needsUpdate) return;
      dispatch({
        type: "CONFIGURE_DEVICE",
        payload: {
          deviceId: item.id,
          config: updates,
          stateKey
        }
      });
    },
    [dispatch]
  );
  const transferItemToCanvas = reactExports.useCallback(
    (itemId, targetCanvas) => {
      const location = findItemLocationLatest(itemId);
      if (!location) return false;
      if (location.stateKey === targetCanvas) return true;
      const target = findEmptyBlockLatest(targetCanvas);
      if (!target) return false;
      dispatch({
        type: "TRANSFER_ITEM",
        payload: {
          itemId,
          fromCanvas: location.stateKey,
          fromBlockX: location.item.blockX,
          fromBlockY: location.item.blockY,
          toCanvas: targetCanvas,
          toBlockX: target.blockX,
          toBlockY: target.blockY
        }
      });
      return true;
    },
    [dispatch, findEmptyBlockLatest, findItemLocationLatest]
  );
  const placeItemOnCanvas = reactExports.useCallback(
    (itemId, stateKey) => {
      const target = findEmptyBlockLatest(stateKey);
      if (!target) return false;
      dispatch({
        type: "PLACE_ITEM",
        payload: { itemId, stateKey, ...target }
      });
      return true;
    },
    [dispatch, findEmptyBlockLatest]
  );
  const syncBufferState = reactExports.useCallback(() => {
    setReceivedSeqs(Array.from(receivedSeqsRef.current).sort((a, b) => a - b));
    setWaitingSeqs(Array.from(waitingSeqsRef.current).sort((a, b) => a - b));
  }, []);
  const addReceivedItem = reactExports.useCallback(
    (item) => {
      ensureInventoryItems(INVENTORY_GROUP_IDS.received, [item], true);
    },
    [ensureInventoryItems]
  );
  const sendServerPacket = reactExports.useCallback(
    (item) => {
      addReceivedItem(item);
      placeItemOnCanvas(item.id, "internet");
    },
    [addReceivedItem, placeItemOnCanvas]
  );
  const appendServerLog = reactExports.useCallback((message) => {
    setServerLog((prev) => {
      const timestamp = Date.now();
      serverLogSequenceRef.current += 1;
      const entry = {
        id: `server-log-${serverLogSequenceRef.current}`,
        type: "output",
        content: message,
        timestamp
      };
      return [...prev, entry];
    });
  }, []);
  const updateServerStatus = reactExports.useCallback(
    (message) => {
      setServerStatus(message);
      appendServerLog(message);
    },
    [appendServerLog]
  );
  reactExports.useEffect(() => {
    if (serverLogSequenceRef.current === 0) {
      appendServerLog(serverStatus);
    }
  }, [appendServerLog, serverStatus]);
  const getActiveSequences = reactExports.useCallback(
    () => lossScenarioRef.current ? NOTES_SEQUENCES : MESSAGE_SEQUENCES,
    []
  );
  const buildAckServerMessage = reactExports.useCallback(() => {
    const sequences = getActiveSequences();
    const received = receivedSeqsRef.current;
    const waiting = waitingSeqsRef.current;
    const missing = [];
    const buffered = [];
    for (const seq of sequences) {
      if (received.has(seq)) {
        continue;
      }
      if (waiting.has(seq)) {
        buffered.push(seq);
      } else {
        missing.push(seq);
      }
    }
    const nextExpected = sequences.find((seq) => !received.has(seq)) ?? sequences[sequences.length - 1] + 1;
    if (missing.length === 0 && buffered.length === 0) {
      return {
        ackNumber: nextExpected,
        total: sequences.length,
        message: `Replying with ACK ${nextExpected}, all packets received.`
      };
    }
    const parts = [];
    if (missing.length > 0) {
      const missingLabel = formatPacketList(missing);
      parts.push(`${missingLabel} ${missing.length === 1 ? "is" : "are"} missing`);
    }
    if (buffered.length > 0) {
      const bufferedLabel = formatPacketList(buffered);
      parts.push(
        `${bufferedLabel} ${buffered.length === 1 ? "is" : "are"} buffered for ordering`
      );
    }
    return {
      ackNumber: nextExpected,
      total: sequences.length,
      message: `Replying with ACK ${nextExpected}, ${parts.join("; ")}.`
    };
  }, [getActiveSequences]);
  const resetBuffer = reactExports.useCallback(() => {
    receivedSeqsRef.current.clear();
    waitingSeqsRef.current.clear();
    syncBufferState();
  }, [syncBufferState]);
  const updateSplitPacketsForSequence = reactExports.useCallback(
    (targetFileKey) => {
      updateSplitInventory((item) => {
        const seq = typeof item.data?.seq === "number" ? item.data.seq : void 0;
        if (!seq) return item;
        const fileKey = getFileKey(item.data);
        if (targetFileKey && fileKey !== targetFileKey) {
          return item;
        }
        const nextIcon = item.icon ? {
          ...item.icon,
          color: getPacketColor(fileKey, true)
        } : {
          icon: "mdi:package-variant",
          color: getPacketColor(fileKey, true)
        };
        return {
          ...item,
          name: `Packet #${seq}`,
          icon: nextIcon,
          data: { ...item.data, seqEnabled: true }
        };
      });
    },
    [updateSplitInventory]
  );
  const highlightMissingPacket = reactExports.useCallback((targetSeq) => {
    updateSplitInventory((item) => {
      const seq = typeof item.data?.seq === "number" ? item.data.seq : void 0;
      if (!seq || getFileKey(item.data) !== "notes") return item;
      const isTarget = seq === targetSeq;
      const nextColor = isTarget ? "#F87171" : getPacketColor("notes", true);
      const nextIcon = item.icon ? { ...item.icon, color: nextColor } : { icon: "mdi:package-variant", color: nextColor };
      return {
        ...item,
        name: isTarget ? `Packet #${seq} (Resend?)` : `Packet #${seq}`,
        icon: nextIcon
      };
    });
  }, [updateSplitInventory]);
  const trackDuplicateAck = reactExports.useCallback(
    (ackNumber, total) => {
      if (!lossScenarioRef.current) return;
      if (ackNumber > total) {
        duplicateAckCountRef.current = 0;
        lastAckNumberRef.current = ackNumber;
        return;
      }
      if (lastAckNumberRef.current === ackNumber) {
        duplicateAckCountRef.current += 1;
      } else {
        duplicateAckCountRef.current = 0;
      }
      lastAckNumberRef.current = ackNumber;
      if (duplicateAckCountRef.current >= 3) {
        if (ackNumber === LOSS_PACKET_SEQ) {
          allowPacket2Ref.current = true;
        }
        resendTargetSeqRef.current = ackNumber;
        setPhase("resend");
        highlightMissingPacket(ackNumber);
        if (duplicateAckModalSeqRef.current !== ackNumber) {
          duplicateAckModalSeqRef.current = ackNumber;
          dispatch({
            type: "OPEN_MODAL",
            payload: buildDuplicateAckModal(ackNumber)
          });
        }
      }
    },
    [dispatch, highlightMissingPacket]
  );
  const clearResendHighlight = reactExports.useCallback(() => {
    updateSplitInventory((item) => {
      const seq = typeof item.data?.seq === "number" ? item.data.seq : void 0;
      if (!seq) return item;
      const fileKey = getFileKey(item.data);
      const nextIcon = item.icon ? { ...item.icon, color: getPacketColor(fileKey, true) } : {
        icon: "mdi:package-variant",
        color: getPacketColor(fileKey, true)
      };
      return {
        ...item,
        name: `Packet #${seq}`,
        icon: nextIcon
      };
    });
  }, [updateSplitInventory]);
  const handleServerReject = reactExports.useCallback(
    (item, stateKey) => {
      updateServerStatus("Processing...");
      updateItemIfNeeded(item, stateKey, {
        status: "warning",
        tcpState: "processing"
      });
      const processingTimer = setTimeout(() => {
        updateItemIfNeeded(item, stateKey, {
          status: "error",
          tcpState: "rejected"
        });
        updateServerStatus("I don't understand this package!");
        const rejectionTimer = setTimeout(() => {
          const location = findItemLocationLatest(item.id);
          if (location) {
            removeItem(location.item, location.stateKey);
          }
          updateServerStatus("🔴 Disconnected");
          if (phase === "split-send") {
            ensureInventoryItems(
              INVENTORY_GROUP_IDS.tcpTools,
              [TCP_TOOL_ITEMS.syn],
              true
            );
            setPhase("syn");
            if (!modalShownRef.current.synIntro) {
              modalShownRef.current.synIntro = true;
              dispatch({
                type: "OPEN_MODAL",
                payload: buildSynIntroModal()
              });
            }
          }
        }, SERVER_REJECT_DELAY_MS);
        registerTimer(rejectionTimer);
      }, SERVER_PROCESS_MS);
      registerTimer(processingTimer);
    },
    [
      dispatch,
      ensureInventoryItems,
      findItemLocationLatest,
      phase,
      registerTimer,
      removeItem,
      updateServerStatus,
      updateItemIfNeeded
    ]
  );
  const handleConnectionEstablished = reactExports.useCallback(() => {
    setConnectionActive(true);
    updateServerStatus("🟢 Connected - Waiting for data...");
    if (!modalShownRef.current.handshake) {
      modalShownRef.current.handshake = true;
      dispatch({
        type: "OPEN_MODAL",
        payload: buildHandshakeCompleteModal()
      });
    }
    setSequenceEnabled(true);
    updateSplitPacketsForSequence("message");
    setPhase("connected");
  }, [dispatch, updateServerStatus, updateSplitPacketsForSequence]);
  const handleAssembledMessage = reactExports.useCallback((delayMs = ASSEMBLE_DELAY_MS) => {
    if (assembleActiveRef.current) return;
    assembleActiveRef.current = true;
    updateServerStatus("Processing...");
    const assembleTimer = setTimeout(() => {
      const fileLabel = lossScenarioRef.current ? "notes.txt" : "message.txt";
      updateServerStatus(`📄 ${fileLabel} received successfully!`);
      if (!lossScenarioRef.current) {
        updateInventoryGroup(INVENTORY_GROUP_IDS.split, {
          visible: false,
          items: []
        });
        updateInventoryGroup(INVENTORY_GROUP_IDS.files, {
          visible: true,
          items: [NOTES_FILE_ITEM]
        });
        setLossScenarioActive(true);
        setPhase("notes");
        resetBuffer();
        duplicateAckCountRef.current = 0;
        lastAckNumberRef.current = null;
        allowPacket2Ref.current = false;
        duplicateAckModalSeqRef.current = null;
        resendTargetSeqRef.current = null;
        assembleActiveRef.current = false;
      } else {
        setPhase("closing");
        if (!modalShownRef.current.closeConnection) {
          modalShownRef.current.closeConnection = true;
          dispatch({
            type: "OPEN_MODAL",
            payload: buildCloseConnectionModal()
          });
        }
        ensureInventoryItems(INVENTORY_GROUP_IDS.tcpTools, [TCP_TOOL_ITEMS.fin], true);
      }
    }, delayMs);
    registerTimer(assembleTimer);
  }, [
    dispatch,
    ensureInventoryItems,
    registerTimer,
    resetBuffer,
    updateInventoryGroup,
    updateServerStatus
  ]);
  const handleAllPacketsReceived = reactExports.useCallback(
    (delayMs) => {
      if (lossScenarioRef.current) {
        clearResendHighlight();
      }
      handleAssembledMessage(delayMs);
    },
    [clearResendHighlight, handleAssembledMessage]
  );
  const releaseBufferedPackets = reactExports.useCallback(() => {
    const received = receivedSeqsRef.current;
    const waiting = waitingSeqsRef.current;
    const sequences = getActiveSequences();
    let nextSeq = sequences.find((value) => !received.has(value));
    if (nextSeq === void 0) {
      bufferReleaseTimerRef.current = null;
      return;
    }
    const fileKey = lossScenarioRef.current ? "notes" : "message";
    const seqsToRelease = [];
    while (waiting.has(nextSeq)) {
      seqsToRelease.push(nextSeq);
      nextSeq += 1;
    }
    if (seqsToRelease.length === 0) {
      bufferReleaseTimerRef.current = null;
      return;
    }
    seqsToRelease.forEach((seq, index) => {
      const releaseTimer = setTimeout(() => {
        waiting.delete(seq);
        received.add(seq);
        const serverCanvas = canvasesRef.current.server;
        const bufferedItem = serverCanvas?.placedItems.find((entry) => {
          if (entry.type !== "split-packet") return false;
          if (getSeq(entry) !== seq) return false;
          return getFileKey(entry.data) === fileKey;
        });
        if (bufferedItem) {
          updateItemIfNeeded(bufferedItem, "server", {
            status: "success",
            tcpState: "received"
          });
        }
        syncBufferState();
        const { ackNumber, message, total } = buildAckServerMessage();
        appendServerLog(message);
        trackDuplicateAck(ackNumber, total);
        if (index === seqsToRelease.length - 1) {
          bufferReleaseTimerRef.current = null;
          if (received.size >= sequences.length) {
            const delayMs = lossScenarioRef.current ? void 0 : 0;
            handleAllPacketsReceived(delayMs);
          }
        }
      }, index * BUFFER_STEP_DELAY_MS);
      registerTimer(releaseTimer);
      if (index === seqsToRelease.length - 1) {
        bufferReleaseTimerRef.current = releaseTimer;
      }
    });
  }, [
    appendServerLog,
    buildAckServerMessage,
    getActiveSequences,
    handleAllPacketsReceived,
    registerTimer,
    trackDuplicateAck,
    syncBufferState,
    updateItemIfNeeded
  ]);
  const scheduleBufferRelease = reactExports.useCallback(() => {
    if (bufferReleaseTimerRef.current) return;
    bufferReleaseTimerRef.current = setTimeout(() => {
      releaseBufferedPackets();
    }, BUFFER_RELEASE_DELAY_MS);
    registerTimer(bufferReleaseTimerRef.current);
  }, [registerTimer, releaseBufferedPackets]);
  const handleSeqArrival = reactExports.useCallback(
    (item, stateKey, seq) => {
      const sequences = getActiveSequences();
      const received = receivedSeqsRef.current;
      const waiting = waitingSeqsRef.current;
      const smallestMissing = sequences.find((value) => !received.has(value));
      if (smallestMissing !== void 0 && seq > smallestMissing) {
        if (!modalShownRef.current.holBlocking) {
          modalShownRef.current.holBlocking = true;
          dispatch({
            type: "OPEN_MODAL",
            payload: buildHolBlockingModal()
          });
        }
        waiting.add(seq);
        updateItemIfNeeded(item, stateKey, {
          status: "warning",
          tcpState: "buffered"
        });
        syncBufferState();
        scheduleBufferRelease();
        const { ackNumber: ackNumber2, message: message2, total: total2 } = buildAckServerMessage();
        appendServerLog(message2);
        trackDuplicateAck(ackNumber2, total2);
        return false;
      }
      received.add(seq);
      syncBufferState();
      if (waiting.size > 0) {
        scheduleBufferRelease();
      }
      const { ackNumber, message, total } = buildAckServerMessage();
      appendServerLog(message);
      trackDuplicateAck(ackNumber, total);
      if (phase === "resend" && resendTargetSeqRef.current === seq) {
        resendTargetSeqRef.current = null;
        clearResendHighlight();
        setPhase("loss");
        if (lossScenarioRef.current && seq < LOSS_PACKET_SEQ && !allowPacket2Ref.current) {
          const bufferedAfterLoss = Array.from(waitingSeqsRef.current).filter(
            (value) => value > LOSS_PACKET_SEQ
          ).length;
          if (bufferedAfterLoss >= 3) {
            allowPacket2Ref.current = true;
            resendTargetSeqRef.current = LOSS_PACKET_SEQ;
            setPhase("resend");
            highlightMissingPacket(LOSS_PACKET_SEQ);
            if (duplicateAckModalSeqRef.current !== LOSS_PACKET_SEQ) {
              duplicateAckModalSeqRef.current = LOSS_PACKET_SEQ;
              dispatch({
                type: "OPEN_MODAL",
                payload: buildDuplicateAckModal(LOSS_PACKET_SEQ)
              });
            }
          }
        }
      }
      return true;
    },
    [
      appendServerLog,
      buildAckServerMessage,
      getActiveSequences,
      clearResendHighlight,
      dispatch,
      highlightMissingPacket,
      phase,
      trackDuplicateAck,
      scheduleBufferRelease,
      syncBufferState,
      updateItemIfNeeded
    ]
  );
  const activeSequences = reactExports.useMemo(
    () => lossScenarioActive ? NOTES_SEQUENCES : MESSAGE_SEQUENCES,
    [lossScenarioActive]
  );
  const bufferSlots = reactExports.useMemo(
    () => activeSequences.map((seq) => {
      if (receivedSeqs.includes(seq)) {
        return { seq, status: "received" };
      }
      if (waitingSeqs.includes(seq)) {
        return { seq, status: "waiting" };
      }
      return { seq, status: "empty" };
    }),
    [activeSequences, receivedSeqs, waitingSeqs]
  );
  const hasStarted = phase !== "mtu" || (canvases.internet?.placedItems.length ?? 0) > 0 || (canvases.server?.placedItems.length ?? 0) > 0 || (canvases.splitter?.placedItems.length ?? 0) > 0;
  reactExports.useEffect(() => {
    if (!sequenceEnabled) return;
    const allPackets = [
      ...canvases.internet?.placedItems ?? [],
      ...canvases.server?.placedItems ?? []
    ].filter((item) => item.type === "split-packet");
    for (const item of allPackets) {
      const location = findItemLocationLatest(item.id);
      if (!location) continue;
      updateItemIfNeeded(location.item, location.stateKey, {
        seqEnabled: true
      });
    }
  }, [canvases, findItemLocationLatest, sequenceEnabled, updateItemIfNeeded]);
  const prevSplitterIdsRef = reactExports.useRef(/* @__PURE__ */ new Set());
  reactExports.useEffect(() => {
    const splitterCanvas = canvases.splitter;
    if (!splitterCanvas) return;
    const currentIds = new Set(splitterCanvas.placedItems.map((item) => item.id));
    const newItems = splitterCanvas.placedItems.filter(
      (item) => !prevSplitterIdsRef.current.has(item.id)
    );
    for (const item of newItems) {
      if (item.type === "message-file") {
        setPhase("split-send");
        updateInventoryGroup(INVENTORY_GROUP_IDS.files, {
          visible: false,
          items: []
        });
        updateInventoryGroup(INVENTORY_GROUP_IDS.split, {
          visible: true,
          items: MESSAGE_PACKET_ITEMS
        });
        const removeTimer = setTimeout(() => {
          const location = findItemLocationLatest(item.id);
          if (location) {
            removeItem(location.item, location.stateKey);
          }
        }, 300);
        registerTimer(removeTimer);
        continue;
      }
      if (item.type === "notes-file") {
        setPhase("loss");
        updateInventoryGroup(INVENTORY_GROUP_IDS.files, {
          visible: false,
          items: []
        });
        updateInventoryGroup(INVENTORY_GROUP_IDS.split, {
          visible: true,
          items: NOTES_PACKET_ITEMS
        });
        resetBuffer();
        duplicateAckCountRef.current = 0;
        lastAckNumberRef.current = null;
        allowPacket2Ref.current = false;
        duplicateAckModalSeqRef.current = null;
        resendTargetSeqRef.current = null;
        if (sequenceEnabled) {
          updateSplitPacketsForSequence("notes");
        }
        const removeTimer = setTimeout(() => {
          const location = findItemLocationLatest(item.id);
          if (location) {
            removeItem(location.item, location.stateKey);
          }
        }, 300);
        registerTimer(removeTimer);
      }
    }
    prevSplitterIdsRef.current = currentIds;
  }, [
    canvases.splitter,
    findItemLocationLatest,
    registerTimer,
    removeItem,
    updateInventoryGroup,
    updateSplitPacketsForSequence,
    sequenceEnabled,
    resetBuffer
  ]);
  const prevInternetIdsRef = reactExports.useRef(/* @__PURE__ */ new Set());
  reactExports.useEffect(() => {
    const internetCanvas = canvases.internet;
    if (!internetCanvas) return;
    const currentIds = new Set(internetCanvas.placedItems.map((item) => item.id));
    const newItems = internetCanvas.placedItems.filter(
      (item) => !prevInternetIdsRef.current.has(item.id)
    );
    for (const item of newItems) {
      const direction = item.data?.direction;
      if (item.type === "message-file" || item.type === "notes-file") {
        updateItemIfNeeded(item, "internet", {
          status: "error",
          tcpState: "rejected"
        });
        const nextPhase = item.type === "notes-file" ? "notes" : "splitter";
        const rejectTimer = setTimeout(() => {
          const location = findItemLocationLatest(item.id);
          if (location && location.stateKey === "internet") {
            removeItem(location.item, location.stateKey);
            setSplitterVisible(true);
            setPhase(nextPhase);
            if (!modalShownRef.current.mtu) {
              modalShownRef.current.mtu = true;
              dispatch({
                type: "OPEN_MODAL",
                payload: buildMtuModal()
              });
            }
          }
        }, MESSAGE_REJECT_DELAY_MS);
        registerTimer(rejectTimer);
        continue;
      }
      if (item.type === "syn-flag" && !connectionActiveRef.current) {
        setPhase("syn-wait");
      }
      if (item.type === "syn-ack-flag") {
        updateItemIfNeeded(item, "internet", {
          status: "warning",
          tcpState: "in-transit"
        });
        const receiveTimer = setTimeout(() => {
          const location = findItemLocationLatest(item.id);
          if (!location || location.stateKey !== "internet") {
            return;
          }
          updateItemIfNeeded(location.item, location.stateKey, {
            status: "success",
            tcpState: "delivered"
          });
          removeItem(location.item, location.stateKey);
          updateServerStatus("🟡 SYN-ACK sent - waiting for ACK...");
          ensureInventoryItems(
            INVENTORY_GROUP_IDS.tcpTools,
            [TCP_TOOL_ITEMS.ack],
            true
          );
          setPhase("ack");
          if (!modalShownRef.current.synAck) {
            modalShownRef.current.synAck = true;
            dispatch({
              type: "OPEN_MODAL",
              payload: buildSynAckModal(() => {
                if (modalShownRef.current.ackIntro) {
                  return;
                }
                modalShownRef.current.ackIntro = true;
                dispatch({
                  type: "OPEN_MODAL",
                  payload: buildAckIntroModal()
                });
              })
            });
          }
        }, INTERNET_TRAVEL_MS);
        registerTimer(receiveTimer);
        continue;
      }
      if (item.type === "fin-ack-flag" || item.type === "ack-packet" || direction === "server-to-client") {
        updateItemIfNeeded(item, "internet", {
          status: "warning",
          tcpState: "in-transit"
        });
        const receiveTimer = setTimeout(() => {
          const location = findItemLocationLatest(item.id);
          if (!location || location.stateKey !== "internet") {
            return;
          }
          updateItemIfNeeded(location.item, location.stateKey, {
            status: "success",
            tcpState: "delivered"
          });
          removeItem(location.item, location.stateKey);
        }, INTERNET_TRAVEL_MS);
        registerTimer(receiveTimer);
        continue;
      }
      if (item.type === "split-packet") {
        const seq = getSeq(item);
        const fileKey = getFileKey(item.data);
        if (lossScenarioRef.current && fileKey === "notes" && seq && seq === LOSS_PACKET_SEQ && !allowPacket2Ref.current) {
          if (!modalShownRef.current.packetLoss) {
            modalShownRef.current.packetLoss = true;
            dispatch({
              type: "OPEN_MODAL",
              payload: buildPacketLossModal()
            });
          }
          updateItemIfNeeded(item, "internet", {
            status: "error",
            tcpState: "lost"
          });
          const lossTimer = setTimeout(() => {
            const location = findItemLocationLatest(item.id);
            if (location) {
              removeItem(location.item, location.stateKey);
            }
          }, LOSS_FADE_MS);
          registerTimer(lossTimer);
          continue;
        }
      }
      updateItemIfNeeded(item, "internet", {
        status: "warning",
        tcpState: "in-transit"
      });
      const transferTimer = setTimeout(() => {
        const moved = transferItemToCanvas(item.id, "server");
        if (moved && item.type === "split-packet" && !connectionActiveRef.current) {
          updateServerStatus("Processing...");
        }
      }, INTERNET_TRAVEL_MS);
      registerTimer(transferTimer);
    }
    prevInternetIdsRef.current = currentIds;
  }, [
    canvases.internet,
    dispatch,
    ensureInventoryItems,
    findItemLocationLatest,
    registerTimer,
    removeItem,
    transferItemToCanvas,
    updateServerStatus,
    updateItemIfNeeded
  ]);
  const prevServerIdsRef = reactExports.useRef(/* @__PURE__ */ new Set());
  reactExports.useEffect(() => {
    const serverCanvas = canvases.server;
    if (!serverCanvas) return;
    const currentIds = new Set(serverCanvas.placedItems.map((item) => item.id));
    const newItems = serverCanvas.placedItems.filter(
      (item) => !prevServerIdsRef.current.has(item.id)
    );
    for (const item of newItems) {
      if (item.type === "syn-flag") {
        updateItemIfNeeded(item, "server", {
          status: "success",
          tcpState: "received"
        });
        updateServerStatus("🟡 SYN received - sending SYN-ACK...");
        sendServerPacket({
          ...SYSTEM_PACKET_ITEMS.synAck,
          data: {
            ...SYSTEM_PACKET_ITEMS.synAck.data,
            direction: "server-to-client"
          }
        });
        setPhase("syn-wait");
        continue;
      }
      if (item.type === "ack-flag") {
        updateItemIfNeeded(item, "server", {
          status: "success",
          tcpState: "received"
        });
        handleConnectionEstablished();
        continue;
      }
      if (item.type === "fin-flag") {
        updateItemIfNeeded(item, "server", {
          status: "success",
          tcpState: "received"
        });
        sendServerPacket({
          ...SYSTEM_PACKET_ITEMS.finAck,
          data: {
            ...SYSTEM_PACKET_ITEMS.finAck.data,
            direction: "server-to-client"
          }
        });
        setConnectionClosed(true);
        setConnectionActive(false);
        updateServerStatus("🔴 Disconnected");
        setPhase("terminal");
        continue;
      }
      if (item.type === "split-packet") {
        const seq = getSeq(item);
        if (!connectionActiveRef.current) {
          handleServerReject(item, "server");
          continue;
        }
        if (seq) {
          const accepted = handleSeqArrival(item, "server", seq);
          if (!accepted) {
            continue;
          }
          updateItemIfNeeded(item, "server", {
            status: "success",
            tcpState: "received"
          });
          const sequences = getActiveSequences();
          if (receivedSeqsRef.current.size >= sequences.length) {
            handleAllPacketsReceived();
          }
        }
      }
    }
    prevServerIdsRef.current = currentIds;
  }, [
    appendServerLog,
    buildAckServerMessage,
    canvases.server,
    dispatch,
    ensureInventoryItems,
    getActiveSequences,
    handleAllPacketsReceived,
    handleConnectionEstablished,
    handleSeqArrival,
    handleServerReject,
    registerTimer,
    updateServerStatus,
    updateItemIfNeeded
  ]);
  const receivedCount = receivedSeqs.length;
  const waitingCount = waitingSeqs.length;
  return {
    phase,
    splitterVisible,
    serverStatus,
    connectionActive,
    connectionClosed,
    sequenceEnabled,
    lossScenarioActive,
    hasStarted,
    serverLog,
    bufferSlots,
    receivedCount,
    waitingCount
  };
};
const NETSTAT_OUTPUT = `Active Connections

Proto  Local Address      Foreign Address    State
TCP    192.168.1.10:54321 93.184.216.34:80  ESTABLISHED`;
const TCPDUMP_OUTPUT = `15:04:32.001 IP 192.168.1.10 > 93.184.216.34: Flags [S], seq 1000
15:04:32.045 IP 93.184.216.34 > 192.168.1.10: Flags [S.], seq 2000, ack 1001
15:04:32.046 IP 192.168.1.10 > 93.184.216.34: Flags [.], ack 2001

15:04:32.100 IP 192.168.1.10 > 93.184.216.34: Flags [P.], seq 1001:1101, ack 2001
15:04:32.150 IP 93.184.216.34 > 192.168.1.10: Flags [.], ack 1101

15:04:32.200 IP 192.168.1.10 > 93.184.216.34: Flags [P.], seq 1101:1201, ack 2001
15:04:32.205 IP 93.184.216.34 > 192.168.1.10: Flags [.], ack 1101 (dup)
15:04:32.255 IP 93.184.216.34 > 192.168.1.10: Flags [.], ack 1101 (dup)
15:04:32.305 IP 93.184.216.34 > 192.168.1.10: Flags [.], ack 1101 (dup)

15:04:32.400 IP 192.168.1.10 > 93.184.216.34: Flags [P.], seq 1101:1201, ack 2001 (retransmission)
15:04:32.450 IP 93.184.216.34 > 192.168.1.10: Flags [.], ack 1201

15:04:32.500 IP 192.168.1.10 > 93.184.216.34: Flags [P.], seq 1201:1301, ack 2001
15:04:32.550 IP 93.184.216.34 > 192.168.1.10: Flags [.], ack 1301

15:04:33.000 IP 192.168.1.10 > 93.184.216.34: Flags [F.], seq 1301, ack 2001
15:04:33.050 IP 93.184.216.34 > 192.168.1.10: Flags [F.], seq 2001, ack 1302
15:04:33.051 IP 192.168.1.10 > 93.184.216.34: Flags [.], ack 2002

--- Connection closed gracefully ---`;
const TCPDUMP_EXPLAIN_OUTPUT = `TCP Flags explained:
  [S]  = SYN      - Start connection
  [S.] = SYN-ACK  - Acknowledge + start
  [.]  = ACK      - Acknowledgment
  [P.] = PSH-ACK  - Push data + ack
  [F.] = FIN-ACK  - Finish + ack

Your session:
  1. Three-way handshake (SYN -> SYN-ACK -> ACK)
  2. Data transfer (3 packets, loss + retransmission)
  3. Connection close (FIN -> FIN-ACK -> ACK)

Total packets: 16
Retransmissions: 1
Packet loss: 1`;
const SS_OUTPUT = `State  Recv-Q Send-Q Local Address:Port Peer Address:Port
ESTAB  0      0      192.168.1.10:54321 93.184.216.34:80`;
const HELP_OUTPUT = `Supported commands:
- netstat
- netstat -an
- tcpdump
- tcpdump -explain
- tcpdump -count
- ss -t
- help
- clear`;
const useTcpTerminal = ({ onQuestionComplete }) => {
  const dispatch = useGameDispatch();
  const state = useGameState();
  return reactExports.useCallback(
    (input, helpers) => {
      if (state.question.status === "completed") return;
      if (state.phase !== "terminal") {
        helpers.writeOutput("Error: Terminal is not ready yet.", "error");
        return;
      }
      const normalized = input.trim();
      if (!normalized) return;
      const parts = normalized.split(/\s+/);
      const command = parts[0]?.toLowerCase();
      const arg = parts.slice(1).join(" ").toLowerCase();
      switch (command) {
        case "help":
          helpers.writeOutput(HELP_OUTPUT, "output");
          return;
        case "clear":
          helpers.clearHistory();
          return;
        case "netstat":
          if (arg === "-an") {
            helpers.writeOutput(NETSTAT_OUTPUT, "output");
            return;
          }
          helpers.writeOutput(NETSTAT_OUTPUT, "output");
          return;
        case "tcpdump": {
          let shouldComplete = false;
          if (arg === "-explain") {
            helpers.writeOutput(TCPDUMP_EXPLAIN_OUTPUT, "output");
            shouldComplete = true;
          } else if (arg === "-count") {
            helpers.writeOutput("Total packets: 16\nRetransmissions: 1\nPacket loss: 1", "output");
          } else if (!arg) {
            helpers.writeOutput(TCPDUMP_OUTPUT, "output");
            shouldComplete = true;
          } else {
            helpers.writeOutput("Unknown tcpdump option. Try tcpdump -explain", "error");
            return;
          }
          if (shouldComplete) {
            dispatch({
              type: "OPEN_MODAL",
              payload: buildSuccessModal(onQuestionComplete)
            });
            helpers.finishEngine();
            dispatch({ type: "COMPLETE_QUESTION" });
          }
          return;
        }
        case "ss":
          if (arg === "-t") {
            helpers.writeOutput(SS_OUTPUT, "output");
            return;
          }
          helpers.writeOutput("Usage: ss -t", "output");
          return;
        default:
          helpers.writeOutput(
            `Unknown command: ${normalized}. Type 'help' for available commands.`,
            "error"
          );
      }
    },
    [dispatch, onQuestionComplete, state.phase, state.question.status]
  );
};
const TcpQuestion = ({ onQuestionComplete }) => {
  return /* @__PURE__ */ jsxRuntimeExports.jsx(GameProvider, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(TcpGame, { onQuestionComplete }) });
};
const TcpGame = ({
  onQuestionComplete
}) => {
  const dispatch = useGameDispatch();
  const state = useGameState();
  const initializedRef = reactExports.useRef(false);
  const [tunnelVisible, setTunnelVisible] = reactExports.useState(false);
  const [tunnelActive, setTunnelActive] = reactExports.useState(false);
  const terminalInput = useTerminalInput();
  const isCompleted = state.question.status === "completed";
  const successShownRef = reactExports.useRef(false);
  const inventoryGroups = reactExports.useMemo(
    () => [
      {
        id: INVENTORY_GROUP_IDS.files,
        title: "Files",
        visible: true,
        items: FILE_INVENTORY_ITEMS
      },
      {
        id: INVENTORY_GROUP_IDS.split,
        title: "Split Packages",
        visible: false,
        items: []
      },
      {
        id: INVENTORY_GROUP_IDS.tcpTools,
        title: "TCP Tools",
        visible: false,
        items: []
      },
      {
        id: INVENTORY_GROUP_IDS.received,
        title: "Received",
        visible: false,
        items: []
      }
    ],
    []
  );
  const tcpState = useTcpState();
  const showCommandTerminal = state.phase === "terminal" || state.phase === "completed";
  const handleCommand = useTcpTerminal({
    onQuestionComplete
  });
  useTerminalEngine({
    onCommand: handleCommand
  });
  const spec = reactExports.useMemo(
    () => ({
      meta: {
        id: QUESTION_ID,
        title: QUESTION_TITLE,
        description: QUESTION_DESCRIPTION
      },
      init: {
        kind: "multi",
        payload: {
          questionId: QUESTION_ID,
          canvases: CANVAS_CONFIGS,
          inventoryGroups,
          terminal: {
            visible: false,
            prompt: TERMINAL_PROMPT,
            history: []
          },
          phase: "setup",
          questionStatus: "in_progress"
        }
      },
      phaseRules: [
        {
          kind: "set",
          when: { kind: "eq", key: "questionStatus", value: "completed" },
          to: "completed"
        },
        {
          kind: "set",
          when: { kind: "flag", key: "terminalPhase", is: true },
          to: "terminal"
        }
      ],
      labels: {
        getItemLabel: getTcpItemLabel,
        getStatusMessage: getTcpStatusMessage
      },
      handlers: {
        onCommand: handleCommand,
        onItemClickByType: {},
        isItemClickableByType: {}
      }
    }),
    [handleCommand, inventoryGroups]
  );
  reactExports.useEffect(() => {
    if (initializedRef.current) return;
    initializedRef.current = true;
    dispatch({
      type: "INIT_MULTI_CANVAS",
      payload: spec.init.payload
    });
  }, [dispatch, spec.init.payload]);
  reactExports.useEffect(() => {
    if (tcpState.connectionActive) {
      setTunnelVisible(true);
      const frame = requestAnimationFrame(() => setTunnelActive(true));
      return () => cancelAnimationFrame(frame);
    }
    if (tunnelVisible) {
      setTunnelActive(false);
      const timer = setTimeout(() => setTunnelVisible(false), 600);
      return () => clearTimeout(timer);
    }
    return void 0;
  }, [tcpState.connectionActive, tunnelVisible]);
  reactExports.useEffect(() => {
    const basePhase = tcpState.hasStarted ? "playing" : "setup";
    const context = {
      questionStatus: state.question.status,
      terminalPhase: tcpState.phase === "terminal" || tcpState.connectionClosed
    };
    const resolved = resolvePhase(
      spec.phaseRules,
      context,
      state.phase,
      basePhase
    );
    if (state.phase !== resolved.nextPhase) {
      dispatch({ type: "SET_PHASE", payload: { phase: resolved.nextPhase } });
    }
  }, [
    dispatch,
    spec.phaseRules,
    state.phase,
    state.question.status,
    tcpState.connectionClosed,
    tcpState.hasStarted,
    tcpState.phase
  ]);
  reactExports.useEffect(() => {
    if (successShownRef.current) return;
    if (!tcpState.connectionClosed) return;
    if (state.question.status === "completed") return;
    successShownRef.current = true;
    dispatch({
      type: "OPEN_MODAL",
      payload: buildSuccessModal(onQuestionComplete)
    });
    dispatch({ type: "COMPLETE_QUESTION" });
  }, [
    dispatch,
    onQuestionComplete,
    state.question.status,
    tcpState.connectionClosed
  ]);
  const contextualHint = reactExports.useMemo(
    () => getContextualHint({
      phase: tcpState.phase,
      splitterVisible: tcpState.splitterVisible,
      connectionActive: tcpState.connectionActive,
      sequenceEnabled: tcpState.sequenceEnabled,
      lossScenarioActive: tcpState.lossScenarioActive,
      receivedCount: tcpState.receivedCount,
      waitingCount: tcpState.waitingCount,
      connectionClosed: tcpState.connectionClosed
    }),
    [
      tcpState.connectionClosed,
      tcpState.connectionActive,
      tcpState.lossScenarioActive,
      tcpState.phase,
      tcpState.receivedCount,
      tcpState.sequenceEnabled,
      tcpState.splitterVisible,
      tcpState.waitingCount
    ]
  );
  return /* @__PURE__ */ jsxRuntimeExports.jsx(GameShell, { getItemLabel: spec.labels.getItemLabel, children: /* @__PURE__ */ jsxRuntimeExports.jsxs(
    Flex,
    {
      direction: "column",
      px: { base: 2, md: 12, lg: 24 },
      py: { base: 2, md: 6 },
      children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs(Box, { textAlign: "left", mb: { base: 2, md: 4 }, pb: { base: 1, md: 0 }, children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            Text,
            {
              fontSize: { base: "2xl", md: "4xl" },
              fontWeight: "bold",
              color: "gray.50",
              children: QUESTION_TITLE
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsx(Text, { fontSize: { base: "sm", md: "md" }, color: "gray.400", children: QUESTION_DESCRIPTION })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          Flex,
          {
            direction: { base: "column", xl: "row" },
            gap: { base: 2, md: 4 },
            align: { base: "stretch", xl: "flex-start" },
            children: CANVAS_ORDER.map((key) => {
              const config = CANVAS_CONFIGS[key];
              if (!config) return null;
              if (key === "splitter" && !tcpState.splitterVisible) {
                return null;
              }
              return /* @__PURE__ */ jsxRuntimeExports.jsxs(
                Box,
                {
                  flexGrow: config.columns,
                  flexBasis: 0,
                  minW: { base: "100%", xl: "0" },
                  children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx(
                      PlayCanvas,
                      {
                        stateKey: key,
                        title: config.title ?? key,
                        getItemLabel: spec.labels.getItemLabel,
                        getStatusMessage: spec.labels.getStatusMessage
                      }
                    ),
                    key === "server" && /* @__PURE__ */ jsxRuntimeExports.jsxs(
                      Box,
                      {
                        mt: 2,
                        bg: "gray.900",
                        border: "1px solid",
                        borderColor: "gray.800",
                        borderRadius: "md",
                        px: 3,
                        py: 2,
                        children: [
                          /* @__PURE__ */ jsxRuntimeExports.jsx(Text, { fontSize: "xs", color: "gray.400", mb: 1, children: "Server terminal" }),
                          /* @__PURE__ */ jsxRuntimeExports.jsx(
                            TerminalView,
                            {
                              history: tcpState.serverLog,
                              entryPrefix: "> ",
                              containerProps: {
                                bg: "gray.950",
                                border: "1px solid",
                                borderColor: "gray.800",
                                borderRadius: "md",
                                px: 3,
                                py: 2,
                                height: "120px"
                              }
                            }
                          ),
                          (tcpState.connectionActive || tcpState.receivedCount > 0 || tcpState.waitingCount > 0) && /* @__PURE__ */ jsxRuntimeExports.jsxs(Box, { mt: 2, children: [
                            /* @__PURE__ */ jsxRuntimeExports.jsx(Text, { fontSize: "xs", color: "gray.400", mb: 1, children: "Receiving buffer:" }),
                            /* @__PURE__ */ jsxRuntimeExports.jsx(Flex, { gap: 2, wrap: "wrap", children: tcpState.bufferSlots.map((slot) => {
                              const label = slot.status === "received" ? `#${slot.seq} ✅` : slot.status === "waiting" ? `#${slot.seq} ⏳` : `#${slot.seq} ___`;
                              return /* @__PURE__ */ jsxRuntimeExports.jsxs(
                                Text,
                                {
                                  fontSize: "xs",
                                  color: "gray.300",
                                  children: [
                                    "[",
                                    label,
                                    "]"
                                  ]
                                },
                                slot.seq
                              );
                            }) })
                          ] })
                        ]
                      }
                    )
                  ]
                },
                key
              );
            })
          }
        ),
        tunnelVisible && /* @__PURE__ */ jsxRuntimeExports.jsxs(Box, { mt: 4, mb: 2, px: { base: 2, md: 12 }, children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Text, { fontSize: "xs", color: "gray.400", textAlign: "center", mb: 2, children: "Connection tunnel" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(Box, { bg: "gray.800", borderRadius: "full", h: "8px", overflow: "hidden", children: /* @__PURE__ */ jsxRuntimeExports.jsx(
            Box,
            {
              bgGradient: "linear(to-r, cyan.400, teal.300)",
              h: "100%",
              width: tunnelActive ? "100%" : "0%",
              transition: "width 0.6s ease"
            }
          ) })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(InventoryDrawer, { tooltips: INVENTORY_TOOLTIPS }),
        contextualHint && /* @__PURE__ */ jsxRuntimeExports.jsx(
          Box,
          {
            bg: "gray.800",
            border: "1px solid",
            borderColor: "gray.700",
            borderRadius: "md",
            px: 4,
            py: 2,
            textAlign: "center",
            mb: 4,
            children: /* @__PURE__ */ jsxRuntimeExports.jsx(Text, { fontSize: "sm", color: "gray.100", children: contextualHint })
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          TerminalLayout,
          {
            visible: showCommandTerminal,
            focusRef: terminalInput.inputRef,
            view: /* @__PURE__ */ jsxRuntimeExports.jsx(
              TerminalView,
              {
                history: state.terminal.history,
                prompt: state.terminal.prompt,
                isCompleted
              }
            ),
            input: /* @__PURE__ */ jsxRuntimeExports.jsx(
              TerminalInput,
              {
                value: terminalInput.value,
                onChange: terminalInput.onChange,
                onKeyDown: terminalInput.onKeyDown,
                inputRef: terminalInput.inputRef,
                placeholder: isCompleted ? "Terminal disabled" : "Type a command",
                disabled: isCompleted
              }
            )
          }
        )
      ]
    }
  ) });
};
const TcpQuestionRoute = () => {
  const navigate = useNavigate();
  const handleQuestionComplete = () => {
    markNetworkingQuestionComplete("tcp");
    const nextPath = getNextQuestionPath("tcp");
    void navigate({
      to: nextPath ?? "/questions/networking"
    });
  };
  return /* @__PURE__ */ jsxRuntimeExports.jsx(TcpQuestion, { onQuestionComplete: handleQuestionComplete });
};
export {
  TcpQuestionRoute as component
};
