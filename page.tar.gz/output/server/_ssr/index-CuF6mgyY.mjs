import { j as jsxRuntimeExports, r as reactExports } from "../_libs/react.mjs";
import { d as useNavigate } from "../_libs/@tanstack/react-router.mjs";
import { u as useDragEngine } from "./use-drag-engine-CAadIO0l.mjs";
import { G as GameProvider, u as useGameDispatch, a as useGameState, b as useTerminalInput, c as useTerminalEngine, r as resolvePhase, d as resolveVisibility, e as GameShell, P as PlayCanvas, I as InventoryDrawer, T as TerminalLayout, f as TerminalInput, g as TerminalView, h as useAllCanvases } from "./question-ast-DxRXheAC.mjs";
import { m as markNetworkingQuestionComplete, b as getNextQuestionPath } from "./module-progress-CKDPPitT.mjs";
import { F as Flex, B as Box, T as Text } from "../_libs/@chakra-ui/react.mjs";
import "../_libs/@babel/runtime.mjs";
import "../_libs/tiny-warning.mjs";
import "../_libs/@tanstack/router-core.mjs";
import "../_libs/@tanstack/store.mjs";
import "../_libs/@tanstack/history.mjs";
import "../_libs/tiny-invariant.mjs";
import "node:stream/web";
import "node:stream";
import "../_libs/react-dom.mjs";
import "util";
import "crypto";
import "async_hooks";
import "stream";
import "../_libs/isbot.mjs";
import "../_libs/@tanstack/react-store.mjs";
import "../_libs/use-sync-external-store.mjs";
import "../_libs/gsap.mjs";
import "../_libs/@iconify/react.mjs";
import "../_libs/lucide-react.mjs";
import "../_libs/@ark-ui/react.mjs";
import "../_libs/@zag-js/carousel.mjs";
import "../_libs/@zag-js/anatomy.mjs";
import "../_libs/@zag-js/types.mjs";
import "../_libs/@zag-js/core.mjs";
import "../_libs/@zag-js/utils.mjs";
import "../_libs/@zag-js/dom-query.mjs";
import "../_libs/@zag-js/checkbox.mjs";
import "../_libs/@zag-js/focus-visible.mjs";
import "../_libs/@zag-js/react.mjs";
import "../_libs/@zag-js/color-picker.mjs";
import "../_libs/@zag-js/color-utils.mjs";
import "../_libs/@zag-js/popper.mjs";
import "../_libs/@floating-ui/dom.mjs";
import "../_libs/@floating-ui/core.mjs";
import "../_libs/@floating-ui/utils.mjs";
import "../_libs/@zag-js/dismissable.mjs";
import "../_libs/@zag-js/interact-outside.mjs";
import "../_libs/@zag-js/combobox.mjs";
import "../_libs/@zag-js/collection.mjs";
import "../_libs/@zag-js/auto-resize.mjs";
import "../_libs/@zag-js/listbox.mjs";
import "../_libs/@zag-js/radio-group.mjs";
import "../_libs/@zag-js/tooltip.mjs";
import "../_libs/@zag-js/presence.mjs";
import "../_libs/@pandacss/is-valid-prop.mjs";
import "../_libs/@zag-js/switch.mjs";
import "../_libs/@zag-js/splitter.mjs";
import "../_libs/@zag-js/slider.mjs";
import "../_libs/@zag-js/select.mjs";
import "../_libs/@zag-js/rating-group.mjs";
import "../_libs/@zag-js/popover.mjs";
import "../_libs/@zag-js/menu.mjs";
import "../_libs/@zag-js/rect-utils.mjs";
import "../_libs/@zag-js/file-upload.mjs";
import "../_libs/@zag-js/editable.mjs";
import "../_libs/@zag-js/dialog.mjs";
import "../_libs/@zag-js/accordion.mjs";
import "../_libs/@zag-js/clipboard.mjs";
import "../_libs/@zag-js/avatar.mjs";
import "../_libs/@zag-js/collapsible.mjs";
import "../_libs/@zag-js/hover-card.mjs";
import "../_libs/@zag-js/number-input.mjs";
import "../_libs/@internationalized/number.mjs";
import "../_libs/@zag-js/pin-input.mjs";
import "../_libs/@zag-js/progress.mjs";
import "../_libs/@zag-js/qr-code.mjs";
import "../_libs/@zag-js/scroll-area.mjs";
import "../_libs/@zag-js/tags-input.mjs";
import "../_libs/@zag-js/live-region.mjs";
import "../_libs/@zag-js/tree-view.mjs";
import "../_libs/@emotion/is-prop-valid.mjs";
import "../_libs/@emotion/memoize.mjs";
import "../_libs/@emotion/serialize.mjs";
import "../_libs/@emotion/hash.mjs";
import "../_libs/@emotion/unitless.mjs";
import "../_libs/@emotion/use-insertion-effect-with-fallbacks.mjs";
import "../_libs/@emotion/utils.mjs";
import "../_libs/@emotion/react.mjs";
import "../_libs/@emotion/cache.mjs";
import "../_libs/@emotion/sheet.mjs";
import "../_libs/@emotion/weak-memoize.mjs";
import "../_libs/stylis.mjs";
const QUESTION_ID = "webserver-ssl";
const QUESTION_TITLE = "🔒 Secure Your Website!";
const QUESTION_DESCRIPTION = "Your webserver is running, but browsers warn it's not secure. Set up HTTPS with a certificate from Let's Encrypt!";
const TERMINAL_PROMPT = "Your secure website is ready! Test both HTTP and HTTPS connections.";
const CANVAS_ORDER = [
  "browser",
  "port-80",
  "letsencrypt",
  "port-443"
];
const CANVAS_CONFIGS = {
  browser: {
    id: "ssl-browser",
    title: "Browser",
    stateKey: "browser",
    columns: 1,
    rows: 1,
    maxItems: 1
  },
  "port-80": {
    id: "ssl-port-80",
    title: "HTTP Webserver",
    stateKey: "port-80",
    columns: 3,
    rows: 1,
    maxItems: 3
  },
  letsencrypt: {
    id: "ssl-letsencrypt",
    title: "Let's Encrypt",
    stateKey: "letsencrypt",
    columns: 1,
    rows: 1,
    maxItems: 1
  },
  "port-443": {
    id: "ssl-port-443",
    title: "HTTPS Webserver",
    stateKey: "port-443",
    columns: 5,
    rows: 1,
    maxItems: 5
  }
};
const DEFAULT_DOMAIN = "example.com";
const DEFAULT_INDEX_HTML = "/var/www/html/index.html";
const TERMINAL_INTRO_ENTRIES = [
  {
    id: "intro-ssl-1",
    type: "output",
    content: "Available commands:",
    timestamp: 0
  },
  {
    id: "intro-ssl-2",
    type: "output",
    content: `- curl http://${DEFAULT_DOMAIN}`,
    timestamp: 1
  },
  {
    id: "intro-ssl-3",
    type: "output",
    content: `- curl https://${DEFAULT_DOMAIN}`,
    timestamp: 2
  },
  {
    id: "intro-ssl-4",
    type: "output",
    content: `- curl -v https://${DEFAULT_DOMAIN}`,
    timestamp: 3
  },
  {
    id: "intro-ssl-5",
    type: "output",
    content: `- curl -I https://${DEFAULT_DOMAIN}`,
    timestamp: 4
  },
  {
    id: "intro-ssl-6",
    type: "output",
    content: `- openssl s_client https://${DEFAULT_DOMAIN}`,
    timestamp: 5
  },
  {
    id: "intro-ssl-7",
    type: "output",
    content: "- help",
    timestamp: 6
  },
  {
    id: "intro-ssl-8",
    type: "output",
    content: "- clear",
    timestamp: 7
  }
];
const INDEX_HTML_CONTENT = `<!DOCTYPE html>
<html>
<head>
  <title>Welcome to ${DEFAULT_DOMAIN}</title>
  <style>
    body { font-family: sans-serif; text-align: center; padding: 50px; }
    h1 { color: #333; }
    p { color: #666; }
  </style>
</head>
<body>
  <h1>Welcome to ${DEFAULT_DOMAIN}</h1>
  <p>This is your website running on a secure HTTPS connection!</p>
</body>
</html>`;
const TLS_HANDSHAKE_STEPS = [
  { step: 1, phase: "Client Hello", direction: "Browser → Server" },
  { step: 2, phase: "Server Hello", direction: "Server → Browser" },
  { step: 3, phase: "Server Certificate", direction: "Server → Browser" },
  { step: 4, phase: "Server Hello Done", direction: "Server → Browser" },
  { step: 5, phase: "Certificate Verify", direction: "Browser (internal)" },
  { step: 6, phase: "Client Key Exchange", direction: "Browser → Server" },
  { step: 7, phase: "Change Cipher Spec", direction: "Both" },
  { step: 8, phase: "Finished", direction: "Both" }
];
const BASIC_INVENTORY_ITEMS = [
  {
    id: "browser-1",
    type: "browser",
    name: "Browser",
    allowedPlaces: ["inventory", "browser"],
    icon: { icon: "mdi:web" }
  },
  {
    id: "webserver-80-1",
    type: "webserver-80",
    name: "Webserver (HTTP)",
    allowedPlaces: ["inventory", "port-80"],
    icon: { icon: "mdi:server" }
  },
  {
    id: "domain-1",
    type: "domain",
    name: "Domain",
    allowedPlaces: ["inventory", "port-80"],
    icon: { icon: "mdi:domain" }
  },
  {
    id: "index-html-1",
    type: "index-html",
    name: "index.html",
    allowedPlaces: ["inventory", "port-80", "port-443"],
    icon: { icon: "mdi:file-code" }
  }
];
const SSL_SETUP_INVENTORY_ITEMS = [
  {
    id: "webserver-443-1",
    type: "webserver-443",
    name: "Webserver (HTTPS)",
    allowedPlaces: ["inventory", "port-443"],
    icon: { icon: "mdi:server-security" }
  },
  {
    id: "domain-2",
    type: "domain",
    name: "Domain",
    allowedPlaces: ["inventory", "port-80", "port-443"],
    icon: { icon: "mdi:domain" }
  },
  {
    id: "domain-3",
    type: "domain-ssl",
    name: "Domain (SSL)",
    allowedPlaces: ["inventory", "letsencrypt"],
    icon: { icon: "mdi:domain" }
  },
  {
    id: "redirect-https-1",
    type: "redirect-to-https",
    name: "Redirect",
    allowedPlaces: ["inventory", "port-80"],
    icon: { icon: "mdi:arrow-right-bold" }
  }
];
const SSL_ITEMS_INVENTORY = [
  {
    id: "private-key-1",
    type: "private-key",
    name: "Private Key",
    allowedPlaces: ["inventory", "port-443"],
    icon: { icon: "mdi:key" }
  },
  {
    id: "certificate-1",
    type: "certificate",
    name: "Domain Certificate",
    allowedPlaces: ["inventory", "port-443"],
    icon: { icon: "mdi:card-account-details" }
  }
];
const isPort80Complete = (canvas) => {
  if (!canvas) return false;
  const types = canvas.placedItems.map((item) => item.type);
  const hasContent = types.includes("index-html") || types.includes("redirect-to-https");
  return types.includes("webserver-80") && types.includes("domain") && hasContent;
};
const isPort443Complete = (canvas) => {
  if (!canvas) return false;
  const types = canvas.placedItems.map((item) => item.type);
  return types.includes("webserver-443") && types.includes("domain") && types.includes("index-html") && types.includes("private-key") && types.includes("certificate");
};
const isPort80RedirectConfigured = (canvas) => {
  if (!canvas) return false;
  return canvas.placedItems.some((item) => item.type === "redirect-to-https");
};
const getBrowserStatus = (browserCanvas, port80Canvas, port443Canvas) => {
  if (!browserCanvas || browserCanvas.placedItems.length === 0) {
    return "error";
  }
  if (isPort443Complete(port443Canvas) && isPort80RedirectConfigured(port80Canvas)) {
    return "success";
  }
  if (isPort80Complete(port80Canvas)) {
    return "warning";
  }
  return "error";
};
const getDomainFromCanvas = (canvas) => {
  if (!canvas) return void 0;
  const domainItem = canvas.placedItems.find((item) => item.type === "domain");
  if (domainItem && typeof domainItem.data?.domain === "string") {
    return domainItem.data.domain;
  }
  return DEFAULT_DOMAIN;
};
const getCertificateDomain = (canvas) => {
  if (!canvas) return void 0;
  const domainItem = canvas.placedItems.find((item) => item.type === "domain-ssl");
  if (domainItem && typeof domainItem.data?.certificateDomain === "string") {
    return domainItem.data.certificateDomain;
  }
  return void 0;
};
const getContextualHint = (state) => {
  const {
    browserCanvas,
    port80Canvas,
    letsencryptCanvas,
    port443Canvas,
    certificateIssued,
    browserStatus,
    letsencryptModalOpen
  } = state;
  const browserItems = browserCanvas?.placedItems.length ?? 0;
  const port80Items = port80Canvas?.placedItems.map((i) => i.type) ?? [];
  const letsencryptItems = letsencryptCanvas?.placedItems.map((i) => i.type) ?? [];
  const port443Items = port443Canvas?.placedItems.map((i) => i.type) ?? [];
  const port80Complete = isPort80Complete(port80Canvas);
  if (browserItems === 0) {
    return "Drag the Browser to the first canvas";
  }
  if (browserItems > 0 && port80Items.length === 0) {
    return "Now set up your webserver! Drag Webserver (HTTP) to the Port 80 canvas";
  }
  if (port80Items.includes("webserver-80") && !port80Items.includes("domain")) {
    return "Add your domain to the Port 80 canvas";
  }
  if (port80Items.includes("webserver-80") && port80Items.includes("domain") && !port80Items.includes("index-html") && !port80Items.includes("redirect-to-https")) {
    return "Add index.html so your webserver has something to serve";
  }
  if (port80Complete && !isPort80RedirectConfigured(port80Canvas)) {
    return "Click the Browser to see your website!";
  }
  if (browserStatus === "warning") {
    if (letsencryptItems.length === 0) {
      return "⚠️ Your site works but it's not secure! New canvases have appeared...";
    }
    return "Drag the Domain (SSL) to the Let's Encrypt canvas to get a certificate";
  }
  if (letsencryptItems.includes("domain-ssl") && !certificateIssued) {
    if (!letsencryptModalOpen) {
      return "Click the Domain (SSL) in the Let's Encrypt canvas to request a certificate";
    }
    return "Enter your domain name (e.g., example.com)";
  }
  if (certificateIssued && port443Items.length === 0) {
    return "🎉 You got a certificate! Drag the Private Key and Domain Certificate to the Port 443 canvas";
  }
  if (certificateIssued && port443Items.length > 0) {
    if (!port443Items.includes("webserver-443")) {
      return "Set up your HTTPS webserver in the Port 443 canvas";
    }
    const hasPrivateKey = port443Items.includes("private-key");
    const hasCertificate = port443Items.includes("certificate");
    if (!hasPrivateKey && !hasCertificate) {
      return "Add your domain, index.html, private key, and domain certificate to Port 443";
    }
    if (!hasPrivateKey || !hasCertificate) {
      return "Install both the private key AND domain certificate on your HTTPS webserver";
    }
    if (!port443Items.includes("domain")) {
      return "Add your domain and index.html to Port 443";
    }
    if (!port443Items.includes("index-html")) {
      return "Add index.html to Port 443";
    }
  }
  if (isPort443Complete(port443Canvas) && !isPort80RedirectConfigured(port80Canvas)) {
    return "🔒 HTTPS is ready! But visitors might still go to HTTP...";
  }
  if (isPort443Complete(port443Canvas) && !port80Items.includes("redirect-to-https")) {
    return "Drag the redirect to Port 80 to automatically send visitors to HTTPS";
  }
  if (isPort80RedirectConfigured(port80Canvas) && isPort443Complete(port443Canvas)) {
    if (browserStatus !== "success") {
      return "🎉 Perfect! Click the Browser to see the secure connection";
    }
    return "🎉 Your website is now secure with HTTPS! Click the browser to see the TLS handshake.";
  }
  return "";
};
const INVENTORY_TOOLTIPS = {
  browser: {
    content: "A web browser is software that allows users to access websites. You'll use it to test your webserver configuration.",
    seeMoreHref: "https://developer.mozilla.org/en-US/docs/Learn/Common_questions/Web_mechanics/What_is_a_web_browser"
  },
  "webserver-80": {
    content: "An HTTP webserver serves unencrypted content on port 80. Anyone on the network can see what's being sent!",
    seeMoreHref: "https://developer.mozilla.org/en-US/docs/Learn/Common_questions/Web_mechanics/What_is_a_web_server"
  },
  "webserver-443": {
    content: "An HTTPS webserver serves encrypted content on port 443. It requires an SSL certificate and private key.",
    seeMoreHref: "https://developer.mozilla.org/en-US/docs/Web/Security/Secure_contexts"
  },
  domain: {
    content: "A domain name (like example.com) is the address where your website can be found on the internet.",
    seeMoreHref: "https://developer.mozilla.org/en-US/docs/Learn/Common_questions/Web_mechanics/What_is_a_domain_name"
  },
  "index-html": {
    content: "The index.html file is the default page your webserver serves when someone visits your website.",
    seeMoreHref: "https://developer.mozilla.org/en-US/docs/Learn/HTML/Introduction_to_HTML/Document_and_website_structure"
  },
  "private-key": {
    content: "🔑 The private key is SECRET. It stays on your server and is used to decrypt incoming HTTPS traffic. NEVER share it with anyone!",
    seeMoreHref: "https://www.digicert.com/faq/what-is-a-private-key.htm"
  },
  certificate: {
    content: "📜 The domain certificate contains your public key and proves your server's identity to browsers. It's PUBLIC - you share it with visitors.",
    seeMoreHref: "https://www.digicert.com/faq/what-is-an-ssl-certificate.htm"
  },
  "redirect-to-https": {
    content: "↪️ A redirect sends HTTP visitors to HTTPS automatically. This ensures everyone uses the secure connection, even if they type http://",
    seeMoreHref: "https://developer.mozilla.org/en-US/docs/Web/HTTP/Redirections"
  }
};
const validateDomain = (input) => {
  if (!input || input.trim().length === 0) {
    return "Enter your domain name";
  }
  const domain = input.trim();
  const domainRegex = /^[a-zA-Z0-9][a-zA-Z0-9-]*\.[a-zA-Z]{2,}$/;
  if (!domainRegex.test(domain)) {
    return "Invalid domain format. Use: example.com";
  }
  return null;
};
const closeAction = () => ({
  id: "close",
  label: "Close",
  variant: "primary",
  closesModal: true,
  validate: false
});
const buildField = (field) => ({
  kind: "field",
  field
});
const buildText = (text) => ({
  kind: "text",
  text
});
const buildBrowserStatusModal = (deviceId, status, hasTlsHandshake) => {
  const content = [];
  content.push(
    buildField({
      id: "url",
      kind: "readonly",
      label: "URL",
      value: status.url || "Not connected"
    })
  );
  content.push(
    buildField({
      id: "connection",
      kind: "readonly",
      label: "Connection",
      value: status.connection || "Can't connect"
    })
  );
  content.push(
    buildField({
      id: "port",
      kind: "readonly",
      label: "Port",
      value: status.port || "—"
    })
  );
  if (status.connection === "Can't connect") {
    content.push(buildText("\nNo webserver configured"));
  }
  if (status.connection?.includes("Not Secure")) {
    content.push(buildText("\n⚠️ Your connection is not private"));
  }
  if (status.connection?.includes("Secure")) {
    content.push(buildText(`
Certificate: ${DEFAULT_DOMAIN}`));
    content.push(buildText("Issued by: Let's Encrypt"));
  }
  if (hasTlsHandshake) {
    content.push(
      buildText(`
${TLS_HANDSHAKE_STEPS.map((s) => `${s.step}. ${s.phase} (${s.direction})`).join("\n")}`)
    );
  }
  return {
    id: `browser-status-${deviceId}`,
    title: "Browser",
    content,
    actions: [closeAction()]
  };
};
const buildWebserver80StatusModal = (deviceId, config) => {
  const content = [
    buildField({
      id: "port",
      kind: "readonly",
      label: "Listening Port",
      value: "80"
    }),
    buildField({
      id: "status",
      kind: "readonly",
      label: "Status",
      value: config.status || "Not configured"
    }),
    buildField({
      id: "domain",
      kind: "readonly",
      label: "Domain",
      value: config.domain || "Not set"
    }),
    buildField({
      id: "documentRoot",
      kind: "readonly",
      label: "Document Root",
      value: "/var/www/html"
    }),
    buildField({
      id: "servingFile",
      kind: "readonly",
      label: "Serving",
      value: config.servingFile || "Nothing"
    })
  ];
  content.push(
    buildText(
      "\nPort 80 is the default port for HTTP (unencrypted) web traffic. Browsers automatically connect to port 80 when you type `http://` URLs."
    )
  );
  return {
    id: `webserver-80-status-${deviceId}`,
    title: "Webserver Status (Port 80)",
    content,
    actions: [closeAction()]
  };
};
const buildWebserver443StatusModal = (deviceId, config) => {
  const content = [
    buildField({
      id: "port",
      kind: "readonly",
      label: "Listening Port",
      value: "443"
    }),
    buildField({
      id: "status",
      kind: "readonly",
      label: "Status",
      value: config.status || "Not configured"
    }),
    buildField({
      id: "domain",
      kind: "readonly",
      label: "Domain",
      value: config.domain || "Not set"
    })
  ];
  const hasPrivateKey = config.privateKey === "✓ Installed";
  const hasCertificate = config.certificate === "✓ Installed";
  content.push(
    buildField({
      id: "privateKey",
      kind: "readonly",
      label: "Private Key",
      value: hasPrivateKey ? "✓ Installed" : "Not installed"
    }),
    buildField({
      id: "certificate",
      kind: "readonly",
      label: "Domain Certificate",
      value: hasCertificate ? `✓ Installed (${config.domain || "example.com"})` : "Not installed"
    })
  );
  content.push(
    buildField({
      id: "servingFile",
      kind: "readonly",
      label: "Serving",
      value: config.servingFile || "Nothing"
    })
  );
  content.push(
    buildText(
      "\nPort 443 is the default port for HTTPS (encrypted) web traffic. It requires an SSL certificate and private key to establish secure connections."
    )
  );
  if (!hasPrivateKey && !hasCertificate) {
    content.push(buildText("\n❌ Missing SSL\n   ├─ Private Key: Not installed\n   └─ Domain Certificate: Not installed"));
  } else if (hasPrivateKey && !hasCertificate) {
    content.push(buildText("\n⚠️ Incomplete SSL\n   ├─ Private Key: ✓ Installed\n   └─ Domain Certificate: Not installed"));
  } else if (!hasPrivateKey && hasCertificate) {
    content.push(buildText("\n⚠️ Incomplete SSL\n   ├─ Private Key: Not installed\n   └─ Domain Certificate: ✓ Installed"));
  } else {
    content.push(
      buildText(
        `
🔒 SSL Configured
   ├─ Private Key: ✓ Installed
   └─ Domain Certificate: ✓ Installed (${config.domain || "example.com"})`
      )
    );
  }
  return {
    id: `webserver-443-status-${deviceId}`,
    title: "Webserver Status (Port 443)",
    content,
    actions: [closeAction()]
  };
};
const buildCertificateRequestModal = (deviceId, currentDomain, certificateIssued, port80CanvasConfig) => {
  if (certificateIssued) {
    return {
      id: `certificate-status-${deviceId}`,
      title: "📜 Domain Certificate Status",
      content: [
        buildText(`Domain: ${currentDomain || DEFAULT_DOMAIN}`),
        buildText("Issuer: Let's Encrypt"),
        buildText("Status: ✅ Issued"),
        buildText("Type: RSA 2048-bit"),
        buildText(""),
        buildText("The certificate is being used on your HTTPS webserver. Drag the Private Key and Domain Certificate items to the Port 443 canvas.")
      ],
      actions: [closeAction()]
    };
  }
  const existingPort80Domain = typeof port80CanvasConfig?.domain === "string" ? port80CanvasConfig.domain : DEFAULT_DOMAIN;
  const actions = [
    {
      id: "cancel",
      label: "Cancel",
      variant: "ghost",
      closesModal: true,
      validate: false
    },
    {
      id: "issue",
      label: "Issue Certificate",
      variant: "primary",
      validate: true,
      closesModal: true,
      onClick: async ({ values, dispatch }) => {
        const domain = String(values.domain ?? "").trim();
        if (!domain) {
          throw new Error("Enter your domain name");
        }
        if (domain !== existingPort80Domain) {
          throw new Error(`Domain must match: ${existingPort80Domain}`);
        }
        dispatch({
          type: "CONFIGURE_DEVICE",
          payload: {
            deviceId,
            config: {
              certificateIssued: true,
              verified: true,
              certificateDomain: domain
            },
            stateKey: "letsencrypt"
          }
        });
        dispatch({
          type: "UPDATE_INVENTORY_GROUP",
          payload: { id: "ssl-items", visible: true }
        });
      }
    }
  ];
  const content = [
    buildField({
      id: "domain",
      kind: "text",
      label: "Domain Name",
      placeholder: "example.com",
      defaultValue: currentDomain,
      validate: validateDomain
    })
  ];
  content.push(
    buildText(
      "\n> Get a free SSL certificate from Let's Encrypt for your domain."
    ),
    buildText(
      `> To prove ownership, Let's Encrypt will verify: http://${DEFAULT_DOMAIN}/.well-known/acme-challenge/xxx`
    ),
    buildText(
      "\n> Make sure your Port 80 webserver is configured before requesting!"
    )
  );
  return {
    id: `certificate-request-${deviceId}`,
    title: "Request SSL Certificate",
    content,
    actions
  };
};
const buildPrivateKeyInfoModal = (deviceId, installed) => {
  return {
    id: `private-key-info-${deviceId}`,
    title: "Private Key",
    content: [
      buildText("🔑 Private Key for example.com"),
      buildText("\nThis is your server's SECRET key."),
      buildText("- Used to decrypt incoming HTTPS traffic"),
      buildText("- Must be installed on your webserver (port 443)"),
      buildText("- NEVER share this with anyone!"),
      buildText(`
Status: ${"Installed on server"}`)
    ],
    actions: [closeAction()]
  };
};
const buildCertificateInfoModal = (deviceId, installed) => {
  return {
    id: `certificate-info-${deviceId}`,
    title: "Domain Certificate",
    content: [
      buildText("📜 Domain Certificate"),
      buildText("\nSubject: example.com"),
      buildText("Issuer: Let's Encrypt Authority X3"),
      buildText("Valid: 90 days"),
      buildText("\nThis certificate is sent to browsers to prove your server's identity."),
      buildText("It contains your public key (browsers use this to encrypt data to you)."),
      buildText(`
Status: ${installed ? "Installed on server" : "In Inventory"}`)
    ],
    actions: [closeAction()]
  };
};
const buildRedirectInfoModal = (deviceId) => {
  return {
    id: `redirect-info-${deviceId}`,
    title: "HTTP to HTTPS Redirect",
    content: [
      buildText("↪️ Redirect to HTTPS"),
      buildText("\nWhen a visitor goes to:"),
      buildText("  http://example.com"),
      buildText("\nThey will be automatically redirected to:"),
      buildText("  https://example.com"),
      buildText("\nThis ensures all visitors use the secure connection!"),
      buildText("\nServer response: HTTP 301 Moved Permanently"),
      buildText("Location: https://example.com/")
    ],
    actions: [closeAction()]
  };
};
const buildIndexHtmlViewModal = (deviceId) => {
  return {
    id: `index-html-view-${deviceId}`,
    title: "index.html",
    content: [
      buildText(INDEX_HTML_CONTENT)
    ],
    actions: [closeAction()]
  };
};
const buildTlsHandshakeModal = () => {
  const stepsText = TLS_HANDSHAKE_STEPS.map(
    (step) => `${step.step}. ${step.direction}: ${step.phase}`
  ).join("\n");
  return {
    id: "tls-handshake",
    title: "🔒 TLS Handshake Complete ✓",
    content: [
      buildText("Your browser has established a secure connection with the server!\n"),
      buildText(stepsText),
      buildText("\nThe connection is now encrypted. All data exchanged is secure!")
    ],
    actions: [closeAction()]
  };
};
const buildSuccessModal = (onQuestionComplete) => {
  return {
    id: "success",
    title: "🔒 Website Secured!",
    content: [
      buildText("Congratulations! You've successfully secured your website with HTTPS."),
      buildText("\nYou learned:"),
      buildText("- **Port 80 (HTTP)** serves unencrypted content - anyone can read it!"),
      buildText("- **Port 443 (HTTPS)** serves encrypted content - only you and the server can read it"),
      buildText("- **Let's Encrypt** is a free Certificate Authority that verifies domain ownership"),
      buildText("- **Private Key** stays secret on your server (decrypts incoming data)"),
      buildText("- **Certificate** is shared with browsers (proves your identity)"),
      buildText("- **SSL Handshake** establishes a secure connection before any data is sent"),
      buildText("- **HTTP→HTTPS Redirect** ensures all visitors use the secure connection"),
      buildText("\nThe 🔒 in your browser means the certificate is valid and the connection is encrypted!")
    ],
    actions: [
      {
        id: "primary",
        label: "Next question",
        variant: "primary",
        validate: false,
        closesModal: true,
        onClick: onQuestionComplete ? () => onQuestionComplete() : void 0
      }
    ]
  };
};
const getSslItemLabel = (itemType) => {
  switch (itemType) {
    case "browser":
      return "Browser";
    case "webserver-80":
      return "Webserver (HTTP)";
    case "webserver-443":
      return "Webserver (HTTPS)";
    case "domain":
      return "Domain";
    case "domain-ssl":
      return "Domain (for SSL)";
    case "index-html":
      return "index.html";
    case "private-key":
      return "🔑 Private Key";
    case "certificate":
      return "📜 Domain Certificate";
    case "redirect-to-https":
      return "Redirect";
    default:
      return itemType.charAt(0).toUpperCase() + itemType.slice(1);
  }
};
const getSslStatusMessage = (placedItem, canvasKey) => {
  const { type, status, data } = placedItem;
  if (type === "browser") {
    const domain = typeof data?.domain === "string" ? data.domain : "example.com";
    if (status === "error") {
      return `can't connect to ${domain}`;
    }
    if (status === "warning") {
      return `${domain} is insecure`;
    }
    if (status === "success") {
      return `${domain} is secured`;
    }
    return null;
  }
  if (type === "webserver-80") {
    if (status === "error") {
      return "not configured";
    }
    if (status === "warning") {
      return "serving HTTP";
    }
    if (status === "success") {
      if (canvasKey === "port-80") {
        return "redirecting to HTTPS";
      }
      return "serving HTTP";
    }
    return null;
  }
  if (type === "webserver-443") {
    if (status === "error") {
      return "not configured";
    }
    if (status === "warning") {
      return "missing SSL";
    }
    if (status === "success") {
      return "🔒 serving HTTPS";
    }
    return null;
  }
  if (type === "domain") {
    return "example.com";
  }
  if (type === "domain-ssl") {
    if (status === "success") {
      return "Configured";
    }
    return "Needs Issuing";
  }
  return null;
};
const useSslState = () => {
  const state = useGameState();
  const canvases = useAllCanvases();
  const dispatch = useGameDispatch();
  const browserCanvas = canvases.browser;
  const port80Canvas = canvases["port-80"];
  const letsencryptCanvas = canvases.letsencrypt;
  const port443Canvas = canvases["port-443"];
  const dispatchConfig = reactExports.useCallback(
    (deviceId, config) => {
      for (const [key, canvas] of Object.entries(canvases)) {
        const item = canvas.placedItems.find((i) => i.id === deviceId);
        if (item) {
          dispatch({
            type: "CONFIGURE_DEVICE",
            payload: {
              deviceId,
              config,
              stateKey: key
            }
          });
          return;
        }
      }
    },
    [canvases, dispatch]
  );
  const allPlacedItems = reactExports.useMemo(() => {
    const items = [];
    Object.values(canvases).forEach((canvas) => {
      canvas.placedItems.forEach((item) => {
        items.push({ type: item.type, id: item.id });
      });
    });
    return items;
  }, [canvases]);
  const browserStatus = reactExports.useMemo(
    () => getBrowserStatus(browserCanvas, port80Canvas, port443Canvas),
    [browserCanvas, port80Canvas, port443Canvas]
  );
  const port80Domain = reactExports.useMemo(() => getDomainFromCanvas(port80Canvas), [port80Canvas]);
  const certificateDomain = reactExports.useMemo(
    () => getCertificateDomain(letsencryptCanvas),
    [letsencryptCanvas]
  );
  const httpReady = reactExports.useMemo(() => isPort80Complete(port80Canvas), [port80Canvas]);
  const httpsReady = reactExports.useMemo(() => isPort443Complete(port443Canvas), [port443Canvas]);
  const hasRedirect = reactExports.useMemo(() => isPort80RedirectConfigured(port80Canvas), [port80Canvas]);
  const certificateIssued = reactExports.useMemo(() => {
    const domainItem = letsencryptCanvas?.placedItems.find(
      (i) => i.type === "domain-ssl"
    );
    return !!domainItem?.data?.certificateIssued;
  }, [letsencryptCanvas]);
  reactExports.useEffect(() => {
    if (!letsencryptCanvas) return;
    const domainItem = letsencryptCanvas.placedItems.find(
      (item) => item.type === "domain-ssl"
    );
    if (!domainItem) return;
    const nextStatus = certificateIssued ? "success" : "warning";
    if (domainItem.status !== nextStatus) {
      dispatchConfig(domainItem.id, { status: nextStatus });
    }
  }, [certificateIssued, dispatchConfig, letsencryptCanvas]);
  const port80Config = reactExports.useMemo(() => {
    const types = port80Canvas?.placedItems.map((i) => i.type) ?? [];
    return {
      hasWebserver: types.includes("webserver-80"),
      hasDomain: types.includes("domain"),
      hasIndexHtml: types.includes("index-html"),
      isComplete: isPort80Complete(port80Canvas)
    };
  }, [port80Canvas]);
  const port443SslStatus = reactExports.useMemo(() => {
    const types = port443Canvas?.placedItems.map((i) => i.type) ?? [];
    return {
      hasWebserver: types.includes("webserver-443"),
      hasDomain: types.includes("domain"),
      hasIndexHtml: types.includes("index-html"),
      hasPrivateKey: types.includes("private-key"),
      hasCertificate: types.includes("certificate"),
      isComplete: isPort443Complete(port443Canvas)
    };
  }, [port443Canvas]);
  const letsencryptModalOpen = reactExports.useMemo(
    () => (state.overlay?.activeModal?.id?.includes("letsencrypt") || state.overlay?.activeModal?.id?.includes("certificate")) ?? false,
    [state.overlay]
  );
  reactExports.useEffect(() => {
    if (state.question.status === "completed") {
      return;
    }
    if (browserCanvas) {
      const browserItem = browserCanvas.placedItems.find((item) => item.type === "browser");
      if (browserItem) {
        if (browserItem.status !== browserStatus) {
          dispatchConfig(browserItem.id, { status: browserStatus });
        }
        const currentDomain = typeof browserItem.data?.domain === "string" ? browserItem.data.domain : null;
        const targetDomain = port80Domain ?? DEFAULT_DOMAIN;
        if (currentDomain !== targetDomain) {
          dispatchConfig(browserItem.id, { domain: targetDomain });
        }
      }
    }
  }, [browserCanvas, browserStatus, port80Domain, dispatchConfig, state.question.status]);
  reactExports.useEffect(() => {
    if (state.question.status === "completed") {
      return;
    }
    if (port80Canvas) {
      const webserver = port80Canvas.placedItems.find(
        (item) => item.type === "webserver-80"
      );
      if (webserver) {
        const types = port80Canvas.placedItems.map((item) => item.type);
        const hasDomain = types.includes("domain");
        const hasIndexHtml = types.includes("index-html");
        const hasRedirect2 = types.includes("redirect-to-https");
        const isComplete = isPort80Complete(port80Canvas);
        let nextStatus = "error";
        let stateLabel = "Not configured";
        if (isComplete && hasRedirect2) {
          nextStatus = "success";
          stateLabel = "Redirecting to HTTPS";
        } else if (isComplete) {
          nextStatus = "warning";
          stateLabel = "Serving HTTP";
        }
        const nextDomain = hasDomain ? getDomainFromCanvas(port80Canvas) : null;
        const nextServingFile = hasRedirect2 ? "Redirect to HTTPS" : hasIndexHtml ? DEFAULT_INDEX_HTML : null;
        const currentState = typeof webserver.data?.state === "string" ? webserver.data.state : null;
        const currentDomain = typeof webserver.data?.domain === "string" ? webserver.data.domain : null;
        const currentServingFile = typeof webserver.data?.servingFile === "string" ? webserver.data.servingFile : null;
        if (webserver.status !== nextStatus || currentState !== stateLabel || currentDomain !== nextDomain || currentServingFile !== nextServingFile) {
          dispatchConfig(webserver.id, {
            status: nextStatus,
            state: stateLabel,
            domain: nextDomain,
            servingFile: nextServingFile
          });
        }
      }
    }
    if (port443Canvas) {
      const webserver = port443Canvas.placedItems.find(
        (item) => item.type === "webserver-443"
      );
      if (webserver) {
        const types = port443Canvas.placedItems.map((item) => item.type);
        const hasDomain = types.includes("domain");
        const hasIndexHtml = types.includes("index-html");
        const hasPrivateKey = types.includes("private-key");
        const hasCertificate = types.includes("certificate");
        const hasBasics = hasDomain && hasIndexHtml;
        const hasSsl = hasPrivateKey && hasCertificate;
        let nextStatus = "error";
        let stateLabel = "Not configured";
        if (hasBasics && hasSsl) {
          nextStatus = "success";
          stateLabel = "Serving HTTPS";
        } else if (hasBasics) {
          nextStatus = "warning";
          stateLabel = "Missing SSL";
        }
        const nextDomain = hasDomain ? getDomainFromCanvas(port443Canvas) : null;
        const nextServingFile = hasIndexHtml ? DEFAULT_INDEX_HTML : null;
        const nextPrivateKey = hasPrivateKey ? "✓ Installed" : null;
        const nextCertificate = hasCertificate ? "✓ Installed" : null;
        const currentState = typeof webserver.data?.state === "string" ? webserver.data.state : null;
        const currentDomain = typeof webserver.data?.domain === "string" ? webserver.data.domain : null;
        const currentServingFile = typeof webserver.data?.servingFile === "string" ? webserver.data.servingFile : null;
        const currentPrivateKey = typeof webserver.data?.privateKey === "string" ? webserver.data.privateKey : null;
        const currentCertificate = typeof webserver.data?.certificate === "string" ? webserver.data.certificate : null;
        if (webserver.status !== nextStatus || currentState !== stateLabel || currentDomain !== nextDomain || currentServingFile !== nextServingFile || currentPrivateKey !== nextPrivateKey || currentCertificate !== nextCertificate) {
          dispatchConfig(webserver.id, {
            status: nextStatus,
            state: stateLabel,
            domain: nextDomain,
            privateKey: nextPrivateKey,
            certificate: nextCertificate,
            servingFile: nextServingFile
          });
        }
      }
    }
  }, [dispatchConfig, port443Canvas, port80Canvas, state.question.status]);
  reactExports.useEffect(() => {
    if (letsencryptCanvas) {
      letsencryptCanvas.placedItems.find(
        (item) => item.type === "domain-ssl"
      );
    }
  }, [letsencryptCanvas]);
  return {
    browserCanvas,
    port80Canvas,
    letsencryptCanvas,
    port443Canvas,
    allPlacedItems,
    httpReady,
    httpsReady,
    hasRedirect,
    certificateIssued,
    browserStatus,
    port80Domain,
    certificateDomain,
    port80Config,
    port443SslStatus,
    letsencryptModalOpen,
    dispatch,
    state
  };
};
const useSslTerminal = ({
  hasRedirect,
  port80Domain,
  certificateDomain,
  onQuestionComplete
}) => {
  const dispatch = useGameDispatch();
  const canvases = useAllCanvases();
  const port80Canvas = reactExports.useMemo(
    () => canvases["port-80"],
    [canvases]
  );
  const port443Canvas = reactExports.useMemo(
    () => canvases["port-443"],
    [canvases]
  );
  return reactExports.useCallback(
    (input, helpers) => {
      const trimmedInput = input.trim();
      if (trimmedInput.length === 0) return;
      const tokens = trimmedInput.split(/\s+/);
      const command = tokens[0]?.toLowerCase();
      const getDomain = () => port80Domain || certificateDomain || "example.com";
      const isHttpReady = isPort80Complete(port80Canvas);
      const isHttpsReadyNow = isPort443Complete(port443Canvas);
      const hasRedirectNow = isPort80RedirectConfigured(port80Canvas);
      if (command === "curl") {
        if (tokens.includes("-h") || tokens.includes("--help")) {
          helpers.writeOutput(
            "Usage: curl [options] <url>\n\nOptions:\n  -I, --head     Show document headers only\n  -v, --verbose  Make the operation more talkative\n  -k, --insecure  Allow insecure server connections (skip SSL)\n\nExamples:\n  curl http://example.com\n  curl https://example.com",
            "output"
          );
          return;
        }
        const verbose = tokens.includes("-v") || tokens.includes("--verbose");
        const headOnly = tokens.includes("-I") || tokens.includes("--head");
        const insecure = tokens.includes("-k") || tokens.includes("--insecure");
        let url = "";
        for (let i = tokens.length - 1; i >= 1; i--) {
          if (tokens[i].startsWith("http://") || tokens[i].startsWith("https://")) {
            url = tokens[i];
            break;
          }
        }
        if (!url) {
          helpers.writeOutput("Error: No URL specified. Usage: curl <url>", "error");
          return;
        }
        const targetUrl = url.toLowerCase();
        if (targetUrl.startsWith("http://")) {
          if (hasRedirect || hasRedirectNow) {
            const domain = getDomain();
            if (verbose) {
              helpers.writeOutput(`* Trying ${domain}...`, "output");
              helpers.writeOutput(`* Connected to ${domain} (127.0.0.1) port 80`, "output");
            }
            helpers.writeOutput("HTTP/1.1 301 Moved Permanently", "output");
            helpers.writeOutput(`Location: https://${domain}/`, "output");
            helpers.writeOutput("", "output");
            helpers.writeOutput("Redirecting to HTTPS...", "hint");
          } else if (isHttpReady) {
            if (verbose) {
              helpers.writeOutput(`* Trying ${getDomain()}...`, "output");
              helpers.writeOutput(`* Connected to ${getDomain()} (127.0.0.1) port 80`, "output");
            }
            helpers.writeOutput("HTTP/1.1 200 OK", "output");
            helpers.writeOutput("Content-Type: text/html", "output");
            if (!headOnly) {
              helpers.writeOutput("", "output");
              helpers.writeOutput(INDEX_HTML_CONTENT, "output");
            }
          } else {
            helpers.writeOutput("Error: Connection refused. Webserver not configured.", "error");
          }
          return;
        }
        if (targetUrl.startsWith("https://")) {
          if (insecure) {
            helpers.writeOutput("Error: --insecure flag not supported in this simulation.", "error");
            return;
          }
          if (!isHttpsReadyNow) {
            helpers.writeOutput("Error: SSL handshake failed. Certificate not found.", "error");
            return;
          }
          const domain = getDomain();
          if (verbose) {
            helpers.writeOutput(`* Trying ${domain}:443...`, "output");
            helpers.writeOutput(`* Connected to ${domain} (127.0.0.1) port 443`, "output");
            helpers.writeOutput("* TLS 1.3 connection using TLS_AES_256_GCM_SHA384", "output");
            helpers.writeOutput("* Server certificate:", "output");
            helpers.writeOutput(`*  subject: ${domain}`, "output");
            helpers.writeOutput("*  issuer: Let's Encrypt Authority X3", "output");
            helpers.writeOutput("*  SSL certificate verify ok.", "output");
          }
          helpers.writeOutput("🔒 TLS Handshake successful", "hint");
          helpers.writeOutput(`   Certificate: ${domain}`, "output");
          helpers.writeOutput("   Issuer: Let's Encrypt", "output");
          helpers.writeOutput("", "output");
          helpers.writeOutput("HTTP/1.1 200 OK", "output");
          helpers.writeOutput("Content-Type: text/html", "output");
          if (!headOnly) {
            helpers.writeOutput("", "output");
            helpers.writeOutput(INDEX_HTML_CONTENT, "output");
          }
          if (isHttpsReadyNow && (hasRedirectNow || hasRedirect)) {
            dispatch({
              type: "OPEN_MODAL",
              payload: buildSuccessModal(onQuestionComplete)
            });
            helpers.finishEngine();
            dispatch({ type: "COMPLETE_QUESTION" });
          }
          return;
        }
        helpers.writeOutput("Error: Unknown URL scheme. Use http:// or https://", "error");
        return;
      }
      if (command === "openssl") {
        const subCommand = tokens[1]?.toLowerCase();
        if (subCommand === "s_client") {
          let url = "";
          for (let i = tokens.length - 1; i >= 2; i--) {
            if (tokens[i].startsWith("https://") || tokens[i].startsWith("http://")) {
              url = tokens[i];
              break;
            }
          }
          if (!url) {
            helpers.writeOutput("Usage: openssl s_client <url>", "output");
            return;
          }
          const targetUrl = url.toLowerCase();
          if (!targetUrl.startsWith("https://")) {
            helpers.writeOutput("Error: s_client requires an https:// URL", "error");
            return;
          }
          if (!isHttpsReadyNow) {
            helpers.writeOutput("Error: SSL handshake failed. The server doesn't have a certificate configured.", "error");
            return;
          }
          const domain = getDomain();
          helpers.writeOutput(`CONNECTED(${Date.now() % 1e6})`, "output");
          helpers.writeOutput("---", "output");
          helpers.writeOutput("Certificate chain", "output");
          helpers.writeOutput(` 0 s:${domain}`, "output");
          helpers.writeOutput("   i:R3", "output");
          helpers.writeOutput("---", "output");
          helpers.writeOutput(`Server certificate`, "output");
          helpers.writeOutput(`subject=${domain}`, "output");
          helpers.writeOutput("issuer=Let's Encrypt Authority X3", "output");
          helpers.writeOutput("---", "output");
          helpers.writeOutput("Verify return code: 0 (ok)", "hint");
          return;
        }
        helpers.writeOutput("Available openssl commands: s_client", "output");
        return;
      }
      if (command === "help" || command === "?") {
        helpers.writeOutput(
          "Available commands:\n  curl <url>           Test HTTP/HTTPS connection\n    curl http://example.com\n    curl https://example.com\n    curl -v https://example.com  (verbose)\n    curl -I https://example.com  (headers only)\n\n  openssl s_client <url>  View SSL certificate details\n    openssl s_client https://example.com\n\n  help                  Show this help message\n  clear                 Clear terminal history",
          "output"
        );
        return;
      }
      if (command === "clear") {
        helpers.clearHistory();
        return;
      }
      helpers.writeOutput(`Unknown command: ${command}. Type 'help' for available commands.`, "error");
    },
    [
      hasRedirect,
      port80Domain,
      certificateDomain,
      dispatch,
      onQuestionComplete,
      port80Canvas,
      port443Canvas
    ]
  );
};
const WebserverSslQuestion = ({ onQuestionComplete }) => {
  return /* @__PURE__ */ jsxRuntimeExports.jsx(GameProvider, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(WebserverSslGame, { onQuestionComplete }) });
};
const WebserverSslGame = ({
  onQuestionComplete
}) => {
  const dispatch = useGameDispatch();
  const state = useGameState();
  const terminalInput = useTerminalInput();
  const isCompleted = state.question.status === "completed";
  const initializedRef = reactExports.useRef(false);
  const [showTlsModal, setShowTlsModal] = reactExports.useState(false);
  const [prevSecureState, setPrevSecureState] = reactExports.useState(false);
  const [sslCanvasesUnlocked, setSslCanvasesUnlocked] = reactExports.useState(false);
  const inventoryShownRef = reactExports.useRef({
    "ssl-setup": false,
    "ssl-items": false
  });
  const inventoryGroups = reactExports.useMemo(
    () => [
      {
        id: "ssl-setup",
        title: "SSL Setup",
        visible: false,
        items: SSL_SETUP_INVENTORY_ITEMS
      },
      {
        id: "ssl-items",
        title: "SSL Certificate",
        visible: false,
        items: SSL_ITEMS_INVENTORY
      },
      {
        id: "basic",
        title: "Basic Components",
        visible: true,
        items: BASIC_INVENTORY_ITEMS
      }
    ],
    []
  );
  const dragEngine = useDragEngine();
  const sslState = useSslState();
  const handleCommand = useSslTerminal({
    hasRedirect: sslState.hasRedirect,
    port80Domain: sslState.port80Domain,
    certificateDomain: sslState.certificateDomain,
    onQuestionComplete
  });
  useTerminalEngine({
    onCommand: handleCommand
  });
  const itemClickHandlers = reactExports.useMemo(
    () => ({
      browser: ({ item }) => {
        const url = item.data?.url;
        const connection = item.data?.connection;
        const port = item.data?.port;
        dispatch({
          type: "OPEN_MODAL",
          payload: buildBrowserStatusModal(
            item.id,
            { url, connection, port },
            showTlsModal && sslState.browserStatus === "success"
          )
        });
      },
      "webserver-80": ({ item }) => {
        const status = item.data?.state;
        const domain = item.data?.domain;
        const servingFile = item.data?.servingFile;
        dispatch({
          type: "OPEN_MODAL",
          payload: buildWebserver80StatusModal(item.id, {
            status,
            domain,
            servingFile
          })
        });
      },
      "webserver-443": ({ item }) => {
        const status = item.data?.state;
        const domain = item.data?.domain;
        const privateKey = item.data?.privateKey;
        const certificate = item.data?.certificate;
        const servingFile = item.data?.servingFile;
        dispatch({
          type: "OPEN_MODAL",
          payload: buildWebserver443StatusModal(item.id, {
            status,
            domain,
            privateKey,
            certificate,
            servingFile
          })
        });
      },
      "domain-ssl": ({ item }) => {
        const isInLetsencrypt = sslState.letsencryptCanvas?.placedItems.some(
          (entry) => entry.id === item.id
        );
        if (!isInLetsencrypt) {
          return;
        }
        const currentDomain = typeof item.data?.domain === "string" ? item.data.domain : sslState.port80Domain;
        const certificateIssued = !!sslState.certificateIssued;
        dispatch({
          type: "OPEN_MODAL",
          payload: buildCertificateRequestModal(
            item.id,
            currentDomain || "",
            certificateIssued,
            { domain: sslState.port80Domain }
          )
        });
      },
      "private-key": ({ item }) => {
        dispatch({
          type: "OPEN_MODAL",
          payload: buildPrivateKeyInfoModal(item.id)
        });
      },
      certificate: ({ item }) => {
        dispatch({
          type: "OPEN_MODAL",
          payload: buildCertificateInfoModal(
            item.id,
            sslState.port443SslStatus.hasCertificate
          )
        });
      },
      "redirect-to-https": ({ item }) => {
        dispatch({
          type: "OPEN_MODAL",
          payload: buildRedirectInfoModal(item.id)
        });
      },
      "index-html": ({ item }) => {
        dispatch({
          type: "OPEN_MODAL",
          payload: buildIndexHtmlViewModal(item.id)
        });
      }
    }),
    [
      dispatch,
      showTlsModal,
      sslState.browserStatus,
      sslState.certificateIssued,
      sslState.letsencryptCanvas,
      sslState.port443SslStatus.hasCertificate,
      sslState.port80Domain
    ]
  );
  const spec = reactExports.useMemo(
    () => ({
      meta: {
        id: QUESTION_ID,
        title: QUESTION_TITLE,
        description: QUESTION_DESCRIPTION
      },
      init: {
        kind: "multi",
        payload: {
          questionId: QUESTION_ID,
          canvases: CANVAS_CONFIGS,
          inventoryGroups,
          terminal: {
            visible: false,
            prompt: TERMINAL_PROMPT,
            history: TERMINAL_INTRO_ENTRIES
          },
          phase: "setup",
          questionStatus: "in_progress"
        }
      },
      phaseRules: [
        {
          kind: "set",
          when: { kind: "eq", key: "questionStatus", value: "completed" },
          to: "completed"
        },
        {
          kind: "set",
          when: {
            kind: "and",
            all: [
              { kind: "flag", key: "httpsReady", is: true },
              { kind: "flag", key: "hasRedirect", is: true },
              { kind: "eq", key: "browserStatus", value: "success" }
            ]
          },
          to: "terminal"
        },
        {
          kind: "set",
          when: {
            kind: "and",
            all: [
              { kind: "flag", key: "httpReady", is: true },
              { kind: "eq", key: "browserStatus", value: "warning" }
            ]
          },
          to: "playing"
        }
      ],
      inventoryRules: [
        {
          kind: "show-group",
          groupId: "ssl-setup",
          when: {
            kind: "and",
            all: [
              { kind: "flag", key: "httpReady", is: true },
              { kind: "eq", key: "browserStatus", value: "warning" }
            ]
          }
        },
        {
          kind: "show-group",
          groupId: "ssl-items",
          when: { kind: "flag", key: "certificateIssued", is: true }
        }
      ],
      canvasRules: [
        {
          kind: "show",
          canvasKey: "letsencrypt",
          when: {
            kind: "or",
            any: [
              { kind: "flag", key: "httpReady", is: true },
              { kind: "flag", key: "sslUnlocked", is: true }
            ]
          }
        },
        {
          kind: "show",
          canvasKey: "port-443",
          when: {
            kind: "or",
            any: [
              { kind: "flag", key: "httpReady", is: true },
              { kind: "flag", key: "sslUnlocked", is: true }
            ]
          }
        }
      ],
      labels: {
        getItemLabel: getSslItemLabel,
        getStatusMessage: getSslStatusMessage
      },
      handlers: {
        onCommand: handleCommand,
        onItemClickByType: itemClickHandlers,
        isItemClickableByType: {
          browser: true,
          "webserver-80": true,
          "webserver-443": true,
          domain: true,
          "domain-ssl": true,
          "private-key": true,
          certificate: true,
          "redirect-to-https": true,
          "index-html": true
        }
      }
    }),
    [handleCommand, inventoryGroups, itemClickHandlers]
  );
  reactExports.useEffect(() => {
    if (initializedRef.current) {
      return;
    }
    initializedRef.current = true;
    dispatch({
      type: "INIT_MULTI_CANVAS",
      payload: spec.init.payload
    });
  }, [dispatch, spec.init.payload]);
  reactExports.useEffect(() => {
    if (!dragEngine) return;
    if (state.question.status === "completed") return;
    const context = {
      questionStatus: state.question.status,
      httpReady: sslState.httpReady,
      httpsReady: sslState.httpsReady,
      hasRedirect: sslState.hasRedirect,
      browserStatus: sslState.browserStatus,
      certificateIssued: sslState.certificateIssued,
      sslUnlocked: sslCanvasesUnlocked
    };
    const resolved = resolvePhase(
      spec.phaseRules,
      context,
      state.phase,
      "setup"
    );
    if (sslState.httpReady && sslState.browserStatus === "warning") {
      if (!sslCanvasesUnlocked) {
        setSslCanvasesUnlocked(true);
      }
    }
    if (spec.inventoryRules) {
      const shouldShowSslSetup = resolveVisibility(
        spec.inventoryRules,
        context,
        "ssl-setup",
        inventoryShownRef.current["ssl-setup"]
      );
      if (shouldShowSslSetup && !inventoryShownRef.current["ssl-setup"]) {
        inventoryShownRef.current["ssl-setup"] = true;
        dispatch({
          type: "UPDATE_INVENTORY_GROUP",
          payload: { id: "ssl-setup", visible: true }
        });
      }
      const shouldShowSslItems = resolveVisibility(
        spec.inventoryRules,
        context,
        "ssl-items",
        inventoryShownRef.current["ssl-items"]
      );
      if (shouldShowSslItems && !inventoryShownRef.current["ssl-items"]) {
        inventoryShownRef.current["ssl-items"] = true;
        dispatch({
          type: "UPDATE_INVENTORY_GROUP",
          payload: { id: "ssl-items", visible: true }
        });
      }
    }
    let desiredPhase = resolved.nextPhase;
    if (sslCanvasesUnlocked && desiredPhase === "setup") {
      desiredPhase = state.phase;
    }
    if (state.phase !== desiredPhase) {
      dispatch({ type: "SET_PHASE", payload: { phase: desiredPhase } });
    }
  }, [
    dispatch,
    spec.inventoryRules,
    spec.phaseRules,
    state.phase,
    state.question.status,
    sslState.httpReady,
    sslState.browserStatus,
    sslState.certificateIssued,
    sslState.httpsReady,
    sslState.hasRedirect,
    sslCanvasesUnlocked,
    dragEngine
  ]);
  reactExports.useEffect(() => {
    if (!prevSecureState && sslState.browserStatus === "success" && sslState.httpsReady && sslState.hasRedirect) {
      dispatch({
        type: "OPEN_MODAL",
        payload: buildTlsHandshakeModal()
      });
      setShowTlsModal(true);
    }
    setPrevSecureState(
      sslState.browserStatus === "success" && sslState.httpsReady && sslState.hasRedirect
    );
  }, [
    dispatch,
    prevSecureState,
    sslState.browserStatus,
    sslState.httpsReady,
    sslState.hasRedirect
  ]);
  const contextualHint = reactExports.useMemo(
    () => getContextualHint({
      browserCanvas: sslState.browserCanvas,
      port80Canvas: sslState.port80Canvas,
      letsencryptCanvas: sslState.letsencryptCanvas,
      port443Canvas: sslState.port443Canvas,
      certificateIssued: sslState.certificateIssued,
      browserStatus: sslState.browserStatus,
      letsencryptModalOpen: sslState.letsencryptModalOpen
    }),
    [
      sslState.browserCanvas,
      sslState.port80Canvas,
      sslState.letsencryptCanvas,
      sslState.port443Canvas,
      sslState.allPlacedItems,
      sslState.httpReady,
      sslState.httpsReady,
      sslState.certificateIssued,
      sslState.browserStatus,
      sslState.letsencryptModalOpen
    ]
  );
  const handlePlacedItemClick = reactExports.useCallback(
    (item) => {
      const handler = spec.handlers.onItemClickByType[item.type];
      if (handler) {
        handler({ item });
      }
    },
    [spec.handlers.onItemClickByType]
  );
  const isItemClickable = reactExports.useCallback(
    (item) => spec.handlers.isItemClickableByType[item.type] === true,
    [spec.handlers.isItemClickableByType]
  );
  const shouldShowCanvas = reactExports.useCallback(
    (key) => {
      const context = {
        questionStatus: state.question.status,
        httpReady: sslState.httpReady,
        httpsReady: sslState.httpsReady,
        hasRedirect: sslState.hasRedirect,
        browserStatus: sslState.browserStatus,
        certificateIssued: sslState.certificateIssued,
        sslUnlocked: sslCanvasesUnlocked
      };
      const defaultVisible = key === "browser" || key === "port-80";
      if (!spec.canvasRules) {
        return defaultVisible;
      }
      return resolveVisibility(spec.canvasRules, context, key, defaultVisible);
    },
    [
      spec.canvasRules,
      sslCanvasesUnlocked,
      sslState.browserStatus,
      sslState.certificateIssued,
      sslState.hasRedirect,
      sslState.httpReady,
      sslState.httpsReady,
      state.question.status
    ]
  );
  return /* @__PURE__ */ jsxRuntimeExports.jsx(GameShell, { getItemLabel: spec.labels.getItemLabel, children: /* @__PURE__ */ jsxRuntimeExports.jsxs(
    Flex,
    {
      direction: "column",
      px: { base: 2, md: 12, lg: 24 },
      py: { base: 2, md: 6 },
      children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs(Box, { textAlign: "left", mb: { base: 2, md: 4 }, pb: { base: 1, md: 0 }, children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            Text,
            {
              fontSize: { base: "2xl", md: "4xl" },
              fontWeight: "bold",
              color: "gray.50",
              children: QUESTION_TITLE
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsx(Text, { fontSize: { base: "sm", md: "md" }, color: "gray.400", children: QUESTION_DESCRIPTION })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          Flex,
          {
            direction: { base: "column", xl: "row" },
            gap: { base: 2, md: 4 },
            align: { base: "stretch", xl: "flex-start" },
            children: CANVAS_ORDER.map((key) => {
              if (!shouldShowCanvas(key)) {
                return null;
              }
              const config = CANVAS_CONFIGS[key];
              if (!config) {
                return null;
              }
              const stateKey = config.stateKey ?? key;
              return /* @__PURE__ */ jsxRuntimeExports.jsx(
                Box,
                {
                  flexGrow: config.columns,
                  flexBasis: 0,
                  minW: { base: "100%", xl: "0" },
                  children: /* @__PURE__ */ jsxRuntimeExports.jsx(
                    PlayCanvas,
                    {
                      stateKey,
                      title: config.title ?? key,
                      getItemLabel: spec.labels.getItemLabel,
                      getStatusMessage: spec.labels.getStatusMessage,
                      onPlacedItemClick: handlePlacedItemClick,
                      isItemClickable
                    }
                  )
                },
                key
              );
            })
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsx(InventoryDrawer, { tooltips: INVENTORY_TOOLTIPS }),
        contextualHint && /* @__PURE__ */ jsxRuntimeExports.jsx(
          Box,
          {
            bg: "gray.800",
            border: "1px solid",
            borderColor: "gray.700",
            borderRadius: "md",
            px: 4,
            py: 2,
            textAlign: "center",
            mb: 4,
            children: /* @__PURE__ */ jsxRuntimeExports.jsx(Text, { fontSize: "sm", color: "gray.100", children: contextualHint })
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          TerminalLayout,
          {
            visible: state.terminal.visible,
            focusRef: terminalInput.inputRef,
            view: /* @__PURE__ */ jsxRuntimeExports.jsx(
              TerminalView,
              {
                history: state.terminal.history,
                prompt: state.terminal.prompt,
                isCompleted
              }
            ),
            input: /* @__PURE__ */ jsxRuntimeExports.jsx(
              TerminalInput,
              {
                value: terminalInput.value,
                onChange: terminalInput.onChange,
                onKeyDown: terminalInput.onKeyDown,
                inputRef: terminalInput.inputRef,
                placeholder: isCompleted ? "Terminal disabled" : "Type a command",
                disabled: isCompleted
              }
            )
          }
        )
      ]
    }
  ) });
};
const WebserverSslQuestionRoute = () => {
  const navigate = useNavigate();
  const handleQuestionComplete = () => {
    markNetworkingQuestionComplete("webserver-ssl");
    const nextPath = getNextQuestionPath("webserver-ssl");
    void navigate({
      to: nextPath ?? "/questions/networking"
    });
  };
  return /* @__PURE__ */ jsxRuntimeExports.jsx(WebserverSslQuestion, { onQuestionComplete: handleQuestionComplete });
};
export {
  WebserverSslQuestionRoute as component
};
