import { r as reactExports } from "../_libs/react.mjs";
import { a as useGameState, i as useEngineProgress } from "./question-ast-DxRXheAC.mjs";
const useDragEngine = (config = {}) => {
  const { autoStart = true, ...progressOptions } = config;
  const gameState = useGameState();
  const controller = useEngineProgress(progressOptions);
  const hasAutoStarted = reactExports.useRef(false);
  const state = reactExports.useMemo(
    () => ({
      canvas: gameState.canvas,
      placedItems: gameState.canvas.placedItems,
      connections: gameState.canvas.connections
    }),
    [gameState.canvas]
  );
  reactExports.useEffect(() => {
    if (!autoStart) return;
    if (hasAutoStarted.current) return;
    if (controller.progress.status !== "pending") return;
    if (state.placedItems.length === 0 && state.connections.length === 0)
      return;
    hasAutoStarted.current = true;
    controller.start();
  }, [
    autoStart,
    controller,
    state.placedItems.length,
    state.connections.length
  ]);
  return { ...controller, state };
};
export {
  useDragEngine as u
};
