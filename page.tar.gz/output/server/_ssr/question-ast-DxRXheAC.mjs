import { r as reactExports, j as jsxRuntimeExports } from "../_libs/react.mjs";
import { g as gsapWithCSS, D as Draggable, I as InertiaPlugin } from "../_libs/gsap.mjs";
import { r as reactDomExports } from "../_libs/react-dom.mjs";
import { I as Icon } from "../_libs/@iconify/react.mjs";
import { B as Box, u as useBreakpointValue, F as Flex, T as Text, e as Input, c as Button, L as Link, f as CheckboxRoot, g as CheckboxHiddenInput, h as CheckboxControl, i as CheckboxIndicator, j as CheckboxLabel, k as Textarea, l as TooltipRoot, m as TooltipTrigger, n as TooltipPositioner, o as TooltipContent, p as TooltipArrow, q as TooltipArrowTip } from "../_libs/@chakra-ui/react.mjs";
import { I as Info } from "../_libs/lucide-react.mjs";
import { P as Portal } from "../_libs/@ark-ui/react.mjs";
const MAX_HISTORY_ENTRIES = 100;
const MAX_INPUT_LENGTH$1 = 200;
const MAX_OUTPUT_LENGTH = 500;
const MAX_CONFIG_VALUE_LENGTH = 100;
const MAX_INVENTORY_ITEMS = 50;
const DEFAULT_INVENTORY_GROUP_ID = "default";
const DEFAULT_INVENTORY_TITLE = "Inventory";
const defaultCanvasConfig = {
  id: "default-canvas",
  columns: 6,
  rows: 4,
  orientation: "horizontal"
};
const sanitizeText = (value, maxLength) => value.slice(0, maxLength).replace(/<[^>]*>/g, "").replace(/[<>"'&]/g, "").trim();
const sanitizeTerminalInput = (input) => sanitizeText(input, MAX_INPUT_LENGTH$1);
const sanitizeTerminalOutput = (output) => sanitizeText(output, MAX_OUTPUT_LENGTH);
const sanitizeConfigValue = (value) => sanitizeText(value, MAX_CONFIG_VALUE_LENGTH);
const sanitizeDeviceConfig = (config) => {
  const sanitized = {};
  for (const [key, value] of Object.entries(config)) {
    if (value === null) {
      sanitized[key] = null;
      continue;
    }
    if (typeof value === "string") {
      sanitized[key] = sanitizeConfigValue(value);
      continue;
    }
    if (typeof value === "number" || typeof value === "boolean") {
      sanitized[key] = value;
    }
  }
  return sanitized;
};
const createBlockGrid = (columns, rows) => Array.from(
  { length: rows },
  (_, rowIndex) => Array.from({ length: columns }, (_2, colIndex) => ({
    x: colIndex,
    y: rowIndex,
    status: "empty"
  }))
);
const createCanvasState = (config) => ({
  config,
  blocks: createBlockGrid(config.columns, config.rows),
  placedItems: [],
  connections: [],
  selectedBlock: null
});
const resolveCanvasState = (state, stateKey) => {
  if (!stateKey) {
    return state.canvas;
  }
  return state.canvases?.[stateKey] ?? state.canvas;
};
const updateCanvasState = (state, stateKey, nextCanvas) => {
  if (!stateKey) {
    return { ...state, canvas: nextCanvas };
  }
  const nextPrimary = state.canvas.config.stateKey === stateKey ? nextCanvas : state.canvas;
  return {
    ...state,
    canvas: nextPrimary,
    canvases: {
      ...state.canvases ?? {},
      [stateKey]: nextCanvas
    }
  };
};
const updateBlock = (blocks, blockX, blockY, updates) => {
  if (!blocks[blockY]?.[blockX]) {
    return blocks;
  }
  const nextBlocks = blocks.slice();
  const nextRow = nextBlocks[blockY].slice();
  nextRow[blockX] = { ...nextRow[blockX], ...updates };
  nextBlocks[blockY] = nextRow;
  return nextBlocks;
};
const addHistoryEntry = (history, entry) => {
  const nextHistory = [...history, entry];
  if (nextHistory.length > MAX_HISTORY_ENTRIES) {
    return nextHistory.slice(-MAX_HISTORY_ENTRIES);
  }
  return nextHistory;
};
const normalizeInventory = (items) => items.filter(
  (item) => item && typeof item.id === "string" && typeof item.type === "string"
).slice(0, MAX_INVENTORY_ITEMS);
const normalizeInventoryGroup = (group, usedIds) => {
  if (!group || typeof group.id !== "string") {
    return null;
  }
  const normalizedItems = normalizeInventory(group.items ?? []).filter(
    (item) => {
      if (usedIds.has(item.id)) {
        return false;
      }
      usedIds.add(item.id);
      return true;
    }
  );
  return {
    id: group.id,
    title: typeof group.title === "string" && group.title.trim().length > 0 ? group.title : DEFAULT_INVENTORY_TITLE,
    visible: group.visible ?? true,
    items: normalizedItems
  };
};
const normalizeInventoryGroups = (inventoryGroups) => {
  const usedIds = /* @__PURE__ */ new Set();
  const groups = [];
  if (Array.isArray(inventoryGroups)) {
    for (const group of inventoryGroups) {
      const normalized = normalizeInventoryGroup(group, usedIds);
      if (!normalized) {
        continue;
      }
      if (groups.some((existing) => existing.id === normalized.id)) {
        continue;
      }
      groups.push(normalized);
    }
  }
  if (groups.length === 0) {
    groups.push({
      id: DEFAULT_INVENTORY_GROUP_ID,
      title: DEFAULT_INVENTORY_TITLE,
      visible: true,
      items: []
    });
  }
  return groups;
};
const findInventoryItem = (groups, itemId) => {
  for (let groupIndex = 0; groupIndex < groups.length; groupIndex += 1) {
    const itemIndex = groups[groupIndex].items.findIndex(
      (item) => item.id === itemId
    );
    if (itemIndex >= 0) {
      return {
        groupIndex,
        itemIndex,
        item: groups[groupIndex].items[itemIndex]
      };
    }
  }
  return null;
};
const findAvailableItemByType = (groups, itemType, canvases) => {
  for (let groupIndex = 0; groupIndex < groups.length; groupIndex += 1) {
    const itemIndex = groups[groupIndex].items.findIndex((item) => {
      if (item.type !== itemType) return false;
      const isOnCanvas = canvases ? Object.values(canvases).some(
        (canvas) => canvas.placedItems.some((placed) => placed.itemId === item.id)
      ) : false;
      return !isOnCanvas;
    });
    if (itemIndex >= 0) {
      return {
        groupIndex,
        itemIndex,
        item: groups[groupIndex].items[itemIndex]
      };
    }
  }
  return null;
};
const isItemOnCanvas = (itemId, canvases) => {
  if (!canvases) return false;
  return Object.values(canvases).some(
    (canvas) => canvas.placedItems.some((item) => item.itemId === itemId)
  );
};
const removeInventoryItems = (groups, itemIds) => groups.map((group) => ({
  ...group,
  items: group.items.filter((item) => !itemIds.has(item.id))
}));
const applyInitialPlacements = (canvas, inventoryGroups, allCanvases) => {
  const placements = canvas.config.initialPlacements ?? [];
  if (placements.length === 0) {
    return { canvas, inventoryGroups };
  }
  let nextBlocks = canvas.blocks;
  const nextInventoryGroups = inventoryGroups;
  const placedItems = [];
  const currentCanvasKey = canvas.config.stateKey ?? "canvas";
  placements.forEach((placement) => {
    if (!nextBlocks[placement.blockY]?.[placement.blockX]) {
      return;
    }
    if (nextBlocks[placement.blockY][placement.blockX].status === "occupied") {
      return;
    }
    let itemId = `initial-${placement.itemType}-${placement.blockX}-${placement.blockY}`;
    const canvasesForLookup = {
      ...allCanvases ?? {},
      [currentCanvasKey]: {
        ...canvas,
        placedItems
      }
    };
    const inventoryMatch = findAvailableItemByType(
      nextInventoryGroups,
      placement.itemType,
      canvasesForLookup
    );
    const matchedItem = inventoryMatch?.item;
    if (inventoryMatch) {
      itemId = inventoryMatch.item.id;
    }
    placedItems.push({
      id: itemId,
      itemId,
      type: placement.itemType,
      blockX: placement.blockX,
      blockY: placement.blockY,
      status: "normal",
      icon: matchedItem?.icon,
      behavior: matchedItem?.behavior,
      data: matchedItem?.data ?? {}
    });
    nextBlocks = updateBlock(nextBlocks, placement.blockX, placement.blockY, {
      status: "occupied",
      itemId
    });
  });
  return {
    canvas: {
      ...canvas,
      blocks: nextBlocks,
      placedItems,
      connections: deriveConnectionsFromCables(placedItems)
    },
    inventoryGroups: nextInventoryGroups
  };
};
const removeItemsFromCanvas = (canvas, itemIds) => {
  const removedItems = canvas.placedItems.filter(
    (item) => itemIds.has(item.itemId)
  );
  if (removedItems.length === 0) {
    return canvas;
  }
  let nextBlocks = canvas.blocks;
  for (const item of removedItems) {
    nextBlocks = updateBlock(nextBlocks, item.blockX, item.blockY, {
      status: "empty",
      itemId: void 0
    });
  }
  const nextPlacedItems = canvas.placedItems.filter(
    (item) => !itemIds.has(item.itemId)
  );
  return {
    ...canvas,
    blocks: nextBlocks,
    placedItems: nextPlacedItems,
    connections: deriveConnectionsFromCables(nextPlacedItems)
  };
};
const createDefaultState = () => ({
  phase: "setup",
  inventory: {
    groups: [
      {
        id: DEFAULT_INVENTORY_GROUP_ID,
        title: DEFAULT_INVENTORY_TITLE,
        visible: true,
        items: []
      }
    ]
  },
  canvas: createCanvasState(defaultCanvasConfig),
  crossConnections: [],
  sharedZone: { items: {} },
  terminal: {
    visible: false,
    prompt: "",
    history: []
  },
  overlay: {
    activeModal: null
  },
  question: {
    id: "",
    status: "in_progress"
  },
  sequence: 0
});
const createEntry = (state, type, content) => {
  const nextSequence = state.sequence + 1;
  return {
    entry: {
      id: `entry-${nextSequence}`,
      type,
      content,
      timestamp: nextSequence
    },
    sequence: nextSequence
  };
};
const normalizeConnectionKey = (from, to) => {
  if (from.y < to.y || from.y === to.y && from.x <= to.x) {
    return `${from.x},${from.y}-${to.x},${to.y}`;
  }
  return `${to.x},${to.y}-${from.x},${from.y}`;
};
const CONNECTABLE_DEVICE_TYPES = /* @__PURE__ */ new Set(["pc", "router"]);
const isConnectableDevice = (item) => Boolean(item && CONNECTABLE_DEVICE_TYPES.has(item.type));
const deriveConnectionsFromCables = (placedItems) => {
  const byCoord = /* @__PURE__ */ new Map();
  placedItems.forEach((item) => {
    byCoord.set(`${item.blockX}-${item.blockY}`, item);
  });
  const connections = [];
  const seen = /* @__PURE__ */ new Set();
  const maybeAddConnection = (from, to) => {
    if (!isConnectableDevice(from) || !isConnectableDevice(to)) {
      return;
    }
    if (from.type === to.type) {
      return;
    }
    const fromCoord = { x: from.blockX, y: from.blockY };
    const toCoord = { x: to.blockX, y: to.blockY };
    const key = normalizeConnectionKey(fromCoord, toCoord);
    if (seen.has(key)) {
      return;
    }
    seen.add(key);
    connections.push({
      id: `connection-${key}-link`,
      type: "cable",
      from: fromCoord,
      to: toCoord
    });
  };
  placedItems.filter((item) => item.type === "cable").forEach((cable) => {
    const left = byCoord.get(`${cable.blockX - 1}-${cable.blockY}`);
    const right = byCoord.get(`${cable.blockX + 1}-${cable.blockY}`);
    const up = byCoord.get(`${cable.blockX}-${cable.blockY - 1}`);
    const down = byCoord.get(`${cable.blockX}-${cable.blockY + 1}`);
    if (left && right) {
      maybeAddConnection(left, right);
    }
    if (up && down) {
      maybeAddConnection(up, down);
    }
  });
  return connections;
};
const reducer = (state, action) => {
  switch (action.type) {
    case "INIT_MULTI_CANVAS": {
      const config = action.payload;
      const entries = Object.entries(config.canvases);
      if (entries.length === 0) {
        return state;
      }
      const stateKeys = /* @__PURE__ */ new Set();
      const normalizedCanvases = [];
      for (const [entryKey, canvasConfig] of entries) {
        const resolvedKey = canvasConfig.stateKey ?? entryKey;
        if (stateKeys.has(resolvedKey)) {
          return state;
        }
        stateKeys.add(resolvedKey);
        normalizedCanvases.push({ key: resolvedKey, config: canvasConfig });
      }
      let inventoryGroups = normalizeInventoryGroups(config.inventoryGroups);
      const nextCanvases = {};
      for (const entry of normalizedCanvases) {
        const key = entry.key;
        const canvasConfig = entry.config;
        const seeded = applyInitialPlacements(
          createCanvasState(canvasConfig),
          inventoryGroups,
          nextCanvases
        );
        inventoryGroups = seeded.inventoryGroups;
        nextCanvases[key] = seeded.canvas;
      }
      const firstKey = normalizedCanvases[0]?.key;
      if (!firstKey) {
        return state;
      }
      const firstCanvas = nextCanvases[firstKey];
      if (!firstCanvas) {
        return state;
      }
      const terminal = {
        ...state.terminal,
        ...config.terminal
      };
      return {
        ...createDefaultState(),
        phase: config.phase ?? "setup",
        inventory: { groups: inventoryGroups },
        canvas: firstCanvas,
        canvases: nextCanvases,
        terminal: {
          visible: terminal.visible ?? false,
          prompt: terminal.prompt ?? "",
          history: terminal.history ?? []
        },
        question: {
          id: config.questionId,
          status: config.questionStatus ?? "in_progress"
        }
      };
    }
    case "ADD_INVENTORY_GROUP": {
      const { group } = action.payload;
      if (state.inventory.groups.some((entry) => entry.id === group.id)) {
        return state;
      }
      const usedIds = /* @__PURE__ */ new Set();
      for (const entry of state.inventory.groups) {
        for (const item of entry.items) {
          usedIds.add(item.id);
        }
      }
      const normalized = normalizeInventoryGroup(group, usedIds);
      if (!normalized) {
        return state;
      }
      return {
        ...state,
        inventory: {
          groups: [...state.inventory.groups, normalized]
        }
      };
    }
    case "UPDATE_INVENTORY_GROUP": {
      const { id, title, visible, items } = action.payload;
      const groupIndex = state.inventory.groups.findIndex(
        (entry) => entry.id === id
      );
      if (groupIndex === -1) {
        return state;
      }
      let nextItems;
      if (Array.isArray(items)) {
        const usedIds = /* @__PURE__ */ new Set();
        for (const [index, entry] of state.inventory.groups.entries()) {
          if (index === groupIndex) {
            continue;
          }
          for (const item of entry.items) {
            usedIds.add(item.id);
          }
        }
        const normalizedItems = normalizeInventory(items);
        nextItems = normalizedItems.filter((item) => {
          if (usedIds.has(item.id)) {
            return false;
          }
          usedIds.add(item.id);
          return true;
        });
      }
      const nextGroups = state.inventory.groups.map((entry, index) => {
        if (index !== groupIndex) {
          return entry;
        }
        return {
          ...entry,
          title: typeof title === "string" && title.trim().length > 0 ? title : entry.title,
          visible: visible ?? entry.visible,
          items: nextItems ?? entry.items
        };
      });
      return {
        ...state,
        inventory: { groups: nextGroups }
      };
    }
    case "REMOVE_INVENTORY_GROUP": {
      const nextGroups = state.inventory.groups.filter(
        (entry) => entry.id !== action.payload.id
      );
      return {
        ...state,
        inventory: { groups: nextGroups }
      };
    }
    case "PURGE_ITEMS": {
      const itemIds = new Set(action.payload.itemIds);
      if (itemIds.size === 0) {
        return state;
      }
      const nextInventoryGroups = removeInventoryItems(
        state.inventory.groups,
        itemIds
      );
      let nextCanvas = removeItemsFromCanvas(state.canvas, itemIds);
      let nextCanvases = state.canvases;
      if (state.canvases) {
        nextCanvases = Object.fromEntries(
          Object.entries(state.canvases).map(([key, canvas]) => [
            key,
            removeItemsFromCanvas(canvas, itemIds)
          ])
        );
        const primaryKey = state.canvas.config.stateKey;
        if (primaryKey && nextCanvases[primaryKey]) {
          nextCanvas = nextCanvases[primaryKey];
        }
      }
      const resolveCanvas = (key) => nextCanvases?.[key] ?? (nextCanvas.config.stateKey === key ? nextCanvas : void 0);
      const nextCrossConnections = state.crossConnections.filter(
        (connection) => {
          const fromCanvas = resolveCanvas(connection.from.canvasKey);
          const toCanvas = resolveCanvas(connection.to.canvasKey);
          if (!fromCanvas || !toCanvas) {
            return false;
          }
          const fromBlock = fromCanvas.blocks[connection.from.y]?.[connection.from.x];
          const toBlock = toCanvas.blocks[connection.to.y]?.[connection.to.x];
          return Boolean(fromBlock?.itemId && toBlock?.itemId);
        }
      );
      return {
        ...state,
        canvas: nextCanvas,
        canvases: nextCanvases,
        crossConnections: nextCrossConnections,
        inventory: { groups: nextInventoryGroups }
      };
    }
    case "PLACE_ITEM": {
      const targetKey = action.payload.stateKey;
      const canvas = resolveCanvasState(state, targetKey);
      const { itemId, blockX, blockY } = action.payload;
      const match = findInventoryItem(state.inventory.groups, itemId);
      const item = match?.item;
      if (!item) {
        return state;
      }
      const allowedPlaceKey = targetKey ?? canvas.config.stateKey ?? canvas.config.id ?? "canvas";
      if (!item.allowedPlaces.includes(allowedPlaceKey)) {
        return state;
      }
      if (!canvas.blocks[blockY]?.[blockX]) {
        return state;
      }
      if (canvas.blocks[blockY][blockX].status === "occupied") {
        return state;
      }
      if (typeof canvas.config.maxItems === "number" && canvas.placedItems.length >= canvas.config.maxItems) {
        return state;
      }
      const placedItem = {
        id: item.id,
        itemId: item.id,
        type: item.type,
        blockX,
        blockY,
        status: "normal",
        icon: item.icon,
        behavior: item.behavior,
        data: item.data ?? {}
      };
      const nextBlocks = updateBlock(canvas.blocks, blockX, blockY, {
        status: "occupied",
        itemId: item.id
      });
      const nextPlacedItems = [...canvas.placedItems, placedItem];
      const nextCanvas = {
        ...canvas,
        blocks: nextBlocks,
        placedItems: nextPlacedItems,
        connections: deriveConnectionsFromCables(nextPlacedItems)
      };
      return updateCanvasState(
        {
          ...state
        },
        targetKey,
        nextCanvas
      );
    }
    case "REMOVE_ITEM": {
      const canvas = resolveCanvasState(state, action.payload.stateKey);
      const { blockX, blockY } = action.payload;
      const block = canvas.blocks[blockY]?.[blockX];
      if (!block?.itemId) {
        return state;
      }
      const nextBlocks = updateBlock(canvas.blocks, blockX, blockY, {
        status: "empty",
        itemId: void 0
      });
      const nextPlacedItems = canvas.placedItems.filter(
        (item) => item.itemId !== block.itemId
      );
      const nextConnections = deriveConnectionsFromCables(nextPlacedItems);
      const nextCanvas = {
        ...canvas,
        blocks: nextBlocks,
        placedItems: nextPlacedItems,
        connections: nextConnections
      };
      return updateCanvasState(
        {
          ...state
        },
        action.payload.stateKey,
        nextCanvas
      );
    }
    case "REPOSITION_ITEM": {
      const canvas = resolveCanvasState(state, action.payload.stateKey);
      const { itemId, fromBlockX, fromBlockY, toBlockX, toBlockY } = action.payload;
      if (fromBlockX === toBlockX && fromBlockY === toBlockY) {
        return state;
      }
      const fromBlock = canvas.blocks[fromBlockY]?.[fromBlockX];
      if (!fromBlock?.itemId || fromBlock.itemId !== itemId) {
        return state;
      }
      const toBlock = canvas.blocks[toBlockY]?.[toBlockX];
      if (!toBlock) {
        return state;
      }
      if (toBlock.status === "occupied") {
        return state;
      }
      const placedItem = canvas.placedItems.find((p) => p.itemId === itemId);
      if (!placedItem) {
        return state;
      }
      let nextBlocks = updateBlock(canvas.blocks, fromBlockX, fromBlockY, {
        status: "empty",
        itemId: void 0
      });
      nextBlocks = updateBlock(nextBlocks, toBlockX, toBlockY, {
        status: "occupied",
        itemId
      });
      const nextPlacedItems = canvas.placedItems.map(
        (item) => item.itemId === itemId ? { ...item, blockX: toBlockX, blockY: toBlockY } : item
      );
      const nextCanvas = {
        ...canvas,
        blocks: nextBlocks,
        placedItems: nextPlacedItems,
        connections: deriveConnectionsFromCables(nextPlacedItems)
      };
      return updateCanvasState(state, action.payload.stateKey, nextCanvas);
    }
    case "MAKE_CONNECTION": {
      const canvas = resolveCanvasState(state, action.payload.stateKey);
      const { from, to, cableId } = action.payload;
      if (from.x === to.x && from.y === to.y) {
        return state;
      }
      const fromBlock = canvas.blocks[from.y]?.[from.x];
      const toBlock = canvas.blocks[to.y]?.[to.x];
      if (!fromBlock?.itemId || !toBlock?.itemId) {
        return state;
      }
      const connectionKey = normalizeConnectionKey(from, to);
      const exists = canvas.connections.some(
        (connection) => normalizeConnectionKey(connection.from, connection.to) === connectionKey
      );
      if (exists) {
        return state;
      }
      if (cableId) {
        const cableItem = findInventoryItem(
          state.inventory.groups,
          cableId
        )?.item;
        if (!cableItem) {
          return state;
        }
        if (isItemOnCanvas(cableId, state.canvases)) {
          return state;
        }
      }
      const connectionId = `connection-${connectionKey}-${cableId ?? "link"}`;
      const nextConnections = [
        ...canvas.connections,
        {
          id: connectionId,
          type: "cable",
          from,
          to,
          cableId
        }
      ];
      const nextCanvas = {
        ...canvas,
        connections: nextConnections
      };
      return updateCanvasState(
        {
          ...state
        },
        action.payload.stateKey,
        nextCanvas
      );
    }
    case "REMOVE_CONNECTION": {
      const canvas = resolveCanvasState(state, action.payload.stateKey);
      const connection = canvas.connections.find(
        (entry) => entry.id === action.payload.connectionId
      );
      if (!connection) {
        return state;
      }
      const nextConnections = canvas.connections.filter(
        (entry) => entry.id !== action.payload.connectionId
      );
      const nextCanvas = {
        ...canvas,
        connections: nextConnections
      };
      return updateCanvasState(
        {
          ...state
        },
        action.payload.stateKey,
        nextCanvas
      );
    }
    case "MAKE_CROSS_CONNECTION": {
      const { from, to, cableId } = action.payload;
      if (!state.canvases) {
        return state;
      }
      if (from.canvasKey === to.canvasKey) {
        return state;
      }
      const fromCanvas = state.canvases[from.canvasKey];
      const toCanvas = state.canvases[to.canvasKey];
      if (!fromCanvas || !toCanvas) {
        return state;
      }
      const fromBlock = fromCanvas.blocks[from.y]?.[from.x];
      const toBlock = toCanvas.blocks[to.y]?.[to.x];
      if (!fromBlock?.itemId || !toBlock?.itemId) {
        return state;
      }
      const nextConnection = {
        id: crypto.randomUUID(),
        type: "cable",
        from,
        to,
        cableId
      };
      return {
        ...state,
        crossConnections: [...state.crossConnections, nextConnection]
      };
    }
    case "REMOVE_CROSS_CONNECTION": {
      const nextConnections = state.crossConnections.filter(
        (connection) => connection.id !== action.payload.connectionId
      );
      return {
        ...state,
        crossConnections: nextConnections
      };
    }
    case "SET_SHARED_DATA": {
      const nextItem = {
        id: crypto.randomUUID(),
        key: action.payload.key,
        value: action.payload.value,
        sourceCanvas: action.payload.sourceCanvas,
        timestamp: Date.now()
      };
      return {
        ...state,
        sharedZone: {
          items: {
            ...state.sharedZone.items,
            [action.payload.key]: nextItem
          }
        }
      };
    }
    case "REMOVE_SHARED_DATA": {
      const nextItems = { ...state.sharedZone.items };
      delete nextItems[action.payload.key];
      return {
        ...state,
        sharedZone: {
          items: nextItems
        }
      };
    }
    case "TRANSFER_ITEM": {
      const {
        itemId,
        fromCanvas,
        fromBlockX,
        fromBlockY,
        toCanvas,
        toBlockX,
        toBlockY
      } = action.payload;
      if (!state.canvases) {
        return state;
      }
      if (fromCanvas === toCanvas) {
        return state;
      }
      const sourceCanvas = state.canvases[fromCanvas];
      const targetCanvas = state.canvases[toCanvas];
      if (!sourceCanvas || !targetCanvas) {
        return state;
      }
      const sourceBlock = sourceCanvas.blocks[fromBlockY]?.[fromBlockX];
      if (!sourceBlock?.itemId || sourceBlock.itemId !== itemId) {
        return state;
      }
      const targetBlock = targetCanvas.blocks[toBlockY]?.[toBlockX];
      if (!targetBlock || targetBlock.status === "occupied") {
        return state;
      }
      const movingItem = sourceCanvas.placedItems.find(
        (item) => item.itemId === itemId
      );
      if (!movingItem) {
        return state;
      }
      const inventoryMatch = findInventoryItem(state.inventory.groups, itemId);
      if (inventoryMatch?.item && !inventoryMatch.item.allowedPlaces.includes(toCanvas)) {
        return state;
      }
      if (typeof targetCanvas.config.maxItems === "number" && targetCanvas.placedItems.length >= targetCanvas.config.maxItems) {
        return state;
      }
      const nextSourceBlocks = updateBlock(
        sourceCanvas.blocks,
        fromBlockX,
        fromBlockY,
        { status: "empty", itemId: void 0 }
      );
      const nextSourcePlacedItems = sourceCanvas.placedItems.filter(
        (item) => item.itemId !== itemId
      );
      const nextSourceConnections = deriveConnectionsFromCables(
        nextSourcePlacedItems
      );
      const nextSourceCanvas = {
        ...sourceCanvas,
        blocks: nextSourceBlocks,
        placedItems: nextSourcePlacedItems,
        connections: nextSourceConnections
      };
      const nextTargetBlocks = updateBlock(
        targetCanvas.blocks,
        toBlockX,
        toBlockY,
        { status: "occupied", itemId }
      );
      const nextTargetPlacedItems = [
        ...targetCanvas.placedItems,
        {
          ...movingItem,
          blockX: toBlockX,
          blockY: toBlockY
        }
      ];
      const nextTargetConnections = deriveConnectionsFromCables(
        nextTargetPlacedItems
      );
      const nextTargetCanvas = {
        ...targetCanvas,
        blocks: nextTargetBlocks,
        placedItems: nextTargetPlacedItems,
        connections: nextTargetConnections
      };
      const nextCrossConnections = state.crossConnections.filter(
        (connection) => {
          const fromMatch = connection.from.canvasKey === fromCanvas && connection.from.x === fromBlockX && connection.from.y === fromBlockY;
          const toMatch = connection.to.canvasKey === fromCanvas && connection.to.x === fromBlockX && connection.to.y === fromBlockY;
          return !fromMatch && !toMatch;
        }
      );
      const nextCanvases = {
        ...state.canvases,
        [fromCanvas]: nextSourceCanvas,
        [toCanvas]: nextTargetCanvas
      };
      let nextPrimaryCanvas = state.canvas;
      if (state.canvas.config.stateKey === fromCanvas) {
        nextPrimaryCanvas = nextSourceCanvas;
      } else if (state.canvas.config.stateKey === toCanvas) {
        nextPrimaryCanvas = nextTargetCanvas;
      }
      return {
        ...state,
        canvas: nextPrimaryCanvas,
        canvases: nextCanvases,
        crossConnections: nextCrossConnections
      };
    }
    case "SWAP_ITEMS": {
      const { from, to } = action.payload;
      const resolveCanvasByKey = (key) => {
        if (!key) {
          return state.canvas;
        }
        if (state.canvases?.[key]) {
          return state.canvases[key];
        }
        if (state.canvas.config.stateKey === key) {
          return state.canvas;
        }
        return void 0;
      };
      const fromCanvasKey = from.canvasKey;
      const toCanvasKey = to.canvasKey;
      const sameCanvas = fromCanvasKey === toCanvasKey;
      const sourceCanvas = resolveCanvasByKey(fromCanvasKey);
      const targetCanvas = resolveCanvasByKey(toCanvasKey);
      if (!sourceCanvas || !targetCanvas) {
        return state;
      }
      const fromBlock = sourceCanvas.blocks[from.blockY]?.[from.blockX];
      const toBlock = targetCanvas.blocks[to.blockY]?.[to.blockX];
      if (!fromBlock?.itemId || !toBlock?.itemId) {
        return state;
      }
      if (fromBlock.itemId === toBlock.itemId) {
        return state;
      }
      const fromItem = sourceCanvas.placedItems.find(
        (item) => item.itemId === fromBlock.itemId
      );
      const toItem = targetCanvas.placedItems.find(
        (item) => item.itemId === toBlock.itemId
      );
      if (!fromItem || !toItem) {
        return state;
      }
      if (sameCanvas || !fromCanvasKey || !toCanvasKey) {
        let nextBlocks = updateBlock(
          sourceCanvas.blocks,
          from.blockX,
          from.blockY,
          { itemId: toItem.itemId }
        );
        nextBlocks = updateBlock(nextBlocks, to.blockX, to.blockY, {
          itemId: fromItem.itemId
        });
        const nextPlacedItems = sourceCanvas.placedItems.map((item) => {
          if (item.itemId === fromItem.itemId) {
            return { ...item, blockX: to.blockX, blockY: to.blockY };
          }
          if (item.itemId === toItem.itemId) {
            return { ...item, blockX: from.blockX, blockY: from.blockY };
          }
          return item;
        });
        const nextCanvas = {
          ...sourceCanvas,
          blocks: nextBlocks,
          placedItems: nextPlacedItems,
          connections: deriveConnectionsFromCables(nextPlacedItems)
        };
        return updateCanvasState(state, fromCanvasKey, nextCanvas);
      }
      const toInvMatch = findInventoryItem(
        state.inventory.groups,
        toItem.itemId
      );
      const fromInvMatch = findInventoryItem(
        state.inventory.groups,
        fromItem.itemId
      );
      if (toInvMatch?.item && !toInvMatch.item.allowedPlaces.includes(
        sourceCanvas.config.stateKey ?? fromCanvasKey ?? ""
      )) {
        return state;
      }
      if (fromInvMatch?.item && !fromInvMatch.item.allowedPlaces.includes(
        targetCanvas.config.stateKey ?? toCanvasKey ?? ""
      )) {
        return state;
      }
      const nextSourceBlocks = updateBlock(
        sourceCanvas.blocks,
        from.blockX,
        from.blockY,
        { itemId: toItem.itemId }
      );
      const nextTargetBlocks = updateBlock(
        targetCanvas.blocks,
        to.blockX,
        to.blockY,
        { itemId: fromItem.itemId }
      );
      const nextSourcePlacedItems = [
        ...sourceCanvas.placedItems.filter(
          (item) => item.itemId !== fromItem.itemId
        ),
        { ...toItem, blockX: from.blockX, blockY: from.blockY }
      ];
      const nextTargetPlacedItems = [
        ...targetCanvas.placedItems.filter(
          (item) => item.itemId !== toItem.itemId
        ),
        { ...fromItem, blockX: to.blockX, blockY: to.blockY }
      ];
      const nextSourceCanvas = {
        ...sourceCanvas,
        blocks: nextSourceBlocks,
        placedItems: nextSourcePlacedItems,
        connections: deriveConnectionsFromCables(nextSourcePlacedItems)
      };
      const nextTargetCanvas = {
        ...targetCanvas,
        blocks: nextTargetBlocks,
        placedItems: nextTargetPlacedItems,
        connections: deriveConnectionsFromCables(nextTargetPlacedItems)
      };
      const nextCanvases = {
        ...state.canvases,
        [fromCanvasKey]: nextSourceCanvas,
        [toCanvasKey]: nextTargetCanvas
      };
      let nextPrimaryCanvas = state.canvas;
      if (state.canvas.config.stateKey === fromCanvasKey) {
        nextPrimaryCanvas = nextSourceCanvas;
      } else if (state.canvas.config.stateKey === toCanvasKey) {
        nextPrimaryCanvas = nextTargetCanvas;
      }
      return {
        ...state,
        canvas: nextPrimaryCanvas,
        canvases: nextCanvases
      };
    }
    case "CONFIGURE_DEVICE": {
      const config = sanitizeDeviceConfig(action.payload.config);
      const applyConfig = (canvas) => {
        const itemIndex = canvas.placedItems.findIndex(
          (item) => item.id === action.payload.deviceId
        );
        if (itemIndex === -1) {
          return null;
        }
        const nextPlacedItems = canvas.placedItems.slice();
        const currentItem = nextPlacedItems[itemIndex];
        const newStatus = typeof config.status === "string" ? config.status : void 0;
        const { status: _, ...dataConfig } = config;
        nextPlacedItems[itemIndex] = {
          ...currentItem,
          ...newStatus && { status: newStatus },
          data: {
            ...currentItem.data,
            ...dataConfig
          }
        };
        return {
          ...canvas,
          placedItems: nextPlacedItems
        };
      };
      if (action.payload.stateKey) {
        const canvas = resolveCanvasState(state, action.payload.stateKey);
        const nextCanvas = applyConfig(canvas);
        if (!nextCanvas) {
          return state;
        }
        return updateCanvasState(state, action.payload.stateKey, nextCanvas);
      }
      if (state.canvases) {
        for (const [stateKey, canvas] of Object.entries(state.canvases)) {
          const nextCanvas = applyConfig(canvas);
          if (!nextCanvas) {
            continue;
          }
          return updateCanvasState(state, stateKey, nextCanvas);
        }
      }
      const fallbackCanvas = applyConfig(state.canvas);
      if (!fallbackCanvas) {
        return state;
      }
      return updateCanvasState(state, action.payload.stateKey, fallbackCanvas);
    }
    case "OPEN_MODAL": {
      return {
        ...state,
        overlay: {
          ...state.overlay,
          activeModal: action.payload
        }
      };
    }
    case "CLOSE_MODAL":
      return {
        ...state,
        overlay: {
          ...state.overlay,
          activeModal: null
        }
      };
    case "SUBMIT_COMMAND": {
      const input = sanitizeTerminalInput(action.payload.input);
      if (!input) {
        return state;
      }
      const { entry, sequence } = createEntry(state, "input", input);
      return {
        ...state,
        sequence,
        terminal: {
          ...state.terminal,
          history: addHistoryEntry(state.terminal.history, entry)
        }
      };
    }
    case "ADD_TERMINAL_OUTPUT": {
      const content = sanitizeTerminalOutput(action.payload.content);
      if (!content) {
        return state;
      }
      const { entry, sequence } = createEntry(
        state,
        action.payload.type,
        content
      );
      return {
        ...state,
        sequence,
        terminal: {
          ...state.terminal,
          history: addHistoryEntry(state.terminal.history, entry)
        }
      };
    }
    case "CLEAR_TERMINAL_HISTORY":
      return {
        ...state,
        terminal: {
          ...state.terminal,
          history: []
        }
      };
    case "SET_PHASE":
      return {
        ...state,
        phase: action.payload.phase,
        terminal: {
          ...state.terminal,
          visible: action.payload.phase === "terminal" || action.payload.phase === "completed"
        }
      };
    case "COMPLETE_QUESTION":
      return {
        ...state,
        phase: "completed",
        question: { ...state.question, status: "completed" }
      };
    default:
      return state;
  }
};
const GameStateContext = reactExports.createContext(null);
const GameDispatchContext = reactExports.createContext(null);
const GameProvider = ({ children, initialState }) => {
  const [state, dispatch] = reactExports.useReducer(
    reducer,
    initialState ?? createDefaultState()
  );
  return /* @__PURE__ */ jsxRuntimeExports.jsx(GameStateContext.Provider, { value: state, children: /* @__PURE__ */ jsxRuntimeExports.jsx(GameDispatchContext.Provider, { value: dispatch, children }) });
};
const useGameState = () => {
  const state = reactExports.useContext(GameStateContext);
  if (!state) {
    throw new Error("useGameState must be used within GameProvider");
  }
  return state;
};
const useGameDispatch = () => {
  const dispatch = reactExports.useContext(GameDispatchContext);
  if (!dispatch) {
    throw new Error("useGameDispatch must be used within GameProvider");
  }
  return dispatch;
};
const useAllCanvases = () => {
  const state = useGameState();
  return state.canvases ?? { default: state.canvas };
};
const useEngineProgress = (options = {}) => {
  const { onStarted, onFinished, context, initialStatus = "pending" } = options;
  const [progress, setProgress] = reactExports.useState({
    status: initialStatus
  });
  const start = reactExports.useCallback(() => {
    setProgress((prev) => {
      if (prev.status !== "pending") return prev;
      const next = { status: "started", startedAt: Date.now() };
      onStarted?.(context);
      return next;
    });
  }, [context, onStarted]);
  const finish = reactExports.useCallback(() => {
    setProgress((prev) => {
      if (prev.status === "finished") return prev;
      const next = {
        ...prev,
        status: "finished",
        finishedAt: Date.now()
      };
      onFinished?.(context);
      return next;
    });
  }, [context, onFinished]);
  const reset = reactExports.useCallback(() => {
    setProgress({ status: "pending" });
  }, []);
  return { progress, start, finish, reset, context };
};
const useTerminalEngine = (config = {}) => {
  const dispatch = useGameDispatch();
  const state = useGameState();
  const controller = useEngineProgress(config);
  const lastInputIdRef = reactExports.useRef(null);
  const onCommandRef = reactExports.useRef(config.onCommand);
  onCommandRef.current = config.onCommand;
  const writeOutput = reactExports.useCallback(
    (content, type) => {
      dispatch({
        type: "ADD_TERMINAL_OUTPUT",
        payload: { content, type }
      });
    },
    [dispatch]
  );
  const clearHistory = reactExports.useCallback(() => {
    dispatch({ type: "CLEAR_TERMINAL_HISTORY" });
  }, [dispatch]);
  const finishEngine = reactExports.useCallback(() => {
    controller.finish();
  }, [controller]);
  reactExports.useEffect(() => {
    const lastEntry = state.terminal.history[state.terminal.history.length - 1];
    if (!lastEntry || lastEntry.type !== "input") return;
    if (lastEntry.id === lastInputIdRef.current) return;
    lastInputIdRef.current = lastEntry.id;
    if (controller.progress.status === "pending") {
      controller.start();
    }
    const helpers = {
      writeOutput,
      clearHistory,
      finishEngine,
      context: config.context
    };
    onCommandRef.current?.(lastEntry.content, helpers);
  }, [
    config.context,
    controller,
    state.terminal.history,
    writeOutput,
    clearHistory,
    finishEngine
  ]);
  return controller;
};
const DragContext = reactExports.createContext(null);
function DragProvider({ children }) {
  const [activeDrag, setActiveDrag] = reactExports.useState(null);
  const [lastDropResult, setLastDropResult] = reactExports.useState(
    null
  );
  const proxyRef = reactExports.useRef(null);
  const targetCanvasKeyRef = reactExports.useRef(void 0);
  return /* @__PURE__ */ jsxRuntimeExports.jsx(
    DragContext.Provider,
    {
      value: {
        activeDrag,
        setActiveDrag,
        proxyRef,
        targetCanvasKeyRef,
        lastDropResult,
        setLastDropResult
      },
      children
    }
  );
}
function useDragContext() {
  const context = reactExports.useContext(DragContext);
  if (!context) {
    throw new Error("useDragContext must be used within a DragProvider");
  }
  return context;
}
const Tooltip = reactExports.forwardRef(
  function Tooltip2(props, ref) {
    const {
      showArrow,
      children,
      disabled,
      portalled = true,
      content,
      contentProps,
      portalRef,
      ...rest
    } = props;
    if (disabled) return children;
    return /* @__PURE__ */ jsxRuntimeExports.jsxs(TooltipRoot, { ...rest, children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(TooltipTrigger, { asChild: true, children }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(Portal, { disabled: !portalled, container: portalRef, children: /* @__PURE__ */ jsxRuntimeExports.jsx(TooltipPositioner, { children: /* @__PURE__ */ jsxRuntimeExports.jsxs(TooltipContent, { ref, ...contentProps, children: [
        showArrow && /* @__PURE__ */ jsxRuntimeExports.jsx(TooltipArrow, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(TooltipArrowTip, {}) }),
        content
      ] }) }) })
    ] });
  }
);
const HelpLink = ({ text, href }) => /* @__PURE__ */ jsxRuntimeExports.jsx(
  Link,
  {
    href,
    target: "_blank",
    rel: "noopener noreferrer",
    fontSize: "xs",
    color: "cyan.400",
    _hover: { color: "cyan.300", textDecoration: "underline" },
    children: text
  }
);
const InfoTooltip = ({
  content,
  seeMoreHref,
  seeMoreText = "See more"
}) => /* @__PURE__ */ jsxRuntimeExports.jsx(
  Tooltip,
  {
    interactive: true,
    positioning: { placement: "top", gutter: 4 },
    openDelay: 100,
    closeDelay: 200,
    contentProps: {
      bg: "gray.800",
      color: "gray.100",
      borderColor: "gray.700",
      css: { "--tooltip-bg": "var(--chakra-colors-gray-800)" }
    },
    content: /* @__PURE__ */ jsxRuntimeExports.jsxs(Box, { maxW: "200px", p: 1, children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(Text, { fontSize: "xs", color: "gray.100", mb: seeMoreHref ? 1 : 0, children: content }),
      seeMoreHref && /* @__PURE__ */ jsxRuntimeExports.jsx(
        Link,
        {
          href: seeMoreHref,
          target: "_blank",
          rel: "noopener noreferrer",
          fontSize: "xs",
          color: "cyan.400",
          _hover: { color: "cyan.300", textDecoration: "underline" },
          children: seeMoreText
        }
      )
    ] }),
    children: /* @__PURE__ */ jsxRuntimeExports.jsx(
      Flex,
      {
        as: "span",
        align: "center",
        justify: "center",
        w: "16px",
        h: "16px",
        borderRadius: "full",
        bg: "gray.700",
        cursor: "help",
        _hover: { bg: "gray.600" },
        children: /* @__PURE__ */ jsxRuntimeExports.jsx(Info, { size: 10, color: "currentColor" })
      }
    )
  }
);
const useInventorySlotSize = () => {
  const width = useBreakpointValue({ base: 120, sm: 132, md: 150 }) ?? 150;
  const height = useBreakpointValue({ base: 52, sm: 58, md: 64 }) ?? 64;
  return { width, height };
};
const InventorySlot = ({
  item,
  isEmpty,
  isDragging,
  slotWidth,
  slotHeight,
  onPointerDown,
  slotRef,
  tooltip,
  iconInfo
}) => {
  return /* @__PURE__ */ jsxRuntimeExports.jsx(
    Box,
    {
      ref: slotRef,
      as: "li",
      role: "listitem",
      "data-inventory-slot": item.id,
      "aria-grabbed": isDragging,
      width: `${slotWidth}px`,
      height: `${slotHeight}px`,
      bg: isEmpty ? "transparent" : "gray.800",
      border: "1px",
      borderStyle: isEmpty ? "dashed" : "solid",
      borderColor: isEmpty ? "gray.700" : "cyan.500",
      borderRadius: "md",
      display: "flex",
      flexDirection: "column",
      alignItems: "center",
      justifyContent: "center",
      gap: 1,
      opacity: isDragging ? 0.3 : 1,
      cursor: isEmpty ? "default" : "grab",
      transition: "opacity 0.1s ease",
      style: { touchAction: "none" },
      onPointerDown: isEmpty ? void 0 : onPointerDown,
      children: !isEmpty && /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
        iconInfo && /* @__PURE__ */ jsxRuntimeExports.jsx(
          Icon,
          {
            icon: iconInfo.icon,
            width: 20,
            height: 20,
            color: iconInfo.color
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsxs(Flex, { align: "center", gap: 1, children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Text, { fontSize: "xs", fontWeight: "bold", color: "gray.100", children: item.name ?? item.type }),
          tooltip && /* @__PURE__ */ jsxRuntimeExports.jsx(
            InfoTooltip,
            {
              content: tooltip.content,
              seeMoreHref: tooltip.seeMoreHref
            }
          )
        ] })
      ] })
    }
  );
};
const InventoryPanel = ({ tooltips }) => {
  const { inventory, canvases, canvas } = useGameState();
  const { activeDrag, setActiveDrag, setLastDropResult } = useDragContext();
  const slotRefs = reactExports.useRef(/* @__PURE__ */ new Map());
  const slotSize = useInventorySlotSize();
  const visibleGroups = reactExports.useMemo(
    () => inventory.groups.filter((group) => group.visible),
    [inventory.groups]
  );
  const isItemOnCanvas2 = reactExports.useCallback(
    (itemId) => {
      const allCanvases = canvases ? Object.values(canvases) : [];
      if (canvas) {
        allCanvases.push(canvas);
      }
      return allCanvases.some(
        (c) => c.placedItems.some((p) => p.itemId === itemId)
      );
    },
    [canvases, canvas]
  );
  const handlePointerDown = reactExports.useCallback(
    (item, event) => {
      event.preventDefault();
      const target = event.currentTarget;
      const rect = target.getBoundingClientRect();
      setLastDropResult(null);
      setActiveDrag({
        source: "inventory",
        data: {
          itemId: item.id,
          itemType: item.type,
          itemName: item.name
        },
        element: target,
        initialRect: rect
      });
    },
    [setActiveDrag, setLastDropResult]
  );
  const setSlotRef = reactExports.useCallback(
    (itemId) => (el) => {
      if (el) {
        slotRefs.current.set(itemId, el);
      } else {
        slotRefs.current.delete(itemId);
      }
    },
    []
  );
  if (visibleGroups.length === 0) {
    return null;
  }
  return /* @__PURE__ */ jsxRuntimeExports.jsx(
    Flex,
    {
      className: "inventory-panel",
      "data-inventory-panel": true,
      direction: "column",
      gap: { base: 2, md: 3 },
      width: "fit-content",
      overflow: "visible",
      children: visibleGroups.map((group) => {
        const items = group.items;
        const firstEmptySlot = items.find((item) => !isItemOnCanvas2(item.id))?.id ?? null;
        return /* @__PURE__ */ jsxRuntimeExports.jsxs(
          Box,
          {
            "data-first-empty-slot": firstEmptySlot,
            bg: "gray.900",
            borderTop: "1px solid",
            borderColor: "gray.800",
            p: { base: 2, md: 3 },
            overflow: "visible",
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Text, { fontSize: "sm", fontWeight: "bold", mb: 3, color: "gray.200", children: group.title }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                Flex,
                {
                  as: "ul",
                  role: "list",
                  direction: "row",
                  gap: 2,
                  wrap: "wrap",
                  listStyleType: "none",
                  p: 0,
                  m: 0,
                  children: items.length === 0 ? /* @__PURE__ */ jsxRuntimeExports.jsx(Text, { fontSize: "sm", color: "gray.500", children: "No items." }) : items.map((item) => {
                    const isInInventory = !isItemOnCanvas2(item.id);
                    const isDragging = activeDrag?.source === "inventory" && activeDrag.data.itemId === item.id;
                    const tooltip = tooltips?.[item.type];
                    const iconInfo = item.icon;
                    return /* @__PURE__ */ jsxRuntimeExports.jsx(
                      InventorySlot,
                      {
                        item,
                        isEmpty: !isInInventory,
                        isDragging,
                        slotWidth: slotSize.width,
                        slotHeight: slotSize.height,
                        onPointerDown: (e) => handlePointerDown(item, e),
                        slotRef: setSlotRef(item.id),
                        tooltip,
                        iconInfo
                      },
                      item.id
                    );
                  })
                }
              )
            ]
          },
          group.id
        );
      })
    }
  );
};
const defaultGetItemLabel$1 = (itemType) => itemType.charAt(0).toUpperCase() + itemType.slice(1);
const DragOverlay = ({
  getItemLabel = defaultGetItemLabel$1
}) => {
  const { activeDrag, proxyRef } = useDragContext();
  const slotSize = useInventorySlotSize();
  const slotSizeRef = reactExports.useRef({
    width: slotSize.width,
    height: slotSize.height
  });
  const [isVisible, setIsVisible] = reactExports.useState(false);
  const [size, setSize] = reactExports.useState({ width: 0, height: 0 });
  const initializedRef = reactExports.useRef(false);
  const pointerOffsetRef = reactExports.useRef({ x: 0, y: 0 });
  reactExports.useEffect(() => {
    slotSizeRef.current = { width: slotSize.width, height: slotSize.height };
  }, [slotSize.height, slotSize.width]);
  reactExports.useEffect(() => {
    if (!activeDrag) {
      setIsVisible(false);
      initializedRef.current = false;
      if (proxyRef.current) {
        gsapWithCSS.set(proxyRef.current, { clearProps: "all" });
      }
      return;
    }
    const initialRect2 = activeDrag.initialRect;
    if (!initialRect2) {
      setIsVisible(false);
      return;
    }
    const targetWidth = slotSizeRef.current.width;
    const targetHeight = slotSizeRef.current.height;
    pointerOffsetRef.current = {
      x: targetWidth / 2,
      y: targetHeight / 2
    };
    setSize({ width: targetWidth, height: targetHeight });
    setIsVisible(true);
    const initializePosition = () => {
      if (!proxyRef.current || initializedRef.current) {
        return;
      }
      const pointerX2 = activeDrag.pointerOffset?.x ?? initialRect2.width / 2;
      const pointerY2 = activeDrag.pointerOffset?.y ?? initialRect2.height / 2;
      gsapWithCSS.set(proxyRef.current, {
        x: initialRect2.left + pointerX2 - pointerOffsetRef.current.x,
        y: initialRect2.top + pointerY2 - pointerOffsetRef.current.y,
        width: targetWidth,
        height: targetHeight
      });
      initializedRef.current = true;
    };
    if (proxyRef.current) {
      initializePosition();
    } else {
      requestAnimationFrame(initializePosition);
    }
    const handlePointerMove = (event) => {
      if (proxyRef.current) {
        gsapWithCSS.set(proxyRef.current, {
          x: event.clientX - pointerOffsetRef.current.x,
          y: event.clientY - pointerOffsetRef.current.y
        });
      }
    };
    window.addEventListener("pointermove", handlePointerMove);
    return () => window.removeEventListener("pointermove", handlePointerMove);
  }, [activeDrag, proxyRef]);
  if (!isVisible || !activeDrag) {
    return null;
  }
  const label = activeDrag.data.itemName ?? getItemLabel(activeDrag.data.itemType);
  const initialRect = activeDrag.initialRect;
  const pointerX = activeDrag.pointerOffset?.x ?? (initialRect ? initialRect.width / 2 : 0);
  const pointerY = activeDrag.pointerOffset?.y ?? (initialRect ? initialRect.height / 2 : 0);
  const initialX = initialRect ? initialRect.left + pointerX - pointerOffsetRef.current.x : 0;
  const initialY = initialRect ? initialRect.top + pointerY - pointerOffsetRef.current.y : 0;
  return /* @__PURE__ */ jsxRuntimeExports.jsx(
    Box,
    {
      ref: proxyRef,
      position: "fixed",
      top: 0,
      left: 0,
      width: `${size.width}px`,
      height: `${size.height}px`,
      bg: "gray.800",
      border: "1px solid",
      borderColor: "cyan.500",
      borderRadius: "md",
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      pointerEvents: "none",
      zIndex: 9999,
      boxShadow: "0 4px 20px rgba(0, 0, 0, 0.3)",
      style: { transform: `translate3d(${initialX}px, ${initialY}px, 0)` },
      children: /* @__PURE__ */ jsxRuntimeExports.jsx(Text, { fontSize: "sm", fontWeight: "bold", color: "gray.100", children: label })
    }
  );
};
const DataDrivenModal = ({ modal, onClose }) => {
  const dispatch = useGameDispatch();
  const initialValues = reactExports.useMemo(() => {
    const values2 = { ...modal.initialValues ?? {} };
    for (const block of modal.content) {
      if (block.kind === "field") {
        const field = block.field;
        if (values2[field.id] !== void 0) {
          continue;
        }
        if (field.kind === "checkbox") {
          values2[field.id] = field.defaultValue ?? false;
        } else if (field.kind === "readonly") {
          values2[field.id] = field.value;
        } else {
          values2[field.id] = field.defaultValue ?? "";
        }
      }
    }
    return values2;
  }, [modal.content, modal.initialValues]);
  const [values, setValues] = reactExports.useState(initialValues);
  const [errors, setErrors] = reactExports.useState({});
  const setFieldValue = (fieldId, value) => {
    setValues((prev) => ({ ...prev, [fieldId]: value }));
    setErrors((prev) => ({ ...prev, [fieldId]: null }));
  };
  const runValidation = () => {
    const nextErrors = {};
    for (const block of modal.content) {
      if (block.kind !== "field") {
        continue;
      }
      const field = block.field;
      const value = values[field.id];
      if (field.kind === "text" || field.kind === "textarea") {
        const v = value ?? "";
        if (field.validate) {
          const error = field.validate(v, values);
          if (error) {
            nextErrors[field.id] = error;
          }
        }
      } else if (field.kind === "select") {
        const v = value ?? "";
        if (field.validate) {
          const error = field.validate(v, values);
          if (error) {
            nextErrors[field.id] = error;
          }
        }
      }
    }
    setErrors(nextErrors);
    return Object.values(nextErrors).some(Boolean);
  };
  const handleActionClick = async (action) => {
    const shouldValidate = action.validate ?? true;
    if (shouldValidate) {
      const hasErrors = runValidation();
      if (hasErrors) {
        return;
      }
    }
    if (action.onClick) {
      await action.onClick({
        values,
        close: onClose,
        dispatch
      });
    }
    if (action.closesModal ?? true) {
      onClose();
    }
  };
  const renderField = (field) => {
    switch (field.kind) {
      case "text": {
        const value = values[field.id] ?? "";
        const error = errors[field.id] ?? null;
        return /* @__PURE__ */ jsxRuntimeExports.jsxs(Box, { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Text, { fontSize: "sm", mb: 2, children: field.label }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            Input,
            {
              value,
              onChange: (e) => setFieldValue(field.id, e.target.value),
              placeholder: field.placeholder,
              size: "sm",
              bg: "gray.800",
              borderColor: "gray.700",
              fontFamily: "mono"
            }
          ),
          field.helpLink && /* @__PURE__ */ jsxRuntimeExports.jsx(Box, { mt: 1, children: /* @__PURE__ */ jsxRuntimeExports.jsx(
            HelpLink,
            {
              text: field.helpLink.label,
              href: field.helpLink.href
            }
          ) }),
          field.helpText && !error && /* @__PURE__ */ jsxRuntimeExports.jsx(Text, { fontSize: "xs", color: "gray.400", mt: 1, children: field.helpText }),
          error && /* @__PURE__ */ jsxRuntimeExports.jsx(Text, { fontSize: "xs", color: "red.300", mt: 1, children: error })
        ] }, field.id);
      }
      case "textarea": {
        const value = values[field.id] ?? "";
        const error = errors[field.id] ?? null;
        return /* @__PURE__ */ jsxRuntimeExports.jsxs(Box, { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Text, { fontSize: "sm", mb: 2, children: field.label }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            Textarea,
            {
              value,
              onChange: (e) => setFieldValue(field.id, e.target.value),
              placeholder: field.placeholder,
              size: "sm",
              bg: "gray.800",
              borderColor: "gray.700",
              fontFamily: "mono",
              rows: 3
            }
          ),
          field.helpLink && /* @__PURE__ */ jsxRuntimeExports.jsx(Box, { mt: 1, children: /* @__PURE__ */ jsxRuntimeExports.jsx(
            HelpLink,
            {
              text: field.helpLink.label,
              href: field.helpLink.href
            }
          ) }),
          field.helpText && !error && /* @__PURE__ */ jsxRuntimeExports.jsx(Text, { fontSize: "xs", color: "gray.400", mt: 1, children: field.helpText }),
          error && /* @__PURE__ */ jsxRuntimeExports.jsx(Text, { fontSize: "xs", color: "red.300", mt: 1, children: error })
        ] }, field.id);
      }
      case "checkbox": {
        const checked = !!values[field.id];
        return /* @__PURE__ */ jsxRuntimeExports.jsxs(Box, { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs(
            CheckboxRoot,
            {
              checked,
              onCheckedChange: (details) => setFieldValue(field.id, details.checked === true),
              colorPalette: "green",
              size: "sm",
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(CheckboxHiddenInput, {}),
                /* @__PURE__ */ jsxRuntimeExports.jsx(CheckboxControl, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(CheckboxIndicator, {}) }),
                /* @__PURE__ */ jsxRuntimeExports.jsx(CheckboxLabel, { children: field.label })
              ]
            }
          ),
          field.helpLink && /* @__PURE__ */ jsxRuntimeExports.jsx(Box, { mt: 1, children: /* @__PURE__ */ jsxRuntimeExports.jsx(
            HelpLink,
            {
              text: field.helpLink.label,
              href: field.helpLink.href
            }
          ) })
        ] }, field.id);
      }
      case "readonly": {
        return /* @__PURE__ */ jsxRuntimeExports.jsxs(Box, { children: [
          field.label && /* @__PURE__ */ jsxRuntimeExports.jsx(Text, { fontSize: "sm", mb: 1, color: "gray.400", children: field.label }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(Text, { fontSize: "sm", fontFamily: "mono", children: field.value })
        ] }, field.id);
      }
      case "select": {
        return null;
      }
    }
  };
  const renderContentBlock = (block, index) => {
    switch (block.kind) {
      case "text":
        return /* @__PURE__ */ jsxRuntimeExports.jsx(
          Text,
          {
            fontSize: "sm",
            color: "gray.300",
            children: block.text
          },
          block.id ?? `text-${index}`
        );
      case "link":
        return /* @__PURE__ */ jsxRuntimeExports.jsx(Box, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(HelpLink, { text: block.text, href: block.href }) }, block.id ?? `link-${index}`);
      case "field":
        return renderField(block.field);
    }
  };
  const getButtonVariant = (variant) => {
    switch (variant) {
      case "ghost":
      case "secondary":
        return "ghost";
      case "danger":
        return "outline";
      default:
        return "solid";
    }
  };
  const getButtonColorPalette = (variant) => {
    switch (variant) {
      case "danger":
        return "red";
      default:
        return "green";
    }
  };
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(Box, { display: "flex", flexDirection: "column", gap: 4, children: [
    modal.title && /* @__PURE__ */ jsxRuntimeExports.jsx(Text, { fontSize: "lg", fontWeight: "bold", children: modal.title }),
    modal.content.map((block, index) => renderContentBlock(block, index)),
    /* @__PURE__ */ jsxRuntimeExports.jsx(Flex, { justify: "flex-end", gap: 2, mt: 2, children: modal.actions.map((action) => /* @__PURE__ */ jsxRuntimeExports.jsx(
      Button,
      {
        size: "sm",
        variant: getButtonVariant(action.variant),
        colorPalette: getButtonColorPalette(action.variant),
        onClick: () => void handleActionClick(action),
        children: action.label
      },
      action.id
    )) })
  ] });
};
const getFocusableElements = (container) => Array.from(
  container.querySelectorAll(
    'a, button, input, textarea, select, [tabindex]:not([tabindex="-1"])'
  )
).filter(
  (element) => !element.hasAttribute("disabled") && !element.getAttribute("aria-hidden")
);
const OverlayLayer = () => {
  const { overlay } = useGameState();
  const dispatch = useGameDispatch();
  const [portalTarget, setPortalTarget] = reactExports.useState(null);
  const modalRef = reactExports.useRef(null);
  const lastActiveRef = reactExports.useRef(null);
  const activeModal = overlay.activeModal;
  reactExports.useEffect(() => {
    if (typeof document === "undefined") {
      return;
    }
    let container = document.getElementById("overlay-portal");
    if (!container) {
      container = document.createElement("div");
      container.id = "overlay-portal";
      document.body.appendChild(container);
    }
    setPortalTarget(container);
    return () => {
      setPortalTarget(null);
    };
  }, []);
  reactExports.useEffect(() => {
    if (!activeModal) {
      if (lastActiveRef.current) {
        lastActiveRef.current.focus();
      }
      return;
    }
    if (typeof document !== "undefined") {
      const activeElement = document.activeElement;
      if (activeElement instanceof HTMLElement) {
        lastActiveRef.current = activeElement;
      }
    }
    modalRef.current?.focus();
  }, [activeModal]);
  reactExports.useEffect(() => {
    if (!activeModal || !modalRef.current) {
      return;
    }
    const container = modalRef.current;
    const handleKeyDown = (event) => {
      if (event.key !== "Tab") {
        return;
      }
      const focusable = getFocusableElements(container);
      if (focusable.length === 0) {
        return;
      }
      const first = focusable[0];
      const last = focusable[focusable.length - 1];
      if (event.shiftKey && document.activeElement === first) {
        event.preventDefault();
        last.focus();
        return;
      }
      if (!event.shiftKey && document.activeElement === last) {
        event.preventDefault();
        first.focus();
      }
    };
    container.addEventListener("keydown", handleKeyDown);
    return () => {
      container.removeEventListener("keydown", handleKeyDown);
    };
  }, [activeModal]);
  reactExports.useEffect(() => {
    if (!activeModal) {
      return;
    }
    const handleKeyDown = (event) => {
      if (event.key !== "Escape") {
        return;
      }
      if (activeModal.blocking) {
        return;
      }
      dispatch({ type: "CLOSE_MODAL" });
    };
    window.addEventListener("keydown", handleKeyDown);
    return () => {
      window.removeEventListener("keydown", handleKeyDown);
    };
  }, [activeModal, dispatch]);
  const handleBackdropClick = (event) => {
    if (event.target !== event.currentTarget) {
      return;
    }
    if (activeModal?.blocking) {
      return;
    }
    dispatch({ type: "CLOSE_MODAL" });
  };
  if (!portalTarget) {
    return null;
  }
  if (!activeModal) {
    return null;
  }
  const handleClose = () => dispatch({ type: "CLOSE_MODAL" });
  return reactDomExports.createPortal(
    /* @__PURE__ */ jsxRuntimeExports.jsx(Box, { position: "fixed", inset: "0", zIndex: 1e4, pointerEvents: "none", children: activeModal && /* @__PURE__ */ jsxRuntimeExports.jsx(
      Box,
      {
        position: "absolute",
        inset: "0",
        bg: "rgba(0, 0, 0, 0.6)",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        pointerEvents: "auto",
        onClick: handleBackdropClick,
        children: /* @__PURE__ */ jsxRuntimeExports.jsx(
          Box,
          {
            ref: modalRef,
            tabIndex: -1,
            role: "dialog",
            "aria-modal": "true",
            bg: "gray.900",
            color: "gray.100",
            border: "1px solid",
            borderColor: "gray.700",
            borderRadius: "lg",
            p: 6,
            width: "min(460px, 92vw)",
            boxShadow: "xl",
            children: /* @__PURE__ */ jsxRuntimeExports.jsx(
              reactExports.Suspense,
              {
                fallback: /* @__PURE__ */ jsxRuntimeExports.jsx(Flex, { align: "center", justify: "center", minHeight: "120px", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Text, { fontSize: "sm", color: "gray.300", children: "Loading..." }) }),
                children: /* @__PURE__ */ jsxRuntimeExports.jsx(DataDrivenModal, { modal: activeModal, onClose: handleClose })
              }
            )
          }
        )
      }
    ) }),
    portalTarget
  );
};
const GameShell = ({ children, getItemLabel }) => {
  return /* @__PURE__ */ jsxRuntimeExports.jsx(DragProvider, { children: /* @__PURE__ */ jsxRuntimeExports.jsxs(
    Box,
    {
      as: "main",
      role: "main",
      display: "flex",
      flexDirection: "column",
      bg: "gray.950",
      color: "gray.100",
      position: "relative",
      children: [
        children,
        /* @__PURE__ */ jsxRuntimeExports.jsx(OverlayLayer, {}),
        /* @__PURE__ */ jsxRuntimeExports.jsx(DragOverlay, { getItemLabel })
      ]
    }
  ) });
};
const InventoryDrawer = ({
  tooltips,
  drawerWidth,
  hoverGutterWidth = "10vw",
  closeGutterWidth
}) => {
  const [isOpen, setIsOpen] = reactExports.useState(false);
  const [openSource, setOpenSource] = reactExports.useState(
    "button"
  );
  const [hoverLocked, setHoverLocked] = reactExports.useState(false);
  const { activeDrag, lastDropResult, setLastDropResult } = useDragContext();
  const isMdOrBelow = useBreakpointValue({ base: true, md: true, lg: false }) ?? true;
  const resolvedDrawerWidth = drawerWidth ?? (useBreakpointValue({ base: "80vw", md: "320px" }) ?? "320px");
  const resolvedCloseGutterWidth = closeGutterWidth ?? `calc(100vw - ${resolvedDrawerWidth})`;
  reactExports.useEffect(() => {
    if (!activeDrag) {
      return;
    }
    setIsOpen(false);
    setLastDropResult(null);
  }, [activeDrag, setLastDropResult]);
  reactExports.useEffect(() => {
    if (!lastDropResult || activeDrag) {
      return;
    }
    if (lastDropResult.source === "inventory" && !lastDropResult.placed) {
      setIsOpen(true);
      setOpenSource("auto");
      setHoverLocked(false);
    }
    setLastDropResult(null);
  }, [activeDrag, lastDropResult, setLastDropResult]);
  const handleToggle = reactExports.useCallback(() => {
    setIsOpen((prev) => {
      const next = !prev;
      if (next) {
        setOpenSource("button");
        setHoverLocked(false);
      } else {
        setHoverLocked(true);
      }
      return next;
    });
    setLastDropResult(null);
  }, [setLastDropResult]);
  const handleClose = reactExports.useCallback(
    (reason) => {
      setIsOpen(false);
      if (reason === "x" && openSource === "button") {
        setHoverLocked(true);
      }
      setLastDropResult(null);
    },
    [openSource, setLastDropResult]
  );
  reactExports.useEffect(() => {
    if (!hoverLocked || !isMdOrBelow) {
      return;
    }
    const resolveWidth = (value) => {
      if (value.endsWith("vw")) {
        const ratio = Number.parseFloat(value);
        if (Number.isNaN(ratio)) return 0;
        return window.innerWidth * ratio / 100;
      }
      if (value.endsWith("px")) {
        const px = Number.parseFloat(value);
        return Number.isNaN(px) ? 0 : px;
      }
      return 0;
    };
    const gutterWidthPx = resolveWidth(hoverGutterWidth);
    const handlePointerMove = (event) => {
      if (event.clientX < window.innerWidth - gutterWidthPx) {
        setHoverLocked(false);
      }
    };
    window.addEventListener("pointermove", handlePointerMove);
    return () => window.removeEventListener("pointermove", handlePointerMove);
  }, [hoverGutterWidth, hoverLocked, isMdOrBelow]);
  const hoverZone = reactExports.useMemo(() => {
    if (!isMdOrBelow || isOpen) {
      return null;
    }
    return /* @__PURE__ */ jsxRuntimeExports.jsx(
      Box,
      {
        position: "fixed",
        top: 0,
        right: 0,
        height: "100vh",
        width: hoverGutterWidth,
        zIndex: 90,
        onMouseEnter: () => {
          if (!activeDrag && !hoverLocked) {
            setIsOpen(true);
            setOpenSource("hover");
          }
        }
      }
    );
  }, [activeDrag, hoverGutterWidth, hoverLocked, isMdOrBelow, isOpen]);
  if (!isMdOrBelow) {
    return /* @__PURE__ */ jsxRuntimeExports.jsx(Box, { alignSelf: "center", my: 4, children: /* @__PURE__ */ jsxRuntimeExports.jsx(InventoryPanel, { tooltips }) });
  }
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
    hoverZone,
    /* @__PURE__ */ jsxRuntimeExports.jsx(
      Box,
      {
        as: "button",
        position: "fixed",
        top: 3,
        right: 3,
        zIndex: 1200,
        bg: "gray.900",
        border: "1px solid",
        borderColor: "gray.700",
        color: "gray.100",
        borderRadius: "md",
        width: "36px",
        height: "36px",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        fontSize: "lg",
        onClick: handleToggle,
        "aria-label": isOpen ? "Close inventory drawer" : "Open inventory drawer",
        children: isOpen ? "✕" : "☰"
      }
    ),
    isOpen && isMdOrBelow && /* @__PURE__ */ jsxRuntimeExports.jsx(
      Box,
      {
        position: "fixed",
        top: 0,
        right: resolvedDrawerWidth,
        height: "100vh",
        width: resolvedCloseGutterWidth,
        zIndex: 950,
        bg: "transparent",
        onPointerDown: () => handleClose("gutter"),
        "aria-hidden": true
      }
    ),
    /* @__PURE__ */ jsxRuntimeExports.jsx(
      Box,
      {
        position: "fixed",
        top: 0,
        right: 0,
        height: "100vh",
        width: resolvedDrawerWidth,
        bg: "gray.900",
        borderLeft: "1px solid",
        borderColor: "gray.800",
        transform: isOpen ? "translateX(0)" : "translateX(100%)",
        transition: "transform 0.2s ease",
        zIndex: 1e3,
        pointerEvents: isOpen ? "auto" : "none",
        onMouseLeave: () => {
          if (!activeDrag) {
            handleClose("gutter");
          }
        },
        children: /* @__PURE__ */ jsxRuntimeExports.jsxs(Flex, { direction: "column", height: "100%", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs(
            Flex,
            {
              align: "center",
              justify: "space-between",
              px: 4,
              py: 3,
              borderBottom: "1px solid",
              borderColor: "gray.800",
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(Text, { fontSize: "sm", fontWeight: "bold", color: "gray.100", children: "Inventory" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  Box,
                  {
                    as: "button",
                    onClick: () => handleClose("x"),
                    "aria-label": "Close inventory drawer",
                    color: "gray.400",
                    _hover: { color: "gray.100" },
                    children: "✕"
                  }
                )
              ]
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsx(Box, { flex: "1", overflowY: "auto", px: 4, py: 4, children: /* @__PURE__ */ jsxRuntimeExports.jsx(InventoryPanel, { tooltips }) })
        ] })
      }
    )
  ] });
};
let pluginsRegistered = false;
const ensureGsapPlugins = () => {
  if (pluginsRegistered) {
    return;
  }
  gsapWithCSS.registerPlugin(Draggable, InertiaPlugin);
  pluginsRegistered = true;
};
const createDraggable = (target, options = {}) => {
  ensureGsapPlugins();
  const [instance] = Draggable.create(target, {
    type: "x,y",
    inertia: true,
    ...options
  });
  return {
    instance,
    cleanup: () => {
      instance.kill();
    }
  };
};
const convertPixelToBlock = (x, y, metrics) => {
  const { blockWidth, blockHeight, gapX = 0, gapY = 0 } = metrics;
  const cellWidth = blockWidth + gapX;
  const cellHeight = blockHeight + gapY;
  return {
    blockX: Math.floor(x / cellWidth),
    blockY: Math.floor(y / cellHeight)
  };
};
const hitTestAny = (element, targets, threshold = "50%") => {
  ensureGsapPlugins();
  for (const target of targets) {
    if (Draggable.hitTest(element, target, threshold)) {
      return target;
    }
  }
  return null;
};
const BLOCK_HEIGHT = 60;
const defaultGetItemLabel = (itemType) => {
  return itemType.charAt(0).toUpperCase() + itemType.slice(1);
};
const defaultGetStatusMessage = () => {
  return null;
};
const defaultIsItemClickable = () => true;
const GridCell = reactExports.memo(
  ({
    borderColor,
    showBorder,
    isOccupied,
    height
  }) => {
    const borderStyle = showBorder ? "dashed" : "solid";
    const resolvedBorderColor = showBorder ? borderColor : "transparent";
    return /* @__PURE__ */ jsxRuntimeExports.jsx(
      Box,
      {
        border: `1px ${borderStyle}`,
        borderColor: resolvedBorderColor,
        borderRadius: "md",
        bg: "transparent",
        height: `${height}px`,
        transition: "border-color 0.15s ease",
        "data-occupied": isOccupied
      }
    );
  },
  (prev, next) => prev.borderColor === next.borderColor && prev.showBorder === next.showBorder && prev.isOccupied === next.isOccupied
);
const PlacedItemCard = reactExports.memo(
  ({
    item,
    x,
    y,
    width,
    height,
    isDragging,
    getItemLabel,
    getStatusMessage,
    itemRef
  }) => {
    const label = getItemLabel(item.type);
    const statusMessage = getStatusMessage(item);
    const iconInfo = item.icon;
    const getStatusBadgeColor = () => {
      if (item.status === "error") return "red.600";
      if (item.status === "warning") return "yellow.600";
      if (item.status === "success") return "green.600";
      return "gray.600";
    };
    const getBorderColor = () => {
      const isConnectable = item.behavior === "connectable";
      if (isConnectable) {
        if (item.status === "success") return "cyan.warning";
        if (item.status === "warning") return "yellow.500";
        if (item.status === "error") return "red.500";
        return "gray.500";
      }
      return "cyan.500";
    };
    return /* @__PURE__ */ jsxRuntimeExports.jsxs(
      Box,
      {
        ref: itemRef,
        position: "absolute",
        top: `${y}px`,
        left: `${x}px`,
        width: `${width}px`,
        height: `${height}px`,
        bg: "gray.800",
        border: "1px solid",
        borderColor: getBorderColor(),
        borderRadius: "md",
        display: "flex",
        flexDirection: "row",
        alignItems: "center",
        justifyContent: "center",
        gap: 2,
        px: 3,
        cursor: "grab",
        zIndex: isDragging ? 9999 : 1,
        style: { touchAction: "none" },
        "aria-label": `${label}${statusMessage ? `: ${statusMessage}` : ""}`,
        children: [
          iconInfo && /* @__PURE__ */ jsxRuntimeExports.jsx(
            Icon,
            {
              icon: iconInfo.icon,
              width: 20,
              height: 20,
              color: iconInfo.color
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsx(Text, { fontSize: "xs", fontWeight: "bold", color: "gray.100", children: label }),
          statusMessage && /* @__PURE__ */ jsxRuntimeExports.jsx(
            Box,
            {
              position: "absolute",
              top: "-8px",
              right: "-8px",
              fontSize: "9px",
              px: 1.5,
              py: 0.5,
              borderRadius: "full",
              bg: getStatusBadgeColor(),
              color: "white",
              fontWeight: "medium",
              boxShadow: "sm",
              whiteSpace: "nowrap",
              children: statusMessage
            }
          )
        ]
      }
    );
  },
  (prev, next) => prev.item.id === next.item.id && prev.item.status === next.item.status && prev.item.data?.ip === next.item.data?.ip && prev.item.data?.tcpState === next.item.data?.tcpState && prev.item.data?.seqEnabled === next.item.data?.seqEnabled && prev.item.data?.ack === next.item.data?.ack && prev.x === next.x && prev.y === next.y && prev.width === next.width && prev.height === next.height && prev.isDragging === next.isDragging
);
const PlayCanvas = ({
  stateKey,
  title,
  getItemLabel = defaultGetItemLabel,
  getStatusMessage = defaultGetStatusMessage,
  onPlacedItemClick,
  isItemClickable = defaultIsItemClickable
}) => {
  const state = useGameState();
  const dispatch = useGameDispatch();
  const {
    activeDrag,
    setActiveDrag,
    proxyRef,
    targetCanvasKeyRef,
    setLastDropResult
  } = useDragContext();
  const canvas = stateKey ? state.canvases?.[stateKey] ?? state.canvas : state.canvas;
  const canvasKey = stateKey ?? canvas.config.stateKey ?? canvas.config.id ?? "default";
  const canvasRef = reactExports.useRef(null);
  const activeDragRef = reactExports.useRef(null);
  const placedItemRefs = reactExports.useRef(/* @__PURE__ */ new Map());
  const draggablesRef = reactExports.useRef([]);
  const callbacksRef = reactExports.useRef(null);
  const [dragPreview, setDragPreview] = reactExports.useState(null);
  const [hoveredBlock, setHoveredBlock] = reactExports.useState(null);
  const [draggingItemId, setDraggingItemId] = reactExports.useState(null);
  const [canvasSize, setCanvasSize] = reactExports.useState({
    width: 0,
    height: 0,
    gapX: 0,
    gapY: 0
  });
  const orientation = canvas.config.orientation ?? "horizontal";
  reactExports.useEffect(() => {
    activeDragRef.current = activeDrag;
  }, [activeDrag]);
  reactExports.useEffect(() => {
    if (activeDrag) {
      return;
    }
    setDragPreview(null);
    setHoveredBlock(null);
  }, [activeDrag]);
  const placedItemsByKey = reactExports.useMemo(() => {
    const map = /* @__PURE__ */ new Map();
    for (const item of canvas.placedItems) {
      map.set(`${item.blockX}-${item.blockY}`, item);
    }
    return map;
  }, [canvas.placedItems]);
  const orderedBlocks = reactExports.useMemo(() => {
    if (orientation !== "vertical") {
      return canvas.blocks.flat();
    }
    const blocks = [];
    for (let x = 0; x < canvas.config.columns; x += 1) {
      for (let y = 0; y < canvas.config.rows; y += 1) {
        const block = canvas.blocks[y]?.[x];
        if (block) {
          blocks.push(block);
        }
      }
    }
    return blocks;
  }, [canvas.blocks, canvas.config.columns, canvas.config.rows, orientation]);
  reactExports.useEffect(() => {
    if (!activeDrag || !canvasRef.current) {
      return;
    }
    const element = canvasRef.current;
    const handlePointerMove = (event) => {
      const rect = element.getBoundingClientRect();
      const isInside = event.clientX >= rect.left && event.clientX <= rect.right && event.clientY >= rect.top && event.clientY <= rect.bottom;
      if (!isInside) {
        return;
      }
      if (targetCanvasKeyRef.current !== canvasKey) {
        targetCanvasKeyRef.current = canvasKey;
      }
    };
    window.addEventListener("pointermove", handlePointerMove);
    return () => window.removeEventListener("pointermove", handlePointerMove);
  }, [activeDrag, canvasKey]);
  reactExports.useEffect(() => {
    const element = canvasRef.current;
    if (!element) {
      return;
    }
    const updateSize = () => {
      const rect = element.getBoundingClientRect();
      const styles = window.getComputedStyle(element);
      const gapX = Number.parseFloat(styles.columnGap || styles.gap || "0");
      const gapY = Number.parseFloat(styles.rowGap || styles.gap || "0");
      setCanvasSize({ width: rect.width, height: rect.height, gapX, gapY });
    };
    updateSize();
    if (typeof ResizeObserver === "undefined") {
      window.addEventListener("resize", updateSize);
      return () => window.removeEventListener("resize", updateSize);
    }
    const observer = new ResizeObserver(updateSize);
    observer.observe(element);
    return () => observer.disconnect();
  }, []);
  const blockWidth = (canvasSize.width - canvasSize.gapX * (canvas.config.columns - 1)) / canvas.config.columns || 0;
  const blockHeight = useBreakpointValue({ base: 48, sm: 54, md: 60 }) ?? BLOCK_HEIGHT;
  const stepX = blockWidth + canvasSize.gapX;
  const stepY = blockHeight + canvasSize.gapY;
  const gridMetrics = reactExports.useMemo(
    () => ({
      blockWidth,
      blockHeight,
      gapX: canvasSize.gapX,
      gapY: canvasSize.gapY
    }),
    [blockWidth, blockHeight, canvasSize.gapX, canvasSize.gapY]
  );
  const canPlaceItemAt = reactExports.useCallback(
    (data, target, targetCanvasKey) => {
      if (target.blockX < 0 || target.blockY < 0 || target.blockX >= canvas.config.columns || target.blockY >= canvas.config.rows) {
        return false;
      }
      if (targetCanvasKey) {
        const inventoryMatch = findInventoryItem(
          state.inventory.groups,
          data.itemId
        );
        if (inventoryMatch?.item && !inventoryMatch.item.allowedPlaces.includes(targetCanvasKey)) {
          return false;
        }
      }
      const blockKey = `${target.blockX}-${target.blockY}`;
      const placedItem = placedItemsByKey.get(blockKey);
      const isOccupied = Boolean(placedItem);
      return !isOccupied;
    },
    [
      canvas.config.columns,
      canvas.config.rows,
      placedItemsByKey,
      state.inventory.groups
    ]
  );
  const getSwapTarget = reactExports.useCallback(
    (data, target) => {
      if (!data.isReposition) {
        return null;
      }
      const blockKey = `${target.blockX}-${target.blockY}`;
      const targetItem = placedItemsByKey.get(blockKey);
      if (!targetItem) {
        return null;
      }
      if (targetItem.itemId === data.itemId) {
        return null;
      }
      return targetItem;
    },
    [placedItemsByKey]
  );
  const placeOrRepositionItem = reactExports.useCallback(
    (data, target) => {
      if (data.isReposition && typeof data.fromBlockX === "number" && typeof data.fromBlockY === "number") {
        if (data.fromBlockX === target.blockX && data.fromBlockY === target.blockY) {
          return false;
        }
        const swapTarget = getSwapTarget(data, target);
        if (swapTarget) {
          dispatch({
            type: "SWAP_ITEMS",
            payload: {
              from: {
                canvasKey: stateKey,
                blockX: data.fromBlockX,
                blockY: data.fromBlockY
              },
              to: {
                canvasKey: stateKey,
                blockX: target.blockX,
                blockY: target.blockY
              }
            }
          });
          return true;
        }
        if (!canPlaceItemAt(data, target, canvasKey)) {
          return false;
        }
        dispatch({
          type: "REPOSITION_ITEM",
          payload: {
            itemId: data.itemId,
            fromBlockX: data.fromBlockX,
            fromBlockY: data.fromBlockY,
            toBlockX: target.blockX,
            toBlockY: target.blockY,
            stateKey
          }
        });
        return true;
      }
      if (!canPlaceItemAt(data, target, canvasKey)) {
        return false;
      }
      dispatch({
        type: "PLACE_ITEM",
        payload: {
          itemId: data.itemId,
          blockX: target.blockX,
          blockY: target.blockY,
          stateKey
        }
      });
      return true;
    },
    [canPlaceItemAt, dispatch, getSwapTarget, stateKey, canvasKey]
  );
  callbacksRef.current = { canPlaceItemAt, placeOrRepositionItem };
  reactExports.useEffect(() => {
    ensureGsapPlugins();
  }, []);
  reactExports.useLayoutEffect(() => {
    if (!canvasRef.current || !blockWidth || !blockHeight) {
      return;
    }
    for (const handle of draggablesRef.current) {
      handle.cleanup();
    }
    draggablesRef.current = [];
    for (const item of canvas.placedItems) {
      const el = placedItemRefs.current.get(item.id);
      if (!el) {
        continue;
      }
      const placedItem = item;
      const dragData = {
        itemId: placedItem.itemId,
        itemType: placedItem.type,
        isReposition: true,
        fromBlockX: placedItem.blockX,
        fromBlockY: placedItem.blockY
      };
      const startX = placedItem.blockX * stepX;
      const startY = placedItem.blockY * stepY;
      const getOtherPlacedElements = () => {
        const others = [];
        for (const [id, element] of placedItemRefs.current) {
          if (id !== placedItem.id) {
            others.push(element);
          }
        }
        return others;
      };
      const handle = createDraggable(el, {
        inertia: false,
        minimumMovement: 4,
        onClick: () => {
          if (el.dataset.wasDragged === "true") {
            el.dataset.wasDragged = "false";
            return;
          }
          if (onPlacedItemClick && isItemClickable(placedItem)) {
            onPlacedItemClick(placedItem);
          }
        },
        onDragStart: function() {
          el.dataset.wasDragged = "true";
          const rect = el.getBoundingClientRect();
          const pointerOffset = {
            x: this.pointerX - rect.left,
            y: this.pointerY - rect.top
          };
          setDraggingItemId(placedItem.id);
          setActiveDrag({
            source: "canvas",
            data: {
              ...dragData,
              itemName: placedItem.type
            },
            sourceCanvasKey: canvasKey,
            element: el,
            initialRect: rect,
            pointerOffset
          });
          targetCanvasKeyRef.current = canvasKey;
          el.style.opacity = "0";
        },
        onDrag: function() {
          const centerX = startX + this.x + blockWidth / 2;
          const centerY = startY + this.y + blockHeight / 2;
          const { blockX, blockY } = convertPixelToBlock(
            centerX,
            centerY,
            gridMetrics
          );
          const isOutOfBounds = blockX < 0 || blockY < 0 || blockX >= canvas.config.columns || blockY >= canvas.config.rows;
          if (isOutOfBounds) {
            setHoveredBlock(null);
            setDragPreview(null);
            return;
          }
          const collidingElement = hitTestAny(
            el,
            getOtherPlacedElements(),
            "50%"
          );
          const hasCollision = collidingElement !== null;
          const swapTarget = getSwapTarget(dragData, { blockX, blockY });
          const canSwap = Boolean(swapTarget);
          const isOriginalPosition = blockX === placedItem.blockX && blockY === placedItem.blockY;
          setHoveredBlock({ x: blockX, y: blockY });
          setDragPreview({
            itemId: placedItem.itemId,
            itemType: placedItem.type,
            blockX,
            blockY,
            x: blockX * stepX,
            y: blockY * stepY,
            width: blockWidth,
            height: blockHeight,
            valid: !hasCollision || isOriginalPosition || canSwap
          });
        },
        onDragEnd: function() {
          const inventoryPanels = Array.from(
            document.querySelectorAll("[data-inventory-panel]")
          );
          const isOverInventory = inventoryPanels.some((panel) => {
            const rect = panel.getBoundingClientRect();
            return this.pointerX >= rect.left && this.pointerX <= rect.right && this.pointerY >= rect.top && this.pointerY <= rect.bottom;
          });
          const dragSnapshot = activeDragRef.current;
          const targetCanvasKey = targetCanvasKeyRef.current;
          const sourceCanvasKey = dragSnapshot?.sourceCanvasKey ?? canvasKey;
          const isCrossCanvas = targetCanvasKey && targetCanvasKey !== sourceCanvasKey;
          const finishDrag = (restoreOpacity = true) => {
            setActiveDrag(null);
            setDragPreview(null);
            setHoveredBlock(null);
            setDraggingItemId(null);
            targetCanvasKeyRef.current = void 0;
            if (restoreOpacity) {
              el.style.opacity = "1";
            }
          };
          const animateProxyTo = (targetX2, targetY2, targetWidth, targetHeight, onComplete) => {
            if (!proxyRef.current) {
              onComplete();
              return;
            }
            gsapWithCSS.to(proxyRef.current, {
              x: targetX2,
              y: targetY2,
              width: targetWidth,
              height: targetHeight,
              duration: 0.2,
              ease: "power2.out",
              onComplete
            });
          };
          if (isOverInventory) {
            dispatch({
              type: "REMOVE_ITEM",
              payload: {
                blockX: placedItem.blockX,
                blockY: placedItem.blockY,
                stateKey
              }
            });
            gsapWithCSS.set(el, { x: 0, y: 0, clearProps: "transform" });
            finishDrag(false);
            return;
          }
          if (isCrossCanvas && state.canvases) {
            const targetCanvas = state.canvases[targetCanvasKey];
            const targetElement = document.querySelector(
              `[data-game-canvas][data-canvas-key="${targetCanvasKey}"]`
            );
            if (targetCanvas && targetElement) {
              const rect = targetElement.getBoundingClientRect();
              const styles = window.getComputedStyle(targetElement);
              const gapX = Number.parseFloat(
                styles.columnGap || styles.gap || "0"
              );
              const gapY = Number.parseFloat(
                styles.rowGap || styles.gap || "0"
              );
              const targetBlockWidth = (rect.width - gapX * (targetCanvas.config.columns - 1)) / targetCanvas.config.columns || 0;
              const { blockX: blockX2, blockY: blockY2 } = convertPixelToBlock(
                this.pointerX - rect.left,
                this.pointerY - rect.top,
                {
                  blockWidth: targetBlockWidth,
                  blockHeight,
                  gapX,
                  gapY
                }
              );
              const isInsideTarget = blockX2 >= 0 && blockY2 >= 0 && blockX2 < targetCanvas.config.columns && blockY2 < targetCanvas.config.rows;
              if (isInsideTarget) {
                const targetBlock = targetCanvas.blocks[blockY2]?.[blockX2];
                const isTargetOccupied = Boolean(targetBlock?.itemId);
                if (isTargetOccupied) {
                  dispatch({
                    type: "SWAP_ITEMS",
                    payload: {
                      from: {
                        canvasKey: sourceCanvasKey,
                        blockX: placedItem.blockX,
                        blockY: placedItem.blockY
                      },
                      to: {
                        canvasKey: targetCanvasKey,
                        blockX: blockX2,
                        blockY: blockY2
                      }
                    }
                  });
                } else {
                  dispatch({
                    type: "TRANSFER_ITEM",
                    payload: {
                      itemId: placedItem.itemId,
                      fromCanvas: sourceCanvasKey,
                      fromBlockX: placedItem.blockX,
                      fromBlockY: placedItem.blockY,
                      toCanvas: targetCanvasKey,
                      toBlockX: blockX2,
                      toBlockY: blockY2
                    }
                  });
                }
                gsapWithCSS.set(el, { x: 0, y: 0, clearProps: "transform" });
                finishDrag();
                return;
              }
            }
            gsapWithCSS.set(el, { x: 0, y: 0, clearProps: "transform" });
            finishDrag();
            return;
          }
          const canvasElement = canvasRef.current;
          if (!canvasElement) {
            gsapWithCSS.set(el, { x: 0, y: 0, clearProps: "transform" });
            finishDrag();
            return;
          }
          const canvasRect = canvasElement.getBoundingClientRect();
          const centerX = startX + this.x + blockWidth / 2;
          const centerY = startY + this.y + blockHeight / 2;
          const { blockX, blockY } = convertPixelToBlock(
            centerX,
            centerY,
            gridMetrics
          );
          const swapTarget = getSwapTarget(dragData, { blockX, blockY });
          const collidingElement = hitTestAny(
            el,
            getOtherPlacedElements(),
            "50%"
          );
          if (collidingElement && !swapTarget) {
            gsapWithCSS.set(el, { x: 0, y: 0, clearProps: "transform" });
            const originX = canvasRect.left + placedItem.blockX * stepX;
            const originY = canvasRect.top + placedItem.blockY * stepY;
            animateProxyTo(originX, originY, blockWidth, blockHeight, () => {
              finishDrag();
            });
            return;
          }
          const placed = callbacksRef.current?.placeOrRepositionItem(dragData, {
            blockX,
            blockY
          });
          if (!placed) {
            gsapWithCSS.set(el, { x: 0, y: 0, clearProps: "transform" });
            const originX = canvasRect.left + placedItem.blockX * stepX;
            const originY = canvasRect.top + placedItem.blockY * stepY;
            animateProxyTo(originX, originY, blockWidth, blockHeight, () => {
              finishDrag();
            });
            return;
          }
          const targetX = canvasRect.left + blockX * stepX;
          const targetY = canvasRect.top + blockY * stepY;
          gsapWithCSS.set(el, { x: 0, y: 0, clearProps: "transform" });
          animateProxyTo(targetX, targetY, blockWidth, blockHeight, () => {
            finishDrag();
          });
        }
      });
      draggablesRef.current.push(handle);
    }
    return () => {
      for (const handle of draggablesRef.current) {
        handle.cleanup();
      }
      draggablesRef.current = [];
    };
  }, [
    blockHeight,
    blockWidth,
    canPlaceItemAt,
    canvas.placedItems,
    getSwapTarget,
    dispatch,
    gridMetrics,
    isItemClickable,
    onPlacedItemClick,
    proxyRef,
    setActiveDrag,
    state.canvases,
    canvasKey,
    stateKey,
    stepX,
    stepY,
    canvas.config.columns,
    canvas.config.rows
  ]);
  reactExports.useEffect(() => {
    if (!activeDrag || activeDrag.source !== "inventory" || !canvasRef.current) {
      return;
    }
    const canvasElement = canvasRef.current;
    let lastBlockX = null;
    let lastBlockY = null;
    const handlePointerMove = (event) => {
      const rect = canvasElement.getBoundingClientRect();
      const x = event.clientX - rect.left;
      const y = event.clientY - rect.top;
      const isInside = x >= 0 && y >= 0 && x <= rect.width && y <= rect.height;
      if (isInside) {
        targetCanvasKeyRef.current = canvasKey;
      }
      if (x < 0 || y < 0 || x > rect.width || y > rect.height) {
        setDragPreview(null);
        setHoveredBlock(null);
        return;
      }
      const { blockX, blockY } = convertPixelToBlock(x, y, gridMetrics);
      if (blockX < 0 || blockY < 0 || blockX >= canvas.config.columns || blockY >= canvas.config.rows) {
        setDragPreview(null);
        setHoveredBlock(null);
        return;
      }
      if (lastBlockX !== blockX || lastBlockY !== blockY) {
        lastBlockX = blockX;
        lastBlockY = blockY;
        const valid = canPlaceItemAt(
          activeDrag.data,
          { blockX, blockY },
          canvasKey
        );
        setHoveredBlock({ x: blockX, y: blockY });
        setDragPreview({
          itemId: activeDrag.data.itemId,
          itemType: activeDrag.data.itemType,
          blockX,
          blockY,
          x: blockX * stepX,
          y: blockY * stepY,
          width: blockWidth,
          height: blockHeight,
          valid
        });
      }
    };
    const handlePointerUp = (event) => {
      const targetCanvasKey = targetCanvasKeyRef.current;
      if (targetCanvasKey && targetCanvasKey !== canvasKey) {
        return;
      }
      const rect = canvasElement.getBoundingClientRect();
      const x = event.clientX - rect.left;
      const y = event.clientY - rect.top;
      const isInsideCanvas = x >= 0 && y >= 0 && x <= rect.width && y <= rect.height;
      const { blockX, blockY } = convertPixelToBlock(x, y, gridMetrics);
      const canPlace = isInsideCanvas && canPlaceItemAt(activeDrag.data, { blockX, blockY }, canvasKey);
      if (canPlace && proxyRef.current) {
        const targetX = rect.left + blockX * stepX;
        const targetY = rect.top + blockY * stepY;
        gsapWithCSS.to(proxyRef.current, {
          x: targetX,
          y: targetY,
          width: blockWidth,
          height: blockHeight,
          duration: 0.2,
          ease: "power2.out",
          onComplete: () => {
            placeOrRepositionItem(activeDrag.data, { blockX, blockY });
            setLastDropResult({ source: "inventory", placed: true });
            setActiveDrag(null);
            setDragPreview(null);
            setHoveredBlock(null);
            targetCanvasKeyRef.current = void 0;
          }
        });
      } else {
        setLastDropResult({ source: "inventory", placed: false });
        setActiveDrag(null);
        setDragPreview(null);
        setHoveredBlock(null);
        targetCanvasKeyRef.current = void 0;
      }
    };
    window.addEventListener("pointermove", handlePointerMove);
    window.addEventListener("pointerup", handlePointerUp);
    return () => {
      window.removeEventListener("pointermove", handlePointerMove);
      window.removeEventListener("pointerup", handlePointerUp);
    };
  }, [
    activeDrag,
    blockHeight,
    blockWidth,
    canPlaceItemAt,
    canvas.config.columns,
    canvas.config.rows,
    canvasKey,
    gridMetrics,
    placeOrRepositionItem,
    proxyRef,
    setActiveDrag,
    setLastDropResult,
    stepX,
    stepY
  ]);
  const setPlacedItemRef = reactExports.useCallback(
    (itemId) => (el) => {
      if (el) {
        placedItemRefs.current.set(itemId, el);
      } else {
        placedItemRefs.current.delete(itemId);
      }
    },
    []
  );
  const showGrid = true;
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(
    Box,
    {
      className: "play-canvas",
      "data-game-canvas": true,
      bg: "gray.950",
      p: { base: 2, md: 4 },
      overflow: "visible",
      position: "relative",
      display: "flex",
      flexDirection: "column",
      gap: 3,
      children: [
        title ? /* @__PURE__ */ jsxRuntimeExports.jsx(Flex, { align: "center", justify: "space-between", mb: { base: 0, md: 4 }, children: /* @__PURE__ */ jsxRuntimeExports.jsx(
          Text,
          {
            fontSize: { base: "xs", md: "sm" },
            fontWeight: "bold",
            color: "gray.200",
            children: title
          }
        ) }) : null,
        /* @__PURE__ */ jsxRuntimeExports.jsxs(
          Box,
          {
            ref: canvasRef,
            position: "relative",
            display: "grid",
            "data-game-canvas": true,
            "data-canvas-key": canvasKey,
            gridTemplateColumns: `repeat(${canvas.config.columns}, minmax(0, 1fr))`,
            gridTemplateRows: `repeat(${canvas.config.rows}, ${blockHeight}px)`,
            gridAutoFlow: orientation === "vertical" ? "column" : "row",
            gap: 2,
            children: [
              orderedBlocks.map((block) => {
                const key = `${block.x}-${block.y}`;
                const placedItem = placedItemsByKey.get(key);
                const isHovered = hoveredBlock?.x === block.x && hoveredBlock?.y === block.y;
                const borderColor = isHovered && dragPreview ? dragPreview.valid ? "cyan.400" : "red.400" : "gray.700";
                return /* @__PURE__ */ jsxRuntimeExports.jsx(
                  GridCell,
                  {
                    borderColor,
                    showBorder: showGrid,
                    isOccupied: Boolean(placedItem),
                    height: blockHeight
                  },
                  key
                );
              }),
              canvas.placedItems.map((item) => {
                const isDragging = draggingItemId === item.id;
                return /* @__PURE__ */ jsxRuntimeExports.jsx(
                  PlacedItemCard,
                  {
                    item,
                    x: item.blockX * stepX,
                    y: item.blockY * stepY,
                    width: blockWidth,
                    height: blockHeight,
                    isDragging,
                    getItemLabel,
                    getStatusMessage,
                    itemRef: setPlacedItemRef(item.id)
                  },
                  item.id
                );
              }),
              dragPreview && /* @__PURE__ */ jsxRuntimeExports.jsx(
                Box,
                {
                  position: "absolute",
                  zIndex: 10,
                  top: `${dragPreview.y}px`,
                  left: `${dragPreview.x}px`,
                  width: `${dragPreview.width}px`,
                  height: `${dragPreview.height}px`,
                  border: "1px dashed",
                  borderColor: dragPreview.valid ? "cyan.300" : "red.400",
                  borderRadius: "md",
                  pointerEvents: "none",
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  bg: "rgba(15, 23, 42, 0.8)",
                  children: /* @__PURE__ */ jsxRuntimeExports.jsx(Text, { fontSize: "xs", color: "gray.100", children: getItemLabel(dragPreview.itemType) })
                }
              )
            ]
          }
        )
      ]
    }
  );
};
const TerminalLayout = ({
  visible,
  view,
  input,
  title = "Terminal",
  height = "40vh",
  focusRef
}) => {
  const [isCollapsed, setIsCollapsed] = reactExports.useState(false);
  reactExports.useEffect(() => {
    if (visible && !isCollapsed) {
      focusRef?.current?.focus();
    }
  }, [focusRef, isCollapsed, visible]);
  const handleToggleCollapse = reactExports.useCallback(() => {
    setIsCollapsed((prev) => !prev);
  }, []);
  const handleExpandClick = reactExports.useCallback(() => {
    setIsCollapsed(false);
  }, []);
  if (!visible) {
    return null;
  }
  if (isCollapsed) {
    return /* @__PURE__ */ jsxRuntimeExports.jsx(
      Box,
      {
        position: "fixed",
        bottom: 0,
        left: 0,
        right: 0,
        zIndex: 100,
        bg: "gray.900",
        borderTop: "1px solid",
        borderColor: "gray.700",
        cursor: "pointer",
        onClick: handleExpandClick,
        _hover: { bg: "gray.800" },
        role: "button",
        "aria-label": "Expand terminal",
        tabIndex: 0,
        onKeyDown: (event) => {
          if (event.key === "Enter" || event.key === " ") {
            event.preventDefault();
            handleExpandClick();
          }
        },
        children: /* @__PURE__ */ jsxRuntimeExports.jsx(Flex, { align: "center", justify: "flex-start", px: 4, py: 3, children: /* @__PURE__ */ jsxRuntimeExports.jsx(Text, { fontWeight: "bold", color: "gray.100", fontFamily: "mono", children: title }) })
      }
    );
  }
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(
    Box,
    {
      as: "section",
      role: "region",
      "aria-label": title,
      position: "fixed",
      bottom: 0,
      left: 0,
      right: 0,
      height,
      bg: "gray.900",
      color: "gray.200",
      borderTop: "1px solid",
      borderColor: "gray.700",
      display: "flex",
      flexDirection: "column",
      zIndex: 100,
      children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs(
          Flex,
          {
            align: "center",
            justify: "space-between",
            px: 4,
            py: 2,
            borderBottom: "1px solid",
            borderColor: "gray.800",
            flexShrink: 0,
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Text, { fontWeight: "bold", color: "gray.100", fontSize: "sm", children: title }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                Box,
                {
                  asChild: true,
                  px: 2,
                  py: 1,
                  borderRadius: "md",
                  color: "gray.400",
                  _hover: { bg: "gray.800", color: "gray.100" },
                  cursor: "pointer",
                  children: /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "button",
                    {
                      type: "button",
                      onClick: handleToggleCollapse,
                      "aria-label": "Collapse terminal",
                      children: /* @__PURE__ */ jsxRuntimeExports.jsx(Text, { fontSize: "xs", children: "✕" })
                    }
                  )
                }
              )
            ]
          }
        ),
        view,
        input && /* @__PURE__ */ jsxRuntimeExports.jsx(Box, { px: 4, py: 3, borderTop: "1px solid", borderColor: "gray.800", children: input })
      ]
    }
  );
};
const TerminalInput = ({
  value,
  onChange,
  onKeyDown,
  placeholder,
  disabled,
  inputRef,
  inputProps
}) => {
  return /* @__PURE__ */ jsxRuntimeExports.jsx(
    Input,
    {
      ref: inputRef,
      value,
      onChange: (event) => onChange(event.target.value),
      onKeyDown,
      placeholder,
      size: "sm",
      fontFamily: "mono",
      bg: "gray.800",
      borderColor: "gray.700",
      _placeholder: { color: "gray.500" },
      disabled,
      "aria-label": "Terminal input",
      ...inputProps
    }
  );
};
const entryStyles = {
  prompt: { color: "gray.100", fontWeight: "bold" },
  input: { color: "green.300" },
  output: { color: "gray.200" },
  error: { color: "red.300" },
  hint: { color: "gray.400", fontStyle: "italic" }
};
const TerminalEntryRow = reactExports.memo(
  ({ entry, entryPrefix }) => {
    const styles = entryStyles[entry.type];
    const content = entryPrefix ? `${entryPrefix}${entry.content}` : entry.type === "input" ? `> ${entry.content}` : entry.content;
    return /* @__PURE__ */ jsxRuntimeExports.jsx(
      Text,
      {
        fontSize: "sm",
        color: styles.color,
        fontStyle: styles.fontStyle,
        fontWeight: styles.fontWeight,
        children: content
      }
    );
  }
);
const TerminalView = ({
  history,
  prompt,
  isCompleted = false,
  completionMessage = "Question completed. Terminal input is disabled.",
  entryPrefix,
  containerProps
}) => {
  const historyRef = reactExports.useRef(null);
  const { flex = "1", ...restContainerProps } = containerProps ?? {};
  const promptBlock = reactExports.useMemo(() => {
    if (!prompt) {
      return null;
    }
    return /* @__PURE__ */ jsxRuntimeExports.jsx(Text, { fontSize: "sm", color: "gray.100", fontWeight: "bold", children: prompt });
  }, [prompt]);
  reactExports.useEffect(() => {
    if (history.length === 0 && !prompt) {
      return;
    }
    historyRef.current?.scrollTo({
      top: historyRef.current.scrollHeight,
      behavior: "smooth"
    });
  }, [history.length, prompt]);
  return /* @__PURE__ */ jsxRuntimeExports.jsx(
    Box,
    {
      ref: historyRef,
      flex,
      overflowY: "auto",
      px: 4,
      py: 3,
      fontFamily: "mono",
      role: "log",
      "aria-live": "polite",
      ...restContainerProps,
      children: /* @__PURE__ */ jsxRuntimeExports.jsxs(Flex, { direction: "column", gap: 2, children: [
        promptBlock,
        history.map((entry) => /* @__PURE__ */ jsxRuntimeExports.jsx(
          TerminalEntryRow,
          {
            entry,
            entryPrefix
          },
          entry.id
        )),
        isCompleted && /* @__PURE__ */ jsxRuntimeExports.jsx(Text, { fontSize: "sm", color: "green.300", fontWeight: "bold", children: completionMessage })
      ] })
    }
  );
};
const MAX_INPUT_LENGTH = 200;
const sanitizeInput = (input) => input.slice(0, MAX_INPUT_LENGTH).replace(/<[^>]*>/g, "").replace(/[<>"'&]/g, "").trim();
const useTerminalInput = () => {
  const dispatch = useGameDispatch();
  const [input, setInput] = reactExports.useState("");
  const [historyIndex, setHistoryIndex] = reactExports.useState(null);
  const [commandHistory, setCommandHistory] = reactExports.useState([]);
  const inputRef = reactExports.useRef(null);
  const handleSubmit = reactExports.useCallback(() => {
    const sanitized = sanitizeInput(input);
    if (!sanitized) {
      return;
    }
    dispatch({ type: "SUBMIT_COMMAND", payload: { input: sanitized } });
    setInput("");
    setHistoryIndex(null);
    setCommandHistory(
      (prev) => [...prev, sanitized].slice(-50)
    );
  }, [dispatch, input]);
  const handleHistoryUp = reactExports.useCallback(() => {
    if (commandHistory.length === 0) {
      return;
    }
    if (historyIndex === null) {
      const lastIndex = commandHistory.length - 1;
      setHistoryIndex(lastIndex);
      setInput(commandHistory[lastIndex]);
      return;
    }
    const nextIndex = Math.max(historyIndex - 1, 0);
    setHistoryIndex(nextIndex);
    setInput(commandHistory[nextIndex]);
  }, [commandHistory, historyIndex]);
  const handleHistoryDown = reactExports.useCallback(() => {
    if (historyIndex === null) {
      return;
    }
    const nextIndex = historyIndex + 1;
    if (nextIndex >= commandHistory.length) {
      setHistoryIndex(null);
      setInput("");
      return;
    }
    setHistoryIndex(nextIndex);
    setInput(commandHistory[nextIndex]);
  }, [commandHistory, historyIndex]);
  const handleKeyDown = reactExports.useCallback(
    (event) => {
      if (event.key === "Enter") {
        event.preventDefault();
        handleSubmit();
        return;
      }
      if (event.key === "ArrowUp") {
        event.preventDefault();
        handleHistoryUp();
        return;
      }
      if (event.key === "ArrowDown") {
        event.preventDefault();
        handleHistoryDown();
        return;
      }
      if (event.key === "Escape") {
        event.preventDefault();
        setInput("");
        setHistoryIndex(null);
        return;
      }
      if (event.key.toLowerCase() === "l" && event.ctrlKey) {
        event.preventDefault();
        dispatch({ type: "CLEAR_TERMINAL_HISTORY" });
      }
    },
    [dispatch, handleHistoryDown, handleHistoryUp, handleSubmit]
  );
  return {
    value: input,
    onChange: setInput,
    onKeyDown: handleKeyDown,
    inputRef
  };
};
const evaluateCondition = (condition, context) => {
  switch (condition.kind) {
    case "and":
      return condition.all.every((entry) => evaluateCondition(entry, context));
    case "or":
      return condition.any.some((entry) => evaluateCondition(entry, context));
    case "not":
      return !evaluateCondition(condition.value, context);
    case "flag":
      return Boolean(context[condition.key]) === condition.is;
    case "eq":
      return context[condition.key] === condition.value;
    case "in": {
      const value = context[condition.key];
      if (value === void 0 || value === null) {
        return false;
      }
      return condition.values.includes(value);
    }
    default:
      return false;
  }
};
const resolvePhase = (rules, context, currentPhase, fallbackPhase) => {
  let nextPhase = fallbackPhase;
  for (const rule of rules) {
    if (!evaluateCondition(rule.when, context)) {
      continue;
    }
    if (rule.kind === "retain") {
      return { nextPhase: currentPhase, shouldRetain: true };
    }
    nextPhase = rule.to;
  }
  return { nextPhase, shouldRetain: false };
};
const resolveVisibility = (rules, context, key, current) => {
  let next = current;
  for (const rule of rules) {
    const matchesKey = "groupId" in rule ? rule.groupId === key : rule.canvasKey === key;
    if (!matchesKey) {
      continue;
    }
    if (!evaluateCondition(rule.when, context)) {
      continue;
    }
    next = rule.kind === "show-group" || rule.kind === "show";
  }
  return next;
};
export {
  GameProvider as G,
  InventoryDrawer as I,
  PlayCanvas as P,
  TerminalLayout as T,
  useGameState as a,
  useTerminalInput as b,
  useTerminalEngine as c,
  resolveVisibility as d,
  GameShell as e,
  TerminalInput as f,
  TerminalView as g,
  useAllCanvases as h,
  useEngineProgress as i,
  resolvePhase as r,
  useGameDispatch as u
};
