import { j as jsxRuntimeExports, r as reactExports } from "../_libs/react.mjs";
import { d as useNavigate } from "../_libs/@tanstack/react-router.mjs";
import { u as useDragEngine } from "./use-drag-engine-CAadIO0l.mjs";
import { G as GameProvider, u as useGameDispatch, a as useGameState, b as useTerminalInput, c as useTerminalEngine, r as resolvePhase, e as GameShell, P as PlayCanvas, I as InventoryDrawer, T as TerminalLayout, f as TerminalInput, g as TerminalView, h as useAllCanvases } from "./question-ast-DxRXheAC.mjs";
import { m as markNetworkingQuestionComplete, b as getNextQuestionPath } from "./module-progress-CKDPPitT.mjs";
import { F as Flex, B as Box, T as Text } from "../_libs/@chakra-ui/react.mjs";
import "../_libs/@babel/runtime.mjs";
import "../_libs/tiny-warning.mjs";
import "../_libs/@tanstack/router-core.mjs";
import "../_libs/@tanstack/store.mjs";
import "../_libs/@tanstack/history.mjs";
import "../_libs/tiny-invariant.mjs";
import "node:stream/web";
import "node:stream";
import "../_libs/react-dom.mjs";
import "util";
import "crypto";
import "async_hooks";
import "stream";
import "../_libs/isbot.mjs";
import "../_libs/@tanstack/react-store.mjs";
import "../_libs/use-sync-external-store.mjs";
import "../_libs/gsap.mjs";
import "../_libs/@iconify/react.mjs";
import "../_libs/lucide-react.mjs";
import "../_libs/@ark-ui/react.mjs";
import "../_libs/@zag-js/carousel.mjs";
import "../_libs/@zag-js/anatomy.mjs";
import "../_libs/@zag-js/types.mjs";
import "../_libs/@zag-js/core.mjs";
import "../_libs/@zag-js/utils.mjs";
import "../_libs/@zag-js/dom-query.mjs";
import "../_libs/@zag-js/checkbox.mjs";
import "../_libs/@zag-js/focus-visible.mjs";
import "../_libs/@zag-js/react.mjs";
import "../_libs/@zag-js/color-picker.mjs";
import "../_libs/@zag-js/color-utils.mjs";
import "../_libs/@zag-js/popper.mjs";
import "../_libs/@floating-ui/dom.mjs";
import "../_libs/@floating-ui/core.mjs";
import "../_libs/@floating-ui/utils.mjs";
import "../_libs/@zag-js/dismissable.mjs";
import "../_libs/@zag-js/interact-outside.mjs";
import "../_libs/@zag-js/combobox.mjs";
import "../_libs/@zag-js/collection.mjs";
import "../_libs/@zag-js/auto-resize.mjs";
import "../_libs/@zag-js/listbox.mjs";
import "../_libs/@zag-js/radio-group.mjs";
import "../_libs/@zag-js/tooltip.mjs";
import "../_libs/@zag-js/presence.mjs";
import "../_libs/@pandacss/is-valid-prop.mjs";
import "../_libs/@zag-js/switch.mjs";
import "../_libs/@zag-js/splitter.mjs";
import "../_libs/@zag-js/slider.mjs";
import "../_libs/@zag-js/select.mjs";
import "../_libs/@zag-js/rating-group.mjs";
import "../_libs/@zag-js/popover.mjs";
import "../_libs/@zag-js/menu.mjs";
import "../_libs/@zag-js/rect-utils.mjs";
import "../_libs/@zag-js/file-upload.mjs";
import "../_libs/@zag-js/editable.mjs";
import "../_libs/@zag-js/dialog.mjs";
import "../_libs/@zag-js/accordion.mjs";
import "../_libs/@zag-js/clipboard.mjs";
import "../_libs/@zag-js/avatar.mjs";
import "../_libs/@zag-js/collapsible.mjs";
import "../_libs/@zag-js/hover-card.mjs";
import "../_libs/@zag-js/number-input.mjs";
import "../_libs/@internationalized/number.mjs";
import "../_libs/@zag-js/pin-input.mjs";
import "../_libs/@zag-js/progress.mjs";
import "../_libs/@zag-js/qr-code.mjs";
import "../_libs/@zag-js/scroll-area.mjs";
import "../_libs/@zag-js/tags-input.mjs";
import "../_libs/@zag-js/live-region.mjs";
import "../_libs/@zag-js/tree-view.mjs";
import "../_libs/@emotion/is-prop-valid.mjs";
import "../_libs/@emotion/memoize.mjs";
import "../_libs/@emotion/serialize.mjs";
import "../_libs/@emotion/hash.mjs";
import "../_libs/@emotion/unitless.mjs";
import "../_libs/@emotion/use-insertion-effect-with-fallbacks.mjs";
import "../_libs/@emotion/utils.mjs";
import "../_libs/@emotion/react.mjs";
import "../_libs/@emotion/cache.mjs";
import "../_libs/@emotion/sheet.mjs";
import "../_libs/@emotion/weak-memoize.mjs";
import "../_libs/stylis.mjs";
const QUESTION_ID = "internet-gateway";
const QUESTION_TITLE = "🌐 Connect to the Internet!";
const QUESTION_DESCRIPTION = "Now you can setup a router, but you can't reach Google yet. Connect to your ISP and configure the router to access the internet!";
const TERMINAL_PROMPT = "Your network is configured! Can you verify that you can reach Google?";
const GOOGLE_IP = "142.250.80.46";
const TERMINAL_INTRO_ENTRIES = [
  {
    id: "intro-internet-1",
    type: "output",
    content: "Available commands:",
    timestamp: 0
  },
  {
    id: "intro-internet-2",
    type: "output",
    content: "- ifconfig",
    timestamp: 1
  },
  {
    id: "intro-internet-3",
    type: "output",
    content: "- nslookup google.com",
    timestamp: 2
  },
  {
    id: "intro-internet-4",
    type: "output",
    content: "- ping google.com",
    timestamp: 3
  },
  {
    id: "intro-internet-5",
    type: "output",
    content: `- ping ${GOOGLE_IP}`,
    timestamp: 4
  }
];
const INVENTORY_ITEMS = [
  {
    id: "cable-1",
    type: "cable",
    name: "Ethernet Cable",
    allowedPlaces: ["inventory", "conn-1"],
    icon: { icon: "mdi:ethernet-cable", color: "#2596be" },
    behavior: "connectable"
  },
  {
    id: "fiber-1",
    type: "fiber",
    name: "Fiber Cable",
    allowedPlaces: ["inventory", "conn-2"],
    icon: { icon: "mdi:fiber-smart-record", color: "#f97316" },
    behavior: "connectable"
  },
  {
    id: "pc-1",
    type: "pc",
    name: "PC",
    allowedPlaces: ["inventory", "local"],
    icon: { icon: "twemoji:laptop-computer" },
    behavior: "connectable"
  },
  {
    id: "router-lan-1",
    type: "router-lan",
    name: "Router (LAN)",
    allowedPlaces: ["inventory", "router"],
    icon: { icon: "mdi:lan" },
    behavior: "connectable"
  },
  {
    id: "router-nat-1",
    type: "router-nat",
    name: "Router (NAT)",
    allowedPlaces: ["inventory", "router"],
    icon: { icon: "mdi:swap-horizontal" },
    behavior: "connectable"
  },
  {
    id: "router-wan-1",
    type: "router-wan",
    name: "Router (WAN)",
    allowedPlaces: ["inventory", "router"],
    icon: { icon: "mdi:wan" },
    behavior: "connectable"
  },
  {
    id: "igw-1",
    type: "igw",
    name: "Internet Gateway",
    allowedPlaces: ["inventory", "internet"],
    icon: { icon: "mdi:server-network" },
    behavior: "connectable"
  },
  {
    id: "internet-1",
    type: "internet",
    name: "Internet",
    allowedPlaces: ["inventory", "internet"],
    icon: { icon: "mdi:cloud" },
    behavior: "connectable"
  },
  {
    id: "dns-1",
    type: "dns",
    name: "DNS Server",
    allowedPlaces: ["inventory", "internet"],
    icon: { icon: "mdi:dns" },
    behavior: "connectable"
  },
  {
    id: "google-1",
    type: "google",
    name: "Google",
    allowedPlaces: ["inventory", "internet"],
    icon: { icon: "mdi:google" },
    behavior: "connectable"
  }
];
const INVENTORY_GROUPS = [
  {
    id: "default",
    title: "Inventory",
    visible: true,
    items: INVENTORY_ITEMS
  }
];
const CANVAS_ORDER = [
  "local",
  "conn-1",
  "router",
  "conn-2",
  "internet"
];
const CANVAS_CONFIGS = {
  local: {
    id: "internet-local",
    title: "Client",
    stateKey: "client",
    columns: 1,
    rows: 1,
    maxItems: 1
  },
  "conn-1": {
    id: "internet-conn-1",
    title: "Connector",
    stateKey: "conn-1",
    columns: 1,
    rows: 1,
    maxItems: 1
  },
  router: {
    id: "internet-router",
    title: "Router",
    stateKey: "router",
    columns: 3,
    rows: 1,
    maxItems: 3
  },
  "conn-2": {
    id: "internet-conn-2",
    title: "Connector",
    stateKey: "conn-2",
    columns: 1,
    rows: 1,
    maxItems: 1
  },
  internet: {
    id: "internet-external",
    title: "Internet",
    stateKey: "internet",
    columns: 4,
    rows: 1,
    maxItems: 4
  }
};
const PUBLIC_DNS_SERVERS = ["8.8.8.8", "8.8.4.4", "1.1.1.1", "1.0.0.1"];
const VALID_PPPOE_CREDENTIALS = {
  username: "user@telkom.net",
  password: "telkom123"
};
const EXPECTED_ORDER$1 = [
  "pc",
  "cable",
  "router-lan",
  "router-nat",
  "router-wan",
  "fiber",
  "igw",
  "internet",
  "dns",
  "google"
];
const isCorrectOrder = (placedItems) => {
  const sorted = [...placedItems].sort((a, b) => a.blockX - b.blockX);
  for (let i = 0; i < sorted.length; i++) {
    const expectedIndex = EXPECTED_ORDER$1.indexOf(sorted[i].type);
    if (i > 0) {
      const prevExpectedIndex = EXPECTED_ORDER$1.indexOf(sorted[i - 1].type);
      if (expectedIndex <= prevExpectedIndex) {
        return false;
      }
    }
  }
  return true;
};
const getContextualHint = (state) => {
  const {
    placedItems,
    pc,
    cable,
    routerLan,
    routerNat,
    routerWan,
    fiber,
    igw,
    internet,
    dns,
    google,
    allDevicesPlaced,
    routerLanConfigured,
    routerNatConfigured,
    routerWanConfigured,
    routerLanSettingsOpen,
    routerNatSettingsOpen,
    routerWanSettingsOpen,
    dhcpEnabled,
    natEnabled,
    startIp,
    endIp,
    dnsServer,
    connectionType,
    pppoeUsername,
    googleReachable
  } = state;
  if (routerWanConfigured && !dnsServer) {
    return "⚠️ You're connected to the internet but can't resolve domain names - set a DNS server in Router LAN";
  }
  if (dnsServer && !natEnabled && routerLanConfigured) {
    return "⚠️ DNS is configured but NAT is disabled - traffic can't leave your network";
  }
  if (placedItems.length === 0) {
    return "Drag the PC from inventory to the leftmost slot";
  }
  if (pc && !cable) {
    return "Connect the ethernet cable to the PC";
  }
  if (cable && !routerLan) {
    return "Place the Router (LAN) - this is where your home network starts";
  }
  if (routerLan && !routerNat) {
    return "Place the Router (NAT) - this translates your private IP";
  }
  if (routerNat && !routerWan) {
    return "Place the Router (WAN) - this connects to your ISP";
  }
  if (routerWan && !fiber) {
    return "Connect the fiber cable to the router's WAN side";
  }
  if (fiber && !igw) {
    return "Place the Internet Gateway - this is your ISP's modem";
  }
  if (igw && !internet) {
    return "Add the Internet cloud";
  }
  if (internet && !dns) {
    return "Place the DNS server - it translates domain names to IPs";
  }
  if (dns && !google) {
    return "Finally, place Google - your destination!";
  }
  if (allDevicesPlaced && !routerLanConfigured && !routerLanSettingsOpen) {
    return "Click Router (LAN) to configure DHCP and DNS settings";
  }
  if (routerLanSettingsOpen && !dhcpEnabled) {
    return "Enable DHCP so your PC can get an IP address";
  }
  if (routerLanSettingsOpen && dhcpEnabled && (!startIp || !endIp)) {
    return "Set the IP range (e.g., 192.168.1.100 to 192.168.1.200)";
  }
  if (routerLanSettingsOpen && dhcpEnabled && startIp && endIp && !dnsServer) {
    return "Set the DNS server (e.g., 8.8.8.8) so you can resolve domain names";
  }
  if (routerLanConfigured && !routerWanConfigured && !routerWanSettingsOpen) {
    return "Click Router (WAN) to configure your ISP connection";
  }
  if (routerWanSettingsOpen && !connectionType) {
    return "Select PPPoE as the connection type";
  }
  if (routerWanSettingsOpen && connectionType === "PPPoE" && !pppoeUsername) {
    return "Enter your ISP credentials (username: user@telkom.net)";
  }
  if (routerWanConfigured && !routerNatConfigured && !routerNatSettingsOpen) {
    return "Click Router (NAT) to enable address translation";
  }
  if (routerNatSettingsOpen && !natEnabled) {
    return "Enable NAT so your private IP can reach the internet";
  }
  if (placedItems.length > 1 && !isCorrectOrder(placedItems)) {
    return "❌ Devices must be connected in order: PC → Cable → Router LAN → Router NAT → Router WAN → Fiber → IGW → Internet → DNS → Google";
  }
  if (routerLanConfigured && routerNatConfigured && routerWanConfigured && googleReachable) {
    return "🎉 You're connected to the internet! Try pinging Google";
  }
  return "";
};
const INVENTORY_TOOLTIPS = {
  cable: {
    content: "Ethernet cable connects your PC to the router's LAN port",
    seeMoreHref: "https://www.google.com/search?q=what+is+ethernet+cable"
  },
  "router-lan": {
    content: "The LAN (Local Area Network) side of the router. Assigns private IP addresses to devices via DHCP and configures which DNS server to use.",
    seeMoreHref: "https://www.google.com/search?q=what+is+router+LAN"
  },
  "router-nat": {
    content: "NAT (Network Address Translation) translates private IP addresses to the public IP address so multiple devices can share one internet connection.",
    seeMoreHref: "https://www.google.com/search?q=what+is+NAT+network+address+translation"
  },
  "router-wan": {
    content: "The WAN (Wide Area Network) side of the router. Connects to your ISP using PPPoE authentication to get a public IP address.",
    seeMoreHref: "https://www.google.com/search?q=what+is+router+WAN+PPPoE"
  },
  fiber: {
    content: "Fiber optic cable provides high-speed connection to your ISP",
    seeMoreHref: "https://www.google.com/search?q=what+is+fiber+optic+internet"
  },
  igw: {
    content: "Internet Gateway (modem) connects your home to the ISP's network",
    seeMoreHref: "https://www.google.com/search?q=what+is+internet+gateway"
  },
  internet: {
    content: "The global network of interconnected computers",
    seeMoreHref: "https://www.google.com/search?q=how+does+the+internet+work"
  },
  dns: {
    content: "DNS Server translates domain names (google.com) to IP addresses",
    seeMoreHref: "https://www.google.com/search?q=what+is+DNS"
  },
  google: {
    content: "Google's server - your destination!",
    seeMoreHref: "https://www.google.com/search?q=how+do+websites+work"
  }
};
const getInternetItemLabel = (itemType) => {
  switch (itemType) {
    case "pc":
      return "PC";
    case "cable":
      return "Ethernet Cable";
    case "router-lan":
      return "Router (LAN)";
    case "router-nat":
      return "Router (NAT)";
    case "router-wan":
      return "Router (WAN)";
    case "fiber":
      return "Fiber Cable";
    case "igw":
      return "Internet Gateway";
    case "internet":
      return "Internet";
    case "dns":
      return "DNS Server";
    case "google":
      return "Google";
    default:
      return itemType.charAt(0).toUpperCase() + itemType.slice(1);
  }
};
const getInternetStatusMessage = (placedItem) => {
  const { type, status, data } = placedItem;
  switch (type) {
    case "pc": {
      const ip = typeof data?.ip === "string" ? data.ip : null;
      if (status === "error") {
        return "no ip";
      }
      if (status === "warning" && ip) {
        return ip;
      }
      if (status === "success" && ip) {
        return `I have access to internet!`;
      }
      return null;
    }
    case "router-lan": {
      if (status === "error") {
        return "not configured";
      }
      if (status === "warning") {
        return "no DNS";
      }
      if (status === "success") {
        return "configured";
      }
      return null;
    }
    case "router-nat": {
      if (status === "error") {
        return "disabled";
      }
      if (status === "success") {
        return "enabled";
      }
      return null;
    }
    case "router-wan": {
      const publicIp = typeof data?.publicIp === "string" ? data.publicIp : null;
      if (status === "error") {
        return "not configured";
      }
      if (status === "warning") {
        return "no connection";
      }
      if (status === "success") {
        return publicIp ? `connected ${publicIp}` : "connected";
      }
      return null;
    }
    case "igw": {
      if (status === "warning") {
        return "waiting for auth";
      }
      if (status === "success") {
        return "connected";
      }
      return null;
    }
    case "internet": {
      if (status === "warning") {
        return "no route";
      }
      if (status === "success") {
        return "online";
      }
      return null;
    }
    case "dns": {
      if (status === "error") {
        return "unreachable";
      }
      if (status === "success") {
        return "resolving";
      }
      return null;
    }
    case "google": {
      if (status === "error") {
        return "can't resolve";
      }
      if (status === "warning") {
        return "no route";
      }
      if (status === "success") {
        return "142.250.80.46";
      }
      return null;
    }
    case "cable":
    case "fiber":
      return null;
    default:
      return null;
  }
};
const PRIVATE_IP_RANGES$1 = [
  /^10\./,
  /^172\.(1[6-9]|2\d|3[01])\./,
  /^192\.168\./
];
const VALID_DNS_SERVERS = [
  "8.8.8.8",
  "8.8.4.4",
  "1.1.1.1",
  "1.0.0.1",
  "208.67.222.222"
];
const validateIpAddress = (input) => {
  if (!input) {
    return null;
  }
  const ipPattern = /^(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})$/;
  const match = input.match(ipPattern);
  if (!match) {
    return "Invalid format. Use 192.168.1.100";
  }
  const octets = [match[1], match[2], match[3], match[4]].map(
    (s) => Number.parseInt(s, 10)
  );
  if (octets.some((n) => n < 0 || n > 255)) {
    return "Each number must be 0-255.";
  }
  return null;
};
const validatePrivateIp = (input, allValues) => {
  const baseError = validateIpAddress(input);
  if (baseError) {
    return baseError;
  }
  if (!input) {
    return null;
  }
  if (!PRIVATE_IP_RANGES$1.some((range) => range.test(input))) {
    return "Use a private IP range (192.168.x.x)";
  }
  return null;
};
const validateEndIp = (input, allValues) => {
  const baseError = validatePrivateIp(input);
  if (baseError) {
    return baseError;
  }
  const startIp = allValues.startIp;
  if (!startIp || !input) {
    return null;
  }
  const parseIp = (ip) => {
    const parts = ip.split(".").map((p) => Number.parseInt(p, 10));
    return (parts[0] << 24 >>> 0) + (parts[1] << 16) + (parts[2] << 8) + parts[3];
  };
  const startNum = parseIp(startIp);
  const endNum = parseIp(input);
  if (endNum < startNum) {
    return "End IP must be greater than start IP.";
  }
  if (endNum - startNum + 1 < 2) {
    return "Range must have at least 2 addresses.";
  }
  return null;
};
const validateDnsServer = (input) => {
  if (!input) {
    return null;
  }
  const baseError = validateIpAddress(input);
  if (baseError) {
    return baseError;
  }
  if (!VALID_DNS_SERVERS.includes(input)) {
    return "DNS server must be a public IP address (e.g., 8.8.8.8)";
  }
  return null;
};
const validatePppoeUsername = (input, allValues) => {
  const connectionType = allValues.connectionType;
  if (connectionType === "pppoe" && !input) {
    return "Enter your ISP username";
  }
  return null;
};
const validatePppoePassword = (input, allValues) => {
  const connectionType = allValues.connectionType;
  if (connectionType === "pppoe" && !input) {
    return "Enter your ISP password";
  }
  return null;
};
const buildRouterLanConfigModal = (deviceId, currentConfig) => ({
  id: `router-lan-config-${deviceId}`,
  title: "Router LAN Configuration",
  content: [
    {
      kind: "field",
      field: {
        id: "dhcpEnabled",
        kind: "checkbox",
        label: "Enable DHCP",
        defaultValue: typeof currentConfig.dhcpEnabled === "boolean" ? currentConfig.dhcpEnabled : false,
        helpLink: {
          label: "What is DHCP?",
          href: "https://www.google.com/search?q=what+is+DHCP"
        }
      }
    },
    {
      kind: "field",
      field: {
        id: "startIp",
        kind: "text",
        label: "Start IP",
        placeholder: "192.168.1.100",
        defaultValue: typeof currentConfig.startIp === "string" ? currentConfig.startIp : "",
        validate: validatePrivateIp
      }
    },
    {
      kind: "field",
      field: {
        id: "endIp",
        kind: "text",
        label: "End IP",
        placeholder: "192.168.1.200",
        defaultValue: typeof currentConfig.endIp === "string" ? currentConfig.endIp : "",
        validate: validateEndIp
      }
    },
    {
      kind: "field",
      field: {
        id: "dnsServer",
        kind: "text",
        label: "DNS Server",
        placeholder: "8.8.8.8",
        defaultValue: typeof currentConfig.dnsServer === "string" ? currentConfig.dnsServer : "",
        validate: validateDnsServer,
        helpLink: {
          label: "What is DNS?",
          href: "https://www.google.com/search?q=what+is+DNS+server"
        }
      }
    }
  ],
  actions: [
    {
      id: "cancel",
      label: "Cancel",
      variant: "ghost",
      closesModal: true,
      validate: false
    },
    {
      id: "save",
      label: "Save",
      variant: "primary",
      async onClick({ values, dispatch }) {
        const dhcpEnabled = !!values.dhcpEnabled;
        const startIp = String(values.startIp ?? "");
        const endIp = String(values.endIp ?? "");
        const dnsServer = String(values.dnsServer ?? "");
        dispatch({
          type: "CONFIGURE_DEVICE",
          payload: {
            deviceId,
            config: { dhcpEnabled, startIp, endIp, dnsServer }
          }
        });
      }
    }
  ]
});
const buildRouterNatConfigModal = (deviceId, currentConfig) => ({
  id: `router-nat-config-${deviceId}`,
  title: "Router NAT Configuration",
  content: [
    {
      kind: "text",
      text: "NAT (Network Address Translation) allows multiple devices on your home network to share a single public IP address. When enabled, the router translates your private IP (192.168.x.x) to the public IP assigned by your ISP."
    },
    {
      kind: "field",
      field: {
        id: "natEnabled",
        kind: "checkbox",
        label: "Enable NAT",
        defaultValue: typeof currentConfig.natEnabled === "boolean" ? currentConfig.natEnabled : false,
        helpLink: {
          label: "What is NAT?",
          href: "https://www.google.com/search?q=what+is+NAT+network+address+translation"
        }
      }
    }
  ],
  actions: [
    {
      id: "cancel",
      label: "Cancel",
      variant: "ghost",
      closesModal: true,
      validate: false
    },
    {
      id: "save",
      label: "Save",
      variant: "primary",
      async onClick({ values, dispatch }) {
        const natEnabled = !!values.natEnabled;
        dispatch({
          type: "CONFIGURE_DEVICE",
          payload: {
            deviceId,
            config: { natEnabled }
          }
        });
      }
    }
  ]
});
const buildRouterWanConfigModal = (deviceId, currentConfig) => ({
  id: `router-wan-config-${deviceId}`,
  title: "Router WAN Configuration",
  content: [
    {
      kind: "field",
      field: {
        id: "username",
        kind: "text",
        label: "PPPoE Username",
        placeholder: "user@telkom.net",
        defaultValue: typeof currentConfig.username === "string" ? currentConfig.username : "",
        validate: validatePppoeUsername
      }
    },
    {
      kind: "field",
      field: {
        id: "password",
        kind: "text",
        label: "PPPoE Password",
        placeholder: "telkom123",
        defaultValue: typeof currentConfig.password === "string" ? currentConfig.password : "",
        validate: validatePppoePassword
      }
    }
  ],
  actions: [
    {
      id: "cancel",
      label: "Cancel",
      variant: "ghost",
      closesModal: true,
      validate: false
    },
    {
      id: "save",
      label: "Save",
      variant: "primary",
      async onClick({ values, dispatch }) {
        const username = String(values.username ?? "");
        const password = String(values.password ?? "");
        dispatch({
          type: "CONFIGURE_DEVICE",
          payload: {
            deviceId,
            config: { username, password }
          }
        });
      }
    }
  ]
});
const buildPcStatusModal = (deviceId, status) => ({
  id: `pc-status-${deviceId}`,
  title: "PC Status",
  content: [
    {
      kind: "field",
      field: {
        id: "ip",
        kind: "readonly",
        label: "Private IP",
        value: status.ip ?? "Not assigned"
      }
    },
    {
      kind: "field",
      field: {
        id: "status",
        kind: "readonly",
        label: "Status",
        value: status.status ?? "Disconnected"
      }
    }
  ],
  actions: [
    {
      id: "close",
      label: "Close",
      variant: "primary",
      closesModal: true,
      validate: false
    }
  ]
});
const buildIgwStatusModal = (deviceId, status) => ({
  id: `igw-status-${deviceId}`,
  title: "Internet Gateway Status",
  content: [
    {
      kind: "field",
      field: {
        id: "status",
        kind: "readonly",
        label: "Connection Status",
        value: status.status ?? "Waiting for authentication"
      }
    }
  ],
  actions: [
    {
      id: "close",
      label: "Close",
      variant: "primary",
      closesModal: true,
      validate: false
    }
  ]
});
const buildDnsStatusModal = (deviceId, status) => ({
  id: `dns-status-${deviceId}`,
  title: "DNS Server Status",
  content: [
    {
      kind: "field",
      field: {
        id: "ip",
        kind: "readonly",
        label: "DNS Server",
        value: status.ip ?? "Unreachable"
      }
    },
    {
      kind: "field",
      field: {
        id: "status",
        kind: "readonly",
        label: "Status",
        value: status.status ?? "Unreachable"
      }
    }
  ],
  actions: [
    {
      id: "close",
      label: "Close",
      variant: "primary",
      closesModal: true,
      validate: false
    }
  ]
});
const buildGoogleStatusModal = (deviceId, status) => {
  const content = [
    {
      kind: "field",
      field: {
        id: "domain",
        kind: "readonly",
        label: "Domain",
        value: status.domain ?? "google.com"
      }
    },
    {
      kind: "field",
      field: {
        id: "ip",
        kind: "readonly",
        label: "IP Address",
        value: status.ip ?? "Can't resolve"
      }
    },
    {
      kind: "field",
      field: {
        id: "status",
        kind: "readonly",
        label: "Status",
        value: status.status ?? "Unreachable"
      }
    }
  ];
  if (status.reason && status.status === "Unreachable") {
    content.push({
      kind: "field",
      field: {
        id: "reason",
        kind: "readonly",
        label: "Reason",
        value: status.reason
      }
    });
  }
  return {
    id: `google-status-${deviceId}`,
    title: "Google Server Status",
    content,
    actions: [
      {
        id: "close",
        label: "Close",
        variant: "primary",
        closesModal: true,
        validate: false
      }
    ]
  };
};
const buildSuccessModal = (title, message, actionLabel, onAction) => ({
  id: "success",
  title,
  content: [
    {
      kind: "text",
      text: message
    }
  ],
  actions: [
    {
      id: "primary",
      label: actionLabel,
      variant: "primary",
      validate: false,
      closesModal: true,
      onClick: onAction ? () => onAction() : void 0
    }
  ]
});
const PRIVATE_IP_RANGES = [
  /^10\./,
  /^172\.(1[6-9]|2\d|3[01])\./,
  /^192\.168\./
];
const isValidIp = (ip) => {
  const parts = ip.split(".");
  if (parts.length !== 4) return false;
  return parts.every((part) => {
    const num = Number.parseInt(part, 10);
    return !Number.isNaN(num) && num >= 0 && num <= 255 && part === String(num);
  });
};
const isPrivateIp = (ip) => {
  return PRIVATE_IP_RANGES.some((range) => range.test(ip));
};
const isPublicIp = (ip) => {
  if (!isValidIp(ip)) return false;
  return !isPrivateIp(ip);
};
const EXPECTED_ORDER = [
  "pc",
  "cable",
  "router-lan",
  "router-nat",
  "router-wan",
  "fiber",
  "igw",
  "internet",
  "dns",
  "google"
];
const buildInternetNetworkSnapshot = (placedItems, _connections) => {
  const byCoord = /* @__PURE__ */ new Map();
  placedItems.forEach((item) => {
    byCoord.set(`${item.blockX}-${item.blockY}`, item);
  });
  const pc = placedItems.find((item) => item.type === "pc");
  const cable = placedItems.find((item) => item.type === "cable");
  const routerLan = placedItems.find((item) => item.type === "router-lan");
  const routerNat = placedItems.find((item) => item.type === "router-nat");
  const routerWan = placedItems.find((item) => item.type === "router-wan");
  const fiber = placedItems.find((item) => item.type === "fiber");
  const igw = placedItems.find((item) => item.type === "igw");
  const internet = placedItems.find((item) => item.type === "internet");
  const dns = placedItems.find((item) => item.type === "dns");
  const google = placedItems.find((item) => item.type === "google");
  const devices = [
    pc,
    cable,
    routerLan,
    routerNat,
    routerWan,
    fiber,
    igw,
    internet,
    dns,
    google
  ];
  const connectionErrors = [];
  let isFullyConnected = true;
  const placedDevices = devices.filter(Boolean);
  if (placedDevices.length !== EXPECTED_ORDER.length) {
    isFullyConnected = false;
  }
  const sortedByX = [...placedDevices].sort((a, b) => a.blockX - b.blockX);
  for (let i = 0; i < sortedByX.length; i++) {
    const device = sortedByX[i];
    const expectedType = EXPECTED_ORDER[i];
    if (device.type !== expectedType) {
      connectionErrors.push(
        `Position ${i + 1}: Expected ${expectedType}, found ${device.type}`
      );
      isFullyConnected = false;
    }
    if (i > 0) {
      const prevDevice = sortedByX[i - 1];
      if (device.blockX !== prevDevice.blockX + 1) {
        connectionErrors.push(
          `${device.type} is not adjacent to ${prevDevice.type}`
        );
        isFullyConnected = false;
      }
      if (device.blockY !== prevDevice.blockY) {
        connectionErrors.push(
          `${device.type} is not on the same row as ${prevDevice.type}`
        );
        isFullyConnected = false;
      }
    }
  }
  let pcConnectedToRouterLan = false;
  if (pc && cable && routerLan) {
    const pcNextToCable = cable.blockX === pc.blockX + 1 && cable.blockY === pc.blockY;
    const cableNextToRouterLan = routerLan.blockX === cable.blockX + 1 && routerLan.blockY === cable.blockY;
    pcConnectedToRouterLan = pcNextToCable && cableNextToRouterLan;
  }
  let routerWanConnectedToIgw = false;
  if (routerWan && fiber && igw) {
    const routerWanNextToFiber = fiber.blockX === routerWan.blockX + 1 && fiber.blockY === routerWan.blockY;
    const fiberNextToIgw = igw.blockX === fiber.blockX + 1 && igw.blockY === fiber.blockY;
    routerWanConnectedToIgw = routerWanNextToFiber && fiberNextToIgw;
  }
  return {
    pc,
    cable,
    routerLan,
    routerNat,
    routerWan,
    fiber,
    igw,
    internet,
    dns,
    google,
    pcConnectedToRouterLan,
    routerWanConnectedToIgw,
    isFullyConnected,
    connectionErrors
  };
};
const useInternetState = ({ dragEngine }) => {
  const state = useGameState();
  const canvases = useAllCanvases();
  const dispatch = useGameDispatch();
  const { combinedItems, combinedConnections, itemCanvasKeys } = reactExports.useMemo(() => {
    const items = [];
    const connections = [];
    const keys = /* @__PURE__ */ new Map();
    let offsetX = 0;
    for (const key of CANVAS_ORDER) {
      const canvas = canvases[key];
      const config = CANVAS_CONFIGS[key];
      if (!config) {
        continue;
      }
      if (canvas) {
        for (const item of canvas.placedItems) {
          items.push({ ...item, blockX: item.blockX + offsetX });
          keys.set(item.id, key);
        }
        for (const connection of canvas.connections) {
          connections.push({
            ...connection,
            from: { x: connection.from.x + offsetX, y: connection.from.y },
            to: { x: connection.to.x + offsetX, y: connection.to.y }
          });
        }
      }
      offsetX += config.columns;
    }
    return {
      combinedItems: items,
      combinedConnections: connections,
      itemCanvasKeys: keys
    };
  }, [canvases]);
  const resolveCanvasKey = reactExports.useCallback(
    (itemId) => itemCanvasKeys.get(itemId),
    [itemCanvasKeys]
  );
  const dispatchConfig = reactExports.useCallback(
    (deviceId, config) => {
      dispatch({
        type: "CONFIGURE_DEVICE",
        payload: {
          deviceId,
          config,
          stateKey: resolveCanvasKey(deviceId)
        }
      });
    },
    [dispatch, resolveCanvasKey]
  );
  const network = reactExports.useMemo(
    () => buildInternetNetworkSnapshot(combinedItems),
    [combinedConnections, combinedItems]
  );
  const routerLanConfig = network.routerLan?.data ?? {};
  const dhcpEnabled = routerLanConfig.dhcpEnabled === true;
  const startIp = typeof routerLanConfig.startIp === "string" ? routerLanConfig.startIp : null;
  const endIp = typeof routerLanConfig.endIp === "string" ? routerLanConfig.endIp : null;
  const dnsServer = typeof routerLanConfig.dnsServer === "string" ? routerLanConfig.dnsServer : null;
  const routerNatConfig = network.routerNat?.data ?? {};
  const natEnabled = routerNatConfig.natEnabled === true;
  const routerWanConfig = network.routerWan?.data ?? {};
  const connectionType = typeof routerWanConfig.connectionType === "string" ? routerWanConfig.connectionType : null;
  const username = typeof routerWanConfig.username === "string" ? routerWanConfig.username : null;
  const password = typeof routerWanConfig.password === "string" ? routerWanConfig.password : null;
  const publicIp = typeof routerWanConfig.publicIp === "string" ? routerWanConfig.publicIp : null;
  const hasValidIpRange = startIp !== null && endIp !== null && isValidIp(startIp) && isValidIp(endIp) && isPrivateIp(startIp) && isPrivateIp(endIp);
  const hasValidDnsServer = dnsServer !== null && isValidIp(dnsServer) && isPublicIp(dnsServer) && PUBLIC_DNS_SERVERS.includes(dnsServer);
  const hasValidPppoeCredentials = username === VALID_PPPOE_CREDENTIALS.username && password === VALID_PPPOE_CREDENTIALS.password;
  const routerLanConfigured = dhcpEnabled && hasValidIpRange && hasValidDnsServer;
  const routerNatConfigured = natEnabled === true;
  const allRoutersConfigured = routerLanConfigured && routerNatConfigured && hasValidPppoeCredentials;
  const pcHasIp = typeof network.pc?.data?.ip === "string";
  const pcIp = typeof network.pc?.data?.ip === "string" ? network.pc.data.ip : null;
  const googleReachable = allRoutersConfigured && network.isFullyConnected;
  const allDevicesPlaced = network.pc !== void 0 && network.cable !== void 0 && network.routerLan !== void 0 && network.routerNat !== void 0 && network.routerWan !== void 0 && network.fiber !== void 0 && network.igw !== void 0 && network.internet !== void 0 && network.dns !== void 0 && network.google !== void 0;
  const routerLanSettingsOpen = state.overlay.activeModal?.id?.startsWith("router-lan-config") ?? false;
  const routerNatSettingsOpen = state.overlay.activeModal?.id?.startsWith("router-nat-config") ?? false;
  const routerWanSettingsOpen = state.overlay.activeModal?.id?.startsWith("router-wan-config") ?? false;
  reactExports.useEffect(() => {
    if (state.question.status === "completed") {
      return;
    }
    if (network.pc && routerLanConfigured && startIp && network.pcConnectedToRouterLan) {
      const startOctets = startIp.split(".").map((s) => Number.parseInt(s, 10));
      const baseOctets = startOctets.slice(0, 3);
      const startLastOctet = startOctets[3];
      const desiredIp = `${baseOctets.join(".")}.${startLastOctet}`;
      const currentIp = typeof network.pc.data?.ip === "string" ? network.pc.data.ip : null;
      if (currentIp !== desiredIp) {
        dispatch({
          type: "CONFIGURE_DEVICE",
          payload: {
            deviceId: network.pc.id,
            config: { ip: desiredIp },
            stateKey: resolveCanvasKey(network.pc.id)
          }
        });
      }
    } else if (network.pc && (!routerLanConfigured || !network.pcConnectedToRouterLan)) {
      const currentIp = typeof network.pc.data?.ip === "string" ? network.pc.data.ip : null;
      if (currentIp !== null) {
        dispatch({
          type: "CONFIGURE_DEVICE",
          payload: {
            deviceId: network.pc.id,
            config: { ip: null },
            stateKey: resolveCanvasKey(network.pc.id)
          }
        });
      }
    }
  }, [
    dispatch,
    network.pc,
    network.pcConnectedToRouterLan,
    routerLanConfigured,
    startIp,
    resolveCanvasKey,
    state.question.status
  ]);
  reactExports.useEffect(() => {
    if (state.question.status === "completed") {
      return;
    }
    if (network.pc) {
      const hasPcIp = typeof network.pc.data?.ip === "string";
      let desiredStatus;
      if (!hasPcIp) {
        desiredStatus = "error";
      } else if (!googleReachable) {
        desiredStatus = "warning";
      } else {
        desiredStatus = "success";
      }
      if (network.pc.status !== desiredStatus) {
        dispatchConfig(network.pc.id, { status: desiredStatus });
      }
    }
    if (network.routerLan) {
      let desiredStatus;
      if (!dhcpEnabled || !hasValidIpRange) {
        desiredStatus = "error";
      } else if (!hasValidDnsServer) {
        desiredStatus = "warning";
      } else {
        desiredStatus = "success";
      }
      if (network.routerLan.status !== desiredStatus) {
        dispatchConfig(network.routerLan.id, { status: desiredStatus });
      }
    }
    if (network.routerNat) {
      const desiredStatus = natEnabled ? "success" : "error";
      if (network.routerNat.status !== desiredStatus) {
        dispatchConfig(network.routerNat.id, { status: desiredStatus });
      }
    }
    if (network.routerWan) {
      let desiredStatus;
      if (!hasValidPppoeCredentials) {
        desiredStatus = "error";
      } else if (!network.routerWanConnectedToIgw) {
        desiredStatus = "warning";
      } else if (!network.igw || !network.internet) {
        desiredStatus = "warning";
      } else {
        desiredStatus = "success";
      }
      if (network.routerWan.status !== desiredStatus) {
        dispatchConfig(network.routerWan.id, { status: desiredStatus });
      }
    }
    if (network.igw) {
      const desiredStatus = hasValidPppoeCredentials ? "success" : "warning";
      if (network.igw.status !== desiredStatus) {
        dispatchConfig(network.igw.id, { status: desiredStatus });
      }
    }
    if (network.internet) {
      const desiredStatus = hasValidPppoeCredentials ? "success" : "warning";
      if (network.internet.status !== desiredStatus) {
        dispatchConfig(network.internet.id, { status: desiredStatus });
      }
    }
    if (network.dns) {
      const desiredStatus = hasValidDnsServer ? "success" : "error";
      if (network.dns.status !== desiredStatus) {
        dispatchConfig(network.dns.id, { status: desiredStatus });
      }
    }
    if (network.google) {
      let desiredStatus;
      if (!hasValidDnsServer) {
        desiredStatus = "error";
      } else if (!routerNatConfigured || !hasValidPppoeCredentials) {
        desiredStatus = "warning";
      } else {
        desiredStatus = "success";
      }
      if (network.google.status !== desiredStatus) {
        dispatchConfig(network.google.id, { status: desiredStatus });
      }
    }
    if (network.cable) {
      const desiredStatus = network.pcConnectedToRouterLan ? "success" : "warning";
      if (network.cable.status !== desiredStatus) {
        dispatchConfig(network.cable.id, { status: desiredStatus });
      }
    }
    if (network.fiber) {
      const desiredStatus = network.routerWanConnectedToIgw ? "success" : "warning";
      if (network.fiber.status !== desiredStatus) {
        dispatchConfig(network.fiber.id, { status: desiredStatus });
      }
    }
  }, [
    dispatchConfig,
    network.pc,
    network.cable,
    network.routerLan,
    network.routerNat,
    network.routerWan,
    network.fiber,
    network.igw,
    network.internet,
    network.dns,
    network.google,
    network.pcConnectedToRouterLan,
    network.routerWanConnectedToIgw,
    dhcpEnabled,
    hasValidIpRange,
    hasValidDnsServer,
    natEnabled,
    hasValidPppoeCredentials,
    routerNatConfigured,
    state.question.status
  ]);
  reactExports.useEffect(() => {
    if (!dragEngine) return;
    if (state.question.status === "completed") return;
    if (dragEngine.progress.status === "pending" && allDevicesPlaced) {
      dragEngine.start();
    }
    if (dragEngine.progress.status !== "finished" && allRoutersConfigured && googleReachable) {
      dragEngine.finish();
    }
  }, [
    dragEngine,
    allDevicesPlaced,
    allRoutersConfigured,
    googleReachable,
    state.question.status
  ]);
  return {
    network,
    // Router LAN config
    routerLanConfig,
    dhcpEnabled,
    startIp,
    endIp,
    dnsServer,
    hasValidIpRange,
    hasValidDnsServer,
    routerLanConfigured,
    // Router NAT config
    routerNatConfig,
    natEnabled,
    routerNatConfigured,
    // Router WAN config
    routerWanConfig,
    connectionType,
    username,
    password,
    publicIp,
    hasValidPppoeCredentials,
    // Combined state
    allRoutersConfigured,
    // PC state
    pcHasIp,
    pcIp,
    // Connectivity
    googleReachable,
    allDevicesPlaced,
    // Modal states
    routerLanSettingsOpen,
    routerNatSettingsOpen,
    routerWanSettingsOpen,
    // Game state
    placedItems: combinedItems,
    connections: combinedConnections,
    dragProgress: dragEngine?.progress ?? { status: "pending" },
    // Constants for external use
    googleIp: GOOGLE_IP
  };
};
const SUCCESS_TITLE = "🎉 Connected to the Internet!";
const SUCCESS_MESSAGE = `Congratulations! You've successfully connected your home network to the internet.

You learned how:
- **Router LAN + DHCP** assigns private IPs to your devices
- **Router WAN + PPPoE** authenticates with your ISP to get a public IP
- **Router NAT** translates your private IP to the public IP
- **DNS** resolves domain names (google.com) to IP addresses (142.250.80.46)

Your ping traveled: PC → Router LAN → Router NAT → Router WAN → IGW → Internet → Google!`;
const useInternetTerminal = ({
  pcIp,
  dnsConfigured,
  natEnabled,
  wanConnected,
  onQuestionComplete
}) => {
  const dispatch = useGameDispatch();
  const state = useGameState();
  const handleCommand = reactExports.useCallback(
    (input, helpers) => {
      if (state.question.status === "completed") return;
      if (state.phase !== "terminal") {
        helpers.writeOutput("Error: Terminal is not ready yet.", "error");
        return;
      }
      const normalized = input.trim();
      const parts = normalized.split(/\s+/);
      const command = parts[0]?.toLowerCase();
      if (command === "ifconfig") {
        if (pcIp) {
          helpers.writeOutput(`eth0: ${pcIp}`, "output");
        } else {
          helpers.writeOutput("eth0: No IP assigned", "output");
        }
        return;
      }
      if (command === "nslookup") {
        if (parts.length < 2) {
          helpers.writeOutput(
            "Error: Missing domain. Usage: nslookup <domain>",
            "error"
          );
          return;
        }
        const domain = parts[1].toLowerCase();
        if (!dnsConfigured) {
          helpers.writeOutput(
            "Error: Could not resolve hostname. DNS server not configured.",
            "error"
          );
          return;
        }
        if (domain === "google.com") {
          helpers.writeOutput(`google.com → ${GOOGLE_IP}`, "output");
        } else {
          helpers.writeOutput(`Error: Unknown host "${parts[1]}".`, "error");
        }
        return;
      }
      if (command === "ping") {
        if (parts.length < 2) {
          helpers.writeOutput(
            "Error: Missing target. Usage: ping <hostname or IP>",
            "error"
          );
          return;
        }
        const target = parts[1].toLowerCase();
        const isDomainTarget = target === "google.com";
        const isIpTarget = target === GOOGLE_IP.toLowerCase();
        if (!isDomainTarget && !isIpTarget) {
          helpers.writeOutput(`Error: Unknown host "${parts[1]}".`, "error");
          return;
        }
        if (!wanConnected) {
          helpers.writeOutput(
            "Error: Network unreachable. No internet connection.",
            "error"
          );
          return;
        }
        if (!natEnabled) {
          helpers.writeOutput(
            "Error: Network unreachable. Check NAT configuration.",
            "error"
          );
          return;
        }
        if (isDomainTarget && !dnsConfigured) {
          helpers.writeOutput(
            "Error: Could not resolve hostname. DNS server not configured.",
            "error"
          );
          return;
        }
        if (isDomainTarget) {
          helpers.writeOutput(
            `Resolving google.com... ${GOOGLE_IP}
Reply from ${GOOGLE_IP}: bytes=32 time=15ms TTL=117`,
            "output"
          );
        } else {
          helpers.writeOutput(
            `Reply from ${GOOGLE_IP}: bytes=32 time=15ms TTL=117`,
            "output"
          );
        }
        dispatch({
          type: "OPEN_MODAL",
          payload: buildSuccessModal(
            SUCCESS_TITLE,
            SUCCESS_MESSAGE,
            "Next question",
            onQuestionComplete
          )
        });
        helpers.finishEngine();
        dispatch({ type: "COMPLETE_QUESTION" });
        return;
      }
      helpers.writeOutput("Error: Unknown command.", "error");
    },
    [
      dispatch,
      onQuestionComplete,
      pcIp,
      dnsConfigured,
      natEnabled,
      wanConnected,
      state.phase,
      state.question.status
    ]
  );
  return handleCommand;
};
const INTERNET_SPEC_BASE = {
  meta: {
    id: QUESTION_ID,
    title: QUESTION_TITLE,
    description: QUESTION_DESCRIPTION
  },
  init: {
    kind: "multi",
    payload: {
      questionId: QUESTION_ID,
      canvases: CANVAS_CONFIGS,
      inventoryGroups: INVENTORY_GROUPS,
      terminal: {
        visible: false,
        prompt: TERMINAL_PROMPT,
        history: TERMINAL_INTRO_ENTRIES
      },
      phase: "setup",
      questionStatus: "in_progress"
    }
  },
  phaseRules: [
    {
      kind: "set",
      when: { kind: "eq", key: "questionStatus", value: "completed" },
      to: "completed"
    },
    {
      kind: "set",
      when: { kind: "eq", key: "dragStatus", value: "finished" },
      to: "terminal"
    },
    {
      kind: "set",
      when: { kind: "eq", key: "dragStatus", value: "started" },
      to: "playing"
    },
    {
      kind: "set",
      when: { kind: "eq", key: "allDevicesPlaced", value: true },
      to: "configuring"
    }
  ],
  labels: {
    getItemLabel: getInternetItemLabel,
    getStatusMessage: getInternetStatusMessage
  }
};
const InternetQuestion = ({ onQuestionComplete }) => {
  return /* @__PURE__ */ jsxRuntimeExports.jsx(GameProvider, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(InternetGame, { onQuestionComplete }) });
};
const InternetGame = ({
  onQuestionComplete
}) => {
  const dispatch = useGameDispatch();
  const state = useGameState();
  const initializedRef = reactExports.useRef(false);
  const terminalInput = useTerminalInput();
  const isCompleted = state.question.status === "completed";
  const dragEngine = useDragEngine();
  const internetState = useInternetState({ dragEngine });
  const placedItemById = reactExports.useMemo(() => {
    const map = /* @__PURE__ */ new Map();
    for (const entry of internetState.placedItems) {
      map.set(entry.id, entry);
    }
    return map;
  }, [internetState.placedItems]);
  const itemClickHandlers = reactExports.useMemo(
    () => ({
      "router-lan": ({ item }) => {
        const placedItem = placedItemById.get(item.id);
        const currentConfig = placedItem?.data ?? {};
        dispatch({
          type: "OPEN_MODAL",
          payload: buildRouterLanConfigModal(item.id, currentConfig)
        });
      },
      "router-nat": ({ item }) => {
        const placedItem = placedItemById.get(item.id);
        const currentConfig = placedItem?.data ?? {};
        dispatch({
          type: "OPEN_MODAL",
          payload: buildRouterNatConfigModal(item.id, currentConfig)
        });
      },
      "router-wan": ({ item }) => {
        const placedItem = placedItemById.get(item.id);
        const currentConfig = placedItem?.data ?? {};
        dispatch({
          type: "OPEN_MODAL",
          payload: buildRouterWanConfigModal(item.id, currentConfig)
        });
      },
      pc: ({ item }) => {
        const placedItem = placedItemById.get(item.id);
        const currentConfig = placedItem?.data ?? {};
        dispatch({
          type: "OPEN_MODAL",
          payload: buildPcStatusModal(item.id, {
            ip: typeof currentConfig.ip === "string" ? currentConfig.ip : void 0,
            status: internetState.googleReachable ? "Connected to internet" : "Waiting for connection"
          })
        });
      },
      igw: ({ item }) => {
        dispatch({
          type: "OPEN_MODAL",
          payload: buildIgwStatusModal(item.id, {
            status: internetState.hasValidPppoeCredentials ? "Authenticated" : "Waiting for authentication"
          })
        });
      },
      dns: ({ item }) => {
        dispatch({
          type: "OPEN_MODAL",
          payload: buildDnsStatusModal(item.id, {
            ip: internetState.dnsServer ?? void 0,
            status: internetState.hasValidDnsServer ? "Active" : "Unreachable"
          })
        });
      },
      google: ({ item }) => {
        let reason;
        if (!internetState.hasValidDnsServer) {
          reason = "DNS not configured";
        } else if (!internetState.natEnabled) {
          reason = "NAT disabled";
        } else if (!internetState.hasValidPppoeCredentials) {
          reason = "WAN not connected";
        }
        dispatch({
          type: "OPEN_MODAL",
          payload: buildGoogleStatusModal(item.id, {
            domain: "google.com",
            ip: internetState.googleReachable ? internetState.googleIp : void 0,
            status: internetState.googleReachable ? "Reachable" : "Unreachable",
            reason
          })
        });
      }
    }),
    [
      dispatch,
      internetState.dnsServer,
      internetState.googleIp,
      internetState.googleReachable,
      internetState.hasValidDnsServer,
      internetState.hasValidPppoeCredentials,
      internetState.natEnabled,
      placedItemById
    ]
  );
  const handleInternetCommand = useInternetTerminal({
    pcIp: internetState.pcIp,
    dnsConfigured: internetState.hasValidDnsServer,
    natEnabled: internetState.natEnabled,
    wanConnected: internetState.hasValidPppoeCredentials,
    onQuestionComplete
  });
  useTerminalEngine({
    onCommand: handleInternetCommand
  });
  const spec = reactExports.useMemo(
    () => ({
      ...INTERNET_SPEC_BASE,
      handlers: {
        onCommand: handleInternetCommand,
        onItemClickByType: itemClickHandlers,
        isItemClickableByType: {
          "router-lan": true,
          "router-nat": true,
          "router-wan": true,
          pc: true,
          igw: true,
          dns: true,
          google: true
        }
      }
    }),
    [handleInternetCommand, itemClickHandlers]
  );
  reactExports.useEffect(() => {
    if (initializedRef.current) {
      return;
    }
    initializedRef.current = true;
    dispatch({
      type: "INIT_MULTI_CANVAS",
      payload: spec.init.payload
    });
  }, [dispatch, spec.init.payload]);
  reactExports.useEffect(() => {
    const context = {
      dragStatus: dragEngine.progress.status,
      questionStatus: state.question.status,
      allDevicesPlaced: internetState.allDevicesPlaced
    };
    const resolved = resolvePhase(
      spec.phaseRules,
      context,
      state.phase,
      "setup"
    );
    if (state.phase !== resolved.nextPhase) {
      dispatch({ type: "SET_PHASE", payload: { phase: resolved.nextPhase } });
    }
  }, [
    dispatch,
    dragEngine.progress.status,
    internetState.allDevicesPlaced,
    spec.phaseRules,
    state.phase,
    state.question.status
  ]);
  const contextualHint = reactExports.useMemo(
    () => getContextualHint({
      placedItems: internetState.placedItems,
      pc: internetState.network.pc,
      cable: internetState.network.cable,
      routerLan: internetState.network.routerLan,
      routerNat: internetState.network.routerNat,
      routerWan: internetState.network.routerWan,
      fiber: internetState.network.fiber,
      igw: internetState.network.igw,
      internet: internetState.network.internet,
      dns: internetState.network.dns,
      google: internetState.network.google,
      allDevicesPlaced: internetState.allDevicesPlaced,
      routerLanConfigured: internetState.routerLanConfigured,
      routerNatConfigured: internetState.routerNatConfigured,
      routerWanConfigured: internetState.hasValidPppoeCredentials,
      routerLanSettingsOpen: internetState.routerLanSettingsOpen,
      routerNatSettingsOpen: internetState.routerNatSettingsOpen,
      routerWanSettingsOpen: internetState.routerWanSettingsOpen,
      dhcpEnabled: internetState.dhcpEnabled,
      natEnabled: internetState.natEnabled,
      startIp: internetState.startIp,
      endIp: internetState.endIp,
      dnsServer: internetState.dnsServer,
      connectionType: internetState.connectionType,
      pppoeUsername: internetState.username,
      googleReachable: internetState.googleReachable
    }),
    [
      internetState.placedItems,
      internetState.connections,
      internetState.network.pc,
      internetState.network.cable,
      internetState.network.routerLan,
      internetState.network.routerNat,
      internetState.network.routerWan,
      internetState.network.fiber,
      internetState.network.igw,
      internetState.network.internet,
      internetState.network.dns,
      internetState.network.google,
      internetState.allDevicesPlaced,
      internetState.routerLanConfigured,
      internetState.routerNatConfigured,
      internetState.hasValidPppoeCredentials,
      internetState.routerLanSettingsOpen,
      internetState.routerNatSettingsOpen,
      internetState.routerWanSettingsOpen,
      internetState.dhcpEnabled,
      internetState.natEnabled,
      internetState.startIp,
      internetState.endIp,
      internetState.dnsServer,
      internetState.connectionType,
      internetState.username,
      internetState.password,
      internetState.pcHasIp,
      internetState.googleReachable
    ]
  );
  const handlePlacedItemClick = reactExports.useCallback(
    (item) => {
      const handler = spec.handlers.onItemClickByType[item.type];
      if (handler) {
        handler({ item });
      }
    },
    [spec.handlers.onItemClickByType]
  );
  const isItemClickable = reactExports.useCallback(
    (item) => spec.handlers.isItemClickableByType[item.type] === true,
    [spec.handlers.isItemClickableByType]
  );
  return /* @__PURE__ */ jsxRuntimeExports.jsx(GameShell, { getItemLabel: spec.labels.getItemLabel, children: /* @__PURE__ */ jsxRuntimeExports.jsxs(
    Flex,
    {
      direction: "column",
      px: { base: 2, md: 12, lg: 24 },
      py: { base: 2, md: 6 },
      children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs(Box, { textAlign: "left", mb: { base: 2, md: 4 }, pb: { base: 1, md: 0 }, children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            Text,
            {
              fontSize: { base: "2xl", md: "4xl" },
              fontWeight: "bold",
              color: "gray.50",
              children: QUESTION_TITLE
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsx(Text, { fontSize: { base: "sm", md: "md" }, color: "gray.400", children: QUESTION_DESCRIPTION })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          Flex,
          {
            direction: { base: "column", xl: "row" },
            gap: { base: 2, md: 4 },
            align: { base: "stretch", xl: "flex-start" },
            children: CANVAS_ORDER.map((key) => {
              const config = CANVAS_CONFIGS[key];
              const title = config.title ?? key;
              return /* @__PURE__ */ jsxRuntimeExports.jsx(
                Box,
                {
                  flexGrow: config.columns,
                  flexBasis: 0,
                  minW: { base: "100%", xl: "0" },
                  children: /* @__PURE__ */ jsxRuntimeExports.jsx(
                    PlayCanvas,
                    {
                      stateKey: key,
                      title,
                      getItemLabel: spec.labels.getItemLabel,
                      getStatusMessage: spec.labels.getStatusMessage,
                      onPlacedItemClick: handlePlacedItemClick,
                      isItemClickable
                    }
                  )
                },
                key
              );
            })
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsx(InventoryDrawer, { tooltips: INVENTORY_TOOLTIPS }),
        contextualHint && /* @__PURE__ */ jsxRuntimeExports.jsx(
          Box,
          {
            bg: "gray.800",
            border: "1px solid",
            borderColor: "gray.700",
            borderRadius: "md",
            px: 4,
            py: 2,
            textAlign: "center",
            mb: 4,
            children: /* @__PURE__ */ jsxRuntimeExports.jsx(Text, { fontSize: "sm", color: "gray.100", children: contextualHint })
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          TerminalLayout,
          {
            visible: state.terminal.visible,
            focusRef: terminalInput.inputRef,
            view: /* @__PURE__ */ jsxRuntimeExports.jsx(
              TerminalView,
              {
                history: state.terminal.history,
                prompt: state.terminal.prompt,
                isCompleted
              }
            ),
            input: /* @__PURE__ */ jsxRuntimeExports.jsx(
              TerminalInput,
              {
                value: terminalInput.value,
                onChange: terminalInput.onChange,
                onKeyDown: terminalInput.onKeyDown,
                inputRef: terminalInput.inputRef,
                placeholder: isCompleted ? "Terminal disabled" : "Type a command",
                disabled: isCompleted
              }
            )
          }
        )
      ]
    }
  ) });
};
const InternetQuestionRoute = () => {
  const navigate = useNavigate();
  const handleQuestionComplete = () => {
    markNetworkingQuestionComplete("internet");
    const nextPath = getNextQuestionPath("internet");
    void navigate({
      to: nextPath ?? "/questions/networking"
    });
  };
  return /* @__PURE__ */ jsxRuntimeExports.jsx(InternetQuestion, { onQuestionComplete: handleQuestionComplete });
};
export {
  InternetQuestionRoute as component
};
