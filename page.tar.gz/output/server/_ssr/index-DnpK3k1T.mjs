import { j as jsxRuntimeExports } from "../_libs/react.mjs";
import { d as useNavigate } from "../_libs/@tanstack/react-router.mjs";
import { B as Box, F as Flex, T as Text, c as Button } from "../_libs/@chakra-ui/react.mjs";
import "../_libs/@babel/runtime.mjs";
import "../_libs/tiny-warning.mjs";
import "../_libs/@tanstack/router-core.mjs";
import "../_libs/@tanstack/store.mjs";
import "../_libs/@tanstack/history.mjs";
import "../_libs/tiny-invariant.mjs";
import "node:stream/web";
import "node:stream";
import "../_libs/react-dom.mjs";
import "util";
import "crypto";
import "async_hooks";
import "stream";
import "../_libs/isbot.mjs";
import "../_libs/@tanstack/react-store.mjs";
import "../_libs/use-sync-external-store.mjs";
import "../_libs/@pandacss/is-valid-prop.mjs";
import "../_libs/@ark-ui/react.mjs";
import "../_libs/@zag-js/carousel.mjs";
import "../_libs/@zag-js/anatomy.mjs";
import "../_libs/@zag-js/types.mjs";
import "../_libs/@zag-js/core.mjs";
import "../_libs/@zag-js/utils.mjs";
import "../_libs/@zag-js/dom-query.mjs";
import "../_libs/@zag-js/checkbox.mjs";
import "../_libs/@zag-js/focus-visible.mjs";
import "../_libs/@zag-js/react.mjs";
import "../_libs/@zag-js/color-picker.mjs";
import "../_libs/@zag-js/color-utils.mjs";
import "../_libs/@zag-js/popper.mjs";
import "../_libs/@floating-ui/dom.mjs";
import "../_libs/@floating-ui/core.mjs";
import "../_libs/@floating-ui/utils.mjs";
import "../_libs/@zag-js/dismissable.mjs";
import "../_libs/@zag-js/interact-outside.mjs";
import "../_libs/@zag-js/combobox.mjs";
import "../_libs/@zag-js/collection.mjs";
import "../_libs/@zag-js/auto-resize.mjs";
import "../_libs/@zag-js/listbox.mjs";
import "../_libs/@zag-js/radio-group.mjs";
import "../_libs/@zag-js/tooltip.mjs";
import "../_libs/@zag-js/presence.mjs";
import "../_libs/@zag-js/switch.mjs";
import "../_libs/@zag-js/splitter.mjs";
import "../_libs/@zag-js/slider.mjs";
import "../_libs/@zag-js/select.mjs";
import "../_libs/@zag-js/rating-group.mjs";
import "../_libs/@zag-js/popover.mjs";
import "../_libs/@zag-js/menu.mjs";
import "../_libs/@zag-js/rect-utils.mjs";
import "../_libs/@zag-js/file-upload.mjs";
import "../_libs/@zag-js/editable.mjs";
import "../_libs/@zag-js/dialog.mjs";
import "../_libs/@zag-js/accordion.mjs";
import "../_libs/@zag-js/clipboard.mjs";
import "../_libs/@zag-js/avatar.mjs";
import "../_libs/@zag-js/collapsible.mjs";
import "../_libs/@zag-js/hover-card.mjs";
import "../_libs/@zag-js/number-input.mjs";
import "../_libs/@internationalized/number.mjs";
import "../_libs/@zag-js/pin-input.mjs";
import "../_libs/@zag-js/progress.mjs";
import "../_libs/@zag-js/qr-code.mjs";
import "../_libs/@zag-js/scroll-area.mjs";
import "../_libs/@zag-js/tags-input.mjs";
import "../_libs/@zag-js/live-region.mjs";
import "../_libs/@zag-js/tree-view.mjs";
import "../_libs/@emotion/is-prop-valid.mjs";
import "../_libs/@emotion/memoize.mjs";
import "../_libs/@emotion/serialize.mjs";
import "../_libs/@emotion/hash.mjs";
import "../_libs/@emotion/unitless.mjs";
import "../_libs/@emotion/use-insertion-effect-with-fallbacks.mjs";
import "../_libs/@emotion/utils.mjs";
import "../_libs/@emotion/react.mjs";
import "../_libs/@emotion/cache.mjs";
import "../_libs/@emotion/sheet.mjs";
import "../_libs/@emotion/weak-memoize.mjs";
import "../_libs/stylis.mjs";
const LandingPage = () => {
  const navigate = useNavigate();
  const handlePlay = () => {
    void navigate({
      to: "/questions/networking"
    });
  };
  return /* @__PURE__ */ jsxRuntimeExports.jsx(Box, { height: "100vh", display: "flex", flexDirection: "column", bg: "gray.950", color: "gray.100", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Flex, { flex: "1", align: "center", justify: "center", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(Box, { textAlign: "center", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx(Text, { fontSize: "4xl", fontWeight: "bold", mb: 4, children: "Learning Platform" }),
    /* @__PURE__ */ jsxRuntimeExports.jsx(Text, { fontSize: "lg", color: "gray.400", mb: 8, children: "Master networking concepts through interactive challenges." }),
    /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { colorPalette: "green", size: "lg", onClick: handlePlay, children: "Play" })
  ] }) }) });
};
export {
  LandingPage as component
};
