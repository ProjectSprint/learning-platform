import { r as reactExports, j as jsxRuntimeExports } from "../_libs/react.mjs";
import { d as useNavigate, u as useRouterState, O as Outlet } from "../_libs/@tanstack/react-router.mjs";
import { u as useNetworkingProgress, g as getQuestionIndexByPath } from "./module-progress-CKDPPitT.mjs";
import { B as Box, F as Flex, I as IconButton } from "../_libs/@chakra-ui/react.mjs";
import { X } from "../_libs/lucide-react.mjs";
import "../_libs/@babel/runtime.mjs";
import "../_libs/tiny-warning.mjs";
import "../_libs/@tanstack/router-core.mjs";
import "../_libs/@tanstack/store.mjs";
import "../_libs/@tanstack/history.mjs";
import "../_libs/tiny-invariant.mjs";
import "node:stream/web";
import "node:stream";
import "../_libs/react-dom.mjs";
import "util";
import "crypto";
import "async_hooks";
import "stream";
import "../_libs/isbot.mjs";
import "../_libs/@tanstack/react-store.mjs";
import "../_libs/use-sync-external-store.mjs";
import "../_libs/@pandacss/is-valid-prop.mjs";
import "../_libs/@ark-ui/react.mjs";
import "../_libs/@zag-js/carousel.mjs";
import "../_libs/@zag-js/anatomy.mjs";
import "../_libs/@zag-js/types.mjs";
import "../_libs/@zag-js/core.mjs";
import "../_libs/@zag-js/utils.mjs";
import "../_libs/@zag-js/dom-query.mjs";
import "../_libs/@zag-js/checkbox.mjs";
import "../_libs/@zag-js/focus-visible.mjs";
import "../_libs/@zag-js/react.mjs";
import "../_libs/@zag-js/color-picker.mjs";
import "../_libs/@zag-js/color-utils.mjs";
import "../_libs/@zag-js/popper.mjs";
import "../_libs/@floating-ui/dom.mjs";
import "../_libs/@floating-ui/core.mjs";
import "../_libs/@floating-ui/utils.mjs";
import "../_libs/@zag-js/dismissable.mjs";
import "../_libs/@zag-js/interact-outside.mjs";
import "../_libs/@zag-js/combobox.mjs";
import "../_libs/@zag-js/collection.mjs";
import "../_libs/@zag-js/auto-resize.mjs";
import "../_libs/@zag-js/listbox.mjs";
import "../_libs/@zag-js/radio-group.mjs";
import "../_libs/@zag-js/tooltip.mjs";
import "../_libs/@zag-js/presence.mjs";
import "../_libs/@zag-js/switch.mjs";
import "../_libs/@zag-js/splitter.mjs";
import "../_libs/@zag-js/slider.mjs";
import "../_libs/@zag-js/select.mjs";
import "../_libs/@zag-js/rating-group.mjs";
import "../_libs/@zag-js/popover.mjs";
import "../_libs/@zag-js/menu.mjs";
import "../_libs/@zag-js/rect-utils.mjs";
import "../_libs/@zag-js/file-upload.mjs";
import "../_libs/@zag-js/editable.mjs";
import "../_libs/@zag-js/dialog.mjs";
import "../_libs/@zag-js/accordion.mjs";
import "../_libs/@zag-js/clipboard.mjs";
import "../_libs/@zag-js/avatar.mjs";
import "../_libs/@zag-js/collapsible.mjs";
import "../_libs/@zag-js/hover-card.mjs";
import "../_libs/@zag-js/number-input.mjs";
import "../_libs/@internationalized/number.mjs";
import "../_libs/@zag-js/pin-input.mjs";
import "../_libs/@zag-js/progress.mjs";
import "../_libs/@zag-js/qr-code.mjs";
import "../_libs/@zag-js/scroll-area.mjs";
import "../_libs/@zag-js/tags-input.mjs";
import "../_libs/@zag-js/live-region.mjs";
import "../_libs/@zag-js/tree-view.mjs";
import "../_libs/@emotion/is-prop-valid.mjs";
import "../_libs/@emotion/memoize.mjs";
import "../_libs/@emotion/serialize.mjs";
import "../_libs/@emotion/hash.mjs";
import "../_libs/@emotion/unitless.mjs";
import "../_libs/@emotion/use-insertion-effect-with-fallbacks.mjs";
import "../_libs/@emotion/utils.mjs";
import "../_libs/@emotion/react.mjs";
import "../_libs/@emotion/cache.mjs";
import "../_libs/@emotion/sheet.mjs";
import "../_libs/@emotion/weak-memoize.mjs";
import "../_libs/stylis.mjs";
const ProgressHeader = ({ progress, onExit }) => {
  const completedPercent = progress.totalQuestions > 0 ? progress.currentIndex / progress.totalQuestions * 100 : 0;
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(
    Flex,
    {
      as: "header",
      align: "center",
      gap: 3,
      px: 4,
      py: 3,
      bg: "gray.950",
      borderBottom: "1px solid",
      borderColor: "gray.800",
      children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          IconButton,
          {
            "aria-label": "Exit module",
            variant: "ghost",
            size: "sm",
            color: "gray.400",
            _hover: { color: "gray.100", bg: "gray.800" },
            onClick: onExit,
            children: /* @__PURE__ */ jsxRuntimeExports.jsx(X, { size: 20 })
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsxs(Box, { flex: "1", position: "relative", height: "8px", borderRadius: "full", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Box, { position: "absolute", inset: 0, bg: "gray.700", borderRadius: "full" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            Box,
            {
              position: "absolute",
              top: 0,
              left: 0,
              bottom: 0,
              width: `${completedPercent}%`,
              bg: "orange.400",
              borderRadius: "full",
              transition: "width 0.3s ease-out"
            }
          )
        ] })
      ]
    }
  );
};
const NetworkingModuleLayout = () => {
  const navigate = useNavigate();
  const routerState = useRouterState();
  const {
    completedCount,
    totalQuestions
  } = useNetworkingProgress();
  const handleExit = reactExports.useCallback(() => {
    void navigate({
      to: "/"
    });
  }, [navigate]);
  const questionIndex = getQuestionIndexByPath(routerState.location.pathname);
  const showHeader = questionIndex >= 0;
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(Box, { display: "flex", flexDirection: "column", height: "100vh", bg: "gray.950", children: [
    showHeader && /* @__PURE__ */ jsxRuntimeExports.jsx(ProgressHeader, { progress: {
      currentIndex: completedCount,
      totalQuestions
    }, onExit: handleExit }),
    /* @__PURE__ */ jsxRuntimeExports.jsx(Box, { flex: "1", overflow: "auto", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Outlet, {}) })
  ] });
};
export {
  NetworkingModuleLayout as component
};
