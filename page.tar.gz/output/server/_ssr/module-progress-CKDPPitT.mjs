import { r as reactExports } from "../_libs/react.mjs";
const NETWORKING_QUESTIONS = [
  {
    id: "dhcp",
    path: "/questions/networking/dhcp",
    title: "DHCP Basics"
  },
  {
    id: "internet",
    path: "/questions/networking/internet",
    title: "Internet Gateway"
  },
  {
    id: "webserver-ssl",
    path: "/questions/networking/webserver-ssl",
    title: "Webserver SSL"
  },
  {
    id: "tcp",
    path: "/questions/networking/tcp",
    title: "TCP Reliability"
  }
];
const normalizePath = (path) => path.length > 1 ? path.replace(/\/$/, "") : path;
const getQuestionIndexByPath = (pathname) => {
  const normalized = normalizePath(pathname);
  return NETWORKING_QUESTIONS.findIndex(
    (question) => normalizePath(question.path) === normalized
  );
};
const getNextQuestionPath = (id) => {
  const index = NETWORKING_QUESTIONS.findIndex(
    (question) => question.id === id
  );
  if (index < 0) return null;
  const nextQuestion = NETWORKING_QUESTIONS[index + 1];
  return nextQuestion?.path ?? null;
};
const getFirstQuestionPath = () => NETWORKING_QUESTIONS[0]?.path ?? "/questions/networking";
const createDefaultState = () => ({
  completedIds: []
});
let progressState = createDefaultState();
const listeners = /* @__PURE__ */ new Set();
const emitChange = () => {
  for (const listener of listeners) {
    listener();
  }
};
const getState = () => progressState;
const setState = (next) => {
  progressState = {
    completedIds: Array.from(new Set(next.completedIds))
  };
  emitChange();
};
const markComplete = (id) => {
  if (progressState.completedIds.includes(id)) return;
  setState({ completedIds: [...progressState.completedIds, id] });
};
const reset = () => {
  setState(createDefaultState());
};
const subscribe = (listener) => {
  listeners.add(listener);
  return () => {
    listeners.delete(listener);
  };
};
const networkingProgressStore = {
  getState,
  setState,
  markComplete,
  reset,
  subscribe
};
const useNetworkingProgress = () => {
  const snapshot = reactExports.useSyncExternalStore(
    networkingProgressStore.subscribe,
    networkingProgressStore.getState,
    networkingProgressStore.getState
  );
  return {
    completedIds: snapshot.completedIds,
    completedCount: snapshot.completedIds.length,
    totalQuestions: NETWORKING_QUESTIONS.length
  };
};
const markNetworkingQuestionComplete = (id) => networkingProgressStore.markComplete(id);
export {
  getFirstQuestionPath as a,
  getNextQuestionPath as b,
  getQuestionIndexByPath as g,
  markNetworkingQuestionComplete as m,
  useNetworkingProgress as u
};
