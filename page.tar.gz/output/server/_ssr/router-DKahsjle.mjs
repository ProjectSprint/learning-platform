import { c as createRouter, a as createRootRouteWithContext, b as createFileRoute, l as lazyRouteComponent, u as useRouterState, H as HeadContent, S as Scripts } from "../_libs/@tanstack/react-router.mjs";
import { s as setupRouterSsrQueryIntegration } from "../_libs/@tanstack/react-router-ssr-query.mjs";
import { j as jsxRuntimeExports, r as reactExports } from "../_libs/react.mjs";
import { J, z } from "../_libs/next-themes.mjs";
import { L as LuMoon, a as LuSun } from "../_libs/react-icons.mjs";
import { b as betterAuth } from "../_libs/better-auth.mjs";
import { Q as QueryClient } from "../_libs/@tanstack/query-core.mjs";
import { C as ChakraProvider, d as defaultSystem, a as ClientOnly, I as IconButton, S as Skeleton, b as Span } from "../_libs/@chakra-ui/react.mjs";
import "../_libs/tiny-warning.mjs";
import "../_libs/@tanstack/router-core.mjs";
import "../_libs/@tanstack/store.mjs";
import "../_libs/@tanstack/history.mjs";
import "../_libs/tiny-invariant.mjs";
import "node:stream/web";
import "node:stream";
import "../_libs/react-dom.mjs";
import "../_libs/@babel/runtime.mjs";
import "util";
import "crypto";
import "async_hooks";
import "stream";
import "../_libs/isbot.mjs";
import "../_libs/@tanstack/react-store.mjs";
import "../_libs/use-sync-external-store.mjs";
import "../_libs/@tanstack/react-query.mjs";
import "../_libs/@tanstack/router-ssr-query-core.mjs";
import "../_libs/@better-auth/core.mjs";
import "../_libs/better-call.mjs";
import "../_libs/@better-auth/utils.mjs";
import "../_libs/zod.mjs";
import "../_libs/rou3.mjs";
import "../_libs/@better-fetch/fetch.mjs";
import "../_libs/jose.mjs";
import "../_libs/kysely.mjs";
import "../_libs/@noble/hashes.mjs";
import "../_libs/@noble/ciphers.mjs";
import "../_libs/defu.mjs";
import "../_libs/@better-auth/telemetry.mjs";
import "../_libs/@pandacss/is-valid-prop.mjs";
import "../_libs/@ark-ui/react.mjs";
import "../_libs/@zag-js/carousel.mjs";
import "../_libs/@zag-js/anatomy.mjs";
import "../_libs/@zag-js/types.mjs";
import "../_libs/@zag-js/core.mjs";
import "../_libs/@zag-js/utils.mjs";
import "../_libs/@zag-js/dom-query.mjs";
import "../_libs/@zag-js/checkbox.mjs";
import "../_libs/@zag-js/focus-visible.mjs";
import "../_libs/@zag-js/react.mjs";
import "../_libs/@zag-js/color-picker.mjs";
import "../_libs/@zag-js/color-utils.mjs";
import "../_libs/@zag-js/popper.mjs";
import "../_libs/@floating-ui/dom.mjs";
import "../_libs/@floating-ui/core.mjs";
import "../_libs/@floating-ui/utils.mjs";
import "../_libs/@zag-js/dismissable.mjs";
import "../_libs/@zag-js/interact-outside.mjs";
import "../_libs/@zag-js/combobox.mjs";
import "../_libs/@zag-js/collection.mjs";
import "../_libs/@zag-js/auto-resize.mjs";
import "../_libs/@zag-js/listbox.mjs";
import "../_libs/@zag-js/radio-group.mjs";
import "../_libs/@zag-js/tooltip.mjs";
import "../_libs/@zag-js/presence.mjs";
import "../_libs/@zag-js/switch.mjs";
import "../_libs/@zag-js/splitter.mjs";
import "../_libs/@zag-js/slider.mjs";
import "../_libs/@zag-js/select.mjs";
import "../_libs/@zag-js/rating-group.mjs";
import "../_libs/@zag-js/popover.mjs";
import "../_libs/@zag-js/menu.mjs";
import "../_libs/@zag-js/rect-utils.mjs";
import "../_libs/@zag-js/file-upload.mjs";
import "../_libs/@zag-js/editable.mjs";
import "../_libs/@zag-js/dialog.mjs";
import "../_libs/@zag-js/accordion.mjs";
import "../_libs/@zag-js/clipboard.mjs";
import "../_libs/@zag-js/avatar.mjs";
import "../_libs/@zag-js/collapsible.mjs";
import "../_libs/@zag-js/hover-card.mjs";
import "../_libs/@zag-js/number-input.mjs";
import "../_libs/@internationalized/number.mjs";
import "../_libs/@zag-js/pin-input.mjs";
import "../_libs/@zag-js/progress.mjs";
import "../_libs/@zag-js/qr-code.mjs";
import "../_libs/@zag-js/scroll-area.mjs";
import "../_libs/@zag-js/tags-input.mjs";
import "../_libs/@zag-js/live-region.mjs";
import "../_libs/@zag-js/tree-view.mjs";
import "../_libs/@emotion/is-prop-valid.mjs";
import "../_libs/@emotion/memoize.mjs";
import "../_libs/@emotion/serialize.mjs";
import "../_libs/@emotion/hash.mjs";
import "../_libs/@emotion/unitless.mjs";
import "../_libs/@emotion/use-insertion-effect-with-fallbacks.mjs";
import "../_libs/@emotion/utils.mjs";
import "../_libs/@emotion/react.mjs";
import "../_libs/@emotion/cache.mjs";
import "../_libs/@emotion/sheet.mjs";
import "../_libs/@emotion/weak-memoize.mjs";
import "../_libs/stylis.mjs";
function getContext() {
  const queryClient = new QueryClient();
  return {
    queryClient
  };
}
function ColorModeProvider(props) {
  return /* @__PURE__ */ jsxRuntimeExports.jsx(J, { attribute: "class", disableTransitionOnChange: true, ...props });
}
function useColorMode() {
  const { resolvedTheme, setTheme, forcedTheme } = z();
  const colorMode = forcedTheme || resolvedTheme;
  const toggleColorMode = () => {
    setTheme(resolvedTheme === "dark" ? "light" : "dark");
  };
  return {
    colorMode,
    setColorMode: setTheme,
    toggleColorMode
  };
}
function ColorModeIcon() {
  const { colorMode } = useColorMode();
  return colorMode === "dark" ? /* @__PURE__ */ jsxRuntimeExports.jsx(LuMoon, {}) : /* @__PURE__ */ jsxRuntimeExports.jsx(LuSun, {});
}
reactExports.forwardRef(function ColorModeButton2(props, ref) {
  const { toggleColorMode } = useColorMode();
  return /* @__PURE__ */ jsxRuntimeExports.jsx(ClientOnly, { fallback: /* @__PURE__ */ jsxRuntimeExports.jsx(Skeleton, { boxSize: "9" }), children: /* @__PURE__ */ jsxRuntimeExports.jsx(
    IconButton,
    {
      onClick: toggleColorMode,
      variant: "ghost",
      "aria-label": "Toggle color mode",
      size: "sm",
      ref,
      ...props,
      css: {
        _icon: {
          width: "5",
          height: "5"
        }
      },
      children: /* @__PURE__ */ jsxRuntimeExports.jsx(ColorModeIcon, {})
    }
  ) });
});
reactExports.forwardRef(
  function LightMode2(props, ref) {
    return /* @__PURE__ */ jsxRuntimeExports.jsx(
      Span,
      {
        color: "fg",
        display: "contents",
        className: "chakra-theme light",
        colorPalette: "gray",
        colorScheme: "light",
        ref,
        ...props
      }
    );
  }
);
reactExports.forwardRef(
  function DarkMode2(props, ref) {
    return /* @__PURE__ */ jsxRuntimeExports.jsx(
      Span,
      {
        color: "fg",
        display: "contents",
        className: "chakra-theme dark",
        colorPalette: "gray",
        colorScheme: "dark",
        ref,
        ...props
      }
    );
  }
);
function Provider(props) {
  return /* @__PURE__ */ jsxRuntimeExports.jsx(ChakraProvider, { value: defaultSystem, children: /* @__PURE__ */ jsxRuntimeExports.jsx(ColorModeProvider, { ...props }) });
}
const appCss = "/assets/styles-CucSowog.css";
const Route$8 = createRootRouteWithContext()({
  head: () => ({
    meta: [
      {
        charSet: "utf-8"
      },
      {
        name: "viewport",
        content: "width=device-width, initial-scale=1"
      },
      {
        title: "TanStack Start Starter"
      }
    ],
    links: [
      {
        rel: "stylesheet",
        href: appCss
      }
    ]
  }),
  shellComponent: RootDocument
});
function RootDocument({ children }) {
  const routerState = useRouterState();
  const isQuestionRoute = routerState.location.pathname.startsWith("/questions");
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("html", { lang: "en", suppressHydrationWarning: true, children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx("head", { children: /* @__PURE__ */ jsxRuntimeExports.jsx(HeadContent, {}) }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("body", { children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs(Provider, { children: [
        children,
        !isQuestionRoute
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(Scripts, {})
    ] })
  ] });
}
const $$splitComponentImporter$6 = () => import("./index-DnpK3k1T.mjs");
const Route$7 = createFileRoute("/")({
  component: lazyRouteComponent($$splitComponentImporter$6, "component")
});
const $$splitComponentImporter$5 = () => import("./route-Cjn1uXOs.mjs");
const Route$6 = createFileRoute("/questions/networking")({
  component: lazyRouteComponent($$splitComponentImporter$5, "component")
});
const $$splitComponentImporter$4 = () => import("./index-STtIaqis.mjs");
const Route$5 = createFileRoute("/questions/networking/")({
  component: lazyRouteComponent($$splitComponentImporter$4, "component")
});
const auth = betterAuth({
  emailAndPassword: {
    enabled: true
  }
});
const Route$4 = createFileRoute("/api/auth/$")({
  server: {
    handlers: {
      GET: ({ request }) => auth.handler(request),
      POST: ({ request }) => auth.handler(request)
    }
  }
});
const $$splitComponentImporter$3 = () => import("./index-CuF6mgyY.mjs");
const Route$3 = createFileRoute("/questions/networking/webserver-ssl/")({
  component: lazyRouteComponent($$splitComponentImporter$3, "component")
});
const $$splitComponentImporter$2 = () => import("./index-CcJnb959.mjs");
const Route$2 = createFileRoute("/questions/networking/tcp/")({
  component: lazyRouteComponent($$splitComponentImporter$2, "component")
});
const $$splitComponentImporter$1 = () => import("./index-DwRszB1u.mjs");
const Route$1 = createFileRoute("/questions/networking/internet/")({
  component: lazyRouteComponent($$splitComponentImporter$1, "component")
});
const $$splitComponentImporter = () => import("./index-C0UfydAf.mjs");
const Route = createFileRoute("/questions/networking/dhcp/")({
  component: lazyRouteComponent($$splitComponentImporter, "component")
});
const IndexRoute = Route$7.update({
  id: "/",
  path: "/",
  getParentRoute: () => Route$8
});
const QuestionsNetworkingRouteRoute = Route$6.update({
  id: "/questions/networking",
  path: "/questions/networking",
  getParentRoute: () => Route$8
});
const QuestionsNetworkingIndexRoute = Route$5.update({
  id: "/",
  path: "/",
  getParentRoute: () => QuestionsNetworkingRouteRoute
});
const ApiAuthSplatRoute = Route$4.update({
  id: "/api/auth/$",
  path: "/api/auth/$",
  getParentRoute: () => Route$8
});
const QuestionsNetworkingWebserverSslIndexRoute = Route$3.update({
  id: "/webserver-ssl/",
  path: "/webserver-ssl/",
  getParentRoute: () => QuestionsNetworkingRouteRoute
});
const QuestionsNetworkingTcpIndexRoute = Route$2.update({
  id: "/tcp/",
  path: "/tcp/",
  getParentRoute: () => QuestionsNetworkingRouteRoute
});
const QuestionsNetworkingInternetIndexRoute = Route$1.update({
  id: "/internet/",
  path: "/internet/",
  getParentRoute: () => QuestionsNetworkingRouteRoute
});
const QuestionsNetworkingDhcpIndexRoute = Route.update({
  id: "/dhcp/",
  path: "/dhcp/",
  getParentRoute: () => QuestionsNetworkingRouteRoute
});
const QuestionsNetworkingRouteRouteChildren = {
  QuestionsNetworkingIndexRoute,
  QuestionsNetworkingDhcpIndexRoute,
  QuestionsNetworkingInternetIndexRoute,
  QuestionsNetworkingTcpIndexRoute,
  QuestionsNetworkingWebserverSslIndexRoute
};
const QuestionsNetworkingRouteRouteWithChildren = QuestionsNetworkingRouteRoute._addFileChildren(
  QuestionsNetworkingRouteRouteChildren
);
const rootRouteChildren = {
  IndexRoute,
  QuestionsNetworkingRouteRoute: QuestionsNetworkingRouteRouteWithChildren,
  ApiAuthSplatRoute
};
const routeTree = Route$8._addFileChildren(rootRouteChildren)._addFileTypes();
const getRouter = () => {
  const rqContext = getContext();
  const router = createRouter({
    routeTree,
    context: {
      ...rqContext
    },
    defaultPreload: "intent"
  });
  setupRouterSsrQueryIntegration({
    router,
    queryClient: rqContext.queryClient
  });
  return router;
};
export {
  getRouter
};
