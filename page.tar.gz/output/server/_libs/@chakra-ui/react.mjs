import { r as reactExports, j as jsxRuntimeExports } from "../react.mjs";
import { i as isCssProperty } from "../@pandacss/is-valid-prop.mjs";
import { c as colorPickerAnatomy$1, a as comboboxAnatomy$1, l as listboxAnatomy$1, f as fieldsetAnatomy$1, b as fieldAnatomy$1, d as carouselAnatomy, e as checkboxAnatomy, s as segmentGroupAnatomy, C as CheckboxHiddenInput$1, g as CheckboxRoot$1, h as CheckboxControl$1, u as useCheckboxContext, i as CheckboxLabel$1, j as CheckboxRootProvider, k as CheckboxGroup, F as FieldInput, m as FieldTextarea, T as TooltipRoot$1, n as TooltipTrigger$1, o as TooltipPositioner$1, p as TooltipContent$1, q as TooltipArrow$1, r as TooltipArrowTip$1, t as TooltipRootProvider } from "../@ark-ui/react.mjs";
import { c as createAnatomy } from "../@zag-js/anatomy.mjs";
import { a as anatomy } from "../@zag-js/switch.mjs";
import { a as anatomy$1 } from "../@zag-js/splitter.mjs";
import { a as anatomy$2 } from "../@zag-js/slider.mjs";
import { a as anatomy$3 } from "../@zag-js/select.mjs";
import { a as anatomy$4 } from "../@zag-js/rating-group.mjs";
import { a as anatomy$5 } from "../@zag-js/radio-group.mjs";
import { a as anatomy$6 } from "../@zag-js/popover.mjs";
import { a as anatomy$7 } from "../@zag-js/menu.mjs";
import { a as anatomy$8 } from "../@zag-js/file-upload.mjs";
import { a as anatomy$9 } from "../@zag-js/editable.mjs";
import { a as anatomy$a } from "../@zag-js/dialog.mjs";
import { a as anatomy$b } from "../@zag-js/accordion.mjs";
import { a as anatomy$c } from "../@zag-js/clipboard.mjs";
import { a as anatomy$d } from "../@zag-js/avatar.mjs";
import { a as anatomy$e } from "../@zag-js/collapsible.mjs";
import { a as anatomy$f } from "../@zag-js/hover-card.mjs";
import { a as anatomy$g } from "../@zag-js/number-input.mjs";
import { a as anatomy$h } from "../@zag-js/pin-input.mjs";
import { a as anatomy$i } from "../@zag-js/progress.mjs";
import { a as anatomy$j } from "../@zag-js/qr-code.mjs";
import { a as anatomy$k } from "../@zag-js/scroll-area.mjs";
import { a as anatomy$l } from "../@zag-js/tags-input.mjs";
import { a as anatomy$m } from "../@zag-js/tooltip.mjs";
import { a as anatomy$n } from "../@zag-js/tree-view.mjs";
import { i as isPropValid$1 } from "../@emotion/is-prop-valid.mjs";
import { s as serializeStyles } from "../@emotion/serialize.mjs";
import { u as useInsertionEffectAlwaysWithSyncFallback } from "../@emotion/use-insertion-effect-with-fallbacks.mjs";
import { g as getRegisteredStyles, r as registerStyles, i as insertStyles } from "../@emotion/utils.mjs";
import { G as Global, w as withEmotionCache, T as ThemeContext } from "../@emotion/react.mjs";
function callAll(...fns) {
  return function mergedFn(...args) {
    fns.forEach((fn) => fn?.(...args));
  };
}
const clsx = (...args) => args.map((str) => str?.trim?.()).filter(Boolean).join(" ");
const eventRegex = /^on[A-Z]/;
function mergeProps(...args) {
  let result = {};
  for (let props of args) {
    for (let key in result) {
      if (eventRegex.test(key) && typeof result[key] === "function" && typeof props[key] === "function") {
        result[key] = callAll(result[key], props[key]);
        continue;
      }
      if (key === "className" || key === "class") {
        result[key] = clsx(result[key], props[key]);
        continue;
      }
      if (key === "style") {
        result[key] = Object.assign({}, result[key] ?? {}, props[key] ?? {});
        continue;
      }
      result[key] = props[key] !== void 0 ? props[key] : result[key];
    }
    for (let key in props) {
      if (result[key] === void 0) {
        result[key] = props[key];
      }
    }
  }
  return result;
}
const majorVersion = parseInt(reactExports.version.split(".")[0], 10);
const shouldReturnCleanup = majorVersion >= 19;
function assignRef(ref, value) {
  if (ref == null) return;
  if (typeof ref === "function") {
    return ref(value);
  }
  try {
    ref.current = value;
  } catch (error) {
    throw new Error(`Cannot assign value '${value}' to ref '${ref}'`);
  }
}
function mergeRefs(...refs) {
  const availableRefs = refs.filter((ref) => ref != null);
  if (shouldReturnCleanup) {
    const cleanupMap = /* @__PURE__ */ new Map();
    return (node) => {
      availableRefs.forEach((ref) => {
        const cleanup = assignRef(ref, node);
        if (cleanup) {
          cleanupMap.set(ref, cleanup);
        }
      });
      return () => {
        availableRefs.forEach((ref) => {
          const cleanup = cleanupMap.get(ref);
          if (cleanup && typeof cleanup === "function") {
            cleanup();
          } else {
            assignRef(ref, null);
          }
        });
        cleanupMap.clear();
      };
    };
  } else {
    return (node) => {
      availableRefs.forEach((ref) => {
        assignRef(ref, node);
      });
    };
  }
}
function compact(object) {
  const clone2 = Object.assign({}, object);
  for (let key in clone2) {
    if (clone2[key] === void 0) delete clone2[key];
  }
  return clone2;
}
const isObject = (v) => v != null && typeof v === "object" && !Array.isArray(v);
const isString = (v) => typeof v === "string";
const isFunction = (v) => typeof v === "function";
const cx = (...classNames) => {
  const classes = [];
  for (let i = 0; i < classNames.length; i++) {
    const className = classNames[i];
    if (!isString(className)) continue;
    const trimmed = className.trim();
    if (trimmed) classes.push(trimmed);
  }
  return classes.join(" ");
};
function interopDefault(mod) {
  return mod.default || mod;
}
function getElementRef(el) {
  const version = reactExports.version;
  if (!isString(version)) return el?.ref;
  if (version.startsWith("18.")) return el?.ref;
  return el?.props?.ref;
}
const uniq = (...items) => {
  const set = items.reduce((acc, curr) => {
    if (curr != null) curr.forEach((item) => acc.add(item));
    return acc;
  }, /* @__PURE__ */ new Set([]));
  return Array.from(set);
};
function getErrorMessage(hook, provider) {
  return `${hook} returned \`undefined\`. Seems you forgot to wrap component within ${provider}`;
}
function createContext(options = {}) {
  const {
    name,
    strict = true,
    hookName = "useContext",
    providerName = "Provider",
    errorMessage,
    defaultValue
  } = options;
  const Context = reactExports.createContext(defaultValue);
  Context.displayName = name;
  function useContext$1() {
    const context = reactExports.useContext(Context);
    if (!context && strict) {
      const error = new Error(
        errorMessage ?? getErrorMessage(hookName, providerName)
      );
      error.name = "ContextError";
      Error.captureStackTrace?.(error, useContext$1);
      throw error;
    }
    return context;
  }
  return [Context.Provider, useContext$1, Context];
}
const [ChakraContextProvider, useChakraContext] = createContext({
  name: "ChakraContext",
  strict: true,
  providerName: "<ChakraProvider />"
});
function ChakraProvider(props) {
  const { value: sys, children } = props;
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(ChakraContextProvider, { value: sys, children: [
    !sys._config.disableLayers && /* @__PURE__ */ jsxRuntimeExports.jsx(Global, { styles: sys.layers.atRule }),
    /* @__PURE__ */ jsxRuntimeExports.jsx(Global, { styles: sys._global }),
    children
  ] });
}
const splitPropFn = (props, predicate) => {
  const rest = {};
  const result = {};
  const allKeys = Object.keys(props);
  for (const key of allKeys) {
    if (predicate(key)) {
      result[key] = props[key];
    } else {
      rest[key] = props[key];
    }
  }
  return [result, rest];
};
const splitProps = (props, keys) => {
  const predicate = isFunction(keys) ? keys : (key) => keys.includes(key);
  return splitPropFn(props, predicate);
};
const htmlProps = /* @__PURE__ */ new Set([
  "htmlWidth",
  "htmlHeight",
  "htmlSize",
  "htmlTranslate"
]);
function isHtmlProp(prop) {
  return typeof prop === "string" && htmlProps.has(prop);
}
function useResolvedProps(inProps, cvaRecipe, shouldForwardProps) {
  const { css, isValidProperty } = useChakraContext();
  const { children, ...props } = inProps;
  const result = reactExports.useMemo(() => {
    const [forwardedProps, restProps_B] = splitProps(
      props,
      (key) => shouldForwardProps(key, cvaRecipe.variantKeys)
    );
    const [variantProps, restProps_C] = splitProps(
      restProps_B,
      cvaRecipe.variantKeys
    );
    const [styleProps, elementProps] = splitProps(restProps_C, isValidProperty);
    return {
      forwardedProps,
      variantProps,
      styleProps,
      elementProps
    };
  }, [cvaRecipe.variantKeys, shouldForwardProps, props, isValidProperty]);
  const { css: cssStyles, ...propStyles } = result.styleProps;
  const cvaStyles = reactExports.useMemo(() => {
    const variantProps = { ...result.variantProps };
    const hasColorPalette = cvaRecipe.variantKeys.includes("colorPalette");
    const hasOrientation = cvaRecipe.variantKeys.includes("orientation");
    if (!hasColorPalette) {
      variantProps.colorPalette = props.colorPalette;
    }
    if (!hasOrientation) {
      variantProps.orientation = props.orientation;
    }
    return cvaRecipe(variantProps);
  }, [cvaRecipe, result.variantProps, props.colorPalette, props.orientation]);
  const styles = reactExports.useMemo(() => {
    return css(cvaStyles, ...toArray(cssStyles), propStyles);
  }, [css, cvaStyles, cssStyles, propStyles]);
  return {
    styles,
    props: {
      ...result.forwardedProps,
      ...result.elementProps,
      children
    }
  };
}
const toArray = (val) => {
  const res = Array.isArray(val) ? val : [val];
  return res.filter(Boolean).flat();
};
const isPropValid = interopDefault(isPropValid$1);
const testOmitPropsOnStringTag = isPropValid;
const testOmitPropsOnComponent = (key) => key !== "theme";
const composeShouldForwardProps = (tag, options, isReal) => {
  let shouldForwardProp;
  if (options) {
    const optionsShouldForwardProp = options.shouldForwardProp;
    shouldForwardProp = tag.__emotion_forwardProp && optionsShouldForwardProp ? (propName) => tag.__emotion_forwardProp(propName) && optionsShouldForwardProp(propName) : optionsShouldForwardProp;
  }
  if (typeof shouldForwardProp !== "function" && isReal) {
    shouldForwardProp = tag.__emotion_forwardProp;
  }
  return shouldForwardProp;
};
let isBrowser = typeof document !== "undefined";
const Insertion = ({ cache: cache2, serialized, isStringTag }) => {
  registerStyles(cache2, serialized, isStringTag);
  const rules = useInsertionEffectAlwaysWithSyncFallback(
    () => insertStyles(cache2, serialized, isStringTag)
  );
  if (!isBrowser && rules !== void 0) {
    let serializedNames = serialized.name;
    let next = serialized.next;
    while (next !== void 0) {
      serializedNames = cx(serializedNames, next.name);
      next = next.next;
    }
    return /* @__PURE__ */ jsxRuntimeExports.jsx(
      "style",
      {
        ...{
          [`data-emotion`]: cx(cache2.key, serializedNames),
          dangerouslySetInnerHTML: { __html: rules },
          nonce: cache2.sheet.nonce
        }
      }
    );
  }
  return null;
};
const exceptionPropMap = {
  path: ["d"],
  text: ["x", "y"],
  circle: ["cx", "cy", "r"],
  rect: ["width", "height", "x", "y", "rx", "ry"],
  ellipse: ["cx", "cy", "rx", "ry"],
  g: ["transform"],
  stop: ["offset", "stopOpacity"]
};
const hasProp = (obj, prop) => {
  return Object.prototype.hasOwnProperty.call(obj, prop);
};
const createStyled = (tag, configOrCva = {}, options = {}) => {
  if (hasProp(exceptionPropMap, tag)) {
    options.forwardProps || (options.forwardProps = []);
    const props = exceptionPropMap[tag];
    options.forwardProps = uniq([...options.forwardProps, ...props]);
  }
  const isReal = tag.__emotion_real === tag;
  const baseTag = isReal && tag.__emotion_base || tag;
  let identifierName;
  let targetClassName;
  if (options !== void 0) {
    identifierName = options.label;
    targetClassName = options.target;
  }
  let styles = [];
  const Styled = withEmotionCache((inProps, cache2, ref) => {
    const { cva, isValidProperty } = useChakraContext();
    const cvaFn = configOrCva.__cva__ ? configOrCva : cva(configOrCva);
    const cvaRecipe = mergeCva$1(tag.__emotion_cva, cvaFn);
    const createShouldForwardProps = (props2) => {
      return (prop, variantKeys) => {
        if (props2.includes(prop)) return true;
        return !variantKeys?.includes(prop) && !isValidProperty(prop);
      };
    };
    if (!options.shouldForwardProp && options.forwardProps) {
      options.shouldForwardProp = createShouldForwardProps(options.forwardProps);
    }
    const fallbackShouldForwardProp = (prop, variantKeys) => {
      const emotionSfp = typeof tag === "string" && tag.charCodeAt(0) > 96 ? testOmitPropsOnStringTag : testOmitPropsOnComponent;
      const chakraSfp = !variantKeys?.includes(prop) && !isValidProperty(prop);
      return emotionSfp(prop) && chakraSfp;
    };
    const shouldForwardProp = composeShouldForwardProps(tag, options, isReal) || fallbackShouldForwardProp;
    const propsWithDefault = reactExports.useMemo(
      () => Object.assign({}, options.defaultProps, compact(inProps)),
      [inProps]
    );
    const { props, styles: styleProps } = useResolvedProps(
      propsWithDefault,
      cvaRecipe,
      shouldForwardProp
    );
    let className = "";
    let classInterpolations = [styleProps];
    let mergedProps = props;
    if (props.theme == null) {
      mergedProps = {};
      for (let key in props) {
        mergedProps[key] = props[key];
      }
      mergedProps.theme = reactExports.useContext(ThemeContext);
    }
    if (typeof props.className === "string") {
      className = getRegisteredStyles(
        cache2.registered,
        classInterpolations,
        props.className
      );
    } else if (props.className != null) {
      className = cx(className, props.className);
    }
    const serialized = serializeStyles(
      styles.concat(classInterpolations),
      cache2.registered,
      mergedProps
    );
    if (serialized.styles) {
      className = cx(className, `${cache2.key}-${serialized.name}`);
    }
    if (targetClassName !== void 0) {
      className = cx(className, targetClassName);
    }
    const shouldUseAs = !shouldForwardProp("as");
    let FinalTag = shouldUseAs && props.as || baseTag;
    let finalProps = {};
    for (let prop in props) {
      if (shouldUseAs && prop === "as") continue;
      if (isHtmlProp(prop)) {
        const nativeProp = prop.replace("html", "").toLowerCase();
        finalProps[nativeProp] = props[prop];
        continue;
      }
      if (shouldForwardProp(prop)) {
        finalProps[prop] = props[prop];
      }
    }
    let classNameToUse = className.trim();
    if (classNameToUse) {
      finalProps.className = classNameToUse;
    } else {
      Reflect.deleteProperty(finalProps, "className");
    }
    finalProps.ref = ref;
    const forwardAsChild = options.forwardAsChild || options.forwardProps?.includes("asChild");
    if (props.asChild && !forwardAsChild) {
      const child = reactExports.isValidElement(props.children) ? reactExports.Children.only(props.children) : reactExports.Children.toArray(props.children).find(reactExports.isValidElement);
      if (!child) {
        throw new Error("[chakra-ui > factory] No valid child found");
      }
      FinalTag = child.type;
      finalProps.children = null;
      Reflect.deleteProperty(finalProps, "asChild");
      finalProps = mergeProps(finalProps, child.props);
      finalProps.ref = mergeRefs(ref, getElementRef(child));
    }
    if (finalProps.as && forwardAsChild) {
      finalProps.as = void 0;
      return /* @__PURE__ */ jsxRuntimeExports.jsxs(reactExports.Fragment, { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          Insertion,
          {
            cache: cache2,
            serialized,
            isStringTag: typeof FinalTag === "string"
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsx(FinalTag, { asChild: true, ...finalProps, children: /* @__PURE__ */ jsxRuntimeExports.jsx(props.as, { children: finalProps.children }) })
      ] });
    }
    return /* @__PURE__ */ jsxRuntimeExports.jsxs(reactExports.Fragment, { children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        Insertion,
        {
          cache: cache2,
          serialized,
          isStringTag: typeof FinalTag === "string"
        }
      ),
      /* @__PURE__ */ jsxRuntimeExports.jsx(FinalTag, { ...finalProps })
    ] });
  });
  Styled.displayName = identifierName !== void 0 ? identifierName : `chakra(${typeof baseTag === "string" ? baseTag : baseTag.displayName || baseTag.name || "Component"})`;
  Styled.__emotion_real = Styled;
  Styled.__emotion_base = baseTag;
  Styled.__emotion_forwardProp = options.shouldForwardProp;
  Styled.__emotion_cva = configOrCva;
  Object.defineProperty(Styled, "toString", {
    value() {
      return `.${targetClassName}`;
    }
  });
  return Styled;
};
const styledFn = createStyled.bind();
const cache = /* @__PURE__ */ new Map();
const chakraImpl = new Proxy(styledFn, {
  apply(_, __, args) {
    return styledFn(...args);
  },
  get(_, el) {
    if (!cache.has(el)) {
      cache.set(el, styledFn(el));
    }
    return cache.get(el);
  }
});
const chakra = chakraImpl;
const mergeCva$1 = (cvaA, cvaB) => {
  if (cvaA && !cvaB) return cvaA;
  if (!cvaA && cvaB) return cvaB;
  return cvaA.merge(cvaB);
};
const Box = chakra("div");
Box.displayName = "Box";
const Square = reactExports.forwardRef(
  function Square2(props, ref) {
    const { size, ...rest } = props;
    return /* @__PURE__ */ jsxRuntimeExports.jsx(
      Box,
      {
        ...rest,
        ref,
        boxSize: size,
        css: {
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          flexShrink: 0,
          flexGrow: 0,
          ...props.css
        }
      }
    );
  }
);
Square.displayName = "Square";
const Circle = reactExports.forwardRef(
  function Circle2(props, ref) {
    const { size, ...rest } = props;
    return /* @__PURE__ */ jsxRuntimeExports.jsx(Square, { size, ref, borderRadius: "9999px", ...rest });
  }
);
Circle.displayName = "Circle";
const EMPTY_STYLES = Object.freeze({});
const EMPTY_SLOT_STYLES = Object.freeze(
  {}
);
function useRecipe(options) {
  const { key, recipe: recipeProp } = options;
  const sys = useChakraContext();
  return reactExports.useMemo(() => {
    const recipe = recipeProp || (key != null ? sys.getRecipe(key) : {});
    return sys.cva(structuredClone(recipe));
  }, [key, recipeProp, sys]);
}
const upperFirst$1 = (str) => str.charAt(0).toUpperCase() + str.slice(1);
function createRecipeContext(options) {
  const { key: recipeKey, recipe: recipeConfig } = options;
  const contextName = upperFirst$1(
    recipeKey || recipeConfig.className || "Component"
  );
  const [PropsProvider, usePropsContext2] = createContext({
    strict: false,
    name: `${contextName}PropsContext`,
    providerName: `${contextName}PropsContext`
  });
  function useRecipeResult2(props) {
    const { unstyled, ...restProps } = props;
    const recipe = useRecipe({
      key: recipeKey,
      recipe: restProps.recipe || recipeConfig
    });
    const [variantProps, otherProps] = reactExports.useMemo(
      () => recipe.splitVariantProps(restProps),
      [recipe, restProps]
    );
    const styles = unstyled ? EMPTY_STYLES : recipe(variantProps);
    return {
      styles,
      className: recipe.className,
      props: otherProps
    };
  }
  const withContext2 = (Component, options2) => {
    const SuperComponent = chakra(Component, {}, options2);
    const StyledComponent = reactExports.forwardRef((inProps, ref) => {
      const propsContext = usePropsContext2();
      const props = reactExports.useMemo(
        () => mergeProps(propsContext, inProps),
        [inProps, propsContext]
      );
      const { styles, className, props: localProps } = useRecipeResult2(props);
      return /* @__PURE__ */ jsxRuntimeExports.jsx(
        SuperComponent,
        {
          ...localProps,
          ref,
          css: [styles, props.css],
          className: cx(className, props.className)
        }
      );
    });
    StyledComponent.displayName = Component.displayName || Component.name;
    return StyledComponent;
  };
  function withPropsProvider() {
    return PropsProvider;
  }
  return {
    withContext: withContext2,
    PropsProvider,
    withPropsProvider,
    usePropsContext: usePropsContext2,
    useRecipeResult: useRecipeResult2
  };
}
const Span = chakra("span");
Span.displayName = "Span";
const { withContext: withContext$7 } = createRecipeContext({
  key: "text"
});
const Text = withContext$7("p");
Text.displayName = "Text";
function useCallbackRef(callback, deps = []) {
  const callbackRef = reactExports.useRef(() => {
    throw new Error("Cannot call an event handler while rendering.");
  });
  reactExports.useInsertionEffect(() => {
    callbackRef.current = callback;
  });
  return reactExports.useCallback((...args) => callbackRef.current?.(...args), deps);
}
function listen(query, callback) {
  try {
    query.addEventListener("change", callback);
    return () => query.removeEventListener("change", callback);
  } catch (e) {
    query.addListener(callback);
    return () => query.removeListener(callback);
  }
}
function useMediaQuery(query, options = {}) {
  const { fallback: _fallback = [], ssr = true, getWindow } = options;
  const getWin = useCallbackRef(getWindow);
  const queries = Array.isArray(query) ? query : [query];
  const fallback2 = _fallback?.filter((v) => v != null);
  const [value, setValue] = reactExports.useState(() => {
    return queries.map((query2, index) => {
      if (!ssr) {
        const { media, matches } = (getWindow?.() ?? window).matchMedia(query2);
        return { media, matches };
      }
      return { media: query2, matches: !!fallback2[index] };
    });
  });
  reactExports.useEffect(() => {
    const win = getWin() ?? window;
    setValue((prev) => {
      const current = queries.map((query2) => {
        const { media, matches } = win.matchMedia(query2);
        return { media, matches };
      });
      return prev.every(
        (v, i) => v.matches === current[i].matches && v.media === current[i].media
      ) ? prev : current;
    });
    const mql = queries.map((query2) => win.matchMedia(query2));
    const handler = (evt) => {
      setValue((prev) => {
        return prev.slice().map((item) => {
          if (item.media === evt.media) return { ...item, matches: evt.matches };
          return item;
        });
      });
    };
    const cleanups = mql.map((v) => listen(v, handler));
    return () => cleanups.forEach((fn) => fn());
  }, [getWin]);
  return value.map((item) => item.matches);
}
function useBreakpoint(options = {}) {
  options.fallback || (options.fallback = "base");
  const sys = useChakraContext();
  let fallbackPassed = false;
  const allBreakpoints = sys.breakpoints.values;
  const breakpoints2 = allBreakpoints.map(({ min, name: breakpoint }) => {
    const item = {
      breakpoint,
      query: `(min-width: ${min})`,
      fallback: !fallbackPassed
    };
    if (breakpoint === options.fallback) {
      fallbackPassed = true;
    }
    return item;
  }).filter(({ breakpoint }) => !!options.breakpoints?.includes(breakpoint));
  const fallback2 = breakpoints2.map(({ fallback: fallback22 }) => fallback22);
  const values = useMediaQuery(
    breakpoints2.map((bp) => bp.query),
    { fallback: fallback2, ssr: options.ssr }
  );
  const index = values.lastIndexOf(true);
  return breakpoints2[index]?.breakpoint ?? options.fallback;
}
function useBreakpointValue(value, opts) {
  const sys = useChakraContext();
  const normalized = sys.normalizeValue(value);
  const breakpoint = useBreakpoint({
    breakpoints: Object.keys(normalized),
    ...opts
  });
  return normalized[breakpoint];
}
function omit(object, keysToOmit = []) {
  const clone2 = Object.assign({}, object);
  for (const key of keysToOmit) {
    if (key in clone2) {
      delete clone2[key];
    }
  }
  return clone2;
}
const colorMix = (value, token) => {
  if (!value || typeof value !== "string") {
    return { invalid: true, value };
  }
  const [rawColor, rawOpacity] = value.split("/");
  if (!rawColor || !rawOpacity || rawColor === "currentBg") {
    return { invalid: true, value: rawColor };
  }
  const colorToken = token(`colors.${rawColor}`);
  const opacityToken = token.raw(`opacity.${rawOpacity}`)?.value;
  if (!opacityToken && isNaN(Number(rawOpacity))) {
    return { invalid: true, value: rawColor };
  }
  const percent = opacityToken ? Number(opacityToken) * 100 + "%" : `${rawOpacity}%`;
  const color = colorToken ?? rawColor;
  return {
    invalid: false,
    color,
    value: `color-mix(in srgb, ${color} ${percent}, transparent)`
  };
};
const createColorMixTransform = (prop) => (value, args) => {
  const mix = args.utils.colorMix(value);
  if (mix.invalid) return { [prop]: value };
  const cssVar2 = "--mix-" + prop;
  return {
    [cssVar2]: mix.value,
    [prop]: `var(${cssVar2}, ${mix.color})`
  };
};
function clone(obj) {
  if (obj === null || typeof obj !== "object") return obj;
  if (Array.isArray(obj)) return obj.map((prop) => clone(prop));
  const _clone = Object.create(Object.getPrototypeOf(obj));
  for (const key of Object.keys(obj)) {
    _clone[key] = clone(obj[key]);
  }
  return _clone;
}
function merge(target, source) {
  if (source == null) return target;
  for (const key of Object.keys(source)) {
    if (source[key] === void 0 || key === "__proto__") continue;
    if (!isObject(target[key]) && isObject(source[key])) {
      Object.assign(target, { [key]: source[key] });
    } else if (target[key] && isObject(source[key])) {
      merge(target[key], source[key]);
    } else if (Array.isArray(source[key]) && Array.isArray(target[key])) {
      let i = 0;
      for (; i < source[key].length; i++) {
        if (isObject(target[key][i]) && isObject(source[key][i])) {
          merge(target[key][i], source[key][i]);
        } else {
          target[key][i] = source[key][i];
        }
      }
    } else {
      Object.assign(target, { [key]: source[key] });
    }
  }
  return target;
}
function mergeWith(target, ...sources) {
  for (const source of sources) {
    merge(target, source);
  }
  return target;
}
const isNotNullish = (element) => element != null;
function walkObject(target, predicate, options = {}) {
  const { stop: stop2, getKey } = options;
  function inner(value, path = []) {
    if (isObject(value) || Array.isArray(value)) {
      const result = {};
      for (const [prop, child] of Object.entries(value)) {
        const key = getKey?.(prop, child) ?? prop;
        const childPath = [...path, key];
        if (stop2?.(value, childPath)) {
          return predicate(value, path);
        }
        const next = inner(child, childPath);
        if (isNotNullish(next)) {
          result[key] = next;
        }
      }
      return result;
    }
    return predicate(value, path);
  }
  return inner(target);
}
function mapObject(obj, fn) {
  if (Array.isArray(obj))
    return obj.map((value) => {
      return isNotNullish(value) ? fn(value) : value;
    });
  if (!isObject(obj)) {
    return isNotNullish(obj) ? fn(obj) : obj;
  }
  return walkObject(obj, (value) => fn(value));
}
const tokenKeys = ["value", "type", "description"];
const isValidToken = (token) => {
  return token && typeof token === "object" && !Array.isArray(token);
};
const mergeConfigs = (...configs) => {
  const merged = mergeWith({}, ...configs.map(clone));
  if (merged.theme?.tokens) {
    walkObject(
      merged.theme.tokens,
      (value) => {
        const keys = Object.keys(value);
        const nestedKeys = keys.filter((k) => !tokenKeys.includes(k));
        const hasNested = nestedKeys.length > 0;
        const hasTokenProps = tokenKeys.some((k) => value[k] != null);
        if (hasNested && hasTokenProps) {
          value.DEFAULT || (value.DEFAULT = {});
          tokenKeys.forEach((key) => {
            var _a;
            if (value[key] == null) return;
            (_a = value.DEFAULT)[key] || (_a[key] = value[key]);
            delete value[key];
          });
        }
        return value;
      },
      {
        stop(value) {
          return isValidToken(value) && Object.keys(value).some(
            (k) => tokenKeys.includes(k) || k !== k.toLowerCase() && k !== k.toUpperCase()
          );
        }
      }
    );
  }
  return merged;
};
const defineConditions = (v) => v;
const defineRecipe = (v) => v;
const defineSlotRecipe = (v) => v;
const defineKeyframes = (v) => v;
const defineGlobalStyles = (v) => v;
const defineStyle = (v) => v;
const defineTextStyles = (v) => v;
const defineAnimationStyles = (v) => v;
const defineLayerStyles = (v) => v;
function createProxy() {
  const identity = (v) => v;
  return new Proxy(identity, {
    get() {
      return identity;
    }
  });
}
const defineTokens = /* @__PURE__ */ createProxy();
const defineSemanticTokens = /* @__PURE__ */ createProxy();
const defineConfig = (v) => v;
const escRegex = /[^a-zA-Z0-9_\u0081-\uffff-]/g;
function esc$1(string) {
  return `${string}`.replace(escRegex, (s) => `\\${s}`);
}
const dashCaseRegex = /[A-Z]/g;
function dashCase(string) {
  return string.replace(dashCaseRegex, (match) => `-${match.toLowerCase()}`);
}
function cssVar(name, options = {}) {
  const { fallback: fallback2 = "", prefix = "" } = options;
  const variable = dashCase(["-", prefix, esc$1(name)].filter(Boolean).join("-"));
  return {
    var: variable,
    ref: `var(${variable}${fallback2 ? `, ${fallback2}` : ""})`
  };
}
const isCssVar = (v) => /^var\(--.+\)$/.test(v);
const wrap = (str, v) => v != null ? `${str}(${v})` : v;
const deg = (v) => {
  if (isCssVar(v) || v == null) return v;
  const unitless = typeof v === "string" && !v.endsWith("deg");
  return typeof v === "number" || unitless ? `${v}deg` : v;
};
const createFocusRing = (selector) => {
  return {
    values: ["outside", "inside", "mixed", "none"],
    transform(value, { token }) {
      const focusRingColor = token("colors.colorPalette.focusRing");
      const styles = {
        inside: {
          "--focus-ring-color": focusRingColor,
          [selector]: {
            outlineOffset: "0px",
            outlineWidth: "var(--focus-ring-width, 1px)",
            outlineColor: "var(--focus-ring-color)",
            outlineStyle: "var(--focus-ring-style, solid)",
            borderColor: "var(--focus-ring-color)"
          }
        },
        outside: {
          "--focus-ring-color": focusRingColor,
          [selector]: {
            outlineWidth: "var(--focus-ring-width, 2px)",
            outlineOffset: "var(--focus-ring-offset, 2px)",
            outlineStyle: "var(--focus-ring-style, solid)",
            outlineColor: "var(--focus-ring-color)"
          }
        },
        mixed: {
          "--focus-ring-color": focusRingColor,
          [selector]: {
            outlineWidth: "var(--focus-ring-width, 3px)",
            outlineStyle: "var(--focus-ring-style, solid)",
            outlineColor: "color-mix(in srgb, var(--focus-ring-color), transparent 60%)",
            borderColor: "var(--focus-ring-color)"
          }
        },
        none: {
          "--focus-ring-color": focusRingColor,
          [selector]: {
            outline: "none"
          }
        }
      };
      return styles[value] ?? {};
    }
  };
};
const divideColor = createColorMixTransform("borderColor");
const createTransition = (value) => {
  return {
    transition: value,
    transitionTimingFunction: "cubic-bezier(0.4, 0, 0.2, 1)",
    transitionDuration: "150ms"
  };
};
const defaultConditions = defineConditions({
  hover: [
    "@media (hover: hover)",
    "&:is(:hover, [data-hover]):not(:disabled, [data-disabled])"
  ],
  active: "&:is(:active, [data-active]):not(:disabled, [data-disabled], [data-state=open])",
  focus: "&:is(:focus, [data-focus])",
  focusWithin: "&:is(:focus-within, [data-focus-within])",
  focusVisible: "&:is(:focus-visible, [data-focus-visible])",
  disabled: "&:is(:disabled, [disabled], [data-disabled], [aria-disabled=true])",
  visited: "&:visited",
  target: "&:target",
  readOnly: "&:is([data-readonly], [aria-readonly=true], [readonly])",
  readWrite: "&:read-write",
  empty: "&:is(:empty, [data-empty])",
  checked: "&:is(:checked, [data-checked], [aria-checked=true], [data-state=checked])",
  enabled: "&:enabled",
  expanded: "&:is([aria-expanded=true], [data-expanded], [data-state=expanded])",
  highlighted: "&[data-highlighted]",
  complete: "&[data-complete]",
  incomplete: "&[data-incomplete]",
  dragging: "&[data-dragging]",
  before: "&::before",
  after: "&::after",
  firstLetter: "&::first-letter",
  firstLine: "&::first-line",
  marker: "&::marker",
  selection: "&::selection",
  file: "&::file-selector-button",
  backdrop: "&::backdrop",
  first: "&:first-of-type",
  last: "&:last-of-type",
  notFirst: "&:not(:first-of-type)",
  notLast: "&:not(:last-of-type)",
  only: "&:only-child",
  even: "&:nth-of-type(even)",
  odd: "&:nth-of-type(odd)",
  peerFocus: ".peer:is(:focus, [data-focus]) ~ &",
  peerHover: ".peer:is(:hover, [data-hover]):not(:disabled, [data-disabled]) ~ &",
  peerActive: ".peer:is(:active, [data-active]):not(:disabled, [data-disabled]) ~ &",
  peerFocusWithin: ".peer:focus-within ~ &",
  peerFocusVisible: ".peer:is(:focus-visible, [data-focus-visible]) ~ &",
  peerDisabled: ".peer:is(:disabled, [disabled], [data-disabled]) ~ &",
  peerChecked: ".peer:is(:checked, [data-checked], [aria-checked=true], [data-state=checked]) ~ &",
  peerInvalid: ".peer:is(:invalid, [data-invalid], [aria-invalid=true]) ~ &",
  peerExpanded: ".peer:is([aria-expanded=true], [data-expanded], [data-state=expanded]) ~ &",
  peerPlaceholderShown: ".peer:placeholder-shown ~ &",
  groupFocus: ".group:is(:focus, [data-focus]) &",
  groupHover: ".group:is(:hover, [data-hover]):not(:disabled, [data-disabled]) &",
  groupActive: ".group:is(:active, [data-active]):not(:disabled, [data-disabled]) &",
  groupFocusWithin: ".group:focus-within &",
  groupFocusVisible: ".group:is(:focus-visible, [data-focus-visible]) &",
  groupDisabled: ".group:is(:disabled, [disabled], [data-disabled]) &",
  groupChecked: ".group:is(:checked, [data-checked], [aria-checked=true], [data-state=checked]) &",
  groupExpanded: ".group:is([aria-expanded=true], [data-expanded], [data-state=expanded]) &",
  groupInvalid: ".group:invalid &",
  indeterminate: "&:is(:indeterminate, [data-indeterminate], [aria-checked=mixed], [data-state=indeterminate])",
  required: "&:is([data-required], [aria-required=true])",
  valid: "&:is([data-valid], [data-state=valid])",
  invalid: "&:is([data-invalid], [aria-invalid=true], [data-state=invalid])",
  autofill: "&:autofill",
  inRange: "&:is(:in-range, [data-in-range])",
  outOfRange: "&:is(:out-of-range, [data-outside-range])",
  placeholder: "&::placeholder, &[data-placeholder]",
  placeholderShown: "&:is(:placeholder-shown, [data-placeholder-shown])",
  pressed: "&:is([aria-pressed=true], [data-pressed])",
  selected: "&:is([aria-selected=true], [data-selected])",
  grabbed: "&:is([aria-grabbed=true], [data-grabbed])",
  underValue: "&[data-state=under-value]",
  overValue: "&[data-state=over-value]",
  atValue: "&[data-state=at-value]",
  default: "&:default",
  optional: "&:optional",
  open: "&:is([open], [data-open], [data-state=open])",
  closed: "&:is([closed], [data-closed], [data-state=closed])",
  fullscreen: "&:is(:fullscreen, [data-fullscreen])",
  loading: "&:is([data-loading], [aria-busy=true])",
  hidden: "&:is([hidden], [data-hidden])",
  current: "&[data-current]",
  currentPage: "&[aria-current=page]",
  currentStep: "&[aria-current=step]",
  today: "&[data-today]",
  unavailable: "&[data-unavailable]",
  rangeStart: "&[data-range-start]",
  rangeEnd: "&[data-range-end]",
  now: "&[data-now]",
  topmost: "&[data-topmost]",
  motionReduce: "@media (prefers-reduced-motion: reduce)",
  motionSafe: "@media (prefers-reduced-motion: no-preference)",
  print: "@media print",
  landscape: "@media (orientation: landscape)",
  portrait: "@media (orientation: portrait)",
  dark: ".dark &, .dark .chakra-theme:not(.light) &",
  light: ":root &, .light &",
  osDark: "@media (prefers-color-scheme: dark)",
  osLight: "@media (prefers-color-scheme: light)",
  highContrast: "@media (forced-colors: active)",
  lessContrast: "@media (prefers-contrast: less)",
  moreContrast: "@media (prefers-contrast: more)",
  ltr: "[dir=ltr] &",
  rtl: "[dir=rtl] &",
  scrollbar: "&::-webkit-scrollbar",
  scrollbarThumb: "&::-webkit-scrollbar-thumb",
  scrollbarTrack: "&::-webkit-scrollbar-track",
  horizontal: "&[data-orientation=horizontal]",
  vertical: "&[data-orientation=vertical]",
  icon: "& :where(svg)",
  starting: "@starting-style"
});
const currentBgVar = cssVar("bg-currentcolor");
const isCurrentBgVar = (value) => value === currentBgVar.ref || value === "currentBg";
const colorValues = (theme) => ({
  ...theme("colors"),
  currentBg: currentBgVar
});
const defaultBaseConfig = defineConfig({
  conditions: defaultConditions,
  utilities: {
    // background
    background: {
      values: colorValues,
      shorthand: ["bg"],
      transform(value, args) {
        if (isCurrentBgVar(args.raw)) return { background: currentBgVar.ref };
        const styleObj = createColorMixTransform("background")(value, args);
        return { ...styleObj, [currentBgVar.var]: styleObj?.background };
      }
    },
    backgroundColor: {
      values: colorValues,
      shorthand: ["bgColor"],
      transform(value, args) {
        if (isCurrentBgVar(args.raw))
          return { backgroundColor: currentBgVar.ref };
        const styleObj = createColorMixTransform("backgroundColor")(value, args);
        return {
          ...styleObj,
          [currentBgVar.var]: styleObj?.backgroundColor
        };
      }
    },
    backgroundSize: { shorthand: ["bgSize"] },
    backgroundPosition: { shorthand: ["bgPos"] },
    backgroundRepeat: { shorthand: ["bgRepeat"] },
    backgroundAttachment: { shorthand: ["bgAttachment"] },
    backgroundClip: {
      shorthand: ["bgClip"],
      values: ["text"],
      transform(value) {
        return value === "text" ? { color: "transparent", backgroundClip: "text" } : { backgroundClip: value };
      }
    },
    backgroundGradient: {
      shorthand: ["bgGradient"],
      values(theme) {
        return {
          ...theme("gradients"),
          "to-t": "linear-gradient(to top, var(--gradient))",
          "to-tr": "linear-gradient(to top right, var(--gradient))",
          "to-r": "linear-gradient(to right, var(--gradient))",
          "to-br": "linear-gradient(to bottom right, var(--gradient))",
          "to-b": "linear-gradient(to bottom, var(--gradient))",
          "to-bl": "linear-gradient(to bottom left, var(--gradient))",
          "to-l": "linear-gradient(to left, var(--gradient))",
          "to-tl": "linear-gradient(to top left, var(--gradient))"
        };
      },
      transform(value) {
        return {
          "--gradient-stops": "var(--gradient-from), var(--gradient-to)",
          "--gradient": "var(--gradient-via-stops, var(--gradient-stops))",
          backgroundImage: value
        };
      }
    },
    gradientFrom: {
      values: colorValues,
      transform: createColorMixTransform("--gradient-from")
    },
    gradientTo: {
      values: colorValues,
      transform: createColorMixTransform("--gradient-to")
    },
    gradientVia: {
      values: colorValues,
      transform(value, args) {
        const styles = createColorMixTransform("--gradient-via")(value, args);
        return {
          ...styles,
          "--gradient-via-stops": "var(--gradient-from), var(--gradient-via), var(--gradient-to)"
        };
      }
    },
    backgroundImage: {
      values(theme) {
        return { ...theme("gradients"), ...theme("assets") };
      },
      shorthand: ["bgImg", "bgImage"]
    },
    // border
    border: { values: "borders" },
    borderTop: { values: "borders" },
    borderLeft: { values: "borders" },
    borderBlockStart: { values: "borders" },
    borderRight: { values: "borders" },
    borderBottom: { values: "borders" },
    borderBlockEnd: { values: "borders" },
    borderInlineStart: { values: "borders", shorthand: ["borderStart"] },
    borderInlineEnd: { values: "borders", shorthand: ["borderEnd"] },
    borderInline: { values: "borders", shorthand: ["borderX"] },
    borderBlock: { values: "borders", shorthand: ["borderY"] },
    // border colors
    borderColor: {
      values: colorValues,
      transform: createColorMixTransform("borderColor")
    },
    borderTopColor: {
      values: colorValues,
      transform: createColorMixTransform("borderTopColor")
    },
    borderBlockStartColor: {
      values: colorValues,
      transform: createColorMixTransform("borderBlockStartColor")
    },
    borderBottomColor: {
      values: colorValues,
      transform: createColorMixTransform("borderBottomColor")
    },
    borderBlockEndColor: {
      values: colorValues,
      transform: createColorMixTransform("borderBlockEndColor")
    },
    borderLeftColor: {
      values: colorValues,
      transform: createColorMixTransform("borderLeftColor")
    },
    borderInlineStartColor: {
      values: colorValues,
      shorthand: ["borderStartColor"],
      transform: createColorMixTransform("borderInlineStartColor")
    },
    borderRightColor: {
      values: colorValues,
      transform: createColorMixTransform("borderRightColor")
    },
    borderInlineEndColor: {
      values: colorValues,
      shorthand: ["borderEndColor"],
      transform: createColorMixTransform("borderInlineEndColor")
    },
    // border styles
    borderStyle: { values: "borderStyles" },
    borderTopStyle: { values: "borderStyles" },
    borderBlockStartStyle: { values: "borderStyles" },
    borderBottomStyle: { values: "borderStyles" },
    borderBlockEndStyle: {
      values: "borderStyles"
    },
    borderInlineStartStyle: {
      values: "borderStyles",
      shorthand: ["borderStartStyle"]
    },
    borderInlineEndStyle: {
      values: "borderStyles",
      shorthand: ["borderEndStyle"]
    },
    borderLeftStyle: { values: "borderStyles" },
    borderRightStyle: { values: "borderStyles" },
    // border radius
    borderRadius: { values: "radii", shorthand: ["rounded"] },
    borderTopLeftRadius: { values: "radii", shorthand: ["roundedTopLeft"] },
    borderStartStartRadius: {
      values: "radii",
      shorthand: ["roundedStartStart", "borderTopStartRadius"]
    },
    borderEndStartRadius: {
      values: "radii",
      shorthand: ["roundedEndStart", "borderBottomStartRadius"]
    },
    borderTopRightRadius: {
      values: "radii",
      shorthand: ["roundedTopRight"]
    },
    borderStartEndRadius: {
      values: "radii",
      shorthand: ["roundedStartEnd", "borderTopEndRadius"]
    },
    borderEndEndRadius: {
      values: "radii",
      shorthand: ["roundedEndEnd", "borderBottomEndRadius"]
    },
    borderBottomLeftRadius: {
      values: "radii",
      shorthand: ["roundedBottomLeft"]
    },
    borderBottomRightRadius: {
      values: "radii",
      shorthand: ["roundedBottomRight"]
    },
    borderInlineStartRadius: {
      values: "radii",
      property: "borderRadius",
      shorthand: ["roundedStart", "borderStartRadius"],
      transform: (value) => ({
        borderStartStartRadius: value,
        borderEndStartRadius: value
      })
    },
    borderInlineEndRadius: {
      values: "radii",
      property: "borderRadius",
      shorthand: ["roundedEnd", "borderEndRadius"],
      transform: (value) => ({
        borderStartEndRadius: value,
        borderEndEndRadius: value
      })
    },
    borderTopRadius: {
      values: "radii",
      property: "borderRadius",
      shorthand: ["roundedTop"],
      transform: (value) => ({
        borderTopLeftRadius: value,
        borderTopRightRadius: value
      })
    },
    borderBottomRadius: {
      values: "radii",
      property: "borderRadius",
      shorthand: ["roundedBottom"],
      transform: (value) => ({
        borderBottomLeftRadius: value,
        borderBottomRightRadius: value
      })
    },
    borderLeftRadius: {
      values: "radii",
      property: "borderRadius",
      shorthand: ["roundedLeft"],
      transform: (value) => ({
        borderTopLeftRadius: value,
        borderBottomLeftRadius: value
      })
    },
    borderRightRadius: {
      values: "radii",
      property: "borderRadius",
      shorthand: ["roundedRight"],
      transform: (value) => ({
        borderTopRightRadius: value,
        borderBottomRightRadius: value
      })
    },
    borderWidth: { values: "borderWidths" },
    borderBlockStartWidth: { values: "borderWidths" },
    borderTopWidth: { values: "borderWidths" },
    borderBottomWidth: { values: "borderWidths" },
    borderBlockEndWidth: { values: "borderWidths" },
    borderRightWidth: { values: "borderWidths" },
    borderInlineWidth: {
      values: "borderWidths",
      shorthand: ["borderXWidth"]
    },
    borderInlineStartWidth: {
      values: "borderWidths",
      shorthand: ["borderStartWidth"]
    },
    borderInlineEndWidth: {
      values: "borderWidths",
      shorthand: ["borderEndWidth"]
    },
    borderLeftWidth: { values: "borderWidths" },
    borderBlockWidth: {
      values: "borderWidths",
      shorthand: ["borderYWidth"]
    },
    // colors
    color: {
      values: colorValues,
      transform: createColorMixTransform("color")
    },
    fill: {
      values: colorValues,
      transform: createColorMixTransform("fill")
    },
    stroke: {
      values: colorValues,
      transform: createColorMixTransform("stroke")
    },
    accentColor: {
      values: colorValues,
      transform: createColorMixTransform("accentColor")
    },
    // divide
    divideX: {
      values: { type: "string" },
      transform(value) {
        return {
          "& > :not(style, [hidden]) ~ :not(style, [hidden])": {
            borderInlineStartWidth: value,
            borderInlineEndWidth: "0px"
          }
        };
      }
    },
    divideY: {
      values: { type: "string" },
      transform(value) {
        return {
          "& > :not(style, [hidden]) ~ :not(style, [hidden])": {
            borderTopWidth: value,
            borderBottomWidth: "0px"
          }
        };
      }
    },
    divideColor: {
      values: colorValues,
      transform(value, args) {
        return {
          "& > :not(style, [hidden]) ~ :not(style, [hidden])": divideColor(
            value,
            args
          )
        };
      }
    },
    divideStyle: {
      property: "borderStyle",
      transform(value) {
        return {
          "& > :not(style, [hidden]) ~ :not(style, [hidden])": {
            borderStyle: value
          }
        };
      }
    },
    // effects
    boxShadow: { values: "shadows", shorthand: ["shadow"] },
    boxShadowColor: {
      values: colorValues,
      transform: createColorMixTransform("--shadow-color"),
      shorthand: ["shadowColor"]
    },
    mixBlendMode: { shorthand: ["blendMode"] },
    backgroundBlendMode: { shorthand: ["bgBlendMode"] },
    opacity: { values: "opacity" },
    // filters
    filter: {
      transform(v) {
        if (v !== "auto") {
          return { filter: v };
        }
        return {
          filter: `var(--blur) var(--brightness) var(--contrast) var(--grayscale) var(--hue-rotate) var(--invert) var(--saturate) var(--sepia) var(--drop-shadow)`
        };
      }
    },
    blur: {
      values: "blurs",
      transform: (v) => ({ "--blur": wrap("blur", v) })
    },
    brightness: {
      transform: (v) => ({ "--brightness": wrap("brightness", v) })
    },
    contrast: {
      transform: (v) => ({ "--contrast": wrap("contrast", v) })
    },
    grayscale: {
      transform: (v) => ({ "--grayscale": wrap("grayscale", v) })
    },
    hueRotate: {
      transform: (v) => ({ "--hue-rotate": wrap("hue-rotate", deg(v)) })
    },
    invert: { transform: (v) => ({ "--invert": wrap("invert", v) }) },
    saturate: {
      transform: (v) => ({ "--saturate": wrap("saturate", v) })
    },
    sepia: { transform: (v) => ({ "--sepia": wrap("sepia", v) }) },
    dropShadow: {
      transform: (v) => ({ "--drop-shadow": wrap("drop-shadow", v) })
    },
    // backdrop filters
    backdropFilter: {
      transform(v) {
        if (v !== "auto") {
          return { backdropFilter: v };
        }
        return {
          backdropFilter: `var(--backdrop-blur) var(--backdrop-brightness) var(--backdrop-contrast) var(--backdrop-grayscale) var(--backdrop-hue-rotate) var(--backdrop-invert) var(--backdrop-opacity) var(--backdrop-saturate) var(--backdrop-sepia)`
        };
      }
    },
    backdropBlur: {
      values: "blurs",
      transform: (v) => ({ "--backdrop-blur": wrap("blur", v) })
    },
    backdropBrightness: {
      transform: (v) => ({
        "--backdrop-brightness": wrap("brightness", v)
      })
    },
    backdropContrast: {
      transform: (v) => ({ "--backdrop-contrast": wrap("contrast", v) })
    },
    backdropGrayscale: {
      transform: (v) => ({
        "--backdrop-grayscale": wrap("grayscale", v)
      })
    },
    backdropHueRotate: {
      transform: (v) => ({
        "--backdrop-hue-rotate": wrap("hue-rotate", deg(v))
      })
    },
    backdropInvert: {
      transform: (v) => ({ "--backdrop-invert": wrap("invert", v) })
    },
    backdropOpacity: {
      transform: (v) => ({ "--backdrop-opacity": wrap("opacity", v) })
    },
    backdropSaturate: {
      transform: (v) => ({ "--backdrop-saturate": wrap("saturate", v) })
    },
    backdropSepia: {
      transform: (v) => ({ "--backdrop-sepia": wrap("sepia", v) })
    },
    // flexbox
    flexBasis: { values: "sizes" },
    gap: { values: "spacing" },
    rowGap: { values: "spacing", shorthand: ["gapY"] },
    columnGap: { values: "spacing", shorthand: ["gapX"] },
    flexDirection: { shorthand: ["flexDir"] },
    // grid
    gridGap: { values: "spacing" },
    gridColumnGap: { values: "spacing" },
    gridRowGap: { values: "spacing" },
    // interactivity
    outlineColor: {
      values: colorValues,
      transform: createColorMixTransform("outlineColor")
    },
    focusRing: createFocusRing("&:is(:focus, [data-focus])"),
    focusVisibleRing: createFocusRing(
      "&:is(:focus-visible, [data-focus-visible])"
    ),
    focusRingColor: {
      values: colorValues,
      transform: createColorMixTransform("--focus-ring-color")
    },
    focusRingOffset: {
      values: "spacing",
      transform: (v) => ({ "--focus-ring-offset": v })
    },
    focusRingWidth: {
      values: "borderWidths",
      property: "outlineWidth",
      transform: (v) => ({ "--focus-ring-width": v })
    },
    focusRingStyle: {
      values: "borderStyles",
      property: "outlineStyle",
      transform: (v) => ({ "--focus-ring-style": v })
    },
    // layout
    aspectRatio: { values: "aspectRatios" },
    width: { values: "sizes", shorthand: ["w"] },
    inlineSize: { values: "sizes" },
    height: { values: "sizes", shorthand: ["h"] },
    blockSize: { values: "sizes" },
    boxSize: {
      values: "sizes",
      property: "width",
      transform: (v) => ({ width: v, height: v })
    },
    minWidth: { values: "sizes", shorthand: ["minW"] },
    minInlineSize: { values: "sizes" },
    minHeight: { values: "sizes", shorthand: ["minH"] },
    minBlockSize: { values: "sizes" },
    maxWidth: { values: "sizes", shorthand: ["maxW"] },
    maxInlineSize: { values: "sizes" },
    maxHeight: { values: "sizes", shorthand: ["maxH"] },
    maxBlockSize: { values: "sizes" },
    hideFrom: {
      values: "breakpoints",
      //@ts-ignore
      transform: (value, { raw, token }) => {
        const bp = token.raw(`breakpoints.${raw}`);
        const media = bp ? `@breakpoint ${raw}` : `@media screen and (min-width: ${value})`;
        return {
          [media]: { display: "none" }
        };
      }
    },
    hideBelow: {
      values: "breakpoints",
      //@ts-ignore
      transform(value, { raw, token }) {
        const bp = token.raw(`breakpoints.${raw}`);
        const media = bp ? `@breakpoint ${raw}Down` : `@media screen and (max-width: ${value})`;
        return {
          [media]: {
            display: "none"
          }
        };
      }
    },
    // scroll
    overscrollBehavior: { shorthand: ["overscroll"] },
    overscrollBehaviorX: { shorthand: ["overscrollX"] },
    overscrollBehaviorY: { shorthand: ["overscrollY"] },
    scrollbar: {
      values: ["visible", "hidden"],
      transform(v) {
        switch (v) {
          case "visible":
            return {
              msOverflowStyle: "auto",
              scrollbarWidth: "auto",
              "&::-webkit-scrollbar": { display: "block" }
            };
          case "hidden":
            return {
              msOverflowStyle: "none",
              scrollbarWidth: "none",
              "&::-webkit-scrollbar": { display: "none" }
            };
          default:
            return {};
        }
      }
    },
    scrollbarColor: {
      values: colorValues,
      transform: createColorMixTransform("scrollbarColor")
    },
    scrollbarGutter: { values: "spacing" },
    scrollbarWidth: { values: "sizes" },
    // scroll margin
    scrollMargin: { values: "spacing" },
    scrollMarginTop: { values: "spacing" },
    scrollMarginBottom: { values: "spacing" },
    scrollMarginLeft: { values: "spacing" },
    scrollMarginRight: { values: "spacing" },
    scrollMarginX: {
      values: "spacing",
      transform: (v) => ({ scrollMarginLeft: v, scrollMarginRight: v })
    },
    scrollMarginY: {
      values: "spacing",
      transform: (v) => ({ scrollMarginTop: v, scrollMarginBottom: v })
    },
    // scroll padding
    scrollPadding: { values: "spacing" },
    scrollPaddingTop: { values: "spacing" },
    scrollPaddingBottom: { values: "spacing" },
    scrollPaddingLeft: { values: "spacing" },
    scrollPaddingRight: { values: "spacing" },
    scrollPaddingInline: { values: "spacing", shorthand: ["scrollPaddingX"] },
    scrollPaddingBlock: { values: "spacing", shorthand: ["scrollPaddingY"] },
    // scroll snap
    scrollSnapType: {
      values: {
        none: "none",
        x: "x var(--scroll-snap-strictness)",
        y: "y var(--scroll-snap-strictness)",
        both: "both var(--scroll-snap-strictness)"
      }
    },
    scrollSnapStrictness: {
      values: ["mandatory", "proximity"],
      transform: (v) => ({ "--scroll-snap-strictness": v })
    },
    scrollSnapMargin: { values: "spacing" },
    scrollSnapMarginTop: { values: "spacing" },
    scrollSnapMarginBottom: { values: "spacing" },
    scrollSnapMarginLeft: { values: "spacing" },
    scrollSnapMarginRight: { values: "spacing" },
    // list
    listStylePosition: { shorthand: ["listStylePos"] },
    listStyleImage: { values: "assets", shorthand: ["listStyleImg"] },
    // position
    position: { shorthand: ["pos"] },
    zIndex: { values: "zIndex" },
    inset: { values: "spacing" },
    insetInline: { values: "spacing", shorthand: ["insetX"] },
    insetBlock: { values: "spacing", shorthand: ["insetY"] },
    top: { values: "spacing" },
    insetBlockStart: { values: "spacing" },
    bottom: { values: "spacing" },
    insetBlockEnd: { values: "spacing" },
    left: { values: "spacing" },
    right: { values: "spacing" },
    insetInlineStart: {
      values: "spacing",
      shorthand: ["insetStart"]
    },
    insetInlineEnd: {
      values: "spacing",
      shorthand: ["insetEnd"]
    },
    // shadow / ring
    ring: {
      transform(value) {
        return {
          "--ring-offset-shadow": `var(--ring-inset) 0 0 0 var(--ring-offset-width) var(--ring-offset-color)`,
          "--ring-shadow": `var(--ring-inset) 0 0 0 calc(var(--ring-width) + var(--ring-offset-width)) var(--ring-color)`,
          "--ring-width": value,
          boxShadow: "var(--ring-offset-shadow), var(--ring-shadow), var(--shadow, 0 0 #0000)"
        };
      }
    },
    ringColor: {
      values: colorValues,
      transform: createColorMixTransform("--ring-color")
    },
    ringOffset: {
      transform: (value) => ({ "--ring-offset-width": value })
    },
    ringOffsetColor: {
      values: colorValues,
      transform: createColorMixTransform("--ring-offset-color")
    },
    ringInset: {
      transform: (v) => ({ "--ring-inset": v })
    },
    // margin
    margin: { values: "spacing", shorthand: ["m"] },
    marginTop: { values: "spacing", shorthand: ["mt"] },
    marginBlockStart: { values: "spacing" },
    marginRight: { values: "spacing", shorthand: ["mr"] },
    marginBottom: { values: "spacing", shorthand: ["mb"] },
    marginBlockEnd: { values: "spacing" },
    marginLeft: { values: "spacing", shorthand: ["ml"] },
    marginInlineStart: { values: "spacing", shorthand: ["ms", "marginStart"] },
    marginInlineEnd: { values: "spacing", shorthand: ["me", "marginEnd"] },
    marginInline: { values: "spacing", shorthand: ["mx", "marginX"] },
    marginBlock: { values: "spacing", shorthand: ["my", "marginY"] },
    // padding
    padding: { values: "spacing", shorthand: ["p"] },
    paddingTop: { values: "spacing", shorthand: ["pt"] },
    paddingRight: { values: "spacing", shorthand: ["pr"] },
    paddingBottom: { values: "spacing", shorthand: ["pb"] },
    paddingBlockStart: { values: "spacing" },
    paddingBlockEnd: { values: "spacing" },
    paddingLeft: { values: "spacing", shorthand: ["pl"] },
    paddingInlineStart: {
      values: "spacing",
      shorthand: ["ps", "paddingStart"]
    },
    paddingInlineEnd: { values: "spacing", shorthand: ["pe", "paddingEnd"] },
    paddingInline: { values: "spacing", shorthand: ["px", "paddingX"] },
    paddingBlock: { values: "spacing", shorthand: ["py", "paddingY"] },
    // text decoration
    textDecoration: { shorthand: ["textDecor"] },
    textDecorationColor: {
      values: colorValues,
      transform: createColorMixTransform("textDecorationColor")
    },
    textShadow: { values: "shadows" },
    // transform
    transform: {
      transform: (value) => {
        let v = value;
        if (value === "auto") {
          v = `translateX(var(--translate-x, 0)) translateY(var(--translate-y, 0)) rotate(var(--rotate, 0)) scaleX(var(--scale-x, 1)) scaleY(var(--scale-y, 1)) skewX(var(--skew-x, 0)) skewY(var(--skew-y, 0))`;
        }
        if (value === "auto-gpu") {
          v = `translate3d(var(--translate-x, 0), var(--translate-y, 0), 0) rotate(var(--rotate, 0)) scaleX(var(--scale-x, 1)) scaleY(var(--scale-y, 1)) skewX(var(--skew-x, 0)) skewY(var(--skew-y, 0))`;
        }
        return { transform: v };
      }
    },
    skewX: { transform: (v) => ({ "--skew-x": deg(v) }) },
    skewY: { transform: (v) => ({ "--skew-y": deg(v) }) },
    scaleX: { transform: (v) => ({ "--scale-x": v }) },
    scaleY: { transform: (v) => ({ "--scale-y": v }) },
    scale: {
      transform(value) {
        if (value !== "auto") return { scale: value };
        return {
          scale: `var(--scale-x, 1) var(--scale-y, 1)`
        };
      }
    },
    spaceXReverse: {
      values: { type: "boolean" },
      transform(value) {
        return {
          "& > :not(style, [hidden]) ~ :not(style, [hidden])": {
            "--space-x-reverse": value ? "1" : void 0
          }
        };
      }
    },
    spaceX: {
      property: "marginInlineStart",
      values: "spacing",
      transform: (v) => ({
        "& > :not(style, [hidden]) ~ :not(style, [hidden])": {
          "--space-x-reverse": "0",
          marginInlineStart: `calc(${v} * calc(1 - var(--space-x-reverse)))`,
          marginInlineEnd: `calc(${v} * var(--space-x-reverse))`
        }
      })
    },
    spaceYReverse: {
      values: { type: "boolean" },
      transform(value) {
        return {
          "& > :not(style, [hidden]) ~ :not(style, [hidden])": {
            "--space-y-reverse": value ? "1" : void 0
          }
        };
      }
    },
    spaceY: {
      property: "marginTop",
      values: "spacing",
      transform: (v) => ({
        "& > :not(style, [hidden]) ~ :not(style, [hidden])": {
          "--space-y-reverse": "0",
          marginTop: `calc(${v} * calc(1 - var(--space-y-reverse)))`,
          marginBottom: `calc(${v} * var(--space-y-reverse))`
        }
      })
    },
    rotate: {
      transform(value) {
        if (value !== "auto") return { rotate: deg(value) };
        return {
          rotate: `var(--rotate-x, 0) var(--rotate-y, 0) var(--rotate-z, 0)`
        };
      }
    },
    rotateX: {
      transform(value) {
        return { "--rotate-x": deg(value) };
      }
    },
    rotateY: {
      transform(value) {
        return { "--rotate-y": deg(value) };
      }
    },
    // transform / translate
    translate: {
      transform(value) {
        if (value !== "auto") return { translate: value };
        return {
          translate: `var(--translate-x) var(--translate-y)`
        };
      }
    },
    translateX: {
      values: "spacing",
      transform: (v) => ({ "--translate-x": v })
    },
    translateY: {
      values: "spacing",
      transform: (v) => ({ "--translate-y": v })
    },
    // transition
    transition: {
      values: [
        "all",
        "common",
        "colors",
        "opacity",
        "position",
        "backgrounds",
        "size",
        "shadow",
        "transform"
      ],
      transform(value) {
        switch (value) {
          case "all":
            return createTransition("all");
          case "position":
            return createTransition(
              "left, right, top, bottom, inset-inline, inset-block"
            );
          case "colors":
            return createTransition(
              "color, background-color, border-color, text-decoration-color, fill, stroke"
            );
          case "opacity":
            return createTransition("opacity");
          case "shadow":
            return createTransition("box-shadow");
          case "transform":
            return createTransition("transform");
          case "size":
            return createTransition("width, height");
          case "backgrounds":
            return createTransition(
              "background, background-color, background-image, background-position"
            );
          case "common":
            return createTransition(
              "color, background-color, border-color, text-decoration-color, fill, stroke, opacity, box-shadow, transform, filter, backdrop-filter"
            );
          default:
            return { transition: value };
        }
      }
    },
    transitionDuration: { values: "durations" },
    transitionProperty: {
      values: {
        common: "background-color, border-color, color, fill, stroke, opacity, box-shadow, translate, transform",
        colors: "background-color, border-color, color, fill, stroke",
        size: "width, height",
        position: "left, right, top, bottom, inset-inline, inset-block",
        background: "background, background-color, background-image, background-position"
      }
    },
    transitionTimingFunction: { values: "easings" },
    // animation
    animation: { values: "animations" },
    animationDuration: { values: "durations" },
    animationDelay: { values: "durations" },
    animationTimingFunction: { values: "easings" },
    // typography
    fontFamily: { values: "fonts" },
    fontSize: { values: "fontSizes" },
    fontWeight: { values: "fontWeights" },
    lineHeight: { values: "lineHeights" },
    letterSpacing: { values: "letterSpacings" },
    textIndent: { values: "spacing" },
    truncate: {
      values: { type: "boolean" },
      transform(value) {
        if (value === true) {
          return {
            overflow: "hidden",
            textOverflow: "ellipsis",
            whiteSpace: "nowrap"
          };
        }
        return {};
      }
    },
    lineClamp: {
      transform(value) {
        if (value === "none") {
          return {
            WebkitLineClamp: "unset"
          };
        }
        return {
          overflow: "hidden",
          display: "-webkit-box",
          WebkitLineClamp: value,
          WebkitBoxOrient: "vertical",
          textWrap: "wrap"
        };
      }
    },
    // table
    borderSpacing: {
      values: (token) => ({
        ...token("spacing"),
        auto: "var(--border-spacing-x, 0) var(--border-spacing-y, 0)"
      })
    },
    borderSpacingX: {
      values: "spacing",
      transform(value) {
        return {
          "--border-spacing-x": value
        };
      }
    },
    borderSpacingY: {
      values: "spacing",
      transform(value) {
        return {
          "--border-spacing-y": value
        };
      }
    },
    // helpers
    srOnly: {
      values: { type: "boolean" },
      transform(value) {
        return srMapping[value] || {};
      }
    },
    debug: {
      values: { type: "boolean" },
      transform(value) {
        if (!value) return {};
        return {
          outline: "1px solid blue !important",
          "& > *": {
            outline: "1px solid red !important"
          }
        };
      }
    },
    caretColor: {
      values: colorValues,
      transform: createColorMixTransform("caretColor")
    },
    cursor: { values: "cursor" }
  }
});
const srMapping = {
  true: {
    position: "absolute",
    width: "1px",
    height: "1px",
    padding: "0",
    margin: "-1px",
    overflow: "hidden",
    clip: "rect(0, 0, 0, 0)",
    whiteSpace: "nowrap",
    borderWidth: "0"
  },
  false: {
    position: "static",
    width: "auto",
    height: "auto",
    padding: "0",
    margin: "0",
    overflow: "visible",
    clip: "auto",
    whiteSpace: "normal"
  }
};
function mapEntries(obj, f) {
  const result = {};
  for (const key in obj) {
    const kv = f(key, obj[key]);
    result[kv[0]] = kv[1];
  }
  return result;
}
function flatten(values, stop2) {
  const result = {};
  walkObject(
    values,
    (token, paths) => {
      if (token) {
        result[paths.join(".")] = token.value;
      }
    },
    { stop: stop2 }
  );
  return result;
}
var __defProp = Object.defineProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __publicField = (obj, key, value) => __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
function simpleHash(value) {
  if (value === null) return "null";
  if (value === void 0) return "undefined";
  const type = typeof value;
  if (type === "string") return `s:${value}`;
  if (type === "number") return `n:${value}`;
  if (type === "boolean") return `b:${value}`;
  if (type === "function") return `f:${value.name || "anonymous"}`;
  if (Array.isArray(value)) {
    return `a:[${value.map(simpleHash).join(",")}]`;
  }
  if (type === "object") {
    const keys = Object.keys(value).sort();
    return `o:{${keys.map((k) => `${k}:${simpleHash(value[k])}`).join(",")}}`;
  }
  return String(value);
}
class LRUCache {
  constructor(maxSize = 500) {
    __publicField(this, "cache", /* @__PURE__ */ new Map());
    __publicField(this, "maxSize");
    this.maxSize = maxSize;
  }
  get(key) {
    const value = this.cache.get(key);
    if (value !== void 0) {
      this.cache.delete(key);
      this.cache.set(key, value);
    }
    return value;
  }
  set(key, value) {
    if (this.cache.has(key)) {
      this.cache.delete(key);
    } else if (this.cache.size >= this.maxSize) {
      const firstKey = this.cache.keys().next().value;
      if (firstKey !== void 0) {
        this.cache.delete(firstKey);
      }
    }
    this.cache.set(key, value);
  }
  clear() {
    this.cache.clear();
  }
}
const memo = (fn) => {
  const cache2 = new LRUCache();
  function get(...args) {
    const key = args.length === 1 ? simpleHash(args[0]) : args.map(simpleHash).join("|");
    let result = cache2.get(key);
    if (result === void 0) {
      result = fn.apply(this, args);
      cache2.set(key, result);
    }
    return result;
  }
  return get;
};
const BASE_FONT_SIZE = 16;
const UNIT_PX = "px";
const UNIT_EM = "em";
const UNIT_REM = "rem";
function getUnit(value = "") {
  const DIGIT_REGEX = new RegExp(String.raw`-?\d+(?:\.\d+|\d*)`);
  const UNIT_REGEX = new RegExp(`${UNIT_PX}|${UNIT_EM}|${UNIT_REM}`);
  const unit = value.match(
    new RegExp(`${DIGIT_REGEX.source}(${UNIT_REGEX.source})`)
  );
  return unit?.[1];
}
function toPx(value = "") {
  if (typeof value === "number") {
    return `${value}px`;
  }
  const unit = getUnit(value);
  if (!unit) return value;
  if (unit === UNIT_PX) {
    return value;
  }
  if (unit === UNIT_EM || unit === UNIT_REM) {
    return `${parseFloat(value) * BASE_FONT_SIZE}${UNIT_PX}`;
  }
}
function toRem(value = "") {
  const unit = getUnit(value);
  if (!unit) return value;
  if (unit === UNIT_REM) {
    return value;
  }
  if (unit === UNIT_EM) {
    return `${parseFloat(value)}${UNIT_REM}`;
  }
  if (unit === UNIT_PX) {
    return `${parseFloat(value) / BASE_FONT_SIZE}${UNIT_REM}`;
  }
}
const capitalize = (str) => str.charAt(0).toUpperCase() + str.slice(1);
function createBreakpoints(breakpoints2) {
  const sorted = sort(breakpoints2);
  const values = Object.fromEntries(sorted);
  function get(name) {
    return values[name];
  }
  function only(name) {
    return build(get(name));
  }
  function getRanges() {
    const breakpoints22 = Object.keys(values);
    const permuations = getPermutations(breakpoints22);
    const results = breakpoints22.flatMap((name) => {
      const value = get(name);
      const down2 = [
        `${name}Down`,
        build({ max: adjust(value.min) })
      ];
      const up2 = [name, build({ min: value.min })];
      const _only = [`${name}Only`, only(name)];
      return [up2, _only, down2];
    }).filter(([, value]) => value !== "").concat(
      permuations.map(([min, max]) => {
        const minValue = get(min);
        const maxValue2 = get(max);
        return [
          `${min}To${capitalize(max)}`,
          build({ min: minValue.min, max: adjust(maxValue2.min) })
        ];
      })
    );
    return Object.fromEntries(results);
  }
  function toConditions() {
    const ranges = getRanges();
    return Object.fromEntries(Object.entries(ranges));
  }
  const conditions = toConditions();
  const getCondition = (key) => {
    return conditions[key];
  };
  function keys() {
    return uniq(["base", ...Object.keys(values)]);
  }
  function up(name) {
    return build({ min: get(name).min });
  }
  function down(name) {
    return build({ max: adjust(get(name).min) });
  }
  return {
    values: Object.values(values),
    only,
    keys,
    conditions,
    getCondition,
    up,
    down
  };
}
function adjust(value) {
  const computedMax = parseFloat(toPx(value) ?? "") - 0.04;
  return toRem(`${computedMax}px`);
}
function sort(breakpoints2) {
  const entries = Object.entries(breakpoints2).sort(([, minA], [, minB]) => {
    return parseInt(minA, 10) < parseInt(minB, 10) ? -1 : 1;
  });
  return entries.map(([name, min], index, entries2) => {
    let max = null;
    if (index <= entries2.length - 1) {
      max = entries2[index + 1]?.[1];
    }
    if (max != null) {
      max = adjust(max);
    }
    return [name, { name, min: toRem(min), max }];
  });
}
function getPermutations(values) {
  const result = [];
  values.forEach((current, index) => {
    let idx = index;
    idx++;
    let next = values[idx];
    while (next) {
      result.push([current, next]);
      idx++;
      next = values[idx];
    }
  });
  return result;
}
function build({
  min,
  max
}) {
  if (min == null && max == null) return "";
  return [
    "@media screen",
    min && `(min-width: ${min})`,
    max && `(max-width: ${max})`
  ].filter(Boolean).join(" and ");
}
const SPECIAL_KEY_REGEX = /^@|&|&$/;
const createConditions = (options) => {
  const { breakpoints: breakpoints2, conditions: conds = {} } = options;
  const conditions = mapEntries(conds, (key, value) => [`_${key}`, value]);
  const values = Object.assign({}, conditions, breakpoints2.conditions);
  function keys() {
    return Object.keys(values);
  }
  function has(key) {
    return keys().includes(key) || SPECIAL_KEY_REGEX.test(key) || key.startsWith("_");
  }
  const sort2 = memo((paths) => {
    return paths.filter((v) => v !== "base").sort((a, b) => {
      const aa = has(a);
      const bb = has(b);
      if (aa && !bb) return 1;
      if (!aa && bb) return -1;
      return 0;
    });
  });
  function expandAtRule(key) {
    if (!key.startsWith("@breakpoint")) return key;
    return breakpoints2.getCondition(key.replace("@breakpoint ", ""));
  }
  function resolve(key) {
    return Reflect.get(values, key) || key;
  }
  return {
    keys,
    sort: sort2,
    has,
    resolve,
    breakpoints: breakpoints2.keys(),
    expandAtRule
  };
};
const EMPTY_OBJECT = Object.freeze(/* @__PURE__ */ Object.create(null));
const EMPTY_ARRAY = Object.freeze([]);
function createEmptyObject() {
  return /* @__PURE__ */ Object.create(null);
}
const createMediaQueryRegex = (dimension) => ({
  minMax: new RegExp(
    `(!?\\(\\s*min(-device-)?-${dimension})(.|
)+\\(\\s*max(-device)?-${dimension}`,
    "i"
  ),
  min: new RegExp(`\\(\\s*min(-device)?-${dimension}`, "i"),
  maxMin: new RegExp(
    `(!?\\(\\s*max(-device)?-${dimension})(.|
)+\\(\\s*min(-device)?-${dimension}`,
    "i"
  ),
  max: new RegExp(`\\(\\s*max(-device)?-${dimension}`, "i")
});
const widthRegex = createMediaQueryRegex("width");
const heightRegex = createMediaQueryRegex("height");
const createQueryTester = (regexSet) => ({
  isMin: _testQuery(regexSet.minMax, regexSet.maxMin, regexSet.min),
  isMax: _testQuery(regexSet.maxMin, regexSet.minMax, regexSet.max)
});
const { isMin: isMinWidth, isMax: isMaxWidth } = createQueryTester(widthRegex);
const { isMin: isMinHeight, isMax: isMaxHeight } = createQueryTester(heightRegex);
const isPrint = /print/i;
const isPrintOnly = /^print$/i;
const isLength = /(-?\d*\.?\d+)(ch|em|ex|px|rem)/;
const lengthExec = /(\d)/;
const maxValue = Number.MAX_VALUE;
const multipliers = { ch: 8.8984375, em: 16, rem: 16, ex: 8.296875, px: 1 };
function getQueryLength(query) {
  const length = isLength.exec(query) || (isMinWidth(query) || isMinHeight(query) ? lengthExec.exec(query) : null);
  if (!length) return maxValue;
  if (length[0] === "0") return 0;
  const number = parseFloat(length[1]);
  const unit = length[2];
  return number * (multipliers[unit] || 1);
}
function _testQuery(doubleTestTrue, doubleTestFalse, singleTest) {
  return (query) => doubleTestTrue.test(query) || !doubleTestFalse.test(query) && singleTest.test(query);
}
function _testIsPrint(a, b) {
  const isPrintA = isPrint.test(a), isPrintOnlyA = isPrintOnly.test(a);
  const isPrintB = isPrint.test(b), isPrintOnlyB = isPrintOnly.test(b);
  if (isPrintA && isPrintB) {
    if (!isPrintOnlyA && isPrintOnlyB) return 1;
    if (isPrintOnlyA && !isPrintOnlyB) return -1;
    return a.localeCompare(b);
  }
  return isPrintA ? 1 : isPrintB ? -1 : null;
}
const sortAtParams = memo((a, b) => {
  const testIsPrint = _testIsPrint(a, b);
  if (testIsPrint !== null) return testIsPrint;
  const minA = isMinWidth(a) || isMinHeight(a), maxA = isMaxWidth(a) || isMaxHeight(a);
  const minB = isMinWidth(b) || isMinHeight(b), maxB = isMaxWidth(b) || isMaxHeight(b);
  if (minA && maxB) return -1;
  if (maxA && minB) return 1;
  const lengthA = getQueryLength(a), lengthB = getQueryLength(b);
  if (lengthA === maxValue && lengthB === maxValue) return a.localeCompare(b);
  if (lengthA === maxValue) return 1;
  if (lengthB === maxValue) return -1;
  if (lengthA !== lengthB) {
    return lengthA > lengthB ? maxA ? -1 : 1 : maxA ? 1 : -1;
  }
  return a.localeCompare(b);
});
function sortQueries(queries) {
  return queries.sort(([a], [b]) => sortAtParams(a, b));
}
function sortAtRules(obj) {
  const mediaQueries = [];
  const containerQueries = [];
  const rest = {};
  for (const [key, value] of Object.entries(obj)) {
    if (key.startsWith("@media")) {
      mediaQueries.push([key, value]);
    } else if (key.startsWith("@container")) {
      containerQueries.push([key, value]);
    } else if (isObject(value)) {
      rest[key] = sortAtRules(value);
    } else {
      rest[key] = value;
    }
  }
  const sortedMediaQueries = sortQueries(mediaQueries);
  const sortedContainerQueries = sortQueries(containerQueries);
  return {
    ...rest,
    ...Object.fromEntries(sortedMediaQueries),
    ...Object.fromEntries(sortedContainerQueries)
  };
}
const importantRegex = /\s*!(important)?/i;
const isImportant = memo(
  (v) => isString(v) ? importantRegex.test(v) : false
);
const withoutImportant = memo(
  (v) => isString(v) ? v.replace(importantRegex, "").trim() : v
);
function createCssFn(context) {
  const { transform, conditions, normalize: normalize2 } = context;
  const mergeFn = mergeCss(context);
  return memo(function cssFn(...styleArgs) {
    const styles = mergeFn(...styleArgs);
    const normalized = normalize2(styles);
    const result = createEmptyObject();
    walkObject(normalized, (value, paths) => {
      if (value == null) return;
      const [prop, ...selectors] = conditions.sort(paths).map(conditions.resolve);
      const important = isImportant(value);
      if (important) {
        value = withoutImportant(value);
      }
      let transformed = transform(prop, value) ?? EMPTY_OBJECT;
      transformed = walkObject(
        transformed,
        (v) => isString(v) && important ? `${v} !important` : v,
        { getKey: (prop2) => conditions.expandAtRule(prop2) }
      );
      mergeByPath(result, selectors.flat(), transformed);
    });
    return sortAtRules(result);
  });
}
function mergeByPath(target, paths, value) {
  let acc = target;
  for (const path of paths) {
    if (!path) continue;
    if (!acc[path]) acc[path] = createEmptyObject();
    acc = acc[path];
  }
  mergeWith(acc, value);
}
function compactFn(...styles) {
  return styles.filter((style) => {
    if (!isObject(style)) return false;
    const compacted = compact(style);
    const keys = Object.keys(compacted);
    return keys.length > 0;
  });
}
function mergeCss(ctx) {
  function resolve(styles) {
    const comp = compactFn(...styles);
    if (comp.length === 1) return comp;
    return comp.map((style) => ctx.normalize(style));
  }
  return memo(function mergeFn(...styles) {
    return mergeWith({}, ...resolve(styles));
  });
}
const defaults = (conf) => ({
  base: EMPTY_OBJECT,
  variants: EMPTY_OBJECT,
  defaultVariants: EMPTY_OBJECT,
  compoundVariants: [],
  ...conf
});
function createRecipeFn(options) {
  const { css, conditions, normalize: normalize2, layers } = options;
  function cva(config = {}) {
    const defaultsConfig = defaults(config);
    const { base, defaultVariants: defaultVariants2, compoundVariants } = defaultsConfig;
    const variants2 = mapEntries(defaultsConfig.variants, (key, obj) => [
      key,
      mapEntries(obj, (optionKey, styles) => [optionKey, normalize2(styles)])
    ]);
    const getVariantCss = createCssFn({
      conditions,
      normalize: normalize2,
      transform(prop, value) {
        return variants2[prop]?.[value];
      }
    });
    const resolve = (props = {}) => {
      const variantSelections = normalize2({
        ...defaultVariants2,
        ...compact(props)
      });
      let variantCss = { ...normalize2(base) };
      mergeWith(variantCss, getVariantCss(variantSelections));
      const compoundVariantCss = getCompoundVariantCss(
        compoundVariants,
        variantSelections
      );
      return layers.wrap("recipes", css(variantCss, compoundVariantCss));
    };
    const variantKeys = Object.keys(variants2);
    const splitVariantProps = (props) => {
      const restProps = omit(props, ["recipe"]);
      const [recipeProps, localProps] = splitProps(restProps, variantKeys);
      const hasColorPalette = variantKeys.includes("colorPalette");
      const hasOrientation = variantKeys.includes("orientation");
      if (!hasColorPalette) {
        recipeProps.colorPalette = props.colorPalette || defaultVariants2.colorPalette;
      }
      if (hasOrientation) {
        localProps.orientation = props.orientation;
      }
      return [recipeProps, localProps];
    };
    const variantMap = mapEntries(variants2, (key, value) => [
      key,
      Object.keys(value)
    ]);
    const cvaFn = (props) => css(resolve(props));
    return Object.assign(cvaFn, {
      className: config.className,
      __cva__: true,
      variantMap,
      variantKeys,
      raw: resolve,
      config,
      splitVariantProps,
      merge(other) {
        return cva(mergeCva(options)(this, other));
      }
    });
  }
  function getCompoundVariantCss(cvs, vm) {
    let result = EMPTY_OBJECT;
    cvs.forEach((cv) => {
      const isMatching = Object.entries(cv).every(([key, value]) => {
        if (key === "css") return true;
        const values = Array.isArray(value) ? value : [value];
        return values.some((value2) => vm[key] === value2);
      });
      if (isMatching) {
        result = css(result, cv.css);
      }
    });
    return result;
  }
  return cva;
}
function mergeCva(opts) {
  const { css } = opts;
  return function mergeCva2(cvaA, cvaB) {
    const override = defaults(cvaB.config);
    const variantKeys = uniq(cvaA.variantKeys, Object.keys(cvaB.variants));
    const base = css(cvaA.base, override.base);
    const variants2 = Object.fromEntries(
      variantKeys.map((key) => [
        key,
        css(cvaA.config.variants[key], override.variants[key])
      ])
    );
    const defaultVariants2 = mergeWith(
      cvaA.config.defaultVariants,
      override.defaultVariants
    );
    const compoundVariants = [
      ...cvaA.compoundVariants,
      ...override.compoundVariants
    ];
    const className = cx(cvaA.className, cvaB.className);
    return {
      className,
      base,
      variants: variants2,
      defaultVariants: defaultVariants2,
      compoundVariants
    };
  };
}
const defaultLayers = {
  reset: "reset",
  base: "base",
  tokens: "tokens",
  recipes: "recipes"
};
const layerOrder = {
  reset: 0,
  base: 1,
  tokens: 2,
  recipes: 3
};
function createLayers(config) {
  const layers = config.layers ?? defaultLayers;
  const values = Object.values(layers);
  const names = values.sort((a, b) => layerOrder[a] - layerOrder[b]);
  return {
    names,
    atRule: `@layer ${names.join(", ")};`,
    wrap(layer, styles) {
      if (config.disableLayers) return styles;
      const params = layers[layer];
      return { [`@layer ${params}`]: styles };
    }
  };
}
function createNormalizeFn(context) {
  const { utility, normalize: normalize2 } = context;
  const { hasShorthand, resolveShorthand } = utility;
  return function(styles) {
    return walkObject(styles, normalize2, {
      stop: (value) => Array.isArray(value),
      getKey: hasShorthand ? resolveShorthand : void 0
    });
  };
}
function createPreflight(options) {
  const { preflight } = options;
  if (!preflight) return {};
  const { scope = "", level = "parent" } = isObject(preflight) ? preflight : {};
  let selector = "";
  if (scope && level === "parent") {
    selector = `${scope} `;
  } else if (scope && level === "element") {
    selector = `&${scope}`;
  }
  const scoped = {
    "*": {
      margin: "0px",
      padding: "0px",
      font: "inherit",
      wordWrap: "break-word",
      WebkitTapHighlightColor: "transparent"
    },
    "*, *::before, *::after, *::backdrop": {
      boxSizing: "border-box",
      borderWidth: "0px",
      borderStyle: "solid",
      borderColor: "var(--global-color-border, currentColor)"
    },
    hr: {
      height: "0px",
      color: "inherit",
      borderTopWidth: "1px"
    },
    body: {
      minHeight: "100dvh",
      position: "relative"
    },
    img: {
      borderStyle: "none"
    },
    "img, svg, video, canvas, audio, iframe, embed, object": {
      display: "block",
      verticalAlign: "middle"
    },
    iframe: { border: "none" },
    "img, video": { maxWidth: "100%", height: "auto" },
    "p, h1, h2, h3, h4, h5, h6": { overflowWrap: "break-word" },
    "ol, ul": { listStyle: "none" },
    "code, kbd, pre, samp": { fontSize: "1em" },
    "button, [type='button'], [type='reset'], [type='submit']": {
      WebkitAppearance: "button",
      backgroundColor: "transparent",
      backgroundImage: "none"
    },
    "button, input, optgroup, select, textarea": { color: "inherit" },
    "button, select": { textTransform: "none" },
    table: {
      textIndent: "0px",
      borderColor: "inherit",
      borderCollapse: "collapse"
    },
    "*::placeholder": {
      opacity: "unset",
      color: "#9ca3af",
      userSelect: "none"
    },
    textarea: {
      resize: "vertical"
    },
    summary: {
      display: "list-item"
    },
    small: {
      fontSize: "80%"
    },
    "sub, sup": {
      fontSize: "75%",
      lineHeight: 0,
      position: "relative",
      verticalAlign: "baseline"
    },
    sub: {
      bottom: "-0.25em"
    },
    sup: {
      top: "-0.5em"
    },
    dialog: {
      padding: "0px"
    },
    a: {
      color: "inherit",
      textDecoration: "inherit"
    },
    "abbr:where([title])": {
      textDecoration: "underline dotted"
    },
    "b, strong": {
      fontWeight: "bolder"
    },
    "code, kbd, samp, pre": {
      fontSize: "1em",
      "--font-mono-fallback": "ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, 'Liberation Mono', 'Courier New'",
      fontFamily: "var(--global-font-mono, var(--font-mono-fallback))"
    },
    'input[type="text"], input[type="email"], input[type="search"], input[type="password"]': {
      WebkitAppearance: "none",
      MozAppearance: "none"
    },
    "input[type='search']": {
      WebkitAppearance: "textfield",
      outlineOffset: "-2px"
    },
    "::-webkit-search-decoration, ::-webkit-search-cancel-button": {
      WebkitAppearance: "none"
    },
    "::-webkit-file-upload-button": {
      WebkitAppearance: "button",
      font: "inherit"
    },
    'input[type="number"]::-webkit-inner-spin-button, input[type="number"]::-webkit-outer-spin-button': {
      height: "auto"
    },
    "input[type='number']": {
      MozAppearance: "textfield"
    },
    ":-moz-ui-invalid": {
      boxShadow: "none"
    },
    ":-moz-focusring": {
      outline: "auto"
    },
    "[hidden]:where(:not([hidden='until-found']))": {
      display: "none !important"
    }
  };
  const preflightCss = {
    [scope || "html"]: {
      lineHeight: 1.5,
      "--font-fallback": "ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, 'Noto Sans', sans-serif, 'Apple Color Emoji', 'Segoe UI Emoji', 'Segoe UI Symbol', 'Noto Color Emoji'",
      WebkitTextSizeAdjust: "100%",
      WebkitFontSmoothing: "antialiased",
      MozOsxFontSmoothing: "grayscale",
      textRendering: "optimizeLegibility",
      touchAction: "manipulation",
      MozTabSize: "4",
      tabSize: "4",
      fontFamily: "var(--global-font-body, var(--font-fallback))"
    }
  };
  if (level === "element") {
    const modified = Object.entries(scoped).reduce((acc, [k, v]) => {
      acc[k] = { [selector]: v };
      return acc;
    }, {});
    Object.assign(preflightCss, modified);
  } else if (selector) {
    preflightCss[selector] = scoped;
  } else {
    Object.assign(preflightCss, scoped);
  }
  return preflightCss;
}
function createSerializeFn(options) {
  const { conditions, isValidProperty } = options;
  return function serialize(styles) {
    return walkObject(styles, (value) => value, {
      getKey: (prop, value) => {
        if (!isObject(value)) return prop;
        if (!conditions.has(prop) && !isValidProperty(prop)) {
          return parseSelectors(prop).map((s) => {
            const selector = s.startsWith("&") ? s.slice(1) : s;
            return isTopLevelSelector(selector) ? `${selector} &` : `&${selector}`;
          }).join(", ");
        }
        return prop;
      }
    });
  };
}
function isTopLevelSelector(s) {
  const lower = s.toLowerCase();
  return lower.startsWith(":host-context") || lower.startsWith(":host") || lower.startsWith("::slotted");
}
function parseSelectors(selector) {
  const result = [];
  let parenCount = 0;
  let currentSelector = "";
  let inEscape = false;
  for (let i = 0; i < selector.length; i++) {
    const char = selector[i];
    if (char === "\\" && !inEscape) {
      inEscape = true;
      currentSelector += char;
      continue;
    }
    if (inEscape) {
      inEscape = false;
      currentSelector += char;
      continue;
    }
    if (char === "(") {
      parenCount++;
    } else if (char === ")") {
      parenCount--;
    }
    if (char === "," && parenCount === 0) {
      result.push(currentSelector.trim());
      currentSelector = "";
    } else {
      currentSelector += char;
    }
  }
  if (currentSelector) {
    result.push(currentSelector.trim());
  }
  return result;
}
const getSlotRecipes = (config = EMPTY_OBJECT) => {
  const init = (slot) => ({
    base: config.base?.[slot] ?? EMPTY_OBJECT,
    variants: createEmptyObject(),
    defaultVariants: config.defaultVariants ?? EMPTY_OBJECT,
    compoundVariants: config.compoundVariants ? getSlotCompoundVariant(config.compoundVariants, slot) : EMPTY_ARRAY
  });
  const slots = config.slots ?? [];
  const entries = slots.map((slot) => [slot, init(slot)]);
  for (const [variantsKey, variantsSpec] of Object.entries(
    config.variants ?? {}
  )) {
    for (const [variantKey, variantSpec] of Object.entries(
      variantsSpec
    )) {
      entries.forEach(([slot, slotRecipe]) => {
        var _a;
        (_a = slotRecipe.variants)[variantsKey] ?? (_a[variantsKey] = {});
        slotRecipe.variants[variantsKey][variantKey] = variantSpec[slot] ?? EMPTY_OBJECT;
      });
    }
  }
  return Object.fromEntries(entries);
};
const getSlotCompoundVariant = (compoundVariants, slotName) => compoundVariants.filter((compoundVariant) => compoundVariant.css[slotName]).map((compoundVariant) => ({
  ...compoundVariant,
  css: compoundVariant.css[slotName]
}));
function createSlotRecipeFn(options) {
  const { cva } = options;
  return function sva(config = EMPTY_OBJECT) {
    const slots = Object.entries(getSlotRecipes(config)).map(
      ([slot, slotCva]) => [slot, cva(slotCva)]
    );
    function svaFn(props) {
      const result = slots.map(([slot, cvaFn]) => [slot, cvaFn(props)]);
      return Object.fromEntries(result);
    }
    const variants2 = config.variants ?? EMPTY_OBJECT;
    const variantKeys = Object.keys(variants2);
    function splitVariantProps(props) {
      const restProps = omit(props, ["recipe"]);
      const [recipeProps, localProps] = splitProps(restProps, variantKeys);
      const hasColorPalette = variantKeys.includes("colorPalette");
      const hasOrientation = variantKeys.includes("orientation");
      if (!hasColorPalette) {
        recipeProps.colorPalette = props.colorPalette || config.defaultVariants?.colorPalette;
      }
      if (hasOrientation) {
        localProps.orientation = props.orientation;
      }
      return [recipeProps, localProps];
    }
    const variantMap = mapEntries(variants2, (key, value) => [
      key,
      Object.keys(value)
    ]);
    let classNameMap = {};
    if (config.className) {
      classNameMap = Object.fromEntries(
        config.slots.map((slot) => [
          slot,
          `${config.className}__${slot}`
        ])
      );
    }
    return Object.assign(svaFn, {
      variantMap,
      variantKeys,
      splitVariantProps,
      classNameMap
    });
  };
}
const createProps = () => (props) => Array.from(new Set(props));
const rcssescape = /([\0-\x1f\x7f]|^-?\d)|^-$|^-|[^\x80-\uFFFF\w-]/g;
const fcssescape = function(ch, asCodePoint) {
  if (!asCodePoint) return "\\" + ch;
  if (ch === "\0") return "�";
  if (ch === "-" && ch.length === 1) return "\\-";
  return ch.slice(0, -1) + "\\" + ch.charCodeAt(ch.length - 1).toString(16);
};
const esc = (sel) => {
  return (sel + "").replace(rcssescape, fcssescape);
};
const expandTokenReferences = (str, resolve) => {
  let expanded = "";
  let index = 0;
  let state = "char";
  let tokenPath = "";
  let fallback2 = "";
  const currentStates = [];
  while (index < str.length) {
    const char = str[index];
    if (char === "{") {
      const endIndex = str.indexOf("}", index);
      if (endIndex === -1) {
        break;
      }
      const path = str.slice(index + 1, endIndex);
      const resolved = resolve(path);
      expanded += resolved ?? path;
      index = endIndex + 1;
      continue;
    }
    if (state === "token") {
      if (char === ",") {
        if (str[index] === "") {
          index++;
        }
        state = "fallback";
        currentStates.push(state);
        const resolved = resolve(tokenPath);
        if (resolved?.endsWith(")")) {
          expanded += resolved.slice(0, -1);
        }
        tokenPath = "";
        fallback2 = "";
        continue;
      }
    }
    if (state === "fallback") {
      const nextFallback = fallback2 + char;
      if (nextFallback === ", var(") {
        const innerEndIndex = cssVarParser(str.slice(index + 1));
        const endIndex = innerEndIndex + index + 1;
        const cssVar2 = str.slice(index + 1, endIndex);
        if (endIndex === -1) {
          break;
        }
        expanded += ", var(" + cssVar2 + ")";
        index = endIndex + 1;
        state = currentStates.pop() ?? state;
        fallback2 = "";
        continue;
      }
    }
    if (state === "token" || state === "fallback") {
      index++;
      if (char === ")") {
        state = currentStates.pop() ?? state ?? "char";
        fallback2 += char;
        const resolved = tokenPath ? resolve(tokenPath) ?? esc(tokenPath) : tokenPath;
        if (fallback2) {
          fallback2 = fallback2.slice(1).trim();
          if (!fallback2.startsWith("token(") && fallback2.endsWith(")")) {
            fallback2 = fallback2.slice(0, -1);
          }
          if (fallback2.includes("token(")) {
            const parsed = expandTokenReferences(fallback2, resolve);
            if (parsed) {
              fallback2 = parsed.slice(0, -1);
            }
          } else if (fallback2) {
            const resolvedFallback = resolve(fallback2);
            if (resolvedFallback) {
              fallback2 = resolvedFallback;
            }
          }
        }
        const lastChar = expanded.at(-1);
        if (fallback2) {
          if (lastChar?.trim()) {
            expanded += resolved.slice(0, -1) + (", " + fallback2 + ")");
          } else {
            expanded += fallback2;
          }
        } else {
          expanded += resolved || ")";
        }
        tokenPath = "";
        fallback2 = "";
        state = "char";
        continue;
      }
      if (state === "token") {
        tokenPath += char;
      }
      if (state === "fallback") {
        fallback2 += char;
      }
      continue;
    }
    const tokenIndex = str.indexOf("token(", index);
    if (tokenIndex !== -1) {
      const innerTokenIndex = tokenIndex + "token(".length;
      expanded += str.slice(index, tokenIndex);
      index = innerTokenIndex;
      state = "token";
      currentStates.push(state);
      continue;
    }
    expanded += char;
    index++;
  }
  return expanded;
};
const cssVarParser = (str) => {
  let index = 0;
  const openedParenthesises = ["("];
  while (index < str.length) {
    const char = str[index];
    if (char === "(") {
      openedParenthesises.push(char);
    } else if (char === ")") {
      openedParenthesises.pop();
      if (openedParenthesises.length === 0) {
        return index;
      }
    }
    index++;
  }
  return index;
};
function mapToJson(map) {
  const obj = {};
  map.forEach((value, key) => {
    if (value instanceof Map) {
      obj[key] = Object.fromEntries(value);
    } else {
      obj[key] = value;
    }
  });
  return obj;
}
const REFERENCE_REGEX = /({([^}]*)})/g;
const CURLY_REGEX = /[{}]/g;
const TOKEN_PATH_REGEX = /\w+\.\w+/;
const getReferences = (value) => {
  if (!isString(value)) return [];
  const matches = value.match(REFERENCE_REGEX);
  if (!matches) return [];
  return matches.map((match) => match.replace(CURLY_REGEX, "").trim());
};
const hasReference = (value) => REFERENCE_REGEX.test(value);
function expandReferences(token) {
  if (!token.extensions?.references) {
    return token.extensions?.cssVar?.ref ?? token.value;
  }
  const references = token.extensions.references ?? {};
  let valueStr = token.value;
  const keys = Object.keys(references);
  for (let i = 0; i < keys.length; i++) {
    const key = keys[i];
    const referenceToken = references[key];
    if (referenceToken.extensions.conditions) {
      continue;
    }
    const value = expandReferences(referenceToken);
    valueStr = valueStr.replace(`{${key}}`, value);
  }
  token.value = valueStr;
  delete token.extensions.references;
  return token.value;
}
const CALC_REGEX = /calc/g;
function resolveReference(operand) {
  if (isObject(operand) && operand.reference) {
    return operand.reference;
  }
  return String(operand);
}
const toExpression = (operator, ...operands) => operands.map(resolveReference).join(` ${operator} `).replace(CALC_REGEX, "");
const add = (...operands) => `calc(${toExpression("+", ...operands)})`;
const subtract = (...operands) => `calc(${toExpression("-", ...operands)})`;
const multiply = (...operands) => `calc(${toExpression("*", ...operands)})`;
const divide = (...operands) => `calc(${toExpression("/", ...operands)})`;
const negate = (x) => {
  const value = resolveReference(x);
  if (value != null && !Number.isNaN(parseFloat(value))) {
    return String(value).startsWith("-") ? String(value).slice(1) : `-${value}`;
  }
  return multiply(value, -1);
};
const calc = Object.assign(
  (x) => ({
    add: (...operands) => calc(add(x, ...operands)),
    subtract: (...operands) => calc(subtract(x, ...operands)),
    multiply: (...operands) => calc(multiply(x, ...operands)),
    divide: (...operands) => calc(divide(x, ...operands)),
    negate: () => calc(negate(x)),
    toString: () => x.toString()
  }),
  {
    add,
    subtract,
    multiply,
    divide,
    negate
  }
);
const addNegativeTokens = {
  enforce: "pre",
  transform(dictionary) {
    const { prefix, allTokens, formatCssVar, formatTokenName, registerToken } = dictionary;
    const tokens2 = allTokens.filter(
      ({ extensions }) => extensions.category === "spacing"
    );
    tokens2.forEach((token) => {
      const originalPath = token.path.slice();
      const originalVar = formatCssVar(originalPath, prefix);
      if (isString(token.value) && token.value === "0rem") {
        return;
      }
      const newPath = [...token.path];
      const lastPath = newPath[newPath.length - 1];
      if (lastPath != null) {
        newPath[newPath.length - 1] = `-${lastPath}`;
      }
      const nextToken = {
        ...token,
        value: calc.negate(originalVar.ref),
        name: formatTokenName(newPath),
        path: newPath,
        extensions: {
          ...token.extensions,
          negative: true,
          prop: `-${token.extensions.prop}`,
          originalPath
        }
      };
      registerToken(nextToken);
    });
  }
};
const units = /* @__PURE__ */ new Set([
  "spacing",
  "sizes",
  "borderWidths",
  "fontSizes",
  "radii"
]);
const addPixelUnit = {
  enforce: "post",
  transform(dictionary) {
    const tokens2 = dictionary.allTokens.filter((token) => {
      return units.has(token.extensions.category) && !token.extensions.negative;
    });
    tokens2.forEach((token) => {
      Object.assign(token.extensions, {
        pixelValue: toPx(token.value)
      });
    });
  }
};
const addVirtualPalette = {
  enforce: "post",
  transform(dictionary) {
    const { allTokens, registerToken, formatTokenName } = dictionary;
    const tokens2 = allTokens.filter(
      ({ extensions }) => extensions.category === "colors"
    );
    const keys = /* @__PURE__ */ new Map();
    const colorPalettes = /* @__PURE__ */ new Map();
    tokens2.forEach((token) => {
      const { colorPalette } = token.extensions;
      if (!colorPalette) return;
      colorPalette.keys.forEach((keyPath) => {
        keys.set(formatTokenName(keyPath), keyPath);
      });
      colorPalette.roots.forEach((colorPaletteRoot) => {
        const name = formatTokenName(colorPaletteRoot);
        const colorPaletteList = colorPalettes.get(name) || [];
        colorPaletteList.push(token);
        colorPalettes.set(name, colorPaletteList);
        if (token.extensions.default && colorPaletteRoot.length === 1) {
          const keyPath = colorPalette.keys[0]?.filter(Boolean);
          if (!keyPath.length) return;
          const path = colorPaletteRoot.concat(keyPath);
          keys.set(formatTokenName(path), []);
        }
      });
    });
    keys.forEach((segments) => {
      const path = ["colors", "colorPalette", ...segments].filter(Boolean);
      const name = formatTokenName(path);
      const prop = formatTokenName(path.slice(1));
      const token = {
        name,
        value: name,
        originalValue: name,
        path,
        extensions: {
          condition: "base",
          originalPath: path,
          category: "colors",
          prop,
          virtual: true
        }
      };
      registerToken(token, "pre");
    });
  }
};
const removeEmptyTokens = {
  enforce: "post",
  transform(dictionary) {
    dictionary.allTokens = dictionary.allTokens.filter(
      (token) => token.value !== ""
    );
  }
};
const tokenMiddlewares = [
  addNegativeTokens,
  addVirtualPalette,
  addPixelUnit,
  removeEmptyTokens
];
const addCssVariables = {
  type: "extensions",
  enforce: "pre",
  name: "tokens/css-var",
  transform(token, dictionary) {
    const { prefix, formatCssVar } = dictionary;
    const { negative, originalPath } = token.extensions;
    const path = negative ? originalPath : token.path;
    return {
      cssVar: formatCssVar(path.filter(Boolean), prefix)
    };
  }
};
const addConditionalCssVariables = {
  enforce: "post",
  type: "value",
  name: "tokens/conditionals",
  transform(token, dictionary) {
    const { prefix, formatCssVar } = dictionary;
    const refs = getReferences(token.value);
    if (!refs.length) return token.value;
    refs.forEach((ref) => {
      const variable = formatCssVar(ref.split("."), prefix);
      token.value = token.value.replace(`{${variable.ref}}`, variable);
    });
    return token.value;
  }
};
const addColorPalette = {
  type: "extensions",
  enforce: "pre",
  name: "tokens/colors/colorPalette",
  match(token) {
    return token.extensions.category === "colors" && !token.extensions.virtual;
  },
  transform(token, dict) {
    let path = token.path.slice();
    path.pop();
    path.shift();
    if (path.length === 0) {
      const newPath = [...token.path];
      newPath.shift();
      path = newPath;
    }
    if (path.length === 0) {
      return {};
    }
    const roots = path.reduce((acc, _, i, arr) => {
      const next = arr.slice(0, i + 1);
      acc.push(next);
      return acc;
    }, []);
    const root = path[0];
    const value = dict.formatTokenName(path);
    const keys = token.path.slice(token.path.indexOf(root) + 1).reduce((acc, _, i, arr) => {
      acc.push(arr.slice(i));
      return acc;
    }, []);
    if (keys.length === 0) {
      keys.push([""]);
    }
    return {
      colorPalette: { value, roots, keys }
    };
  }
};
const tokenTransforms = [
  addCssVariables,
  addConditionalCssVariables,
  addColorPalette
];
const isToken = (value) => {
  return isObject(value) && Object.prototype.hasOwnProperty.call(value, "value");
};
function expandBreakpoints(breakpoints2) {
  if (!breakpoints2) return { breakpoints: {}, sizes: {} };
  return {
    breakpoints: mapObject(breakpoints2, (value) => ({ value })),
    sizes: mapEntries(breakpoints2, (key, value) => [
      `breakpoint-${key}`,
      { value }
    ])
  };
}
function createTokenDictionary(options) {
  const {
    prefix = "",
    tokens: tokens2 = {},
    semanticTokens: semanticTokens2 = {},
    breakpoints: breakpoints2 = {}
  } = options;
  const formatTokenName = (path) => path.join(".");
  const formatCssVar = (path, prefix2) => cssVar(path.join("-"), { prefix: prefix2 });
  const allTokens = [];
  const tokenNameMap = /* @__PURE__ */ new Map();
  const conditionMap = /* @__PURE__ */ new Map();
  const cssVarMap = /* @__PURE__ */ new Map();
  const colorPaletteMap = /* @__PURE__ */ new Map();
  const flatMap = /* @__PURE__ */ new Map();
  const byCategory = /* @__PURE__ */ new Map();
  const categoryMap = /* @__PURE__ */ new Map();
  const transforms = /* @__PURE__ */ new Map();
  const middlewares = [];
  function registerToken(token, phase) {
    allTokens.push(token);
    tokenNameMap.set(token.name, token);
    if (phase) {
      transforms.forEach((fn) => {
        if (fn.enforce === phase) transformToken(fn, token);
      });
    }
  }
  const breakpointTokens = expandBreakpoints(breakpoints2);
  const computedTokens = compact({
    ...tokens2,
    breakpoints: breakpointTokens.breakpoints,
    sizes: {
      ...tokens2.sizes,
      ...breakpointTokens.sizes
    }
  });
  function registerTokens() {
    walkObject(
      computedTokens,
      (entry, path) => {
        const isDefault = path.includes("DEFAULT");
        path = filterDefault(path);
        const category = path[0];
        const name = formatTokenName(path);
        const t = isString(entry) ? { value: entry } : entry;
        const token = {
          value: t.value,
          originalValue: t.value,
          name,
          path,
          extensions: {
            condition: "base",
            originalPath: path,
            category,
            prop: formatTokenName(path.slice(1))
          }
        };
        if (isDefault) {
          token.extensions.default = true;
        }
        registerToken(token);
      },
      { stop: isToken }
    );
    walkObject(
      semanticTokens2,
      (entry, path) => {
        const isDefault = path.includes("DEFAULT");
        path = filterBaseCondition(filterDefault(path));
        const category = path[0];
        const name = formatTokenName(path);
        const t = isString(entry.value) ? { value: { base: entry.value } } : entry;
        const token = {
          value: t.value.base || "",
          originalValue: t.value.base || "",
          name,
          path,
          extensions: {
            originalPath: path,
            category,
            conditions: t.value,
            condition: "base",
            prop: formatTokenName(path.slice(1))
          }
        };
        if (isDefault) {
          token.extensions.default = true;
        }
        registerToken(token);
      },
      { stop: isToken }
    );
  }
  function getByName(name) {
    return tokenNameMap.get(name);
  }
  function buildConditionMap(token) {
    const { condition } = token.extensions;
    if (!condition) return;
    if (!conditionMap.has(condition)) {
      conditionMap.set(condition, /* @__PURE__ */ new Set());
    }
    conditionMap.get(condition).add(token);
  }
  function buildCategoryMap(token) {
    const { category, prop } = token.extensions;
    if (!category) return;
    if (!categoryMap.has(category)) {
      categoryMap.set(category, /* @__PURE__ */ new Map());
    }
    categoryMap.get(category).set(prop, token);
  }
  function buildCssVars(token) {
    const { condition, negative, virtual, cssVar: cssVar2 } = token.extensions;
    if (negative || virtual || !condition || !cssVar2) return;
    if (!cssVarMap.has(condition)) {
      cssVarMap.set(condition, /* @__PURE__ */ new Map());
    }
    cssVarMap.get(condition).set(cssVar2.var, token.value);
  }
  function buildFlatMap(token) {
    const { category, prop, cssVar: cssVar2, negative } = token.extensions;
    if (!category) return;
    if (!byCategory.has(category)) {
      byCategory.set(category, /* @__PURE__ */ new Map());
    }
    const value = negative ? token.extensions.conditions ? token.originalValue : token.value : cssVar2.ref;
    byCategory.get(category).set(prop, value);
    flatMap.set([category, prop].join("."), value);
  }
  function buildColorPalette(token) {
    const { colorPalette, virtual, default: isDefault } = token.extensions;
    if (!colorPalette || virtual) return;
    colorPalette.roots.forEach((root) => {
      const name = formatTokenName(root);
      if (!colorPaletteMap.has(name)) {
        colorPaletteMap.set(name, /* @__PURE__ */ new Map());
      }
      const virtualPath = replaceRootWithColorPalette(
        [...token.path],
        [...root]
      );
      const virtualName = formatTokenName(virtualPath);
      const virtualToken = getByName(virtualName);
      if (!virtualToken || !virtualToken.extensions.cssVar) return;
      const { var: virtualVar } = virtualToken.extensions.cssVar;
      colorPaletteMap.get(name).set(virtualVar, token.extensions.cssVar.ref);
      if (isDefault && root.length === 1) {
        const colorPaletteName = formatTokenName(["colors", "colorPalette"]);
        const colorPaletteToken = getByName(colorPaletteName);
        if (!colorPaletteToken) return;
        const name2 = formatTokenName(token.path);
        const virtualToken2 = getByName(name2);
        if (!virtualToken2) return;
        const keyPath = colorPalette.keys[0]?.filter(Boolean);
        if (!keyPath.length) return;
        const computedName = formatTokenName(root.concat(keyPath));
        if (!colorPaletteMap.has(computedName)) {
          colorPaletteMap.set(computedName, /* @__PURE__ */ new Map());
        }
        colorPaletteMap.get(computedName).set(
          colorPaletteToken.extensions.cssVar.var,
          virtualToken2.extensions.cssVar.ref
        );
      }
    });
  }
  let byCategoryJson = {};
  function setupViews() {
    allTokens.forEach((token) => {
      buildConditionMap(token);
      buildCategoryMap(token);
      buildCssVars(token);
      buildFlatMap(token);
      buildColorPalette(token);
    });
    byCategoryJson = mapToJson(byCategory);
  }
  const colorMix2 = (value, tokenFn) => {
    if (!value || typeof value !== "string") return { invalid: true, value };
    const [colorPath, rawOpacity] = value.split("/");
    if (!colorPath || !rawOpacity) {
      return { invalid: true, value: colorPath };
    }
    const colorToken = tokenFn(colorPath);
    const opacityToken = getByName(`opacity.${rawOpacity}`)?.value;
    if (!opacityToken && isNaN(Number(rawOpacity))) {
      return { invalid: true, value: colorPath };
    }
    const percent = opacityToken ? Number(opacityToken) * 100 + "%" : `${rawOpacity}%`;
    const color = colorToken ?? colorPath;
    return {
      invalid: false,
      color,
      value: `color-mix(in srgb, ${color} ${percent}, transparent)`
    };
  };
  const getVar = memo((value, fallback2) => {
    return flatMap.get(value) ?? fallback2;
  });
  const getCategoryValues = memo((category) => {
    return byCategoryJson[category] || null;
  });
  const expandReferenceInValue = memo((value) => {
    return expandTokenReferences(value, (path) => {
      if (!path) return;
      if (path.includes("/")) {
        const mix = colorMix2(path, (v) => getVar(v));
        if (mix.invalid) {
          throw new Error("Invalid color mix at " + path + ": " + mix.value);
        }
        return mix.value;
      }
      const resolved = getVar(path);
      if (resolved) return resolved;
      return TOKEN_PATH_REGEX.test(path) ? esc(path) : path;
    });
  });
  const dictionary = {
    prefix,
    allTokens,
    tokenMap: tokenNameMap,
    registerToken,
    getByName,
    formatTokenName,
    formatCssVar,
    flatMap,
    cssVarMap,
    categoryMap,
    colorPaletteMap,
    getVar,
    getCategoryValues,
    expandReferenceInValue
  };
  function registerTransform(...fns) {
    fns.forEach((fn) => {
      transforms.set(fn.name, fn);
    });
  }
  function registerMiddleware(...fns) {
    middlewares.push(...fns);
  }
  function transformToken(transform, token) {
    if (token.extensions.references) return;
    if (isFunction(transform.match) && !transform.match(token)) return;
    const fn = (v) => transform.transform(v, dictionary);
    const transformed = fn(token);
    switch (true) {
      case transform.type === "extensions":
        Object.assign(token.extensions, transformed);
        break;
      case transform.type === "value":
        token.value = transformed;
        break;
      default:
        token[transform.type] = transformed;
        break;
    }
  }
  function applyMiddlewares(enforce) {
    middlewares.forEach((middleware) => {
      if (middleware.enforce === enforce) {
        middleware.transform(dictionary);
      }
    });
  }
  function applyTransforms(enforce) {
    transforms.forEach((transform) => {
      if (transform.enforce === enforce) {
        allTokens.forEach((token) => {
          transformToken(transform, token);
        });
      }
    });
  }
  function addConditionalTokens() {
    allTokens.forEach((token) => {
      const tokens22 = getConditionalTokens(token);
      if (!tokens22 || tokens22.length === 0) return;
      tokens22.forEach((token2) => {
        registerToken(token2);
      });
    });
  }
  function getTokenReferences(value) {
    const refs = getReferences(value);
    const result = [];
    for (let i = 0; i < refs.length; i++) {
      const token = getByName(refs[i]);
      if (token) {
        result.push(token);
      }
    }
    return result;
  }
  function addReferences() {
    allTokens.forEach((token) => {
      if (!hasReference(token.value)) return;
      const references = getTokenReferences(token.value);
      token.extensions.references = references.reduce((acc, ref) => {
        acc[ref.name] = ref;
        return acc;
      }, {});
    });
  }
  function expandTokenReferences$1() {
    allTokens.forEach((token) => {
      expandReferences(token);
    });
  }
  function build2() {
    applyMiddlewares("pre");
    applyTransforms("pre");
    addConditionalTokens();
    addReferences();
    expandTokenReferences$1();
    applyMiddlewares("post");
    applyTransforms("post");
    setupViews();
  }
  registerTokens();
  registerTransform(...tokenTransforms);
  registerMiddleware(...tokenMiddlewares);
  build2();
  return dictionary;
}
function filterDefault(path) {
  if (path[0] === "DEFAULT") return path;
  return path.filter((item) => item !== "DEFAULT");
}
function filterBaseCondition(path) {
  return path.filter((item) => item !== "base");
}
function getConditionalTokens(token) {
  if (!token.extensions.conditions) return;
  const { conditions } = token.extensions;
  const tokens2 = [];
  walkObject(conditions, (value, path) => {
    const nextPath = filterBaseCondition(path);
    if (!nextPath.length) return;
    const nextToken = {
      ...token,
      value,
      extensions: {
        ...token.extensions,
        condition: nextPath.join(":")
      }
    };
    tokens2.push(nextToken);
  });
  return tokens2;
}
function replaceRootWithColorPalette(path, roots) {
  const startIndex = path.findIndex(
    (_, index) => roots.every(
      (rootElement, rootIndex) => path[index + rootIndex] === rootElement
    )
  );
  if (startIndex === -1) {
    return path;
  }
  path.splice(startIndex, roots.length);
  path.splice(startIndex, 0, "colorPalette");
  return path;
}
createProps()([
  "aspectRatios",
  "zIndex",
  "opacity",
  "colors",
  "fonts",
  "fontSizes",
  "fontWeights",
  "lineHeights",
  "letterSpacings",
  "sizes",
  "shadows",
  "spacing",
  "radii",
  "cursor",
  "borders",
  "borderWidths",
  "borderStyles",
  "durations",
  "easings",
  "animations",
  "blurs",
  "gradients",
  "breakpoints",
  "assets"
]);
function normalize(config) {
  return config;
}
function normalizeConfig(config) {
  return mapEntries(config, (property, propertyConfig) => [
    property,
    normalize(propertyConfig)
  ]);
}
function createUtility(options) {
  const configs = normalizeConfig(options.config);
  const tokens2 = options.tokens;
  const shorthands = /* @__PURE__ */ new Map();
  const propValues = /* @__PURE__ */ new Map();
  function register(property, config) {
    configs[property] = normalize(config);
    assignProperty(property, config);
  }
  const assignProperty = (property, config) => {
    const values = getPropertyValues(config);
    if (!values) return;
    propValues.set(property, values);
    assignPropertyType(property, config);
  };
  const assignProperties = () => {
    for (const [prop, config] of Object.entries(configs)) {
      if (!config) continue;
      assignProperty(prop, config);
    }
  };
  const assignShorthands = () => {
    for (const [property, config] of Object.entries(configs)) {
      const { shorthand } = config ?? {};
      if (!shorthand) continue;
      const values = Array.isArray(shorthand) ? shorthand : [shorthand];
      values.forEach((name) => shorthands.set(name, property));
    }
  };
  const assignColorPaletteProperty = () => {
    const values = mapToJson(tokens2.colorPaletteMap);
    register("colorPalette", {
      values: Object.keys(values),
      transform: memo((value) => values[value])
    });
  };
  const propTypes = /* @__PURE__ */ new Map();
  const assignPropertyType = (property, config) => {
    if (!config) return;
    const values = getPropertyValues(config, (key) => `type:Tokens["${key}"]`);
    if (typeof values === "object" && values.type) {
      propTypes.set(property, /* @__PURE__ */ new Set([`type:${values.type}`]));
      return;
    }
    if (values) {
      const keys2 = new Set(Object.keys(values));
      propTypes.set(property, keys2);
    }
    const set = propTypes.get(property) ?? /* @__PURE__ */ new Set();
    if (config.property) {
      propTypes.set(property, set.add(`CssProperties["${config.property}"]`));
    }
  };
  const assignPropertyTypes = () => {
    for (const [property, propertyConfig] of Object.entries(configs)) {
      if (!propertyConfig) continue;
      assignPropertyType(property, propertyConfig);
    }
  };
  const addPropertyType = (property, type) => {
    const set = propTypes.get(property) ?? /* @__PURE__ */ new Set();
    propTypes.set(property, /* @__PURE__ */ new Set([...set, ...type]));
  };
  const getTypes = () => {
    const map = /* @__PURE__ */ new Map();
    for (const [prop, values] of propTypes.entries()) {
      if (values.size === 0) {
        map.set(prop, ["string"]);
        continue;
      }
      const typeValues = Array.from(values).map((key) => {
        if (key.startsWith("CssProperties")) return key;
        if (key.startsWith("type:")) return key.replace("type:", "");
        return JSON.stringify(key);
      });
      map.set(prop, typeValues);
    }
    return map;
  };
  const getPropertyValues = (config, resolveFn) => {
    const { values } = config;
    const fn = (key) => {
      const value = resolveFn?.(key);
      return value ? { [value]: value } : void 0;
    };
    if (isString(values)) {
      return fn?.(values) ?? tokens2.getCategoryValues(values) ?? EMPTY_OBJECT;
    }
    if (Array.isArray(values)) {
      const result = {};
      for (let i = 0; i < values.length; i++) {
        result[values[i]] = values[i];
      }
      return result;
    }
    if (isFunction(values)) {
      return values(resolveFn ? fn : tokens2.getCategoryValues);
    }
    return values;
  };
  const defaultTransform = memo((prop, value) => {
    return {
      [prop]: prop.startsWith("--") ? tokens2.getVar(value, value) : value
    };
  });
  const tokenFn = Object.assign(tokens2.getVar, {
    raw: (path) => tokens2.getByName(path)
  });
  const transform = memo((prop, raw) => {
    const key = resolveShorthand(prop);
    if (isString(raw) && !raw.includes("_EMO_")) {
      raw = tokens2.expandReferenceInValue(raw);
    }
    const config = configs[key];
    if (!config) {
      return defaultTransform(key, raw);
    }
    const value = propValues.get(key)?.[raw];
    if (!config.transform) {
      return defaultTransform(prop, value ?? raw);
    }
    const _colorMix = (value2) => colorMix(value2, tokenFn);
    return config.transform(value ?? raw, {
      raw,
      token: tokenFn,
      utils: { colorMix: _colorMix }
    });
  });
  function build2() {
    assignShorthands();
    assignColorPaletteProperty();
    assignProperties();
    assignPropertyTypes();
  }
  build2();
  const hasShorthand = shorthands.size > 0;
  const resolveShorthand = memo((prop) => {
    return shorthands.get(prop) ?? prop;
  });
  const keys = () => {
    return [...Array.from(shorthands.keys()), ...Object.keys(configs)];
  };
  const instance = {
    keys,
    hasShorthand,
    transform,
    shorthands,
    resolveShorthand,
    register,
    getTypes,
    addPropertyType
  };
  return instance;
}
function createSystem(...configs) {
  const config = mergeConfigs(...configs);
  const {
    theme = {},
    utilities = {},
    globalCss: globalCss2 = {},
    cssVarsRoot: cssVarsRoot2 = ":where(:root, :host)",
    cssVarsPrefix: cssVarsPrefix2 = "chakra",
    preflight
  } = config;
  const layers = createLayers(config);
  const tokens2 = createTokenDictionary({
    breakpoints: theme.breakpoints,
    tokens: theme.tokens,
    semanticTokens: theme.semanticTokens,
    prefix: cssVarsPrefix2
  });
  const breakpoints2 = createBreakpoints(theme.breakpoints ?? EMPTY_OBJECT);
  const conditions = createConditions({
    conditions: config.conditions ?? EMPTY_OBJECT,
    breakpoints: breakpoints2
  });
  const utility = createUtility({
    config: utilities,
    tokens: tokens2
  });
  function assignComposition() {
    const { textStyles: textStyles2, layerStyles: layerStyles2, animationStyles: animationStyles2 } = theme;
    const compositions = compact({
      textStyle: textStyles2,
      layerStyle: layerStyles2,
      animationStyle: animationStyles2
    });
    for (const [key, values] of Object.entries(compositions)) {
      const flatValues = flatten(values ?? EMPTY_OBJECT, stop);
      utility.register(key, {
        values: Object.keys(flatValues),
        transform(value) {
          return css(flatValues[value]);
        }
      });
    }
  }
  assignComposition();
  utility.addPropertyType(
    "animationName",
    Object.keys(theme.keyframes ?? EMPTY_OBJECT)
  );
  const properties = /* @__PURE__ */ new Set(["css", ...utility.keys(), ...conditions.keys()]);
  const isValidProperty = memo(
    (prop) => properties.has(prop) || isCssProperty(prop)
  );
  const normalizeValue = (value) => {
    if (Array.isArray(value)) {
      const result = createEmptyObject();
      for (let index = 0; index < value.length; index++) {
        const current = value[index];
        if (current != null) {
          const key = conditions.breakpoints[index];
          result[key] = current;
        }
      }
      return result;
    }
    return value;
  };
  const normalizeFn = createNormalizeFn({
    utility,
    normalize: normalizeValue
  });
  const serialize = createSerializeFn({
    conditions,
    isValidProperty
  });
  const css = createCssFn({
    transform: utility.transform,
    conditions,
    normalize: normalizeFn
  });
  const cva = createRecipeFn({
    css,
    conditions,
    normalize: normalizeFn,
    layers
  });
  const sva = createSlotRecipeFn({ cva });
  function getTokenCss() {
    const result = {};
    for (const [key, values] of tokens2.cssVarMap.entries()) {
      const varsObj = Object.fromEntries(values);
      if (Object.keys(varsObj).length === 0) continue;
      const selector = key === "base" ? cssVarsRoot2 : conditions.resolve(key);
      const isAtRule = selector.startsWith("@");
      const cssObject = css(
        serialize({
          [selector]: isAtRule ? { [cssVarsRoot2]: varsObj } : varsObj
        })
      );
      mergeWith(result, cssObject);
    }
    return layers.wrap("tokens", result);
  }
  function getGlobalCss() {
    const keyframes2 = mapEntries(
      theme.keyframes ?? EMPTY_OBJECT,
      (key, value) => [`@keyframes ${key}`, value]
    );
    const result = Object.assign({}, keyframes2, css(serialize(globalCss2)));
    return layers.wrap("base", result);
  }
  function splitCssProps(props) {
    return splitProps(props, isValidProperty);
  }
  function getPreflightCss() {
    const result = createPreflight({ preflight });
    return layers.wrap("reset", result);
  }
  const tokenMap = getTokenMap(tokens2);
  const tokenFn = (path, fallback2) => {
    return tokenMap.get(path)?.value || fallback2;
  };
  tokenFn.var = (path, fallback2) => {
    return tokenMap.get(path)?.variable || fallback2;
  };
  function getRecipe(key, fallback2) {
    return theme.recipes?.[key] ?? fallback2;
  }
  function getSlotRecipe(key, fallback2) {
    return theme.slotRecipes?.[key] ?? fallback2;
  }
  function isRecipe(key) {
    return Object.hasOwnProperty.call(theme.recipes ?? EMPTY_OBJECT, key);
  }
  function isSlotRecipe(key) {
    return Object.hasOwnProperty.call(theme.slotRecipes ?? EMPTY_OBJECT, key);
  }
  function hasRecipe(key) {
    return isRecipe(key) || isSlotRecipe(key);
  }
  const _global = [getPreflightCss(), getGlobalCss(), getTokenCss()];
  const query = {
    layerStyles: compositionQuery(theme.layerStyles ?? EMPTY_OBJECT),
    textStyles: compositionQuery(theme.textStyles ?? EMPTY_OBJECT),
    animationStyles: compositionQuery(theme.animationStyles ?? EMPTY_OBJECT),
    tokens: semanticTokenQuery(
      tokens2,
      Object.keys(theme.tokens ?? EMPTY_OBJECT),
      (value, key) => !value.extensions.conditions && !key.includes("colorPalette")
    ),
    semanticTokens: semanticTokenQuery(
      tokens2,
      Object.keys(theme.semanticTokens ?? EMPTY_OBJECT),
      (value) => !!value.extensions.conditions
    ),
    keyframes: basicQuery(theme.keyframes ?? EMPTY_OBJECT),
    breakpoints: basicQuery(theme.breakpoints ?? EMPTY_OBJECT)
  };
  return {
    $$chakra: true,
    _config: config,
    _global,
    breakpoints: breakpoints2,
    tokens: tokens2,
    conditions,
    utility,
    token: tokenFn,
    properties,
    layers,
    isValidProperty,
    splitCssProps,
    normalizeValue,
    getTokenCss,
    getGlobalCss,
    getPreflightCss,
    css,
    cva,
    sva,
    getRecipe,
    getSlotRecipe,
    hasRecipe,
    isRecipe,
    isSlotRecipe,
    query
  };
}
function getTokenMap(tokens2) {
  const map = /* @__PURE__ */ new Map();
  tokens2.allTokens.forEach((token) => {
    const { cssVar: cssVar2, virtual, conditions } = token.extensions;
    const value = !!conditions || virtual ? cssVar2.ref : token.value;
    map.set(token.name, { value, variable: cssVar2.ref });
  });
  return map;
}
const stop = (v) => isObject(v) && "value" in v;
const compositionQuery = (dict) => ({
  list() {
    return Object.keys(flatten(dict, stop));
  },
  search(query) {
    return this.list().filter((style) => style.includes(query));
  }
});
const semanticTokenQuery = (tokens2, categoryKeys, predicate) => ({
  categoryKeys,
  list(category) {
    const map = tokens2.categoryMap.get(category);
    const entries = map ? [...map.entries()] : [];
    const result = [];
    for (let i = 0; i < entries.length; i++) {
      const [key, value] = entries[i];
      if (predicate(value, key)) {
        result.push(key);
      }
    }
    return result;
  },
  search(category, query) {
    return this.list(category).filter((style) => style.includes(query));
  }
});
const basicQuery = (dict) => ({
  list() {
    return Object.keys(dict);
  },
  search(query) {
    return this.list().filter((style) => style.includes(query));
  }
});
const breakpoints = {
  sm: "480px",
  md: "768px",
  lg: "1024px",
  xl: "1280px",
  "2xl": "1536px"
};
const empty = "var(--chakra-empty,/*!*/ /*!*/)";
const globalCss = defineGlobalStyles({
  "*": {
    fontFeatureSettings: '"cv11"',
    "--ring-inset": empty,
    "--ring-offset-width": "0px",
    "--ring-offset-color": "#fff",
    "--ring-color": "rgba(66, 153, 225, 0.6)",
    "--ring-offset-shadow": "0 0 #0000",
    "--ring-shadow": "0 0 #0000",
    ...Object.fromEntries(
      [
        "brightness",
        "contrast",
        "grayscale",
        "hue-rotate",
        "invert",
        "saturate",
        "sepia",
        "drop-shadow"
      ].map((prop) => [`--${prop}`, empty])
    ),
    ...Object.fromEntries(
      [
        "blur",
        "brightness",
        "contrast",
        "grayscale",
        "hue-rotate",
        "invert",
        "opacity",
        "saturate",
        "sepia"
      ].map((prop) => [`--backdrop-${prop}`, empty])
    ),
    "--global-font-mono": "fonts.mono",
    "--global-font-body": "fonts.body",
    "--global-color-border": "colors.border"
  },
  html: {
    color: "fg",
    bg: "bg",
    lineHeight: "1.5",
    colorPalette: "gray"
  },
  "*::placeholder, *[data-placeholder]": {
    color: "fg.muted/80"
  },
  "*::selection": {
    bg: "colorPalette.emphasized/80"
  }
});
const layerStyles = defineLayerStyles({
  // fill: some background color + color combination
  "fill.muted": {
    value: {
      background: "colorPalette.muted",
      color: "colorPalette.fg"
    }
  },
  "fill.subtle": {
    value: {
      background: "colorPalette.subtle",
      color: "colorPalette.fg"
    }
  },
  "fill.surface": {
    value: {
      background: "colorPalette.subtle",
      color: "colorPalette.fg",
      boxShadow: "0 0 0px 1px var(--shadow-color)",
      boxShadowColor: "colorPalette.muted"
    }
  },
  "fill.solid": {
    value: {
      background: "colorPalette.solid",
      color: "colorPalette.contrast"
    }
  },
  // outline: some border color + color combination
  "outline.subtle": {
    value: {
      color: "colorPalette.fg",
      boxShadow: "inset 0 0 0px 1px var(--shadow-color)",
      boxShadowColor: "colorPalette.subtle"
    }
  },
  "outline.solid": {
    value: {
      borderWidth: "1px",
      borderColor: "colorPalette.solid",
      color: "colorPalette.fg"
    }
  },
  // indicator: floating border color or left/bottom border
  "indicator.bottom": {
    value: {
      position: "relative",
      "--indicator-color-fallback": "colors.colorPalette.solid",
      _before: {
        content: `""`,
        position: "absolute",
        bottom: "var(--indicator-offset-y, 0)",
        insetInline: "var(--indicator-offset-x, 0)",
        height: "var(--indicator-thickness, 2px)",
        background: "var(--indicator-color, var(--indicator-color-fallback))"
      }
    }
  },
  "indicator.top": {
    value: {
      position: "relative",
      "--indicator-color-fallback": "colors.colorPalette.solid",
      _before: {
        content: `""`,
        position: "absolute",
        top: "var(--indicator-offset-y, 0)",
        insetInline: "var(--indicator-offset-x, 0)",
        height: "var(--indicator-thickness, 2px)",
        background: "var(--indicator-color, var(--indicator-color-fallback))"
      }
    }
  },
  "indicator.start": {
    value: {
      position: "relative",
      "--indicator-color-fallback": "colors.colorPalette.solid",
      _before: {
        content: `""`,
        position: "absolute",
        insetInlineStart: "var(--indicator-offset-x, 0)",
        insetBlock: "var(--indicator-offset-y, 0)",
        width: "var(--indicator-thickness, 2px)",
        background: "var(--indicator-color, var(--indicator-color-fallback))"
      }
    }
  },
  "indicator.end": {
    value: {
      position: "relative",
      "--indicator-color-fallback": "colors.colorPalette.solid",
      _before: {
        content: `""`,
        position: "absolute",
        insetInlineEnd: "var(--indicator-offset-x, 0)",
        insetBlock: "var(--indicator-offset-y, 0)",
        width: "var(--indicator-thickness, 2px)",
        background: "var(--indicator-color, var(--indicator-color-fallback))"
      }
    }
  },
  disabled: {
    value: {
      opacity: "0.5",
      cursor: "not-allowed"
    }
  },
  none: {
    value: {}
  }
});
const animationStyles = defineAnimationStyles({
  "slide-fade-in": {
    value: {
      transformOrigin: "var(--transform-origin)",
      "&[data-placement^=top]": {
        animationName: "slide-from-bottom, fade-in"
      },
      "&[data-placement^=bottom]": {
        animationName: "slide-from-top, fade-in"
      },
      "&[data-placement^=left]": {
        animationName: "slide-from-right, fade-in"
      },
      "&[data-placement^=right]": {
        animationName: "slide-from-left, fade-in"
      }
    }
  },
  "slide-fade-out": {
    value: {
      transformOrigin: "var(--transform-origin)",
      "&[data-placement^=top]": {
        animationName: "slide-to-bottom, fade-out"
      },
      "&[data-placement^=bottom]": {
        animationName: "slide-to-top, fade-out"
      },
      "&[data-placement^=left]": {
        animationName: "slide-to-right, fade-out"
      },
      "&[data-placement^=right]": {
        animationName: "slide-to-left, fade-out"
      }
    }
  },
  "scale-fade-in": {
    value: {
      transformOrigin: "var(--transform-origin)",
      animationName: "scale-in, fade-in"
    }
  },
  "scale-fade-out": {
    value: {
      transformOrigin: "var(--transform-origin)",
      animationName: "scale-out, fade-out"
    }
  }
});
const badgeRecipe = defineRecipe({
  className: "chakra-badge",
  base: {
    display: "inline-flex",
    alignItems: "center",
    borderRadius: "l2",
    gap: "1",
    fontWeight: "medium",
    fontVariantNumeric: "tabular-nums",
    whiteSpace: "nowrap",
    userSelect: "none"
  },
  variants: {
    variant: {
      solid: {
        bg: "colorPalette.solid",
        color: "colorPalette.contrast"
      },
      subtle: {
        bg: "colorPalette.subtle",
        color: "colorPalette.fg"
      },
      outline: {
        color: "colorPalette.fg",
        "--outline-shadow-legacy": "colors.colorPalette.muted",
        "--outline-shadow": "colors.colorPalette.border",
        shadow: "inset 0 0 0px 1px var(--shadow-color)",
        shadowColor: "var(--outline-shadow, var(--outline-shadow-legacy))"
      },
      surface: {
        bg: "colorPalette.subtle",
        color: "colorPalette.fg",
        shadow: "inset 0 0 0px 1px var(--shadow-color)",
        shadowColor: "colorPalette.muted"
      },
      plain: {
        color: "colorPalette.fg"
      }
    },
    size: {
      xs: {
        textStyle: "2xs",
        px: "1",
        minH: "4"
      },
      sm: {
        textStyle: "xs",
        px: "1.5",
        minH: "5"
      },
      md: {
        textStyle: "sm",
        px: "2",
        minH: "6"
      },
      lg: {
        textStyle: "sm",
        px: "2.5",
        minH: "7"
      }
    }
  },
  defaultVariants: {
    variant: "subtle",
    size: "sm"
  }
});
const buttonRecipe = defineRecipe({
  className: "chakra-button",
  base: {
    display: "inline-flex",
    appearance: "none",
    alignItems: "center",
    justifyContent: "center",
    userSelect: "none",
    position: "relative",
    borderRadius: "l2",
    whiteSpace: "nowrap",
    verticalAlign: "middle",
    borderWidth: "1px",
    borderColor: "transparent",
    cursor: "button",
    flexShrink: "0",
    outline: "0",
    lineHeight: "1.2",
    isolation: "isolate",
    fontWeight: "medium",
    transitionProperty: "common",
    transitionDuration: "moderate",
    focusVisibleRing: "outside",
    _disabled: {
      layerStyle: "disabled"
    },
    _icon: {
      flexShrink: "0"
    }
  },
  variants: {
    size: {
      "2xs": {
        h: "6",
        minW: "6",
        textStyle: "xs",
        px: "2",
        gap: "1",
        _icon: {
          width: "3.5",
          height: "3.5"
        }
      },
      xs: {
        h: "8",
        minW: "8",
        textStyle: "xs",
        px: "2.5",
        gap: "1",
        _icon: {
          width: "4",
          height: "4"
        }
      },
      sm: {
        h: "9",
        minW: "9",
        px: "3.5",
        textStyle: "sm",
        gap: "2",
        _icon: {
          width: "4",
          height: "4"
        }
      },
      md: {
        h: "10",
        minW: "10",
        textStyle: "sm",
        px: "4",
        gap: "2",
        _icon: {
          width: "5",
          height: "5"
        }
      },
      lg: {
        h: "11",
        minW: "11",
        textStyle: "md",
        px: "5",
        gap: "3",
        _icon: {
          width: "5",
          height: "5"
        }
      },
      xl: {
        h: "12",
        minW: "12",
        textStyle: "md",
        px: "5",
        gap: "2.5",
        _icon: {
          width: "5",
          height: "5"
        }
      },
      "2xl": {
        h: "16",
        minW: "16",
        textStyle: "lg",
        px: "7",
        gap: "3",
        _icon: {
          width: "6",
          height: "6"
        }
      }
    },
    variant: {
      solid: {
        bg: "colorPalette.solid",
        color: "colorPalette.contrast",
        borderColor: "transparent",
        _hover: {
          bg: "colorPalette.solid/90"
        },
        _expanded: {
          bg: "colorPalette.solid/90"
        }
      },
      subtle: {
        bg: "colorPalette.subtle",
        color: "colorPalette.fg",
        borderColor: "transparent",
        _hover: {
          bg: "colorPalette.muted"
        },
        _expanded: {
          bg: "colorPalette.muted"
        }
      },
      surface: {
        bg: "colorPalette.subtle",
        color: "colorPalette.fg",
        shadow: "0 0 0px 1px var(--shadow-color)",
        shadowColor: "colorPalette.muted",
        _hover: {
          bg: "colorPalette.muted"
        },
        _expanded: {
          bg: "colorPalette.muted"
        }
      },
      outline: {
        borderWidth: "1px",
        "--outline-color-legacy": "colors.colorPalette.muted",
        "--outline-color": "colors.colorPalette.border",
        borderColor: "var(--outline-color, var(--outline-color-legacy))",
        color: "colorPalette.fg",
        _hover: {
          bg: "colorPalette.subtle"
        },
        _expanded: {
          bg: "colorPalette.subtle"
        }
      },
      ghost: {
        bg: "transparent",
        color: "colorPalette.fg",
        _hover: {
          bg: "colorPalette.subtle"
        },
        _expanded: {
          bg: "colorPalette.subtle"
        }
      },
      plain: {
        color: "colorPalette.fg"
      }
    }
  },
  defaultVariants: {
    size: "md",
    variant: "solid"
  }
});
const checkmarkRecipe = defineRecipe({
  className: "chakra-checkmark",
  base: {
    display: "inline-flex",
    alignItems: "center",
    justifyContent: "center",
    flexShrink: "0",
    color: "white",
    borderWidth: "1px",
    borderColor: "transparent",
    borderRadius: "l1",
    cursor: "checkbox",
    focusVisibleRing: "outside",
    _icon: {
      boxSize: "full"
    },
    _invalid: {
      colorPalette: "red",
      borderColor: "border.error"
    },
    _disabled: {
      opacity: "0.5",
      cursor: "disabled"
    }
  },
  variants: {
    size: {
      xs: {
        boxSize: "3"
      },
      sm: {
        boxSize: "4"
      },
      md: {
        boxSize: "5",
        p: "0.5"
      },
      lg: {
        boxSize: "6",
        p: "0.5"
      }
    },
    variant: {
      solid: {
        borderColor: "border.emphasized",
        "&:is([data-state=checked], [data-state=indeterminate])": {
          bg: "colorPalette.solid",
          color: "colorPalette.contrast",
          borderColor: "colorPalette.solid"
        }
      },
      outline: {
        borderColor: "border",
        "&:is([data-state=checked], [data-state=indeterminate])": {
          color: "colorPalette.fg",
          borderColor: "colorPalette.solid"
        }
      },
      subtle: {
        bg: "colorPalette.muted",
        borderColor: "colorPalette.muted",
        "&:is([data-state=checked], [data-state=indeterminate])": {
          color: "colorPalette.fg"
        }
      },
      plain: {
        "&:is([data-state=checked], [data-state=indeterminate])": {
          color: "colorPalette.fg"
        }
      },
      inverted: {
        borderColor: "border",
        color: "colorPalette.fg",
        "&:is([data-state=checked], [data-state=indeterminate])": {
          borderColor: "colorPalette.solid"
        }
      }
    },
    filled: {
      true: {
        bg: "bg"
      }
    }
  },
  defaultVariants: {
    variant: "solid",
    size: "md"
  }
});
const { variants: variants$1, defaultVariants: defaultVariants$1 } = badgeRecipe;
const codeRecipe = defineRecipe({
  className: "chakra-code",
  base: {
    fontFamily: "mono",
    alignItems: "center",
    display: "inline-flex",
    borderRadius: "l2"
  },
  variants: variants$1,
  defaultVariants: defaultVariants$1
});
const colorSwatchRecipe = defineRecipe({
  className: "color-swatch",
  base: {
    boxSize: "var(--swatch-size)",
    shadow: "inset 0 0 0 1px rgba(0, 0, 0, 0.1)",
    "--checker-size": "8px",
    "--checker-bg": "colors.bg",
    "--checker-fg": "colors.bg.emphasized",
    background: "linear-gradient(var(--color), var(--color)), repeating-conic-gradient(var(--checker-fg) 0%, var(--checker-fg) 25%, var(--checker-bg) 0%, var(--checker-bg) 50%) 0% 50% / var(--checker-size) var(--checker-size) !important",
    display: "inline-flex",
    alignItems: "center",
    justifyContent: "center",
    flexShrink: "0"
  },
  variants: {
    size: {
      "2xs": { "--swatch-size": "sizes.3.5" },
      xs: { "--swatch-size": "sizes.4" },
      sm: { "--swatch-size": "sizes.4.5" },
      md: { "--swatch-size": "sizes.5" },
      lg: { "--swatch-size": "sizes.6" },
      xl: { "--swatch-size": "sizes.7" },
      "2xl": { "--swatch-size": "sizes.8" },
      inherit: { "--swatch-size": "inherit" },
      full: { "--swatch-size": "100%" }
    },
    shape: {
      square: { borderRadius: "none" },
      circle: { borderRadius: "full" },
      rounded: { borderRadius: "l1" }
    }
  },
  defaultVariants: {
    size: "md",
    shape: "rounded"
  }
});
const containerRecipe = defineRecipe({
  className: "chakra-container",
  base: {
    position: "relative",
    maxWidth: "8xl",
    w: "100%",
    mx: "auto",
    px: { base: "4", md: "6", lg: "8" }
  },
  variants: {
    centerContent: {
      true: {
        display: "flex",
        flexDirection: "column",
        alignItems: "center"
      }
    },
    fluid: {
      true: {
        maxWidth: "full"
      }
    }
  }
});
const headingRecipe = defineRecipe({
  className: "chakra-heading",
  base: {
    fontFamily: "heading",
    fontWeight: "semibold"
  },
  variants: {
    size: {
      xs: { textStyle: "xs" },
      sm: { textStyle: "sm" },
      md: { textStyle: "md" },
      lg: { textStyle: "lg" },
      xl: { textStyle: "xl" },
      "2xl": { textStyle: "2xl" },
      "3xl": { textStyle: "3xl" },
      "4xl": { textStyle: "4xl" },
      "5xl": { textStyle: "5xl" },
      "6xl": { textStyle: "6xl" },
      "7xl": { textStyle: "7xl" }
    }
  },
  defaultVariants: {
    size: "xl"
  }
});
const iconRecipe = defineRecipe({
  className: "chakra-icon",
  base: {
    display: "inline-block",
    lineHeight: "1em",
    flexShrink: "0",
    color: "currentcolor",
    verticalAlign: "middle"
  },
  variants: {
    size: {
      inherit: {},
      xs: { boxSize: "3" },
      sm: { boxSize: "4" },
      md: { boxSize: "5" },
      lg: { boxSize: "6" },
      xl: { boxSize: "7" },
      "2xl": { boxSize: "8" }
    }
  },
  defaultVariants: {
    size: "inherit"
  }
});
const inputRecipe = defineRecipe({
  className: "chakra-input",
  base: {
    width: "100%",
    minWidth: "0",
    outline: "0",
    position: "relative",
    appearance: "none",
    textAlign: "start",
    borderRadius: "l2",
    _disabled: {
      layerStyle: "disabled"
    },
    height: "var(--input-height)",
    minW: "var(--input-height)",
    "--focus-color": "colors.colorPalette.focusRing",
    "--error-color": "colors.border.error",
    _invalid: {
      focusRingColor: "var(--error-color)",
      borderColor: "var(--error-color)"
    }
  },
  variants: {
    size: {
      "2xs": {
        textStyle: "xs",
        px: "2",
        "--input-height": "sizes.7"
      },
      xs: {
        textStyle: "xs",
        px: "2",
        "--input-height": "sizes.8"
      },
      sm: {
        textStyle: "sm",
        px: "2.5",
        "--input-height": "sizes.9"
      },
      md: {
        textStyle: "sm",
        px: "3",
        "--input-height": "sizes.10"
      },
      lg: {
        textStyle: "md",
        px: "4",
        "--input-height": "sizes.11"
      },
      xl: {
        textStyle: "md",
        px: "4.5",
        "--input-height": "sizes.12"
      },
      "2xl": {
        textStyle: "lg",
        px: "5",
        "--input-height": "sizes.16"
      }
    },
    variant: {
      outline: {
        bg: "transparent",
        borderWidth: "1px",
        borderColor: "border",
        focusVisibleRing: "inside",
        focusRingColor: "var(--focus-color)"
      },
      subtle: {
        borderWidth: "1px",
        borderColor: "transparent",
        bg: "bg.muted",
        focusVisibleRing: "inside",
        focusRingColor: "var(--focus-color)"
      },
      flushed: {
        bg: "transparent",
        borderBottomWidth: "1px",
        borderBottomColor: "border",
        borderRadius: "0",
        px: "0",
        _focusVisible: {
          borderColor: "var(--focus-color)",
          boxShadow: "0px 1px 0px 0px var(--focus-color)",
          _invalid: {
            borderColor: "var(--error-color)",
            boxShadow: "0px 1px 0px 0px var(--error-color)"
          }
        }
      }
    }
  },
  defaultVariants: {
    size: "md",
    variant: "outline"
  }
});
const inputAddonRecipe = defineRecipe({
  className: "chakra-input-addon",
  base: {
    flex: "0 0 auto",
    width: "auto",
    display: "flex",
    alignItems: "center",
    whiteSpace: "nowrap",
    alignSelf: "stretch",
    borderRadius: "l2"
  },
  variants: {
    size: inputRecipe.variants.size,
    variant: {
      outline: {
        borderWidth: "1px",
        borderColor: "border",
        bg: "bg.muted"
      },
      subtle: {
        borderWidth: "1px",
        borderColor: "transparent",
        bg: "bg.emphasized"
      },
      flushed: {
        borderBottom: "1px solid",
        borderColor: "inherit",
        borderRadius: "0",
        px: "0",
        bg: "transparent"
      }
    }
  },
  defaultVariants: {
    size: "md",
    variant: "outline"
  }
});
const kbdRecipe = defineRecipe({
  className: "chakra-kbd",
  base: {
    display: "inline-flex",
    alignItems: "center",
    fontWeight: "medium",
    fontFamily: "mono",
    flexShrink: "0",
    whiteSpace: "nowrap",
    wordSpacing: "-0.5em",
    userSelect: "none",
    px: "1",
    borderRadius: "l2"
  },
  variants: {
    variant: {
      raised: {
        bg: "colorPalette.subtle",
        color: "colorPalette.fg",
        borderWidth: "1px",
        borderBottomWidth: "2px",
        borderColor: "colorPalette.muted"
      },
      outline: {
        borderWidth: "1px",
        color: "colorPalette.fg"
      },
      subtle: {
        bg: "colorPalette.muted",
        color: "colorPalette.fg"
      },
      plain: {
        color: "colorPalette.fg"
      }
    },
    size: {
      sm: {
        textStyle: "xs",
        height: "4.5"
      },
      md: {
        textStyle: "sm",
        height: "5"
      },
      lg: {
        textStyle: "md",
        height: "6"
      }
    }
  },
  defaultVariants: {
    size: "md",
    variant: "raised"
  }
});
const linkRecipe = defineRecipe({
  className: "chakra-link",
  base: {
    display: "inline-flex",
    alignItems: "center",
    outline: "none",
    gap: "1.5",
    cursor: "pointer",
    borderRadius: "l1",
    focusRing: "outside"
  },
  variants: {
    variant: {
      underline: {
        color: "colorPalette.fg",
        textDecoration: "underline",
        textUnderlineOffset: "3px",
        textDecorationColor: "currentColor/20"
      },
      plain: {
        color: "colorPalette.fg",
        _hover: {
          textDecoration: "underline",
          textUnderlineOffset: "3px",
          textDecorationColor: "currentColor/20"
        }
      }
    }
  },
  defaultVariants: {
    variant: "plain"
  }
});
const markRecipe = defineRecipe({
  className: "chakra-mark",
  base: {
    bg: "transparent",
    color: "inherit",
    whiteSpace: "nowrap"
  },
  variants: {
    variant: {
      subtle: {
        bg: "colorPalette.subtle",
        color: "inherit"
      },
      solid: {
        bg: "colorPalette.solid",
        color: "colorPalette.contrast"
      },
      text: {
        fontWeight: "medium"
      },
      plain: {}
    }
  }
});
const radiomarkRecipe = defineRecipe({
  className: "chakra-radiomark",
  base: {
    display: "inline-flex",
    alignItems: "center",
    justifyContent: "center",
    flexShrink: 0,
    verticalAlign: "top",
    color: "white",
    borderWidth: "1px",
    borderColor: "transparent",
    borderRadius: "full",
    cursor: "radio",
    _focusVisible: {
      outline: "2px solid",
      outlineColor: "colorPalette.focusRing",
      outlineOffset: "2px"
    },
    _invalid: {
      colorPalette: "red",
      borderColor: "red.500"
    },
    _disabled: {
      opacity: "0.5",
      cursor: "disabled"
    },
    "& .dot": {
      height: "100%",
      width: "100%",
      borderRadius: "full",
      bg: "currentColor",
      scale: "0.4"
    }
  },
  variants: {
    variant: {
      solid: {
        borderWidth: "1px",
        borderColor: "border.emphasized",
        _checked: {
          bg: "colorPalette.solid",
          color: "colorPalette.contrast",
          borderColor: "colorPalette.solid"
        }
      },
      subtle: {
        borderWidth: "1px",
        bg: "colorPalette.muted",
        borderColor: "colorPalette.muted",
        color: "transparent",
        _checked: {
          color: "colorPalette.fg"
        }
      },
      outline: {
        borderWidth: "1px",
        borderColor: "inherit",
        _checked: {
          color: "colorPalette.fg",
          borderColor: "colorPalette.solid"
        },
        "& .dot": {
          scale: "0.6"
        }
      },
      inverted: {
        bg: "bg",
        borderWidth: "1px",
        borderColor: "inherit",
        _checked: {
          color: "colorPalette.solid",
          borderColor: "currentcolor"
        }
      }
    },
    size: {
      xs: {
        boxSize: "3"
      },
      sm: {
        boxSize: "4"
      },
      md: {
        boxSize: "5"
      },
      lg: {
        boxSize: "6"
      }
    },
    filled: {
      true: {
        bg: "bg"
      }
    }
  },
  defaultVariants: {
    variant: "solid",
    size: "md"
  }
});
const separatorRecipe = defineRecipe({
  className: "chakra-separator",
  base: {
    display: "block",
    borderColor: "border"
  },
  variants: {
    variant: {
      solid: {
        borderStyle: "solid"
      },
      dashed: {
        borderStyle: "dashed"
      },
      dotted: {
        borderStyle: "dotted"
      }
    },
    orientation: {
      vertical: {
        borderInlineStartWidth: "var(--separator-thickness)"
      },
      horizontal: {
        borderTopWidth: "var(--separator-thickness)"
      }
    },
    size: {
      xs: {
        "--separator-thickness": "0.5px"
      },
      sm: {
        "--separator-thickness": "1px"
      },
      md: {
        "--separator-thickness": "2px"
      },
      lg: {
        "--separator-thickness": "3px"
      }
    }
  },
  defaultVariants: {
    size: "sm",
    variant: "solid",
    orientation: "horizontal"
  }
});
const skeletonRecipe = defineRecipe({
  className: "chakra-skeleton",
  base: {},
  variants: {
    loading: {
      true: {
        borderRadius: "l2",
        boxShadow: "none",
        backgroundClip: "padding-box",
        cursor: "default",
        color: "transparent",
        pointerEvents: "none",
        userSelect: "none",
        flexShrink: "0",
        "&::before, &::after, *": {
          visibility: "hidden"
        }
      },
      false: {
        background: "unset",
        animation: "fade-in var(--fade-duration, 0.1s) ease-out !important"
      }
    },
    variant: {
      pulse: {
        background: "bg.emphasized",
        animation: "pulse",
        animationDuration: "var(--duration, 1.2s)"
      },
      shine: {
        "--animate-from": "200%",
        "--animate-to": "-200%",
        "--start-color": "colors.bg.muted",
        "--end-color": "colors.bg.emphasized",
        backgroundImage: "linear-gradient(270deg,var(--start-color),var(--end-color),var(--end-color),var(--start-color))",
        backgroundSize: "400% 100%",
        animation: "bg-position var(--duration, 5s) ease-in-out infinite"
      },
      none: {
        animation: "none"
      }
    }
  },
  defaultVariants: {
    variant: "pulse",
    loading: true
  }
});
const skipNavLinkRecipe = defineRecipe({
  className: "chakra-skip-nav",
  base: {
    display: "inline-flex",
    bg: "bg.panel",
    padding: "2.5",
    borderRadius: "l2",
    fontWeight: "semibold",
    focusVisibleRing: "outside",
    textStyle: "sm",
    // visually hidden
    userSelect: "none",
    border: "0",
    height: "1px",
    width: "1px",
    margin: "-1px",
    outline: "0",
    overflow: "hidden",
    position: "absolute",
    clip: "rect(0 0 0 0)",
    _focusVisible: {
      clip: "auto",
      width: "auto",
      height: "auto",
      position: "fixed",
      top: "6",
      insetStart: "6"
    }
  }
});
const spinnerRecipe = defineRecipe({
  className: "chakra-spinner",
  base: {
    display: "inline-block",
    borderColor: "currentColor",
    borderStyle: "solid",
    borderWidth: "2px",
    borderRadius: "full",
    width: "var(--spinner-size)",
    height: "var(--spinner-size)",
    animation: "spin",
    animationDuration: "slowest",
    "--spinner-track-color": "transparent",
    borderBottomColor: "var(--spinner-track-color)",
    borderInlineStartColor: "var(--spinner-track-color)"
  },
  variants: {
    size: {
      inherit: { "--spinner-size": "1em" },
      xs: { "--spinner-size": "sizes.3" },
      sm: { "--spinner-size": "sizes.4" },
      md: { "--spinner-size": "sizes.5" },
      lg: { "--spinner-size": "sizes.8" },
      xl: { "--spinner-size": "sizes.10" }
    }
  },
  defaultVariants: {
    size: "md"
  }
});
const textareaRecipe = defineRecipe({
  className: "chakra-textarea",
  base: {
    width: "100%",
    minWidth: "0",
    outline: "0",
    position: "relative",
    appearance: "none",
    textAlign: "start",
    borderRadius: "l2",
    _disabled: {
      layerStyle: "disabled"
    },
    "--focus-color": "colors.colorPalette.focusRing",
    "--error-color": "colors.border.error",
    _invalid: {
      focusRingColor: "var(--error-color)",
      borderColor: "var(--error-color)"
    }
  },
  variants: {
    size: {
      xs: {
        textStyle: "xs",
        px: "2",
        py: "1.5",
        scrollPaddingBottom: "1.5"
      },
      sm: {
        textStyle: "sm",
        px: "2.5",
        py: "2",
        scrollPaddingBottom: "2"
      },
      md: {
        textStyle: "sm",
        px: "3",
        py: "2",
        scrollPaddingBottom: "2"
      },
      lg: {
        textStyle: "md",
        px: "4",
        py: "3",
        scrollPaddingBottom: "3"
      },
      xl: {
        textStyle: "md",
        px: "4.5",
        py: "3.5",
        scrollPaddingBottom: "3.5"
      }
    },
    variant: {
      outline: {
        bg: "transparent",
        borderWidth: "1px",
        borderColor: "border",
        focusVisibleRing: "inside"
      },
      subtle: {
        borderWidth: "1px",
        borderColor: "transparent",
        bg: "bg.muted",
        focusVisibleRing: "inside"
      },
      flushed: {
        bg: "transparent",
        borderBottomWidth: "1px",
        borderBottomColor: "border",
        borderRadius: "0",
        px: "0",
        _focusVisible: {
          borderColor: "var(--focus-color)",
          boxShadow: "0px 1px 0px 0px var(--focus-color)"
        }
      }
    }
  },
  defaultVariants: {
    size: "md",
    variant: "outline"
  }
});
const recipes = {
  badge: badgeRecipe,
  button: buttonRecipe,
  code: codeRecipe,
  container: containerRecipe,
  heading: headingRecipe,
  input: inputRecipe,
  inputAddon: inputAddonRecipe,
  kbd: kbdRecipe,
  link: linkRecipe,
  mark: markRecipe,
  separator: separatorRecipe,
  skeleton: skeletonRecipe,
  skipNavLink: skipNavLinkRecipe,
  spinner: spinnerRecipe,
  textarea: textareaRecipe,
  icon: iconRecipe,
  checkmark: checkmarkRecipe,
  radiomark: radiomarkRecipe,
  colorSwatch: colorSwatchRecipe
};
const semanticColors = defineSemanticTokens.colors({
  bg: {
    DEFAULT: {
      value: { _light: "{colors.white}", _dark: "{colors.black}" }
    },
    subtle: {
      value: { _light: "{colors.gray.50}", _dark: "{colors.gray.950}" }
    },
    muted: {
      value: { _light: "{colors.gray.100}", _dark: "{colors.gray.900}" }
    },
    emphasized: {
      value: { _light: "{colors.gray.200}", _dark: "{colors.gray.800}" }
    },
    inverted: {
      value: { _light: "{colors.black}", _dark: "{colors.white}" }
    },
    panel: {
      value: { _light: "{colors.white}", _dark: "{colors.gray.950}" }
    },
    error: {
      value: { _light: "{colors.red.50}", _dark: "{colors.red.950}" }
    },
    warning: {
      value: { _light: "{colors.orange.50}", _dark: "{colors.orange.950}" }
    },
    success: {
      value: { _light: "{colors.green.50}", _dark: "{colors.green.950}" }
    },
    info: {
      value: { _light: "{colors.blue.50}", _dark: "{colors.blue.950}" }
    }
  },
  fg: {
    DEFAULT: {
      value: { _light: "{colors.black}", _dark: "{colors.gray.50}" }
    },
    muted: {
      value: { _light: "{colors.gray.600}", _dark: "{colors.gray.400}" }
    },
    subtle: {
      value: { _light: "{colors.gray.400}", _dark: "{colors.gray.500}" }
    },
    inverted: {
      value: { _light: "{colors.gray.50}", _dark: "{colors.black}" }
    },
    error: {
      value: { _light: "{colors.red.500}", _dark: "{colors.red.400}" }
    },
    warning: {
      value: { _light: "{colors.orange.600}", _dark: "{colors.orange.300}" }
    },
    success: {
      value: { _light: "{colors.green.600}", _dark: "{colors.green.300}" }
    },
    info: {
      value: { _light: "{colors.blue.600}", _dark: "{colors.blue.300}" }
    }
  },
  border: {
    DEFAULT: {
      value: { _light: "{colors.gray.200}", _dark: "{colors.gray.800}" }
    },
    muted: {
      value: { _light: "{colors.gray.100}", _dark: "{colors.gray.900}" }
    },
    subtle: {
      value: { _light: "{colors.gray.50}", _dark: "{colors.gray.950}" }
    },
    emphasized: {
      value: { _light: "{colors.gray.300}", _dark: "{colors.gray.700}" }
    },
    inverted: {
      value: { _light: "{colors.gray.800}", _dark: "{colors.gray.200}" }
    },
    error: {
      value: { _light: "{colors.red.500}", _dark: "{colors.red.400}" }
    },
    warning: {
      value: { _light: "{colors.orange.500}", _dark: "{colors.orange.400}" }
    },
    success: {
      value: { _light: "{colors.green.500}", _dark: "{colors.green.400}" }
    },
    info: {
      value: { _light: "{colors.blue.500}", _dark: "{colors.blue.400}" }
    }
  },
  gray: {
    contrast: {
      value: { _light: "{colors.white}", _dark: "{colors.black}" }
    },
    fg: {
      value: { _light: "{colors.gray.800}", _dark: "{colors.gray.200}" }
    },
    subtle: {
      value: { _light: "{colors.gray.100}", _dark: "{colors.gray.900}" }
    },
    muted: {
      value: { _light: "{colors.gray.200}", _dark: "{colors.gray.800}" }
    },
    emphasized: {
      value: { _light: "{colors.gray.300}", _dark: "{colors.gray.700}" }
    },
    solid: {
      value: { _light: "{colors.gray.900}", _dark: "{colors.white}" }
    },
    focusRing: {
      value: { _light: "{colors.gray.400}", _dark: "{colors.gray.400}" }
    },
    border: {
      value: { _light: "{colors.gray.200}", _dark: "{colors.gray.800}" }
    }
  },
  red: {
    contrast: {
      value: { _light: "white", _dark: "white" }
    },
    fg: {
      value: { _light: "{colors.red.700}", _dark: "{colors.red.300}" }
    },
    subtle: {
      value: { _light: "{colors.red.100}", _dark: "{colors.red.900}" }
    },
    muted: {
      value: { _light: "{colors.red.200}", _dark: "{colors.red.800}" }
    },
    emphasized: {
      value: { _light: "{colors.red.300}", _dark: "{colors.red.700}" }
    },
    solid: {
      value: { _light: "{colors.red.600}", _dark: "{colors.red.600}" }
    },
    focusRing: {
      value: { _light: "{colors.red.500}", _dark: "{colors.red.500}" }
    },
    border: {
      value: { _light: "{colors.red.500}", _dark: "{colors.red.400}" }
    }
  },
  orange: {
    contrast: {
      value: { _light: "white", _dark: "black" }
    },
    fg: {
      value: { _light: "{colors.orange.700}", _dark: "{colors.orange.300}" }
    },
    subtle: {
      value: { _light: "{colors.orange.100}", _dark: "{colors.orange.900}" }
    },
    muted: {
      value: { _light: "{colors.orange.200}", _dark: "{colors.orange.800}" }
    },
    emphasized: {
      value: { _light: "{colors.orange.300}", _dark: "{colors.orange.700}" }
    },
    solid: {
      value: { _light: "{colors.orange.600}", _dark: "{colors.orange.500}" }
    },
    focusRing: {
      value: { _light: "{colors.orange.500}", _dark: "{colors.orange.500}" }
    },
    border: {
      value: { _light: "{colors.orange.500}", _dark: "{colors.orange.400}" }
    }
  },
  green: {
    contrast: {
      value: { _light: "white", _dark: "white" }
    },
    fg: {
      value: { _light: "{colors.green.700}", _dark: "{colors.green.300}" }
    },
    subtle: {
      value: { _light: "{colors.green.100}", _dark: "{colors.green.900}" }
    },
    muted: {
      value: { _light: "{colors.green.200}", _dark: "{colors.green.800}" }
    },
    emphasized: {
      value: { _light: "{colors.green.300}", _dark: "{colors.green.700}" }
    },
    solid: {
      value: { _light: "{colors.green.600}", _dark: "{colors.green.600}" }
    },
    focusRing: {
      value: { _light: "{colors.green.500}", _dark: "{colors.green.500}" }
    },
    border: {
      value: { _light: "{colors.green.500}", _dark: "{colors.green.400}" }
    }
  },
  blue: {
    contrast: {
      value: { _light: "white", _dark: "white" }
    },
    fg: {
      value: { _light: "{colors.blue.700}", _dark: "{colors.blue.300}" }
    },
    subtle: {
      value: { _light: "{colors.blue.100}", _dark: "{colors.blue.900}" }
    },
    muted: {
      value: { _light: "{colors.blue.200}", _dark: "{colors.blue.800}" }
    },
    emphasized: {
      value: { _light: "{colors.blue.300}", _dark: "{colors.blue.700}" }
    },
    solid: {
      value: { _light: "{colors.blue.600}", _dark: "{colors.blue.600}" }
    },
    focusRing: {
      value: { _light: "{colors.blue.500}", _dark: "{colors.blue.500}" }
    },
    border: {
      value: { _light: "{colors.blue.500}", _dark: "{colors.blue.400}" }
    }
  },
  yellow: {
    contrast: {
      value: { _light: "black", _dark: "black" }
    },
    fg: {
      value: { _light: "{colors.yellow.800}", _dark: "{colors.yellow.300}" }
    },
    subtle: {
      value: { _light: "{colors.yellow.100}", _dark: "{colors.yellow.900}" }
    },
    muted: {
      value: { _light: "{colors.yellow.200}", _dark: "{colors.yellow.800}" }
    },
    emphasized: {
      value: { _light: "{colors.yellow.300}", _dark: "{colors.yellow.700}" }
    },
    solid: {
      value: { _light: "{colors.yellow.300}", _dark: "{colors.yellow.300}" }
    },
    focusRing: {
      value: { _light: "{colors.yellow.500}", _dark: "{colors.yellow.500}" }
    },
    border: {
      value: { _light: "{colors.yellow.500}", _dark: "{colors.yellow.500}" }
    }
  },
  teal: {
    contrast: {
      value: { _light: "white", _dark: "white" }
    },
    fg: {
      value: { _light: "{colors.teal.700}", _dark: "{colors.teal.300}" }
    },
    subtle: {
      value: { _light: "{colors.teal.100}", _dark: "{colors.teal.900}" }
    },
    muted: {
      value: { _light: "{colors.teal.200}", _dark: "{colors.teal.800}" }
    },
    emphasized: {
      value: { _light: "{colors.teal.300}", _dark: "{colors.teal.700}" }
    },
    solid: {
      value: { _light: "{colors.teal.600}", _dark: "{colors.teal.600}" }
    },
    focusRing: {
      value: { _light: "{colors.teal.500}", _dark: "{colors.teal.500}" }
    },
    border: {
      value: { _light: "{colors.teal.500}", _dark: "{colors.teal.400}" }
    }
  },
  purple: {
    contrast: {
      value: { _light: "white", _dark: "white" }
    },
    fg: {
      value: { _light: "{colors.purple.700}", _dark: "{colors.purple.300}" }
    },
    subtle: {
      value: { _light: "{colors.purple.100}", _dark: "{colors.purple.900}" }
    },
    muted: {
      value: { _light: "{colors.purple.200}", _dark: "{colors.purple.800}" }
    },
    emphasized: {
      value: { _light: "{colors.purple.300}", _dark: "{colors.purple.700}" }
    },
    solid: {
      value: { _light: "{colors.purple.600}", _dark: "{colors.purple.600}" }
    },
    focusRing: {
      value: { _light: "{colors.purple.500}", _dark: "{colors.purple.500}" }
    },
    border: {
      value: { _light: "{colors.purple.500}", _dark: "{colors.purple.400}" }
    }
  },
  pink: {
    contrast: {
      value: { _light: "white", _dark: "white" }
    },
    fg: {
      value: { _light: "{colors.pink.700}", _dark: "{colors.pink.300}" }
    },
    subtle: {
      value: { _light: "{colors.pink.100}", _dark: "{colors.pink.900}" }
    },
    muted: {
      value: { _light: "{colors.pink.200}", _dark: "{colors.pink.800}" }
    },
    emphasized: {
      value: { _light: "{colors.pink.300}", _dark: "{colors.pink.700}" }
    },
    solid: {
      value: { _light: "{colors.pink.600}", _dark: "{colors.pink.600}" }
    },
    focusRing: {
      value: { _light: "{colors.pink.500}", _dark: "{colors.pink.500}" }
    },
    border: {
      value: { _light: "{colors.pink.500}", _dark: "{colors.pink.400}" }
    }
  },
  cyan: {
    contrast: {
      value: { _light: "white", _dark: "white" }
    },
    fg: {
      value: { _light: "{colors.cyan.700}", _dark: "{colors.cyan.300}" }
    },
    subtle: {
      value: { _light: "{colors.cyan.100}", _dark: "{colors.cyan.900}" }
    },
    muted: {
      value: { _light: "{colors.cyan.200}", _dark: "{colors.cyan.800}" }
    },
    emphasized: {
      value: { _light: "{colors.cyan.300}", _dark: "{colors.cyan.700}" }
    },
    solid: {
      value: { _light: "{colors.cyan.600}", _dark: "{colors.cyan.600}" }
    },
    focusRing: {
      value: { _light: "{colors.cyan.500}", _dark: "{colors.cyan.500}" }
    },
    border: {
      value: { _light: "{colors.cyan.500}", _dark: "{colors.cyan.400}" }
    }
  }
});
const semanticRadii = defineSemanticTokens.radii({
  l1: { value: "{radii.xs}" },
  l2: { value: "{radii.sm}" },
  l3: { value: "{radii.md}" }
});
const semanticShadows = defineSemanticTokens.shadows({
  xs: {
    value: {
      _light: "0px 1px 2px {colors.gray.900/10}, 0px 0px 1px {colors.gray.900/20}",
      _dark: "0px 1px 1px {black/64}, 0px 0px 1px inset {colors.gray.300/20}"
    }
  },
  sm: {
    value: {
      _light: "0px 2px 4px {colors.gray.900/10}, 0px 0px 1px {colors.gray.900/30}",
      _dark: "0px 2px 4px {black/64}, 0px 0px 1px inset {colors.gray.300/30}"
    }
  },
  md: {
    value: {
      _light: "0px 4px 8px {colors.gray.900/10}, 0px 0px 1px {colors.gray.900/30}",
      _dark: "0px 4px 8px {black/64}, 0px 0px 1px inset {colors.gray.300/30}"
    }
  },
  lg: {
    value: {
      _light: "0px 8px 16px {colors.gray.900/10}, 0px 0px 1px {colors.gray.900/30}",
      _dark: "0px 8px 16px {black/64}, 0px 0px 1px inset {colors.gray.300/30}"
    }
  },
  xl: {
    value: {
      _light: "0px 16px 24px {colors.gray.900/10}, 0px 0px 1px {colors.gray.900/30}",
      _dark: "0px 16px 24px {black/64}, 0px 0px 1px inset {colors.gray.300/30}"
    }
  },
  "2xl": {
    value: {
      _light: "0px 24px 40px {colors.gray.900/16}, 0px 0px 1px {colors.gray.900/30}",
      _dark: "0px 24px 40px {black/64}, 0px 0px 1px inset {colors.gray.300/30}"
    }
  },
  inner: {
    value: {
      _light: "inset 0 2px 4px 0 {black/5}",
      _dark: "inset 0 2px 4px 0 black"
    }
  },
  inset: {
    value: {
      _light: "inset 0 0 0 1px {black/5}",
      _dark: "inset 0 0 0 1px {colors.gray.300/5}"
    }
  }
});
const accordionAnatomy = anatomy$b.extendWith("itemBody");
const actionBarAnatomy = createAnatomy("action-bar").parts(
  "positioner",
  "content",
  "separator",
  "selectionTrigger",
  "closeTrigger"
);
const alertAnatomy = createAnatomy("alert").parts(
  "title",
  "description",
  "root",
  "indicator",
  "content"
);
const breadcrumbAnatomy = createAnatomy("breadcrumb").parts(
  "link",
  "currentLink",
  "item",
  "list",
  "root",
  "ellipsis",
  "separator"
);
const blockquoteAnatomy = createAnatomy("blockquote").parts(
  "root",
  "icon",
  "content",
  "caption"
);
const cardAnatomy = createAnatomy("card").parts(
  "root",
  "header",
  "body",
  "footer",
  "title",
  "description"
);
const checkboxCardAnatomy = createAnatomy("checkbox-card", [
  "root",
  "control",
  "label",
  "description",
  "addon",
  "indicator",
  "content"
]);
const dataListAnatomy = createAnatomy("data-list").parts(
  "root",
  "item",
  "itemLabel",
  "itemValue"
);
const dialogAnatomy = anatomy$a.extendWith(
  "header",
  "body",
  "footer",
  "backdrop"
);
const drawerAnatomy = anatomy$a.extendWith(
  "header",
  "body",
  "footer",
  "backdrop"
);
const editableAnatomy = anatomy$9.extendWith("textarea");
const emptyStateAnatomy = createAnatomy("empty-state", [
  "root",
  "content",
  "indicator",
  "title",
  "description"
]);
const fieldAnatomy = fieldAnatomy$1.extendWith("requiredIndicator");
const fieldsetAnatomy = fieldsetAnatomy$1.extendWith("content");
const fileUploadAnatomy = anatomy$8.extendWith(
  "itemContent",
  "dropzoneContent",
  "fileText"
);
const listAnatomy = createAnatomy("list").parts(
  "root",
  "item",
  "indicator"
);
const menuAnatomy = anatomy$7.extendWith("itemCommand");
const nativeSelectAnatomy = createAnatomy("select").parts(
  "root",
  "field",
  "indicator"
);
const popoverAnatomy = anatomy$6.extendWith(
  "header",
  "body",
  "footer"
);
const radioGroupAnatomy = anatomy$5.extendWith(
  "itemAddon",
  "itemIndicator"
);
const radioCardAnatomy = radioGroupAnatomy.extendWith(
  "itemContent",
  "itemDescription"
);
const ratingGroupAnatomy = anatomy$4.extendWith("itemIndicator");
const selectAnatomy = anatomy$3.extendWith("indicatorGroup");
const comboboxAnatomy = comboboxAnatomy$1.extendWith(
  "indicatorGroup",
  "empty"
);
const sliderAnatomy = anatomy$2.extendWith(
  "markerIndicator",
  "markerLabel"
);
const statAnatomy = createAnatomy("stat").parts(
  "root",
  "label",
  "helpText",
  "valueText",
  "valueUnit",
  "indicator"
);
const statusAnatomy = createAnatomy("status").parts("root", "indicator");
const stepsAnatomy = createAnatomy("steps", [
  "root",
  "list",
  "item",
  "trigger",
  "indicator",
  "separator",
  "content",
  "title",
  "description",
  "nextTrigger",
  "prevTrigger",
  "progress"
]);
const switchAnatomy = anatomy.extendWith("indicator");
const tableAnatomy = createAnatomy("table").parts(
  "root",
  "header",
  "body",
  "row",
  "columnHeader",
  "cell",
  "footer",
  "caption"
);
const toastAnatomy = createAnatomy("toast").parts(
  "root",
  "title",
  "description",
  "indicator",
  "closeTrigger",
  "actionTrigger"
);
const tabsAnatomy = createAnatomy("tabs").parts(
  "root",
  "trigger",
  "list",
  "content",
  "contentGroup",
  "indicator"
);
const tagAnatomy = createAnatomy("tag").parts(
  "root",
  "label",
  "closeTrigger",
  "startElement",
  "endElement"
);
const timelineAnatomy = createAnatomy("timeline").parts(
  "root",
  "item",
  "content",
  "separator",
  "indicator",
  "connector",
  "title",
  "description"
);
const colorPickerAnatomy = colorPickerAnatomy$1.extendWith("channelText");
const codeBlockAnatomy = createAnatomy("code-block", [
  "root",
  "content",
  "title",
  "header",
  "footer",
  "control",
  "overlay",
  "code",
  "codeText",
  "copyTrigger",
  "copyIndicator",
  "collapseTrigger",
  "collapseIndicator",
  "collapseText"
]);
const splitterAnatomy = anatomy$1.extendWith(
  "resizeTriggerSeparator",
  "resizeTriggerIndicator"
);
anatomy$c.extendWith("valueText");
const listboxAnatomy = listboxAnatomy$1;
const accordionSlotRecipe = defineSlotRecipe({
  className: "chakra-accordion",
  slots: accordionAnatomy.keys(),
  base: {
    root: {
      width: "full",
      "--accordion-radius": "radii.l2"
    },
    item: {
      overflowAnchor: "none"
    },
    itemTrigger: {
      display: "flex",
      alignItems: "center",
      textAlign: "start",
      width: "full",
      outline: "0",
      gap: "3",
      fontWeight: "medium",
      borderRadius: "var(--accordion-radius)",
      _focusVisible: {
        outline: "2px solid",
        outlineColor: "colorPalette.focusRing"
      },
      _disabled: {
        layerStyle: "disabled"
      }
    },
    itemBody: {
      pt: "var(--accordion-padding-y)",
      pb: "calc(var(--accordion-padding-y) * 2)"
    },
    itemContent: {
      overflow: "hidden",
      borderRadius: "var(--accordion-radius)",
      _open: {
        animationName: "expand-height, fade-in",
        animationDuration: "moderate"
      },
      _closed: {
        animationName: "collapse-height, fade-out",
        animationDuration: "moderate"
      }
    },
    itemIndicator: {
      transition: "rotate 0.2s",
      transformOrigin: "center",
      color: "fg.subtle",
      _open: {
        rotate: "180deg"
      },
      _icon: {
        width: "1.2em",
        height: "1.2em"
      }
    }
  },
  variants: {
    variant: {
      outline: {
        item: {
          borderBottomWidth: "1px"
        }
      },
      subtle: {
        itemTrigger: {
          px: "var(--accordion-padding-x)"
        },
        itemContent: {
          px: "var(--accordion-padding-x)"
        },
        item: {
          borderRadius: "var(--accordion-radius)",
          _open: {
            bg: "colorPalette.subtle"
          }
        }
      },
      enclosed: {
        root: {
          borderWidth: "1px",
          borderRadius: "var(--accordion-radius)",
          divideY: "1px",
          overflow: "hidden"
        },
        itemTrigger: {
          px: "var(--accordion-padding-x)"
        },
        itemContent: {
          px: "var(--accordion-padding-x)"
        },
        item: {
          _open: {
            bg: "bg.subtle"
          }
        }
      },
      plain: {}
    },
    size: {
      sm: {
        root: {
          "--accordion-padding-x": "spacing.3",
          "--accordion-padding-y": "spacing.2"
        },
        itemTrigger: {
          textStyle: "sm",
          py: "var(--accordion-padding-y)"
        }
      },
      md: {
        root: {
          "--accordion-padding-x": "spacing.4",
          "--accordion-padding-y": "spacing.2"
        },
        itemTrigger: {
          textStyle: "md",
          py: "var(--accordion-padding-y)"
        }
      },
      lg: {
        root: {
          "--accordion-padding-x": "spacing.4.5",
          "--accordion-padding-y": "spacing.2.5"
        },
        itemTrigger: {
          textStyle: "lg",
          py: "var(--accordion-padding-y)"
        }
      }
    }
  },
  defaultVariants: {
    size: "md",
    variant: "outline"
  }
});
const actionBarSlotRecipe = defineSlotRecipe({
  className: "chakra-action-bar",
  slots: actionBarAnatomy.keys(),
  base: {
    positioner: {
      position: "fixed",
      display: "flex",
      pointerEvents: "none",
      insetInline: "0",
      "--action-bar-offset": "spacing.4"
    },
    content: {
      bg: "bg.panel",
      shadow: "md",
      display: "flex",
      alignItems: "center",
      gap: "3",
      borderRadius: "l3",
      py: "2.5",
      px: "3",
      pointerEvents: "auto",
      // Stabilize the position of the action bar when the scrollbar is hidden
      // by using the scrollbar width to offset the position.
      translate: "calc(-1 * var(--scrollbar-width) / 2) 0px",
      _open: {
        animationName: "slide-from-bottom, fade-in",
        animationDuration: "moderate"
      },
      _closed: {
        animationName: "slide-to-bottom, fade-out",
        animationDuration: "faster"
      }
    },
    separator: {
      width: "1px",
      height: "5",
      bg: "border"
    },
    selectionTrigger: {
      display: "inline-flex",
      alignItems: "center",
      gap: "2",
      alignSelf: "stretch",
      textStyle: "sm",
      px: "4",
      py: "1",
      borderRadius: "l2",
      borderWidth: "1px",
      borderStyle: "dashed"
    }
  },
  variants: {
    placement: {
      bottom: {
        positioner: {
          bottom: "calc(env(safe-area-inset-bottom) + var(--action-bar-offset))",
          justifyContent: "center"
        }
      },
      "bottom-start": {
        positioner: {
          bottom: "calc(env(safe-area-inset-bottom) + var(--action-bar-offset))",
          justifyContent: "flex-start",
          ps: "var(--action-bar-offset)"
        }
      },
      "bottom-end": {
        positioner: {
          bottom: "calc(env(safe-area-inset-bottom) + var(--action-bar-offset))",
          justifyContent: "flex-end",
          pe: "var(--action-bar-offset)"
        }
      }
    }
  },
  defaultVariants: {
    placement: "bottom"
  }
});
const alertSlotRecipe = defineSlotRecipe({
  slots: alertAnatomy.keys(),
  className: "chakra-alert",
  base: {
    root: {
      width: "full",
      display: "flex",
      alignItems: "flex-start",
      position: "relative",
      borderRadius: "l3"
    },
    title: {
      fontWeight: "medium"
    },
    description: {
      display: "inline"
    },
    indicator: {
      display: "inline-flex",
      alignItems: "center",
      justifyContent: "center",
      flexShrink: "0",
      width: "1em",
      height: "1em",
      _icon: { boxSize: "full" }
    },
    content: {
      display: "flex",
      flex: "1",
      gap: "1"
    }
  },
  variants: {
    status: {
      info: {
        root: { colorPalette: "blue" }
      },
      warning: {
        root: { colorPalette: "orange" }
      },
      success: {
        root: { colorPalette: "green" }
      },
      error: {
        root: { colorPalette: "red" }
      },
      neutral: {
        root: { colorPalette: "gray" }
      }
    },
    inline: {
      true: {
        content: {
          display: "inline-flex",
          flexDirection: "row",
          alignItems: "center"
        }
      },
      false: {
        content: {
          display: "flex",
          flexDirection: "column"
        }
      }
    },
    variant: {
      subtle: {
        root: {
          bg: "colorPalette.subtle",
          color: "colorPalette.fg"
        }
      },
      surface: {
        root: {
          bg: "colorPalette.subtle",
          color: "colorPalette.fg",
          shadow: "inset 0 0 0px 1px var(--shadow-color)",
          shadowColor: "colorPalette.muted"
        },
        indicator: {
          color: "colorPalette.fg"
        }
      },
      outline: {
        root: {
          color: "colorPalette.fg",
          shadow: "inset 0 0 0px 1px var(--shadow-color)",
          "--outline-shadow-legacy": "colors.colorPalette.muted",
          "--outline-shadow": "colors.colorPalette.border",
          shadowColor: "var(--outline-shadow, var(--outline-shadow-legacy))"
        },
        indicator: {
          color: "colorPalette.fg"
        }
      },
      solid: {
        root: {
          bg: "colorPalette.solid",
          color: "colorPalette.contrast"
        },
        indicator: {
          color: "colorPalette.contrast"
        }
      }
    },
    size: {
      sm: {
        root: {
          gap: "2",
          px: "3",
          py: "3",
          textStyle: "xs"
        },
        indicator: {
          textStyle: "lg"
        }
      },
      md: {
        root: {
          gap: "3",
          px: "4",
          py: "4",
          textStyle: "sm"
        },
        indicator: {
          textStyle: "xl"
        }
      },
      lg: {
        root: {
          gap: "3",
          px: "4",
          py: "4",
          textStyle: "md"
        },
        indicator: {
          textStyle: "2xl"
        }
      }
    }
  },
  defaultVariants: {
    status: "info",
    variant: "subtle",
    size: "md",
    inline: false
  }
});
const avatarSlotRecipe = defineSlotRecipe({
  slots: anatomy$d.keys(),
  className: "chakra-avatar",
  base: {
    root: {
      display: "inline-flex",
      alignItems: "center",
      justifyContent: "center",
      fontWeight: "medium",
      position: "relative",
      verticalAlign: "top",
      flexShrink: "0",
      userSelect: "none",
      width: "var(--avatar-size)",
      height: "var(--avatar-size)",
      fontSize: "var(--avatar-font-size)",
      borderRadius: "var(--avatar-radius)",
      "&[data-group-item]": {
        borderWidth: "2px",
        borderColor: "bg"
      }
    },
    image: {
      width: "100%",
      height: "100%",
      objectFit: "cover",
      borderRadius: "var(--avatar-radius)"
    },
    fallback: {
      lineHeight: "1",
      textTransform: "uppercase",
      fontWeight: "medium",
      fontSize: "var(--avatar-font-size)",
      borderRadius: "var(--avatar-radius)"
    }
  },
  variants: {
    size: {
      full: {
        root: {
          "--avatar-size": "100%",
          "--avatar-font-size": "100%"
        }
      },
      "2xs": {
        root: {
          "--avatar-font-size": "fontSizes.2xs",
          "--avatar-size": "sizes.6"
        }
      },
      xs: {
        root: {
          "--avatar-font-size": "fontSizes.xs",
          "--avatar-size": "sizes.8"
        }
      },
      sm: {
        root: {
          "--avatar-font-size": "fontSizes.sm",
          "--avatar-size": "sizes.9"
        }
      },
      md: {
        root: {
          "--avatar-font-size": "fontSizes.md",
          "--avatar-size": "sizes.10"
        }
      },
      lg: {
        root: {
          "--avatar-font-size": "fontSizes.md",
          "--avatar-size": "sizes.11"
        }
      },
      xl: {
        root: {
          "--avatar-font-size": "fontSizes.lg",
          "--avatar-size": "sizes.12"
        }
      },
      "2xl": {
        root: {
          "--avatar-font-size": "fontSizes.xl",
          "--avatar-size": "sizes.16"
        }
      }
    },
    variant: {
      solid: {
        root: {
          bg: "colorPalette.solid",
          color: "colorPalette.contrast"
        }
      },
      subtle: {
        root: {
          bg: "colorPalette.muted",
          color: "colorPalette.fg"
        }
      },
      outline: {
        root: {
          color: "colorPalette.fg",
          borderWidth: "1px",
          "--outline-shadow-legacy": "colors.colorPalette.muted",
          "--outline-shadow": "colors.colorPalette.border",
          borderColor: "var(--outline-shadow, var(--outline-shadow-legacy))"
        }
      }
    },
    shape: {
      square: {},
      rounded: {
        root: { "--avatar-radius": "radii.l3" }
      },
      full: {
        root: { "--avatar-radius": "radii.full" }
      }
    },
    borderless: {
      true: {
        root: {
          "&[data-group-item]": {
            borderWidth: "0px"
          }
        }
      }
    }
  },
  defaultVariants: {
    size: "md",
    shape: "full",
    variant: "subtle"
  }
});
const blockquoteSlotRecipe = defineSlotRecipe({
  className: "chakra-blockquote",
  slots: blockquoteAnatomy.keys(),
  base: {
    root: {
      position: "relative",
      display: "flex",
      flexDirection: "column",
      gap: "2"
    },
    caption: {
      textStyle: "sm",
      color: "fg.muted"
    },
    icon: {
      boxSize: "5"
    }
  },
  variants: {
    justify: {
      start: {
        root: {
          alignItems: "flex-start",
          textAlign: "start"
        }
      },
      center: {
        root: {
          alignItems: "center",
          textAlign: "center"
        }
      },
      end: {
        root: {
          alignItems: "flex-end",
          textAlign: "end"
        }
      }
    },
    variant: {
      subtle: {
        root: {
          paddingX: "5",
          borderStartWidth: "4px",
          borderStartColor: "colorPalette.muted"
        },
        icon: {
          color: "colorPalette.fg"
        }
      },
      solid: {
        root: {
          paddingX: "5",
          borderStartWidth: "4px",
          borderStartColor: "colorPalette.solid"
        },
        icon: {
          color: "colorPalette.solid"
        }
      },
      plain: {
        root: {
          paddingX: "5"
        },
        icon: {
          color: "colorPalette.solid"
        }
      }
    }
  },
  defaultVariants: {
    variant: "subtle",
    justify: "start"
  }
});
const breadcrumbSlotRecipe = defineSlotRecipe({
  className: "chakra-breadcrumb",
  slots: breadcrumbAnatomy.keys(),
  base: {
    list: {
      display: "flex",
      alignItems: "center",
      wordBreak: "break-word",
      color: "fg.muted",
      listStyle: "none"
    },
    link: {
      outline: "0",
      textDecoration: "none",
      borderRadius: "l1",
      focusRing: "outside",
      display: "inline-flex",
      alignItems: "center",
      gap: "2"
    },
    item: {
      display: "inline-flex",
      alignItems: "center"
    },
    separator: {
      color: "fg.muted",
      opacity: "0.8",
      _icon: {
        boxSize: "1em"
      },
      _rtl: {
        rotate: "180deg"
      }
    },
    ellipsis: {
      display: "inline-flex",
      alignItems: "center",
      justifyContent: "center",
      _icon: {
        boxSize: "1em"
      }
    }
  },
  variants: {
    variant: {
      underline: {
        link: {
          color: "colorPalette.fg",
          textDecoration: "underline",
          textUnderlineOffset: "0.2em",
          textDecorationColor: "colorPalette.muted"
        },
        currentLink: {
          color: "colorPalette.fg"
        }
      },
      plain: {
        link: {
          color: "fg.muted",
          _hover: { color: "fg" }
        },
        currentLink: {
          color: "fg"
        }
      }
    },
    size: {
      sm: {
        list: {
          gap: "1",
          textStyle: "xs"
        }
      },
      md: {
        list: {
          gap: "1.5",
          textStyle: "sm"
        }
      },
      lg: {
        list: {
          gap: "2",
          textStyle: "md"
        }
      }
    }
  },
  defaultVariants: {
    variant: "plain",
    size: "md"
  }
});
const cardSlotRecipe = defineSlotRecipe({
  className: "chakra-card",
  slots: cardAnatomy.keys(),
  base: {
    root: {
      display: "flex",
      flexDirection: "column",
      position: "relative",
      minWidth: "0",
      wordWrap: "break-word",
      borderRadius: "l3",
      color: "fg",
      textAlign: "start"
    },
    title: {
      fontWeight: "semibold"
    },
    description: {
      color: "fg.muted",
      fontSize: "sm"
    },
    header: {
      paddingInline: "var(--card-padding)",
      paddingTop: "var(--card-padding)",
      display: "flex",
      flexDirection: "column",
      gap: "1.5"
    },
    body: {
      padding: "var(--card-padding)",
      flex: "1",
      display: "flex",
      flexDirection: "column"
    },
    footer: {
      display: "flex",
      alignItems: "center",
      gap: "2",
      paddingInline: "var(--card-padding)",
      paddingBottom: "var(--card-padding)"
    }
  },
  variants: {
    size: {
      sm: {
        root: {
          "--card-padding": "spacing.4"
        },
        title: {
          textStyle: "md"
        }
      },
      md: {
        root: {
          "--card-padding": "spacing.6"
        },
        title: {
          textStyle: "lg"
        }
      },
      lg: {
        root: {
          "--card-padding": "spacing.7"
        },
        title: {
          textStyle: "xl"
        }
      }
    },
    variant: {
      elevated: {
        root: {
          bg: "bg.panel",
          boxShadow: "md"
        }
      },
      outline: {
        root: {
          bg: "bg.panel",
          borderWidth: "1px",
          borderColor: "border"
        }
      },
      subtle: {
        root: {
          bg: "bg.muted"
        }
      }
    }
  },
  defaultVariants: {
    variant: "outline",
    size: "md"
  }
});
const carouselSlotRecipe = defineSlotRecipe({
  className: "carousel",
  slots: carouselAnatomy.keys(),
  base: {
    root: {
      position: "relative",
      display: "flex",
      gap: "2",
      _horizontal: {
        flexDirection: "column"
      },
      _vertical: {
        flexDirection: "row"
      }
    },
    item: {
      _horizontal: {
        width: "100%"
      },
      _vertical: {
        height: "100%"
      }
    },
    control: {
      display: "flex",
      alignItems: "center",
      _horizontal: {
        flexDirection: "row",
        width: "100%"
      },
      _vertical: {
        flexDirection: "column",
        height: "100%"
      }
    },
    indicatorGroup: {
      display: "flex",
      justifyContent: "center",
      gap: "3",
      _horizontal: {
        flexDirection: "row"
      },
      _vertical: {
        flexDirection: "column"
      }
    },
    indicator: {
      width: "2.5",
      height: "2.5",
      borderRadius: "full",
      bg: "colorPalette.subtle",
      cursor: "button",
      _current: {
        bg: "colorPalette.solid"
      }
    }
  },
  defaultVariants: {}
});
const checkboxSlotRecipe = defineSlotRecipe({
  slots: checkboxAnatomy.keys(),
  className: "chakra-checkbox",
  base: {
    root: {
      display: "inline-flex",
      gap: "2",
      alignItems: "center",
      verticalAlign: "top",
      position: "relative"
    },
    control: checkmarkRecipe.base,
    label: {
      fontWeight: "medium",
      userSelect: "none",
      _disabled: {
        opacity: "0.5"
      }
    }
  },
  variants: {
    size: {
      xs: {
        root: { gap: "1.5" },
        label: { textStyle: "xs" },
        control: checkmarkRecipe.variants?.size?.xs
      },
      sm: {
        root: { gap: "2" },
        label: { textStyle: "sm" },
        control: checkmarkRecipe.variants?.size?.sm
      },
      md: {
        root: { gap: "2.5" },
        label: { textStyle: "sm" },
        control: checkmarkRecipe.variants?.size?.md
      },
      lg: {
        root: { gap: "3" },
        label: { textStyle: "md" },
        control: checkmarkRecipe.variants?.size?.lg
      }
    },
    variant: {
      outline: {
        control: checkmarkRecipe.variants?.variant?.outline
      },
      solid: {
        control: checkmarkRecipe.variants?.variant?.solid
      },
      subtle: {
        control: checkmarkRecipe.variants?.variant?.subtle
      }
    }
  },
  defaultVariants: {
    variant: "solid",
    size: "md"
  }
});
const checkboxCardSlotRecipe = defineSlotRecipe({
  slots: checkboxCardAnatomy.keys(),
  className: "chakra-checkbox-card",
  base: {
    root: {
      display: "flex",
      flexDirection: "column",
      userSelect: "none",
      position: "relative",
      borderRadius: "l2",
      flex: "1",
      focusVisibleRing: "outside",
      _disabled: {
        opacity: "0.8"
      },
      _invalid: {
        outline: "2px solid",
        outlineColor: "border.error"
      }
    },
    control: {
      display: "inline-flex",
      flex: "1",
      position: "relative",
      borderRadius: "inherit",
      justifyContent: "var(--checkbox-card-justify)",
      alignItems: "var(--checkbox-card-align)"
    },
    label: {
      fontWeight: "medium",
      display: "flex",
      alignItems: "center",
      gap: "2",
      flex: "1",
      _disabled: {
        opacity: "0.5"
      }
    },
    description: {
      opacity: "0.64",
      textStyle: "sm",
      _disabled: {
        opacity: "0.5"
      }
    },
    addon: {
      _disabled: {
        opacity: "0.5"
      }
    },
    indicator: checkmarkRecipe.base,
    content: {
      display: "flex",
      flexDirection: "column",
      flex: "1",
      gap: "1",
      justifyContent: "var(--checkbox-card-justify)",
      alignItems: "var(--checkbox-card-align)"
    }
  },
  variants: {
    size: {
      sm: {
        root: {
          textStyle: "sm"
        },
        control: {
          padding: "3",
          gap: "1.5"
        },
        addon: {
          px: "3",
          py: "1.5",
          borderTopWidth: "1px"
        },
        indicator: checkmarkRecipe.variants?.size.sm
      },
      md: {
        root: {
          textStyle: "sm"
        },
        control: {
          padding: "4",
          gap: "2.5"
        },
        addon: {
          px: "4",
          py: "2",
          borderTopWidth: "1px"
        },
        indicator: checkmarkRecipe.variants?.size.md
      },
      lg: {
        root: {
          textStyle: "md"
        },
        control: {
          padding: "4",
          gap: "3.5"
        },
        addon: {
          px: "4",
          py: "2",
          borderTopWidth: "1px"
        },
        indicator: checkmarkRecipe.variants?.size.lg
      }
    },
    variant: {
      surface: {
        root: {
          borderWidth: "1px",
          borderColor: "border",
          _checked: {
            bg: "colorPalette.subtle",
            color: "colorPalette.fg",
            borderColor: "colorPalette.muted"
          },
          _disabled: {
            bg: "bg.muted"
          }
        },
        indicator: checkmarkRecipe.variants?.variant.solid
      },
      subtle: {
        root: {
          bg: "bg.muted"
        },
        control: {
          _checked: {
            bg: "colorPalette.muted",
            color: "colorPalette.fg"
          }
        },
        indicator: checkmarkRecipe.variants?.variant.plain
      },
      outline: {
        root: {
          borderWidth: "1px",
          borderColor: "border",
          _checked: {
            boxShadow: "0 0 0 1px var(--shadow-color)",
            boxShadowColor: "colorPalette.solid",
            borderColor: "colorPalette.solid"
          }
        },
        indicator: checkmarkRecipe.variants?.variant.solid
      },
      solid: {
        root: {
          borderWidth: "1px",
          _checked: {
            bg: "colorPalette.solid",
            color: "colorPalette.contrast",
            borderColor: "colorPalette.solid"
          }
        },
        indicator: checkmarkRecipe.variants?.variant.inverted
      }
    },
    justify: {
      start: {
        root: { "--checkbox-card-justify": "flex-start" }
      },
      end: {
        root: { "--checkbox-card-justify": "flex-end" }
      },
      center: {
        root: { "--checkbox-card-justify": "center" }
      }
    },
    align: {
      start: {
        root: { "--checkbox-card-align": "flex-start" },
        content: { textAlign: "start" }
      },
      end: {
        root: { "--checkbox-card-align": "flex-end" },
        content: { textAlign: "end" }
      },
      center: {
        root: { "--checkbox-card-align": "center" },
        content: { textAlign: "center" }
      }
    },
    orientation: {
      vertical: {
        control: { flexDirection: "column" }
      },
      horizontal: {
        control: { flexDirection: "row" }
      }
    }
  },
  defaultVariants: {
    size: "md",
    variant: "outline",
    align: "start",
    orientation: "horizontal"
  }
});
const codeBlockSlotRecipe = defineSlotRecipe({
  slots: codeBlockAnatomy.keys(),
  className: "code-block",
  base: {
    root: {
      colorPalette: "gray",
      rounded: "var(--code-block-radius)",
      overflow: "hidden",
      bg: "bg",
      color: "fg",
      borderWidth: "1px",
      "--code-block-max-height": "320px",
      "--code-block-bg": "colors.bg",
      "--code-block-fg": "colors.fg",
      "--code-block-obscured-opacity": "0.5",
      "--code-block-obscured-blur": "1px",
      "--code-block-line-number-width": "sizes.3",
      "--code-block-line-number-margin": "spacing.4",
      "--code-block-highlight-bg": "{colors.teal.focusRing/20}",
      "--code-block-highlight-border": "colors.teal.focusRing",
      "--code-block-highlight-added-bg": "{colors.green.focusRing/20}",
      "--code-block-highlight-added-border": "colors.green.focusRing",
      "--code-block-highlight-removed-bg": "{colors.red.focusRing/20}",
      "--code-block-highlight-removed-border": "colors.red.focusRing"
    },
    header: {
      display: "flex",
      alignItems: "center",
      gap: "2",
      position: "relative",
      px: "var(--code-block-padding)",
      minH: "var(--code-block-header-height)",
      mb: "calc(var(--code-block-padding) / 2 * -1)"
    },
    title: {
      display: "inline-flex",
      alignItems: "center",
      gap: "1.5",
      flex: "1",
      color: "fg.muted"
    },
    control: {
      gap: "1.5",
      display: "inline-flex",
      alignItems: "center"
    },
    footer: {
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      gap: "2",
      px: "var(--code-block-padding)",
      minH: "var(--code-block-header-height)"
    },
    content: {
      position: "relative",
      colorScheme: "dark",
      overflowX: "auto",
      overflowY: "hidden",
      borderBottomRadius: "var(--code-block-radius)",
      maxHeight: "var(--code-block-max-height)",
      "& ::selection": {
        bg: "blue.500/40"
      },
      _expanded: {
        maxHeight: "unset"
      }
    },
    overlay: {
      "--bg": "{colors.black/50}",
      display: "flex",
      alignItems: "flex-end",
      justifyContent: "center",
      padding: "4",
      bgImage: "linear-gradient(0deg,var(--bg) 25%,transparent 100%)",
      color: "white",
      minH: "5rem",
      pos: "absolute",
      bottom: "0",
      insetInline: "0",
      zIndex: "1",
      fontWeight: "medium",
      _expanded: {
        display: "none"
      }
    },
    code: {
      fontFamily: "mono",
      lineHeight: "tall",
      whiteSpace: "pre",
      counterReset: "line 0"
    },
    codeText: {
      px: "var(--code-block-padding)",
      py: "var(--code-block-padding)",
      position: "relative",
      display: "block",
      width: "100%",
      "&[data-has-focused]": {
        "& [data-line]:not([data-focused])": {
          transitionProperty: "opacity, filter",
          transitionDuration: "moderate",
          transitionTimingFunction: "ease-in-out",
          opacity: "var(--code-block-obscured-opacity)",
          filter: "blur(var(--code-block-obscured-blur))"
        },
        "&:hover": {
          "--code-block-obscured-opacity": "1",
          "--code-block-obscured-blur": "0px"
        }
      },
      "&[data-has-line-numbers][data-plaintext]": {
        paddingInlineStart: "calc(var(--code-block-line-number-width) + var(--code-block-line-number-margin) + var(--code-block-padding))"
      },
      "& [data-line]": {
        position: "relative",
        paddingInlineEnd: "var(--code-block-padding)",
        "--highlight-bg": "var(--code-block-highlight-bg)",
        "--highlight-border": "var(--code-block-highlight-border)",
        "&[data-highlight], &[data-diff]": {
          display: "inline-block",
          width: "full",
          "&:after": {
            content: `''`,
            display: "block",
            position: "absolute",
            top: "0",
            insetStart: "calc(var(--code-block-padding) * -1)",
            insetEnd: "0px",
            width: "calc(100% + var(--code-block-padding) * 2)",
            height: "100%",
            bg: "var(--highlight-bg)",
            borderStartWidth: "2px",
            borderStartColor: "var(--highlight-border)"
          }
        },
        "&[data-diff='added']": {
          "--highlight-bg": "var(--code-block-highlight-added-bg)",
          "--highlight-border": "var(--code-block-highlight-added-border)"
        },
        "&[data-diff='removed']": {
          "--highlight-bg": "var(--code-block-highlight-removed-bg)",
          "--highlight-border": "var(--code-block-highlight-removed-border)"
        }
      },
      "&[data-word-wrap]": {
        "&[data-plaintext], & [data-line]": {
          whiteSpace: "pre-wrap",
          wordBreak: "break-all"
        }
      },
      "&[data-has-line-numbers]": {
        "--content": "counter(line)",
        "& [data-line]:before": {
          content: "var(--content)",
          counterIncrement: "line",
          width: "var(--code-block-line-number-width)",
          marginRight: "var(--code-block-line-number-margin)",
          display: "inline-block",
          textAlign: "end",
          userSelect: "none",
          whiteSpace: "nowrap",
          opacity: 0.4
        },
        "& [data-diff='added']:before": {
          content: "'+'"
        },
        "& [data-diff='removed']:before": {
          content: "'-'"
        }
      }
    }
  },
  variants: {
    size: {
      sm: {
        root: {
          "--code-block-padding": "spacing.4",
          "--code-block-radius": "radii.md",
          "--code-block-header-height": "sizes.8"
        },
        title: {
          textStyle: "xs"
        },
        code: {
          fontSize: "xs"
        }
      },
      md: {
        root: {
          "--code-block-padding": "spacing.4",
          "--code-block-radius": "radii.lg",
          "--code-block-header-height": "sizes.10"
        },
        title: {
          textStyle: "xs"
        },
        code: {
          fontSize: "sm"
        }
      },
      lg: {
        root: {
          "--code-block-padding": "spacing.5",
          "--code-block-radius": "radii.xl",
          "--code-block-header-height": "sizes.12"
        },
        title: {
          textStyle: "sm"
        },
        code: {
          fontSize: "sm"
        }
      }
    }
  },
  defaultVariants: {
    size: "md"
  }
});
const collapsibleSlotRecipe = defineSlotRecipe({
  slots: anatomy$e.keys(),
  className: "chakra-collapsible",
  base: {
    content: {
      overflow: "hidden",
      _open: {
        animationName: "expand-height, fade-in",
        animationDuration: "moderate",
        "&[data-has-collapsed-size]": {
          animationName: "expand-height"
        }
      },
      _closed: {
        animationName: "collapse-height, fade-out",
        animationDuration: "moderate",
        "&[data-has-collapsed-size]": {
          animationName: "collapse-height"
        }
      }
    }
  }
});
const colorPickerSlotRecipe = defineSlotRecipe({
  className: "colorPicker",
  slots: colorPickerAnatomy.keys(),
  base: {
    root: {
      display: "flex",
      flexDirection: "column",
      gap: "1.5"
    },
    label: {
      color: "fg",
      fontWeight: "medium",
      textStyle: "sm",
      _disabled: {
        opacity: "0.5"
      }
    },
    valueText: {
      textAlign: "start"
    },
    control: {
      display: "flex",
      alignItems: "center",
      flexDirection: "row",
      gap: "2",
      position: "relative"
    },
    swatchTrigger: {
      display: "flex",
      alignItems: "center",
      justifyContent: "center"
    },
    trigger: {
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      flexDirection: "row",
      flexShrink: "0",
      gap: "2",
      textStyle: "sm",
      minH: "var(--input-height)",
      minW: "var(--input-height)",
      px: "1",
      rounded: "l2",
      _disabled: { opacity: "0.5" },
      "--focus-color": "colors.colorPalette.focusRing",
      "&:focus-visible": {
        borderColor: "var(--focus-color)",
        outline: "1px solid var(--focus-color)"
      },
      "&[data-fit-content]": {
        "--input-height": "unset",
        px: "0",
        border: "0"
      }
    },
    content: {
      display: "flex",
      flexDirection: "column",
      bg: "bg.panel",
      borderRadius: "l3",
      boxShadow: "lg",
      width: "64",
      p: "4",
      gap: "3",
      "--color-picker-z-index": "zIndex.popover",
      zIndex: "calc(var(--color-picker-z-index) + var(--layer-index, 0))",
      _open: {
        animationStyle: "slide-fade-in",
        animationDuration: "fast"
      },
      _closed: {
        animationStyle: "slide-fade-out",
        animationDuration: "faster"
      }
    },
    area: {
      height: "180px",
      borderRadius: "l2",
      overflow: "hidden"
    },
    areaThumb: {
      borderRadius: "full",
      height: "var(--thumb-size)",
      width: "var(--thumb-size)",
      borderWidth: "2px",
      borderColor: "white",
      shadow: "sm",
      focusVisibleRing: "mixed",
      focusRingColor: "white"
    },
    areaBackground: {
      height: "full"
    },
    channelSlider: {
      borderRadius: "l2",
      flex: "1"
    },
    channelSliderTrack: {
      height: "var(--slider-height)",
      borderRadius: "inherit",
      boxShadow: "inset 0 0 0 1px rgba(0,0,0,0.1)"
    },
    channelText: {
      textStyle: "xs",
      color: "fg.muted",
      fontWeight: "medium",
      textTransform: "capitalize"
    },
    swatchGroup: {
      display: "flex",
      flexDirection: "row",
      flexWrap: "wrap",
      gap: "2"
    },
    swatch: {
      ...colorSwatchRecipe.base,
      borderRadius: "l1"
    },
    swatchIndicator: {
      color: "white",
      rounded: "full"
    },
    channelSliderThumb: {
      borderRadius: "full",
      height: "var(--thumb-size)",
      width: "var(--thumb-size)",
      borderWidth: "2px",
      borderColor: "white",
      shadow: "sm",
      transform: "translate(-50%, -50%)",
      focusVisibleRing: "outside",
      focusRingOffset: "1px"
    },
    channelInput: {
      ...inputRecipe.base,
      "&::-webkit-inner-spin-button, &::-webkit-outer-spin-button": {
        WebkitAppearance: "none",
        margin: 0
      }
    },
    formatSelect: {
      textStyle: "xs",
      textTransform: "uppercase",
      borderWidth: "1px",
      minH: "6",
      focusRing: "inside",
      rounded: "l2"
    },
    transparencyGrid: {
      borderRadius: "l2"
    },
    view: {
      display: "flex",
      flexDirection: "column",
      gap: "2"
    }
  },
  variants: {
    size: {
      "2xs": {
        channelInput: inputRecipe.variants?.size?.["2xs"],
        swatch: { "--swatch-size": "sizes.4.5" },
        trigger: { "--input-height": "sizes.7" },
        area: { "--thumb-size": "sizes.3" },
        channelSlider: {
          "--slider-height": "sizes.3",
          "--thumb-size": "sizes.3"
        }
      },
      xs: {
        channelInput: inputRecipe.variants?.size?.xs,
        swatch: { "--swatch-size": "sizes.5" },
        trigger: { "--input-height": "sizes.8" },
        area: { "--thumb-size": "sizes.3.5" },
        channelSlider: {
          "--slider-height": "sizes.3.5",
          "--thumb-size": "sizes.3.5"
        }
      },
      sm: {
        channelInput: inputRecipe.variants?.size?.sm,
        swatch: { "--swatch-size": "sizes.6" },
        trigger: { "--input-height": "sizes.9" },
        area: { "--thumb-size": "sizes.3.5" },
        channelSlider: {
          "--slider-height": "sizes.3.5",
          "--thumb-size": "sizes.3.5"
        }
      },
      md: {
        channelInput: inputRecipe.variants?.size?.md,
        swatch: { "--swatch-size": "sizes.7" },
        trigger: { "--input-height": "sizes.10" },
        area: { "--thumb-size": "sizes.3.5" },
        channelSlider: {
          "--slider-height": "sizes.3.5",
          "--thumb-size": "sizes.3.5"
        }
      },
      lg: {
        channelInput: inputRecipe.variants?.size?.lg,
        swatch: { "--swatch-size": "sizes.7" },
        trigger: { "--input-height": "sizes.11" },
        area: { "--thumb-size": "sizes.3.5" },
        channelSlider: {
          "--slider-height": "sizes.3.5",
          "--thumb-size": "sizes.3.5"
        }
      },
      xl: {
        channelInput: inputRecipe.variants?.size?.xl,
        swatch: { "--swatch-size": "sizes.8" },
        trigger: { "--input-height": "sizes.12" },
        area: { "--thumb-size": "sizes.3.5" },
        channelSlider: {
          "--slider-height": "sizes.3.5",
          "--thumb-size": "sizes.3.5"
        }
      },
      "2xl": {
        channelInput: inputRecipe.variants?.size?.["2xl"],
        swatch: { "--swatch-size": "sizes.10" },
        trigger: { "--input-height": "sizes.16" },
        area: { "--thumb-size": "sizes.3.5" },
        channelSlider: {
          "--slider-height": "sizes.3.5",
          "--thumb-size": "sizes.3.5"
        }
      }
    },
    variant: {
      outline: {
        channelInput: inputRecipe.variants?.variant?.outline,
        trigger: {
          borderWidth: "1px"
        }
      },
      subtle: {
        channelInput: inputRecipe.variants?.variant?.subtle,
        trigger: {
          borderWidth: "1px",
          borderColor: "transparent",
          bg: "bg.muted"
        }
      }
    }
  },
  defaultVariants: {
    size: "md",
    variant: "outline"
  }
});
const comboboxSlotRecipe = defineSlotRecipe({
  className: "chakra-combobox",
  slots: comboboxAnatomy.keys(),
  base: {
    root: {
      display: "flex",
      flexDirection: "column",
      gap: "1.5",
      width: "full"
    },
    label: {
      fontWeight: "medium",
      userSelect: "none",
      textStyle: "sm",
      _disabled: {
        layerStyle: "disabled"
      }
    },
    control: {
      pos: "relative",
      "--padding-factor": "1",
      "--combobox-input-padding-end": "var(--combobox-input-padding-x)",
      "&:has([data-part=trigger]), &:has([data-part=clear-trigger])": {
        "--combobox-input-padding-end": "calc(var(--combobox-input-height) * var(--padding-factor))"
      },
      "&:has([data-part=trigger]):has([data-part=clear-trigger]:not([hidden]))": {
        "--padding-factor": "1.5"
      }
    },
    input: {
      display: "flex",
      alignItems: "center",
      justifyContent: "space-between",
      background: "bg.panel",
      width: "full",
      minH: "var(--combobox-input-height)",
      ps: "var(--combobox-input-padding-x)",
      pe: "var(--combobox-input-padding-end)",
      "--input-height": "var(--combobox-input-height)",
      borderRadius: "l2",
      outline: 0,
      userSelect: "none",
      textAlign: "start",
      _placeholderShown: {
        color: "fg.muted"
      },
      _disabled: {
        layerStyle: "disabled"
      },
      "--focus-color": "colors.colorPalette.focusRing",
      "--error-color": "colors.border.error",
      _invalid: {
        focusRingColor: "var(--error-color)",
        borderColor: "var(--error-color)"
      }
    },
    trigger: {
      display: "inline-flex",
      alignItems: "center",
      justifyContent: "center",
      "--input-height": "var(--combobox-input-height)"
    },
    clearTrigger: {
      color: "fg.muted",
      pointerEvents: "auto",
      focusVisibleRing: "inside",
      focusRingWidth: "2px",
      rounded: "l1"
    },
    indicatorGroup: {
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      gap: "1",
      pos: "absolute",
      insetEnd: "0",
      top: "0",
      bottom: "0",
      px: "var(--combobox-input-padding-x)",
      _icon: {
        boxSize: "var(--combobox-indicator-size)"
      },
      "[data-disabled] &": {
        opacity: 0.5
      }
    },
    content: {
      background: "bg.panel",
      display: "flex",
      flexDirection: "column",
      "--combobox-z-index": "zIndex.popover",
      zIndex: "calc(var(--combobox-z-index) + var(--layer-index, 0))",
      borderRadius: "l2",
      outline: 0,
      maxH: "96",
      overflowY: "auto",
      boxShadow: "md",
      _open: {
        animationStyle: "slide-fade-in",
        animationDuration: "fast"
      },
      _closed: {
        animationStyle: "slide-fade-out",
        animationDuration: "0s"
      },
      "&[data-empty]:not(:has([data-scope=combobox][data-part=empty]))": {
        opacity: 0
      }
    },
    item: {
      position: "relative",
      userSelect: "none",
      display: "flex",
      alignItems: "center",
      gap: "2",
      py: "var(--combobox-item-padding-y)",
      px: "var(--combobox-item-padding-x)",
      cursor: "option",
      justifyContent: "space-between",
      flex: "1",
      textAlign: "start",
      borderRadius: "l1",
      _highlighted: {
        bg: "bg.emphasized/60"
      },
      _disabled: {
        pointerEvents: "none",
        opacity: "0.5"
      },
      _icon: {
        boxSize: "var(--combobox-indicator-size)"
      }
    },
    empty: {
      py: "var(--combobox-item-padding-y)",
      px: "var(--combobox-item-padding-x)"
    },
    itemText: {
      flex: "1"
    },
    itemGroup: {
      pb: "var(--combobox-item-padding-y)",
      _last: {
        pb: "0"
      }
    },
    itemGroupLabel: {
      fontWeight: "medium",
      py: "var(--combobox-item-padding-y)",
      px: "var(--combobox-item-padding-x)"
    }
  },
  variants: {
    variant: {
      outline: {
        input: {
          bg: "transparent",
          borderWidth: "1px",
          borderColor: "border",
          focusVisibleRing: "inside"
        }
      },
      subtle: {
        input: {
          borderWidth: "1px",
          borderColor: "transparent",
          bg: "bg.muted",
          focusVisibleRing: "inside"
        }
      },
      flushed: {
        input: {
          bg: "transparent",
          borderBottomWidth: "1px",
          borderBottomColor: "border",
          borderRadius: "0",
          px: "0",
          _focusVisible: {
            borderColor: "var(--focus-color)",
            boxShadow: "0px 1px 0px 0px var(--focus-color)"
          }
        },
        indicatorGroup: {
          px: "0"
        }
      }
    },
    size: {
      xs: {
        root: {
          "--combobox-input-height": "sizes.8",
          "--combobox-input-padding-x": "spacing.2",
          "--combobox-indicator-size": "sizes.3.5"
        },
        input: {
          textStyle: "xs"
        },
        content: {
          "--combobox-item-padding-x": "spacing.1.5",
          "--combobox-item-padding-y": "spacing.1",
          "--combobox-indicator-size": "sizes.3.5",
          p: "1",
          textStyle: "xs"
        },
        trigger: {
          textStyle: "xs",
          gap: "1"
        }
      },
      sm: {
        root: {
          "--combobox-input-height": "sizes.9",
          "--combobox-input-padding-x": "spacing.2.5",
          "--combobox-indicator-size": "sizes.4"
        },
        input: {
          textStyle: "sm"
        },
        content: {
          "--combobox-item-padding-x": "spacing.2",
          "--combobox-item-padding-y": "spacing.1.5",
          "--combobox-indicator-size": "sizes.4",
          p: "1",
          textStyle: "sm"
        },
        trigger: {
          textStyle: "sm",
          gap: "1"
        }
      },
      md: {
        root: {
          "--combobox-input-height": "sizes.10",
          "--combobox-input-padding-x": "spacing.3",
          "--combobox-indicator-size": "sizes.4"
        },
        input: {
          textStyle: "sm"
        },
        content: {
          "--combobox-item-padding-x": "spacing.2",
          "--combobox-item-padding-y": "spacing.1.5",
          "--combobox-indicator-size": "sizes.4",
          p: "1",
          textStyle: "sm"
        },
        itemIndicator: {
          display: "flex",
          alignItems: "center",
          justifyContent: "center"
        },
        trigger: {
          textStyle: "sm",
          gap: "2"
        }
      },
      lg: {
        root: {
          "--combobox-input-height": "sizes.12",
          "--combobox-input-padding-x": "spacing.4",
          "--combobox-indicator-size": "sizes.5"
        },
        input: {
          textStyle: "md"
        },
        content: {
          "--combobox-item-padding-y": "spacing.2",
          "--combobox-item-padding-x": "spacing.3",
          "--combobox-indicator-size": "sizes.5",
          p: "1.5",
          textStyle: "md"
        },
        trigger: {
          textStyle: "md",
          py: "3",
          gap: "2"
        }
      }
    }
  },
  defaultVariants: {
    size: "md",
    variant: "outline"
  }
});
const dataListSlotRecipe = defineSlotRecipe({
  slots: dataListAnatomy.keys(),
  className: "chakra-data-list",
  base: {
    itemLabel: {
      display: "flex",
      alignItems: "center",
      gap: "1"
    },
    itemValue: {
      display: "flex",
      minWidth: "0",
      flex: "1"
    }
  },
  variants: {
    orientation: {
      horizontal: {
        root: {
          display: "flex",
          flexDirection: "column"
        },
        item: {
          display: "inline-flex",
          alignItems: "center",
          gap: "4"
        },
        itemLabel: {
          minWidth: "120px"
        }
      },
      vertical: {
        root: {
          display: "flex",
          flexDirection: "column"
        },
        item: {
          display: "flex",
          flexDirection: "column",
          gap: "1"
        }
      }
    },
    size: {
      sm: {
        root: {
          gap: "3"
        },
        item: {
          textStyle: "xs"
        }
      },
      md: {
        root: {
          gap: "4"
        },
        item: {
          textStyle: "sm"
        }
      },
      lg: {
        root: {
          gap: "5"
        },
        item: {
          textStyle: "md"
        }
      }
    },
    variant: {
      subtle: {
        itemLabel: {
          color: "fg.muted"
        }
      },
      bold: {
        itemLabel: {
          fontWeight: "medium"
        },
        itemValue: {
          color: "fg.muted"
        }
      }
    }
  },
  defaultVariants: {
    size: "md",
    orientation: "vertical",
    variant: "subtle"
  }
});
const dialogSlotRecipe = defineSlotRecipe({
  slots: dialogAnatomy.keys(),
  className: "chakra-dialog",
  base: {
    backdrop: {
      bg: "blackAlpha.500",
      pos: "fixed",
      left: 0,
      top: 0,
      w: "100dvw",
      h: "100dvh",
      zIndex: "var(--z-index)",
      _open: {
        animationName: "fade-in",
        animationDuration: "slow"
      },
      _closed: {
        animationName: "fade-out",
        animationDuration: "moderate"
      }
    },
    positioner: {
      display: "flex",
      width: "100dvw",
      height: "100dvh",
      position: "fixed",
      left: 0,
      top: 0,
      "--dialog-z-index": "zIndex.modal",
      zIndex: "calc(var(--dialog-z-index) + var(--layer-index, 0))",
      justifyContent: "center",
      overscrollBehaviorY: "none"
    },
    content: {
      display: "flex",
      flexDirection: "column",
      position: "relative",
      width: "100%",
      outline: 0,
      borderRadius: "l3",
      textStyle: "sm",
      my: "var(--dialog-margin, var(--dialog-base-margin))",
      "--dialog-z-index": "zIndex.modal",
      zIndex: "calc(var(--dialog-z-index) + var(--layer-index, 0))",
      bg: "bg.panel",
      boxShadow: "lg",
      _open: {
        animationDuration: "moderate"
      },
      _closed: {
        animationDuration: "faster"
      }
    },
    header: {
      display: "flex",
      gap: "2",
      flex: 0,
      px: "6",
      pt: "6",
      pb: "4"
    },
    body: {
      flex: "1",
      px: "6",
      pt: "2",
      pb: "6"
    },
    footer: {
      display: "flex",
      alignItems: "center",
      justifyContent: "flex-end",
      gap: "3",
      px: "6",
      pt: "2",
      pb: "4"
    },
    title: {
      textStyle: "lg",
      fontWeight: "semibold"
    },
    description: {
      color: "fg.muted"
    },
    closeTrigger: {
      pos: "absolute",
      top: "2",
      insetEnd: "2"
    }
  },
  variants: {
    placement: {
      center: {
        positioner: {
          alignItems: "center"
        },
        content: {
          "--dialog-base-margin": "auto",
          mx: "auto"
        }
      },
      top: {
        positioner: {
          alignItems: "flex-start"
        },
        content: {
          "--dialog-base-margin": "spacing.16",
          mx: "auto"
        }
      },
      bottom: {
        positioner: {
          alignItems: "flex-end"
        },
        content: {
          "--dialog-base-margin": "spacing.16",
          mx: "auto"
        }
      }
    },
    scrollBehavior: {
      inside: {
        positioner: {
          overflow: "hidden"
        },
        content: {
          maxH: "calc(100% - 7.5rem)"
        },
        body: {
          overflow: "auto"
        }
      },
      outside: {
        positioner: {
          overflow: "auto",
          pointerEvents: "auto"
        }
      }
    },
    size: {
      xs: {
        content: {
          maxW: "sm"
        }
      },
      sm: {
        content: {
          maxW: "md"
        }
      },
      md: {
        content: {
          maxW: "lg"
        }
      },
      lg: {
        content: {
          maxW: "2xl"
        }
      },
      xl: {
        content: {
          maxW: "4xl"
        }
      },
      cover: {
        positioner: {
          padding: "10"
        },
        content: {
          width: "100%",
          height: "100%",
          "--dialog-margin": "0"
        }
      },
      full: {
        content: {
          maxW: "100dvw",
          minH: "100dvh",
          "--dialog-margin": "0",
          borderRadius: "0"
        }
      }
    },
    motionPreset: {
      scale: {
        content: {
          _open: { animationName: "scale-in, fade-in" },
          _closed: { animationName: "scale-out, fade-out" }
        }
      },
      "slide-in-bottom": {
        content: {
          _open: { animationName: "slide-from-bottom, fade-in" },
          _closed: { animationName: "slide-to-bottom, fade-out" }
        }
      },
      "slide-in-top": {
        content: {
          _open: { animationName: "slide-from-top, fade-in" },
          _closed: { animationName: "slide-to-top, fade-out" }
        }
      },
      "slide-in-left": {
        content: {
          _open: { animationName: "slide-from-left, fade-in" },
          _closed: { animationName: "slide-to-left, fade-out" }
        }
      },
      "slide-in-right": {
        content: {
          _open: { animationName: "slide-from-right, fade-in" },
          _closed: { animationName: "slide-to-right, fade-out" }
        }
      },
      none: {}
    }
  },
  defaultVariants: {
    size: "md",
    scrollBehavior: "outside",
    placement: "top",
    motionPreset: "scale"
  }
});
const drawerSlotRecipe = defineSlotRecipe({
  slots: drawerAnatomy.keys(),
  className: "chakra-drawer",
  base: {
    backdrop: {
      bg: "blackAlpha.500",
      pos: "fixed",
      insetInlineStart: 0,
      top: 0,
      w: "100vw",
      h: "100dvh",
      zIndex: "overlay",
      _open: {
        animationName: "fade-in",
        animationDuration: "slow"
      },
      _closed: {
        animationName: "fade-out",
        animationDuration: "moderate"
      }
    },
    positioner: {
      display: "flex",
      width: "100vw",
      height: "100dvh",
      position: "fixed",
      insetInlineStart: 0,
      top: 0,
      zIndex: "modal",
      overscrollBehaviorY: "none"
    },
    content: {
      display: "flex",
      flexDirection: "column",
      position: "relative",
      width: "100%",
      outline: 0,
      zIndex: "modal",
      textStyle: "sm",
      maxH: "100dvh",
      color: "inherit",
      bg: "bg.panel",
      boxShadow: "lg",
      _open: {
        animationDuration: "slowest",
        animationTimingFunction: "ease-in-smooth"
      },
      _closed: {
        animationDuration: "slower",
        animationTimingFunction: "ease-in-smooth"
      }
    },
    header: {
      display: "flex",
      alignItems: "center",
      gap: "2",
      flex: 0,
      px: "6",
      pt: "6",
      pb: "4"
    },
    body: {
      px: "6",
      py: "2",
      flex: "1",
      overflow: "auto"
    },
    footer: {
      display: "flex",
      alignItems: "center",
      justifyContent: "flex-end",
      gap: "3",
      px: "6",
      pt: "2",
      pb: "4"
    },
    title: {
      flex: "1",
      textStyle: "lg",
      fontWeight: "semibold"
    },
    description: {
      color: "fg.muted"
    },
    closeTrigger: {
      pos: "absolute",
      top: "3",
      insetEnd: "2"
    }
  },
  variants: {
    size: {
      xs: {
        content: {
          maxW: "xs"
        }
      },
      sm: {
        content: {
          maxW: "md"
        }
      },
      md: {
        content: {
          maxW: "lg"
        }
      },
      lg: {
        content: {
          maxW: "2xl"
        }
      },
      xl: {
        content: {
          maxW: "4xl"
        }
      },
      full: {
        content: {
          maxW: "100vw",
          h: "100dvh"
        }
      }
    },
    placement: {
      start: {
        positioner: {
          justifyContent: "flex-start",
          alignItems: "stretch"
        },
        content: {
          _open: {
            animationName: {
              base: "slide-from-left-full, fade-in",
              _rtl: "slide-from-right-full, fade-in"
            }
          },
          _closed: {
            animationName: {
              base: "slide-to-left-full, fade-out",
              _rtl: "slide-to-right-full, fade-out"
            }
          }
        }
      },
      end: {
        positioner: {
          justifyContent: "flex-end",
          alignItems: "stretch"
        },
        content: {
          _open: {
            animationName: {
              base: "slide-from-right-full, fade-in",
              _rtl: "slide-from-left-full, fade-in"
            }
          },
          _closed: {
            animationName: {
              base: "slide-to-right-full, fade-out",
              _rtl: "slide-to-left-full, fade-out"
            }
          }
        }
      },
      top: {
        positioner: {
          justifyContent: "stretch",
          alignItems: "flex-start"
        },
        content: {
          maxW: "100%",
          _open: { animationName: "slide-from-top-full, fade-in" },
          _closed: { animationName: "slide-to-top-full, fade-out" }
        }
      },
      bottom: {
        positioner: {
          justifyContent: "stretch",
          alignItems: "flex-end"
        },
        content: {
          maxW: "100%",
          _open: { animationName: "slide-from-bottom-full, fade-in" },
          _closed: { animationName: "slide-to-bottom-full, fade-out" }
        }
      }
    },
    contained: {
      true: {
        positioner: {
          padding: "4"
        },
        content: {
          borderRadius: "l3"
        }
      }
    }
  },
  defaultVariants: {
    size: "xs",
    placement: "end"
  }
});
const sharedStyles = defineStyle({
  fontSize: "inherit",
  fontWeight: "inherit",
  textAlign: "inherit",
  bg: "transparent",
  borderRadius: "l2"
});
const editableSlotRecipe = defineSlotRecipe({
  slots: editableAnatomy.keys(),
  className: "chakra-editable",
  base: {
    root: {
      display: "inline-flex",
      alignItems: "center",
      position: "relative",
      gap: "1.5",
      width: "full"
    },
    preview: {
      ...sharedStyles,
      py: "1",
      px: "1",
      display: "inline-flex",
      alignItems: "center",
      transitionProperty: "common",
      transitionDuration: "moderate",
      cursor: "text",
      _hover: {
        bg: "bg.muted"
      },
      _disabled: {
        userSelect: "none"
      }
    },
    input: {
      ...sharedStyles,
      outline: "0",
      py: "1",
      px: "1",
      transitionProperty: "common",
      transitionDuration: "normal",
      width: "full",
      focusVisibleRing: "inside",
      focusRingWidth: "2px",
      _placeholder: { opacity: 0.6 }
    },
    control: {
      display: "inline-flex",
      alignItems: "center",
      gap: "1.5"
    }
  },
  variants: {
    size: {
      sm: {
        root: {
          textStyle: "sm"
        },
        preview: { minH: "8" },
        input: { minH: "8" }
      },
      md: {
        root: {
          textStyle: "sm"
        },
        preview: { minH: "9" },
        input: { minH: "9" }
      },
      lg: {
        root: {
          textStyle: "md"
        },
        preview: { minH: "10" },
        input: { minH: "10" }
      }
    }
  },
  defaultVariants: {
    size: "md"
  }
});
const emptyStateSlotRecipe = defineSlotRecipe({
  slots: emptyStateAnatomy.keys(),
  className: "chakra-empty-state",
  base: {
    root: {
      width: "full"
    },
    content: {
      display: "flex",
      flexDirection: "column",
      alignItems: "center",
      justifyContent: "center"
    },
    indicator: {
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      color: "fg.subtle",
      _icon: {
        boxSize: "1em"
      }
    },
    title: {
      fontWeight: "semibold"
    },
    description: {
      textStyle: "sm",
      color: "fg.muted"
    }
  },
  variants: {
    size: {
      sm: {
        root: {
          px: "4",
          py: "6"
        },
        title: {
          textStyle: "md"
        },
        content: {
          gap: "4"
        },
        indicator: {
          textStyle: "2xl"
        }
      },
      md: {
        root: {
          px: "8",
          py: "12"
        },
        title: {
          textStyle: "lg"
        },
        content: {
          gap: "6"
        },
        indicator: {
          textStyle: "4xl"
        }
      },
      lg: {
        root: {
          px: "12",
          py: "16"
        },
        title: {
          textStyle: "xl"
        },
        content: {
          gap: "8"
        },
        indicator: {
          textStyle: "6xl"
        }
      }
    }
  },
  defaultVariants: {
    size: "md"
  }
});
const fieldSlotRecipe = defineSlotRecipe({
  className: "chakra-field",
  slots: fieldAnatomy.keys(),
  base: {
    requiredIndicator: {
      color: "fg.error",
      lineHeight: "1"
    },
    root: {
      display: "flex",
      width: "100%",
      position: "relative",
      gap: "1.5"
    },
    label: {
      display: "flex",
      alignItems: "center",
      textAlign: "start",
      textStyle: "sm",
      fontWeight: "medium",
      gap: "1",
      userSelect: "none",
      _disabled: {
        opacity: "0.5"
      }
    },
    errorText: {
      display: "inline-flex",
      alignItems: "center",
      fontWeight: "medium",
      gap: "1",
      color: "fg.error",
      textStyle: "xs"
    },
    helperText: {
      color: "fg.muted",
      textStyle: "xs"
    }
  },
  variants: {
    orientation: {
      vertical: {
        root: {
          flexDirection: "column",
          alignItems: "flex-start"
        }
      },
      horizontal: {
        root: {
          flexDirection: "row",
          alignItems: "center",
          justifyContent: "space-between"
        },
        label: {
          flex: "0 0 var(--field-label-width, 80px)"
        }
      }
    }
  },
  defaultVariants: {
    orientation: "vertical"
  }
});
const fieldsetSlotRecipe = defineSlotRecipe({
  className: "fieldset",
  slots: fieldsetAnatomy.keys(),
  base: {
    root: {
      display: "flex",
      flexDirection: "column",
      width: "full"
    },
    content: {
      display: "flex",
      flexDirection: "column",
      width: "full"
    },
    legend: {
      color: "fg",
      fontWeight: "medium",
      _disabled: {
        opacity: "0.5"
      }
    },
    helperText: {
      color: "fg.muted",
      textStyle: "sm"
    },
    errorText: {
      display: "inline-flex",
      alignItems: "center",
      color: "fg.error",
      gap: "2",
      fontWeight: "medium",
      textStyle: "sm"
    }
  },
  variants: {
    size: {
      sm: {
        root: { spaceY: "2" },
        content: { gap: "1.5" },
        legend: { textStyle: "sm" }
      },
      md: {
        root: { spaceY: "4" },
        content: { gap: "4" },
        legend: { textStyle: "sm" }
      },
      lg: {
        root: { spaceY: "6" },
        content: { gap: "4" },
        legend: { textStyle: "md" }
      }
    }
  },
  defaultVariants: {
    size: "md"
  }
});
const fileUploadSlotRecipe = defineSlotRecipe({
  className: "chakra-file-upload",
  slots: fileUploadAnatomy.keys(),
  base: {
    root: {
      display: "flex",
      flexDirection: "column",
      gap: "4",
      width: "100%",
      alignItems: "flex-start"
    },
    label: {
      fontWeight: "medium",
      textStyle: "sm"
    },
    dropzone: {
      background: "bg",
      borderRadius: "l3",
      borderWidth: "2px",
      borderStyle: "dashed",
      display: "flex",
      alignItems: "center",
      flexDirection: "column",
      gap: "4",
      justifyContent: "center",
      minHeight: "2xs",
      px: "3",
      py: "2",
      transition: "backgrounds",
      focusVisibleRing: "outside",
      _hover: {
        bg: "bg.subtle"
      },
      _dragging: {
        bg: "colorPalette.subtle",
        borderStyle: "solid",
        borderColor: "colorPalette.solid"
      }
    },
    dropzoneContent: {
      display: "flex",
      flexDirection: "column",
      alignItems: "center",
      textAlign: "center",
      gap: "1",
      textStyle: "sm"
    },
    item: {
      pos: "relative",
      textStyle: "sm",
      animationName: "fade-in",
      animationDuration: "moderate",
      background: "bg",
      borderRadius: "l2",
      borderWidth: "1px",
      width: "100%",
      display: "flex",
      alignItems: "center",
      gap: "3",
      p: "4"
    },
    itemGroup: {
      width: "100%",
      display: "flex",
      flexDirection: "column",
      gap: "3",
      _empty: {
        display: "none"
      }
    },
    itemName: {
      color: "fg",
      fontWeight: "medium",
      lineClamp: "1"
    },
    itemContent: {
      display: "flex",
      flexDirection: "column",
      gap: "0.5",
      flex: "1"
    },
    itemSizeText: {
      color: "fg.muted",
      textStyle: "xs"
    },
    itemDeleteTrigger: {
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      alignSelf: "flex-start",
      boxSize: "5",
      p: "2px",
      color: "fg.muted",
      cursor: "button"
    },
    itemPreview: {
      color: "fg.muted",
      _icon: {
        boxSize: "4.5"
      }
    }
  },
  defaultVariants: {}
});
const hoverCardSlotRecipe = defineSlotRecipe({
  className: "chakra-hover-card",
  slots: anatomy$f.keys(),
  base: {
    content: {
      position: "relative",
      display: "flex",
      flexDirection: "column",
      textStyle: "sm",
      "--hovercard-bg": "colors.bg.panel",
      bg: "var(--hovercard-bg)",
      boxShadow: "lg",
      maxWidth: "80",
      borderRadius: "l3",
      zIndex: "popover",
      transformOrigin: "var(--transform-origin)",
      outline: "0",
      _open: {
        animationStyle: "slide-fade-in",
        animationDuration: "fast"
      },
      _closed: {
        animationStyle: "slide-fade-out",
        animationDuration: "faster"
      }
    },
    arrow: {
      "--arrow-size": "sizes.3",
      "--arrow-background": "var(--hovercard-bg)"
    },
    arrowTip: {
      borderTopWidth: "0.5px",
      borderLeftWidth: "0.5px"
    }
  },
  variants: {
    size: {
      xs: {
        content: {
          padding: "3"
        }
      },
      sm: {
        content: {
          padding: "4"
        }
      },
      md: {
        content: {
          padding: "5"
        }
      },
      lg: {
        content: {
          padding: "6"
        }
      }
    }
  },
  defaultVariants: {
    size: "md"
  }
});
const listSlotRecipe = defineSlotRecipe({
  className: "chakra-list",
  slots: listAnatomy.keys(),
  base: {
    root: {
      display: "flex",
      flexDirection: "column",
      gap: "var(--list-gap)",
      "& :where(ul, ol)": {
        marginTop: "var(--list-gap)"
      }
    },
    item: {
      whiteSpace: "normal",
      display: "list-item"
    },
    indicator: {
      marginEnd: "2",
      minHeight: "1lh",
      flexShrink: 0,
      display: "inline-block",
      verticalAlign: "middle"
    }
  },
  variants: {
    variant: {
      marker: {
        root: {
          listStyle: "revert"
        },
        item: {
          _marker: {
            color: "fg.subtle"
          }
        }
      },
      plain: {
        item: {
          alignItems: "flex-start",
          display: "inline-flex"
        }
      }
    },
    align: {
      center: {
        item: { alignItems: "center" }
      },
      start: {
        item: { alignItems: "flex-start" }
      },
      end: {
        item: { alignItems: "flex-end" }
      }
    }
  },
  defaultVariants: {
    variant: "marker"
  }
});
const listboxSlotRecipe = defineSlotRecipe({
  className: "chakra-listbox",
  slots: listboxAnatomy.keys(),
  base: {
    root: {
      display: "flex",
      flexDirection: "column",
      gap: "1.5",
      width: "full"
    },
    content: {
      display: "flex",
      maxH: "96",
      p: "1",
      gap: "1",
      textStyle: "sm",
      outline: "none",
      scrollPadding: "1",
      _horizontal: {
        flexDirection: "row",
        overflowX: "auto"
      },
      _vertical: {
        flexDirection: "column",
        overflowY: "auto"
      },
      "--listbox-item-padding-x": "spacing.2",
      "--listbox-item-padding-y": "spacing.1.5"
    },
    item: {
      position: "relative",
      userSelect: "none",
      display: "flex",
      alignItems: "center",
      gap: "2",
      cursor: "pointer",
      justifyContent: "space-between",
      flex: "1",
      textAlign: "start",
      borderRadius: "l1",
      py: "var(--listbox-item-padding-y)",
      px: "var(--listbox-item-padding-x)",
      _highlighted: {
        outline: "2px solid",
        outlineColor: "border.emphasized"
      },
      _disabled: {
        pointerEvents: "none",
        opacity: "0.5"
      }
    },
    empty: {
      py: "var(--listbox-item-padding-y)",
      px: "var(--listbox-item-padding-x)"
    },
    itemText: {
      flex: "1"
    },
    itemGroup: {
      mt: "1.5",
      _first: { mt: "0" }
    },
    itemGroupLabel: {
      py: "1.5",
      px: "2",
      fontWeight: "medium"
    },
    label: {
      fontWeight: "medium",
      userSelect: "none",
      textStyle: "sm",
      _disabled: {
        layerStyle: "disabled"
      }
    },
    valueText: {
      lineClamp: "1",
      maxW: "80%"
    },
    itemIndicator: {
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      _icon: {
        boxSize: "4"
      }
    }
  },
  variants: {
    variant: {
      subtle: {
        content: {
          bg: "bg.panel",
          borderWidth: "1px",
          borderRadius: "l2"
        },
        item: {
          _hover: {
            bg: "bg.emphasized/60"
          },
          _selected: {
            bg: "bg.muted"
          }
        }
      },
      solid: {
        content: {
          bg: "bg.panel",
          borderWidth: "1px",
          borderRadius: "l2"
        },
        item: {
          _selected: {
            bg: "colorPalette.solid",
            color: "colorPalette.contrast"
          }
        }
      },
      plain: {}
    }
  },
  defaultVariants: {
    variant: "subtle"
  }
});
const menuSlotRecipe = defineSlotRecipe({
  className: "chakra-menu",
  slots: menuAnatomy.keys(),
  base: {
    content: {
      outline: 0,
      "--menu-bg": "colors.bg.panel",
      bg: "var(--menu-bg)",
      boxShadow: "lg",
      color: "fg",
      maxHeight: "var(--available-height)",
      "--menu-z-index": "zIndex.dropdown",
      zIndex: "calc(var(--menu-z-index) + var(--layer-index, 0))",
      borderRadius: "l2",
      overflow: "hidden",
      overflowY: "auto",
      _open: {
        animationStyle: "slide-fade-in",
        animationDuration: "fast"
      },
      _closed: {
        animationStyle: "slide-fade-out",
        animationDuration: "faster"
      }
    },
    item: {
      textDecoration: "none",
      color: "fg",
      userSelect: "none",
      borderRadius: "l1",
      width: "100%",
      display: "flex",
      cursor: "menuitem",
      alignItems: "center",
      textAlign: "start",
      position: "relative",
      flex: "0 0 auto",
      outline: 0,
      _disabled: {
        layerStyle: "disabled"
      },
      "&[data-type]": {
        ps: "8"
      }
    },
    itemText: {
      flex: "1"
    },
    itemIndicator: {
      position: "absolute",
      insetStart: "2",
      transform: "translateY(-50%)",
      top: "50%"
    },
    itemGroupLabel: {
      px: "2",
      py: "1.5",
      fontWeight: "semibold",
      textStyle: "sm"
    },
    indicator: {
      display: "inline-flex",
      alignItems: "center",
      justifyContent: "center",
      flexShrink: "0"
    },
    itemCommand: {
      opacity: "0.6",
      textStyle: "xs",
      ms: "auto",
      ps: "4",
      letterSpacing: "widest",
      fontFamily: "inherit"
    },
    separator: {
      height: "1px",
      bg: "bg.muted",
      my: "1",
      mx: "-1"
    },
    arrow: {
      "--arrow-size": "sizes.3",
      "--arrow-background": "var(--menu-bg)"
    },
    arrowTip: {
      borderTopWidth: "1px",
      borderLeftWidth: "1px"
    }
  },
  variants: {
    variant: {
      subtle: {
        item: {
          _highlighted: {
            bg: "bg.emphasized/60"
          }
        }
      },
      solid: {
        item: {
          _highlighted: {
            bg: "colorPalette.solid",
            color: "colorPalette.contrast"
          }
        }
      }
    },
    size: {
      sm: {
        content: {
          minW: "8rem",
          padding: "1",
          scrollPadding: "1"
        },
        item: {
          gap: "1",
          textStyle: "xs",
          py: "1",
          px: "1.5"
        }
      },
      md: {
        content: {
          minW: "8rem",
          padding: "1.5",
          scrollPadding: "1.5"
        },
        item: {
          gap: "2",
          textStyle: "sm",
          py: "1.5",
          px: "2"
        }
      }
    }
  },
  defaultVariants: {
    size: "md",
    variant: "subtle"
  }
});
const selectSlotRecipe = defineSlotRecipe({
  className: "chakra-select",
  slots: selectAnatomy.keys(),
  base: {
    root: {
      display: "flex",
      flexDirection: "column",
      gap: "1.5",
      width: "full"
    },
    trigger: {
      display: "flex",
      alignItems: "center",
      justifyContent: "space-between",
      width: "full",
      minH: "var(--select-trigger-height)",
      "--input-height": "var(--select-trigger-height)",
      px: "var(--select-trigger-padding-x)",
      borderRadius: "l2",
      userSelect: "none",
      textAlign: "start",
      focusVisibleRing: "inside",
      _placeholderShown: {
        color: "fg.muted/80"
      },
      _disabled: {
        layerStyle: "disabled"
      },
      _invalid: {
        borderColor: "border.error"
      }
    },
    indicatorGroup: {
      display: "flex",
      alignItems: "center",
      gap: "1",
      pos: "absolute",
      insetEnd: "0",
      top: "0",
      bottom: "0",
      px: "var(--select-trigger-padding-x)",
      pointerEvents: "none"
    },
    indicator: {
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      color: { base: "fg.muted", _disabled: "fg.subtle", _invalid: "fg.error" }
    },
    content: {
      background: "bg.panel",
      display: "flex",
      flexDirection: "column",
      "--select-z-index": "zIndex.popover",
      zIndex: "calc(var(--select-z-index) + var(--layer-index, 0))",
      borderRadius: "l2",
      outline: 0,
      maxH: "96",
      overflowY: "auto",
      boxShadow: "md",
      _open: {
        animationStyle: "slide-fade-in",
        animationDuration: "fast"
      },
      _closed: {
        animationStyle: "slide-fade-out",
        animationDuration: "fastest"
      }
    },
    item: {
      position: "relative",
      userSelect: "none",
      display: "flex",
      alignItems: "center",
      gap: "2",
      cursor: "option",
      justifyContent: "space-between",
      flex: "1",
      textAlign: "start",
      borderRadius: "l1",
      _highlighted: {
        bg: "bg.emphasized/60"
      },
      _disabled: {
        pointerEvents: "none",
        opacity: "0.5"
      },
      _icon: {
        width: "4",
        height: "4"
      }
    },
    control: {
      pos: "relative"
    },
    itemText: {
      flex: "1"
    },
    itemGroup: {
      _first: { mt: "0" }
    },
    itemGroupLabel: {
      py: "1",
      fontWeight: "medium"
    },
    label: {
      fontWeight: "medium",
      userSelect: "none",
      textStyle: "sm",
      _disabled: {
        layerStyle: "disabled"
      }
    },
    valueText: {
      lineClamp: "1",
      maxW: "80%"
    },
    clearTrigger: {
      color: "fg.muted",
      pointerEvents: "auto",
      focusVisibleRing: "inside",
      focusRingWidth: "2px",
      rounded: "l1"
    }
  },
  variants: {
    variant: {
      outline: {
        trigger: {
          bg: "transparent",
          borderWidth: "1px",
          borderColor: "border",
          _expanded: {
            borderColor: "border.emphasized"
          }
        }
      },
      subtle: {
        trigger: {
          borderWidth: "1px",
          borderColor: "transparent",
          bg: "bg.muted"
        }
      },
      ghost: {
        trigger: {
          bg: "transparent",
          _expanded: {
            bg: "bg.muted"
          }
        }
      }
    },
    size: {
      xs: {
        root: {
          "--select-trigger-height": "sizes.8",
          "--select-trigger-padding-x": "spacing.2"
        },
        content: {
          p: "1",
          gap: "1",
          textStyle: "xs"
        },
        trigger: {
          textStyle: "xs",
          gap: "1"
        },
        item: {
          py: "1",
          px: "2"
        },
        itemGroupLabel: {
          py: "1",
          px: "2"
        },
        indicator: {
          _icon: {
            width: "3.5",
            height: "3.5"
          }
        }
      },
      sm: {
        root: {
          "--select-trigger-height": "sizes.9",
          "--select-trigger-padding-x": "spacing.2.5"
        },
        content: {
          p: "1",
          textStyle: "sm"
        },
        trigger: {
          textStyle: "sm",
          gap: "1"
        },
        indicator: {
          _icon: {
            width: "4",
            height: "4"
          }
        },
        item: {
          py: "1",
          px: "1.5"
        },
        itemGroup: {
          mt: "1"
        },
        itemGroupLabel: {
          py: "1",
          px: "1.5"
        }
      },
      md: {
        root: {
          "--select-trigger-height": "sizes.10",
          "--select-trigger-padding-x": "spacing.3"
        },
        content: {
          p: "1",
          textStyle: "sm"
        },
        itemGroup: {
          mt: "1.5"
        },
        item: {
          py: "1.5",
          px: "2"
        },
        itemIndicator: {
          display: "flex",
          alignItems: "center",
          justifyContent: "center"
        },
        itemGroupLabel: {
          py: "1.5",
          px: "2"
        },
        trigger: {
          textStyle: "sm",
          gap: "2"
        },
        indicator: {
          _icon: {
            width: "4",
            height: "4"
          }
        }
      },
      lg: {
        root: {
          "--select-trigger-height": "sizes.12",
          "--select-trigger-padding-x": "spacing.4"
        },
        content: {
          p: "1.5",
          textStyle: "md"
        },
        itemGroup: {
          mt: "2"
        },
        item: {
          py: "2",
          px: "3"
        },
        itemGroupLabel: {
          py: "2",
          px: "3"
        },
        trigger: {
          textStyle: "md",
          py: "3",
          gap: "2"
        },
        indicator: {
          _icon: {
            width: "5",
            height: "5"
          }
        }
      }
    }
  },
  defaultVariants: {
    size: "md",
    variant: "outline"
  }
});
const nativeSelectSlotRecipe = defineSlotRecipe({
  className: "chakra-native-select",
  slots: nativeSelectAnatomy.keys(),
  base: {
    root: {
      height: "fit-content",
      display: "flex",
      width: "100%",
      position: "relative"
    },
    field: {
      width: "100%",
      minWidth: "0",
      outline: "0",
      appearance: "none",
      borderRadius: "l2",
      "--error-color": "colors.border.error",
      "--input-height": "var(--select-field-height)",
      height: "var(--select-field-height)",
      _disabled: {
        layerStyle: "disabled"
      },
      _invalid: {
        focusRingColor: "var(--error-color)",
        borderColor: "var(--error-color)"
      },
      focusVisibleRing: "inside",
      lineHeight: "normal",
      "& > option, & > optgroup": {
        bg: "bg"
      }
    },
    indicator: {
      position: "absolute",
      display: "inline-flex",
      alignItems: "center",
      justifyContent: "center",
      pointerEvents: "none",
      top: "50%",
      transform: "translateY(-50%)",
      height: "100%",
      color: "fg.muted",
      _disabled: {
        opacity: "0.5"
      },
      _invalid: {
        color: "fg.error"
      },
      _icon: {
        width: "1em",
        height: "1em"
      }
    }
  },
  variants: {
    variant: {
      outline: {
        field: selectSlotRecipe.variants?.variant.outline.trigger
      },
      subtle: {
        field: selectSlotRecipe.variants?.variant.subtle.trigger
      },
      plain: {
        field: {
          bg: "transparent",
          color: "fg",
          focusRingWidth: "2px"
        }
      },
      ghost: {
        field: selectSlotRecipe.variants?.variant.ghost.trigger
      }
    },
    size: {
      xs: {
        root: {
          "--select-field-height": "sizes.8"
        },
        field: {
          textStyle: "xs",
          ps: "2",
          pe: "6"
        },
        indicator: {
          textStyle: "sm",
          insetEnd: "1.5"
        }
      },
      sm: {
        root: {
          "--select-field-height": "sizes.9"
        },
        field: {
          textStyle: "sm",
          ps: "2.5",
          pe: "8"
        },
        indicator: {
          textStyle: "md",
          insetEnd: "2"
        }
      },
      md: {
        root: {
          "--select-field-height": "sizes.10"
        },
        field: {
          textStyle: "sm",
          ps: "3",
          pe: "8"
        },
        indicator: {
          textStyle: "lg",
          insetEnd: "2"
        }
      },
      lg: {
        root: {
          "--select-field-height": "sizes.11"
        },
        field: {
          textStyle: "md",
          ps: "4",
          pe: "8"
        },
        indicator: {
          textStyle: "xl",
          insetEnd: "3"
        }
      },
      xl: {
        root: {
          "--select-field-height": "sizes.12"
        },
        field: {
          textStyle: "md",
          ps: "4.5",
          pe: "10"
        },
        indicator: {
          textStyle: "xl",
          insetEnd: "3"
        }
      }
    }
  },
  defaultVariants: selectSlotRecipe.defaultVariants
});
const triggerStyle = defineStyle({
  display: "flex",
  justifyContent: "center",
  alignItems: "center",
  flex: "1",
  userSelect: "none",
  cursor: "button",
  lineHeight: "1",
  color: "fg.muted",
  "--stepper-base-radius": "radii.l1",
  "--stepper-radius": "calc(var(--stepper-base-radius) + 1px)",
  _icon: {
    boxSize: "1em"
  },
  _disabled: {
    opacity: "0.5"
  },
  _hover: {
    bg: "bg.muted"
  },
  _active: {
    bg: "bg.emphasized"
  }
});
const numberInputSlotRecipe = defineSlotRecipe({
  className: "chakra-number-input",
  slots: anatomy$g.keys(),
  base: {
    root: {
      position: "relative",
      zIndex: "0",
      isolation: "isolate"
    },
    input: {
      ...inputRecipe.base,
      verticalAlign: "top",
      pe: "calc(var(--stepper-width) + 0.5rem)"
    },
    control: {
      display: "flex",
      flexDirection: "column",
      position: "absolute",
      top: "0",
      insetEnd: "0px",
      margin: "1px",
      width: "var(--stepper-width)",
      height: "calc(100% - 2px)",
      zIndex: "1",
      borderStartWidth: "1px",
      divideY: "1px"
    },
    incrementTrigger: {
      ...triggerStyle,
      borderTopEndRadius: "var(--stepper-radius)"
    },
    decrementTrigger: {
      ...triggerStyle,
      borderBottomEndRadius: "var(--stepper-radius)"
    },
    valueText: {
      fontWeight: "medium",
      fontFeatureSettings: "pnum",
      fontVariantNumeric: "proportional-nums"
    }
  },
  variants: {
    size: {
      xs: {
        input: inputRecipe.variants.size.xs,
        control: {
          fontSize: "2xs",
          "--stepper-width": "sizes.4"
        }
      },
      sm: {
        input: inputRecipe.variants.size.sm,
        control: {
          fontSize: "xs",
          "--stepper-width": "sizes.5"
        }
      },
      md: {
        input: inputRecipe.variants.size.md,
        control: {
          fontSize: "sm",
          "--stepper-width": "sizes.6"
        }
      },
      lg: {
        input: inputRecipe.variants.size.lg,
        control: {
          fontSize: "sm",
          "--stepper-width": "sizes.6"
        }
      }
    },
    variant: mapEntries(inputRecipe.variants.variant, (key, variantStyles) => [
      key,
      { input: variantStyles }
    ])
  },
  defaultVariants: {
    size: "md",
    variant: "outline"
  }
});
const { variants, defaultVariants } = inputRecipe;
const pinInputSlotRecipe = defineSlotRecipe({
  className: "chakra-pin-input",
  slots: anatomy$h.keys(),
  base: {
    input: {
      ...inputRecipe.base,
      textAlign: "center",
      width: "var(--input-height)"
    },
    control: {
      display: "inline-flex",
      gap: "2",
      isolation: "isolate"
    }
  },
  variants: {
    size: mapEntries(variants.size, (key, value) => [
      key,
      { input: { ...value, px: "1" } }
    ]),
    variant: mapEntries(variants.variant, (key, value) => [
      key,
      { input: value }
    ]),
    attached: {
      true: {
        control: {
          gap: "0",
          spaceX: "-1px"
        },
        input: {
          _notFirst: { borderStartRadius: "0" },
          _notLast: { borderEndRadius: "0" },
          _focusVisible: { zIndex: "1" }
        }
      }
    }
  },
  defaultVariants
});
const popoverSlotRecipe = defineSlotRecipe({
  className: "chakra-popover",
  slots: popoverAnatomy.keys(),
  base: {
    content: {
      position: "relative",
      display: "flex",
      flexDirection: "column",
      textStyle: "sm",
      "--popover-bg": "colors.bg.panel",
      bg: "var(--popover-bg)",
      boxShadow: "lg",
      "--popover-size": "sizes.xs",
      "--popover-mobile-size": "calc(100dvw - 1rem)",
      width: {
        base: "min(var(--popover-mobile-size), var(--popover-size))",
        sm: "var(--popover-size)"
      },
      borderRadius: "l3",
      "--popover-z-index": "zIndex.popover",
      zIndex: "calc(var(--popover-z-index) + var(--layer-index, 0))",
      outline: "0",
      transformOrigin: "var(--transform-origin)",
      maxHeight: "var(--available-height)",
      _open: {
        animationStyle: "scale-fade-in",
        animationDuration: "fast"
      },
      _closed: {
        animationStyle: "scale-fade-out",
        animationDuration: "faster"
      }
    },
    header: {
      paddingInline: "var(--popover-padding)",
      paddingTop: "var(--popover-padding)"
    },
    body: {
      padding: "var(--popover-padding)",
      flex: "1"
    },
    footer: {
      display: "flex",
      alignItems: "center",
      paddingInline: "var(--popover-padding)",
      paddingBottom: "var(--popover-padding)"
    },
    arrow: {
      "--arrow-size": "sizes.3",
      "--arrow-background": "var(--popover-bg)"
    },
    arrowTip: {
      borderTopWidth: "1px",
      borderLeftWidth: "1px"
    }
  },
  variants: {
    size: {
      xs: {
        content: {
          "--popover-padding": "spacing.3"
        }
      },
      sm: {
        content: {
          "--popover-padding": "spacing.4"
        }
      },
      md: {
        content: {
          "--popover-padding": "spacing.5"
        }
      },
      lg: {
        content: {
          "--popover-padding": "spacing.6"
        }
      }
    }
  },
  defaultVariants: {
    size: "md"
  }
});
const progressSlotRecipe = defineSlotRecipe({
  slots: anatomy$i.keys(),
  className: "chakra-progress",
  base: {
    root: {
      textStyle: "sm",
      position: "relative"
    },
    track: {
      overflow: "hidden",
      position: "relative"
    },
    range: {
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      transitionProperty: "width, height",
      transitionDuration: "slow",
      height: "100%",
      bgColor: "var(--track-color)",
      _indeterminate: {
        "--animate-from-x": "-40%",
        "--animate-to-x": "100%",
        position: "absolute",
        willChange: "left",
        minWidth: "50%",
        animation: "position 1s ease infinite normal none running",
        backgroundImage: `linear-gradient(to right, transparent 0%, var(--track-color) 50%, transparent 100%)`
      }
    },
    label: {
      display: "inline-flex",
      fontWeight: "medium",
      alignItems: "center",
      gap: "1"
    },
    valueText: {
      textStyle: "xs",
      lineHeight: "1",
      fontWeight: "medium"
    }
  },
  variants: {
    variant: {
      outline: {
        track: {
          shadow: "inset",
          bgColor: "bg.muted"
        },
        range: {
          bgColor: "colorPalette.solid"
        }
      },
      subtle: {
        track: {
          bgColor: "colorPalette.muted"
        },
        range: {
          bgColor: "colorPalette.solid/72"
        }
      }
    },
    shape: {
      square: {},
      rounded: {
        track: {
          borderRadius: "l1"
        }
      },
      full: {
        track: {
          borderRadius: "full"
        }
      }
    },
    striped: {
      true: {
        range: {
          backgroundImage: `linear-gradient(45deg, var(--stripe-color) 25%, transparent 25%, transparent 50%, var(--stripe-color) 50%, var(--stripe-color) 75%, transparent 75%, transparent)`,
          backgroundSize: `var(--stripe-size) var(--stripe-size)`,
          "--stripe-size": "1rem",
          "--stripe-color": {
            _light: "rgba(255, 255, 255, 0.3)",
            _dark: "rgba(0, 0, 0, 0.3)"
          }
        }
      }
    },
    animated: {
      true: {
        range: {
          "--animate-from": "var(--stripe-size)",
          animation: "bg-position 1s linear infinite"
        }
      }
    },
    size: {
      xs: {
        track: { h: "1.5" }
      },
      sm: {
        track: { h: "2" }
      },
      md: {
        track: { h: "2.5" }
      },
      lg: {
        track: { h: "3" }
      },
      xl: {
        track: { h: "4" }
      }
    }
  },
  defaultVariants: {
    variant: "outline",
    size: "md",
    shape: "rounded"
  }
});
const progressCircleSlotRecipe = defineSlotRecipe({
  className: "chakra-progress-circle",
  slots: anatomy$i.keys(),
  base: {
    root: {
      display: "inline-flex",
      textStyle: "sm",
      position: "relative"
    },
    circle: {
      _indeterminate: {
        animation: "spin 2s linear infinite"
      }
    },
    circleTrack: {
      "--track-color": "colors.colorPalette.muted",
      stroke: "var(--track-color)"
    },
    circleRange: {
      stroke: "colorPalette.solid",
      transitionProperty: "stroke-dashoffset, stroke-dasharray",
      transitionDuration: "0.6s",
      _indeterminate: {
        animation: "circular-progress 1.5s linear infinite"
      }
    },
    label: {
      display: "inline-flex"
    },
    valueText: {
      lineHeight: "1",
      fontWeight: "medium",
      letterSpacing: "tight",
      fontVariantNumeric: "tabular-nums"
    }
  },
  variants: {
    size: {
      xs: {
        circle: {
          "--size": "24px",
          "--thickness": "4px"
        },
        valueText: {
          textStyle: "2xs"
        }
      },
      sm: {
        circle: {
          "--size": "32px",
          "--thickness": "5px"
        },
        valueText: {
          textStyle: "2xs"
        }
      },
      md: {
        circle: {
          "--size": "40px",
          "--thickness": "6px"
        },
        valueText: {
          textStyle: "xs"
        }
      },
      lg: {
        circle: {
          "--size": "48px",
          "--thickness": "7px"
        },
        valueText: {
          textStyle: "sm"
        }
      },
      xl: {
        circle: {
          "--size": "64px",
          "--thickness": "8px"
        },
        valueText: {
          textStyle: "sm"
        }
      }
    }
  },
  defaultVariants: {
    size: "md"
  }
});
const qrCodeSlotRecipe = defineSlotRecipe({
  slots: anatomy$j.keys(),
  className: "chakra-qr-code",
  base: {
    root: {
      position: "relative",
      width: "fit-content",
      "--qr-code-overlay-size": "calc(var(--qr-code-size) / 3)"
    },
    frame: {
      width: "var(--qr-code-size)",
      height: "var(--qr-code-size)",
      fill: "currentColor"
    },
    overlay: {
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      width: "var(--qr-code-overlay-size)",
      height: "var(--qr-code-overlay-size)",
      padding: "1",
      bg: "bg",
      rounded: "l1"
    }
  },
  variants: {
    size: {
      "2xs": {
        root: { "--qr-code-size": "40px" }
      },
      xs: {
        root: { "--qr-code-size": "64px" }
      },
      sm: {
        root: { "--qr-code-size": "80px" }
      },
      md: {
        root: { "--qr-code-size": "120px" }
      },
      lg: {
        root: { "--qr-code-size": "160px" }
      },
      xl: {
        root: { "--qr-code-size": "200px" }
      },
      "2xl": {
        root: { "--qr-code-size": "240px" }
      },
      full: {
        root: { "--qr-code-size": "100%" }
      }
    }
  },
  defaultVariants: {
    size: "md"
  }
});
const radioCardSlotRecipe = defineSlotRecipe({
  className: "chakra-radio-card",
  slots: radioCardAnatomy.keys(),
  base: {
    root: {
      display: "flex",
      flexDirection: "column",
      gap: "1.5",
      isolation: "isolate"
    },
    item: {
      flex: "1",
      display: "flex",
      flexDirection: "column",
      userSelect: "none",
      position: "relative",
      borderRadius: "l2",
      _focus: {
        bg: "colorPalette.muted/20"
      },
      _disabled: {
        opacity: "0.8",
        borderColor: "border.disabled"
      },
      _checked: {
        zIndex: "1"
      }
    },
    label: {
      display: "inline-flex",
      fontWeight: "medium",
      textStyle: "sm",
      _disabled: {
        opacity: "0.5"
      }
    },
    itemText: {
      fontWeight: "medium",
      flex: "1"
    },
    itemDescription: {
      opacity: "0.64",
      textStyle: "sm"
    },
    itemControl: {
      display: "inline-flex",
      flex: "1",
      pos: "relative",
      rounded: "inherit",
      justifyContent: "var(--radio-card-justify)",
      alignItems: "var(--radio-card-align)",
      _disabled: {
        bg: "bg.muted"
      }
    },
    itemIndicator: radiomarkRecipe.base,
    itemAddon: {
      roundedBottom: "inherit",
      _disabled: {
        color: "fg.muted"
      }
    },
    itemContent: {
      display: "flex",
      flexDirection: "column",
      flex: "1",
      gap: "1",
      justifyContent: "var(--radio-card-justify)",
      alignItems: "var(--radio-card-align)"
    }
  },
  variants: {
    size: {
      sm: {
        item: {
          textStyle: "sm"
        },
        itemControl: {
          padding: "3",
          gap: "1.5"
        },
        itemAddon: {
          px: "3",
          py: "1.5",
          borderTopWidth: "1px"
        },
        itemIndicator: radiomarkRecipe.variants?.size.sm
      },
      md: {
        item: {
          textStyle: "sm"
        },
        itemControl: {
          padding: "4",
          gap: "2.5"
        },
        itemAddon: {
          px: "4",
          py: "2",
          borderTopWidth: "1px"
        },
        itemIndicator: radiomarkRecipe.variants?.size.md
      },
      lg: {
        item: {
          textStyle: "md"
        },
        itemControl: {
          padding: "4",
          gap: "3.5"
        },
        itemAddon: {
          px: "4",
          py: "2",
          borderTopWidth: "1px"
        },
        itemIndicator: radiomarkRecipe.variants?.size.lg
      }
    },
    variant: {
      surface: {
        item: {
          borderWidth: "1px",
          _checked: {
            bg: "colorPalette.subtle",
            color: "colorPalette.fg",
            borderColor: "colorPalette.muted"
          }
        },
        itemIndicator: radiomarkRecipe.variants?.variant.solid
      },
      subtle: {
        item: {
          bg: "bg.muted"
        },
        itemControl: {
          _checked: {
            bg: "colorPalette.muted",
            color: "colorPalette.fg"
          }
        },
        itemIndicator: radiomarkRecipe.variants?.variant.outline
      },
      outline: {
        item: {
          borderWidth: "1px",
          _checked: {
            boxShadow: "0 0 0 1px var(--shadow-color)",
            boxShadowColor: "colorPalette.solid",
            borderColor: "colorPalette.solid"
          }
        },
        itemIndicator: radiomarkRecipe.variants?.variant.solid
      },
      solid: {
        item: {
          borderWidth: "1px",
          _checked: {
            bg: "colorPalette.solid",
            color: "colorPalette.contrast",
            borderColor: "colorPalette.solid"
          }
        },
        itemIndicator: radiomarkRecipe.variants?.variant.inverted
      }
    },
    justify: {
      start: {
        item: { "--radio-card-justify": "flex-start" }
      },
      end: {
        item: { "--radio-card-justify": "flex-end" }
      },
      center: {
        item: { "--radio-card-justify": "center" }
      }
    },
    align: {
      start: {
        item: { "--radio-card-align": "flex-start" },
        itemControl: { textAlign: "start" }
      },
      end: {
        item: { "--radio-card-align": "flex-end" },
        itemControl: { textAlign: "end" }
      },
      center: {
        item: { "--radio-card-align": "center" },
        itemControl: { textAlign: "center" }
      }
    },
    orientation: {
      vertical: {
        itemControl: { flexDirection: "column" }
      },
      horizontal: {
        itemControl: { flexDirection: "row" }
      }
    }
  },
  defaultVariants: {
    size: "md",
    variant: "outline",
    align: "start",
    orientation: "horizontal"
  }
});
const radioGroupSlotRecipe = defineSlotRecipe({
  className: "chakra-radio-group",
  slots: radioGroupAnatomy.keys(),
  base: {
    item: {
      display: "inline-flex",
      alignItems: "center",
      position: "relative",
      fontWeight: "medium",
      _disabled: {
        cursor: "disabled"
      }
    },
    itemControl: radiomarkRecipe.base,
    label: {
      userSelect: "none",
      textStyle: "sm",
      _disabled: {
        opacity: "0.5"
      }
    }
  },
  variants: {
    variant: {
      outline: {
        itemControl: radiomarkRecipe.variants?.variant?.outline
      },
      subtle: {
        itemControl: radiomarkRecipe.variants?.variant?.subtle
      },
      solid: {
        itemControl: radiomarkRecipe.variants?.variant?.solid
      }
    },
    size: {
      xs: {
        item: { textStyle: "xs", gap: "1.5" },
        itemControl: radiomarkRecipe.variants?.size?.xs
      },
      sm: {
        item: { textStyle: "sm", gap: "2" },
        itemControl: radiomarkRecipe.variants?.size?.sm
      },
      md: {
        item: { textStyle: "sm", gap: "2.5" },
        itemControl: radiomarkRecipe.variants?.size?.md
      },
      lg: {
        item: { textStyle: "md", gap: "3" },
        itemControl: radiomarkRecipe.variants?.size?.lg
      }
    }
  },
  defaultVariants: {
    size: "md",
    variant: "solid"
  }
});
const ratingGroupSlotRecipe = defineSlotRecipe({
  className: "chakra-rating-group",
  slots: ratingGroupAnatomy.keys(),
  base: {
    root: {
      display: "inline-flex"
    },
    control: {
      display: "inline-flex",
      alignItems: "center"
    },
    item: {
      display: "inline-flex",
      alignItems: "center",
      justifyContent: "center",
      userSelect: "none"
    },
    itemIndicator: {
      display: "inline-flex",
      alignItems: "center",
      justifyContent: "center",
      width: "1em",
      height: "1em",
      position: "relative",
      "--clip-path": { base: "inset(0 50% 0 0)", _rtl: "inset(0 0 0 50%)" },
      _icon: {
        stroke: "currentColor",
        width: "100%",
        height: "100%",
        display: "inline-block",
        flexShrink: 0,
        position: "absolute",
        left: 0,
        top: 0
      },
      "& [data-bg]": {
        color: "bg.emphasized"
      },
      "& [data-fg]": {
        color: "transparent"
      },
      "&[data-highlighted]:not([data-half])": {
        "& [data-fg]": {
          color: "colorPalette.solid"
        }
      },
      "&[data-half]": {
        "& [data-fg]": {
          color: "colorPalette.solid",
          clipPath: "var(--clip-path)"
        }
      }
    }
  },
  variants: {
    size: {
      xs: {
        item: {
          textStyle: "sm"
        }
      },
      sm: {
        item: {
          textStyle: "md"
        }
      },
      md: {
        item: {
          textStyle: "xl"
        }
      },
      lg: {
        item: {
          textStyle: "2xl"
        }
      }
    }
  },
  defaultVariants: {
    size: "md"
  }
});
const scrollAreaSlotRecipe = defineSlotRecipe({
  className: "chakra-scroll-area",
  slots: anatomy$k.keys(),
  base: {
    root: {
      display: "flex",
      flexDirection: "column",
      width: "100%",
      height: "100%",
      position: "relative",
      overflow: "hidden",
      "--scrollbar-margin": "2px",
      "--scrollbar-click-area": "calc(var(--scrollbar-size) + calc(var(--scrollbar-margin) * 2))"
    },
    viewport: {
      display: "flex",
      flexDirection: "column",
      height: "100%",
      width: "100%",
      borderRadius: "inherit",
      WebkitOverflowScrolling: "touch",
      scrollbarWidth: "none",
      "&::-webkit-scrollbar": {
        display: "none"
      }
    },
    content: {
      minWidth: "100%"
    },
    scrollbar: {
      display: "flex",
      userSelect: "none",
      touchAction: "none",
      borderRadius: "full",
      colorPalette: "gray",
      transition: "opacity 150ms 300ms",
      position: "relative",
      margin: "var(--scrollbar-margin)",
      "&:not([data-overflow-x], [data-overflow-y])": {
        display: "none"
      },
      bg: "{colors.colorPalette.solid/10}",
      "--thumb-bg": "{colors.colorPalette.solid/25}",
      "&:is(:hover, :active)": {
        "--thumb-bg": "{colors.colorPalette.solid/50}"
      },
      _before: {
        content: '""',
        position: "absolute"
      },
      _vertical: {
        width: "var(--scrollbar-size)",
        flexDirection: "column",
        "&::before": {
          width: "var(--scrollbar-click-area)",
          height: "100%",
          insetInlineStart: "calc(var(--scrollbar-margin) * -1)"
        }
      },
      _horizontal: {
        height: "var(--scrollbar-size)",
        flexDirection: "row",
        "&::before": {
          height: "var(--scrollbar-click-area)",
          width: "100%",
          top: "calc(var(--scrollbar-margin) * -1)"
        }
      }
    },
    thumb: {
      borderRadius: "inherit",
      bg: "var(--thumb-bg)",
      transition: "backgrounds",
      _vertical: { width: "full" },
      _horizontal: { height: "full" }
    },
    corner: {
      bg: "bg.muted",
      margin: "var(--scrollbar-margin)",
      opacity: 0,
      transition: "opacity 150ms 300ms",
      "&[data-hover]": {
        transitionDelay: "0ms",
        opacity: 1
      }
    }
  },
  variants: {
    variant: {
      hover: {
        scrollbar: {
          opacity: "0",
          "&[data-hover], &[data-scrolling]": {
            opacity: "1",
            transitionDuration: "faster",
            transitionDelay: "0ms"
          }
        }
      },
      always: {
        scrollbar: {
          opacity: "1"
        }
      }
    },
    size: {
      xs: {
        root: {
          "--scrollbar-size": "sizes.1"
        }
      },
      sm: {
        root: {
          "--scrollbar-size": "sizes.1.5"
        }
      },
      md: {
        root: {
          "--scrollbar-size": "sizes.2"
        }
      },
      lg: {
        root: {
          "--scrollbar-size": "sizes.3"
        }
      }
    }
  },
  defaultVariants: {
    size: "md",
    variant: "hover"
  }
});
const segmentGroupSlotRecipe = defineSlotRecipe({
  className: "chakra-segment-group",
  slots: segmentGroupAnatomy.keys(),
  base: {
    root: {
      "--segment-radius": "radii.l2",
      "--segment-indicator-bg": {
        _light: "colors.bg",
        _dark: "colors.bg.emphasized"
      },
      "--segment-indicator-shadow": "shadows.sm",
      borderRadius: "var(--segment-radius)",
      display: "inline-flex",
      boxShadow: "inset",
      minW: "max-content",
      textAlign: "center",
      position: "relative",
      isolation: "isolate",
      bg: "bg.muted",
      _vertical: {
        flexDirection: "column"
      }
    },
    item: {
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      userSelect: "none",
      fontSize: "sm",
      position: "relative",
      color: "fg",
      borderRadius: "var(--segment-radius)",
      _disabled: {
        opacity: "0.5"
      },
      "&:has(input:focus-visible)": {
        focusRing: "outside"
      },
      _before: {
        content: '""',
        position: "absolute",
        bg: "border",
        transition: "opacity 0.2s"
      },
      _horizontal: {
        _before: {
          insetInlineStart: 0,
          insetBlock: "1.5",
          width: "1px"
        }
      },
      _vertical: {
        _before: {
          insetBlockStart: 0,
          insetInline: "1.5",
          height: "1px"
        }
      },
      "& + &[data-state=checked], &[data-state=checked] + &, &:first-of-type": {
        _before: {
          opacity: "0"
        }
      },
      "&[data-state=checked][data-ssr]": {
        shadow: "sm",
        bg: "bg",
        borderRadius: "var(--segment-radius)"
      }
    },
    indicator: {
      shadow: "var(--segment-indicator-shadow)",
      pos: "absolute",
      bg: "var(--segment-indicator-bg)",
      width: "var(--width)",
      height: "var(--height)",
      top: "var(--top)",
      left: "var(--left)",
      zIndex: -1,
      borderRadius: "var(--segment-radius)"
    }
  },
  variants: {
    size: {
      xs: {
        item: {
          textStyle: "xs",
          px: "3",
          gap: "1",
          height: "6"
        }
      },
      sm: {
        item: {
          textStyle: "sm",
          px: "4",
          gap: "2",
          height: "8"
        }
      },
      md: {
        item: {
          textStyle: "sm",
          px: "4",
          gap: "2",
          height: "10"
        }
      },
      lg: {
        item: {
          textStyle: "md",
          px: "4.5",
          gap: "3",
          height: "11"
        }
      }
    }
  },
  defaultVariants: {
    size: "md"
  }
});
const sliderSlotRecipe = defineSlotRecipe({
  className: "chakra-slider",
  slots: sliderAnatomy.keys(),
  base: {
    root: {
      display: "flex",
      flexDirection: "column",
      gap: "1",
      textStyle: "sm",
      position: "relative",
      isolation: "isolate",
      touchAction: "none"
    },
    label: {
      fontWeight: "medium",
      textStyle: "sm"
    },
    control: {
      display: "inline-flex",
      alignItems: "center",
      position: "relative"
    },
    track: {
      overflow: "hidden",
      borderRadius: "full",
      flex: "1"
    },
    range: {
      width: "inherit",
      height: "inherit",
      _disabled: { bg: "border.emphasized!" }
    },
    markerGroup: {
      position: "absolute!",
      zIndex: "1"
    },
    marker: {
      "--marker-bg": { base: "white", _underValue: "colors.bg" },
      display: "flex",
      alignItems: "center",
      gap: "calc(var(--slider-thumb-size) / 2)",
      color: "fg.muted",
      textStyle: "xs"
    },
    markerIndicator: {
      width: "var(--slider-marker-size)",
      height: "var(--slider-marker-size)",
      borderRadius: "full",
      bg: "var(--marker-bg)"
    },
    thumb: {
      width: "var(--slider-thumb-size)",
      height: "var(--slider-thumb-size)",
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      outline: 0,
      zIndex: "2",
      borderRadius: "full",
      transition: "shadow",
      _focusVisible: {
        ring: "3px",
        ringColor: "colorPalette.focusRing/50"
      }
    }
  },
  variants: {
    size: {
      sm: {
        root: {
          "--slider-thumb-size": "sizes.4",
          "--slider-track-size": "sizes.1.5",
          "--slider-marker-center": "6px",
          "--slider-marker-size": "sizes.1",
          "--slider-marker-inset": "3px"
        }
      },
      md: {
        root: {
          "--slider-thumb-size": "sizes.5",
          "--slider-track-size": "sizes.2",
          "--slider-marker-center": "8px",
          "--slider-marker-size": "sizes.1",
          "--slider-marker-inset": "4px"
        }
      },
      lg: {
        root: {
          "--slider-thumb-size": "sizes.6",
          "--slider-track-size": "sizes.2.5",
          "--slider-marker-center": "9px",
          "--slider-marker-size": "sizes.1.5",
          "--slider-marker-inset": "5px"
        }
      }
    },
    variant: {
      outline: {
        track: {
          shadow: "inset",
          bg: "bg.emphasized/72"
        },
        range: {
          bg: "colorPalette.solid"
        },
        thumb: {
          borderWidth: "2px",
          borderColor: "colorPalette.solid",
          bg: "bg",
          _disabled: {
            bg: "border.emphasized",
            borderColor: "border.emphasized"
          }
        }
      },
      solid: {
        track: {
          bg: "colorPalette.subtle",
          _disabled: {
            bg: "bg.muted"
          }
        },
        range: {
          bg: "colorPalette.solid"
        },
        thumb: {
          bg: "colorPalette.solid",
          _disabled: {
            bg: "border.emphasized"
          }
        }
      }
    },
    orientation: {
      vertical: {
        root: {
          display: "inline-flex"
        },
        control: {
          flexDirection: "column",
          height: "100%",
          minWidth: "var(--slider-thumb-size)",
          "&:has(.chakra-slider__markerLabel)": {
            marginEnd: "4"
          }
        },
        track: {
          width: "var(--slider-track-size)"
        },
        thumb: {
          left: "50%",
          translate: "-50% 0"
        },
        markerGroup: {
          insetStart: "var(--slider-marker-center)",
          insetBlock: "var(--slider-marker-inset)"
        },
        marker: {
          flexDirection: "row"
        }
      },
      horizontal: {
        control: {
          flexDirection: "row",
          width: "100%",
          minHeight: "var(--slider-thumb-size)",
          "&:has(.chakra-slider__markerLabel)": {
            marginBottom: "4"
          }
        },
        track: {
          height: "var(--slider-track-size)"
        },
        thumb: {
          top: "50%",
          translate: "0 -50%"
        },
        markerGroup: {
          top: "var(--slider-marker-center)",
          insetInline: "var(--slider-marker-inset)"
        },
        marker: {
          flexDirection: "column"
        }
      }
    }
  },
  defaultVariants: {
    size: "md",
    variant: "outline",
    orientation: "horizontal"
  }
});
const splitterSlotRecipe = defineSlotRecipe({
  slots: splitterAnatomy.keys(),
  className: "splitter",
  base: {
    resizeTrigger: {
      "--splitter-border-color": "colors.border",
      "--splitter-thumb-color": "colors.bg",
      "--splitter-thumb-size": "sizes.2",
      "--splitter-thumb-inset": "calc(var(--splitter-thumb-size) * -0.5)",
      "--splitter-border-size": "1px",
      "--splitter-handle-size": "sizes.6",
      outline: "0",
      display: "grid",
      placeItems: "center",
      position: "relative",
      _focus: {
        "--splitter-border-color": "colors.border.emphasized",
        "--splitter-thumb-color": "colors.colorPalette.subtle"
      },
      _dragging: {
        "--splitter-thumb-color": "colors.colorPalette.focusRing"
      },
      _horizontal: {
        minWidth: "var(--splitter-thumb-size)",
        marginInline: "var(--splitter-thumb-inset)"
      },
      _vertical: {
        minHeight: "var(--splitter-thumb-size)",
        marginBlock: "var(--splitter-thumb-inset)"
      }
    },
    resizeTriggerSeparator: {
      position: "absolute",
      bg: "var(--splitter-border-color)",
      "[data-part='resize-trigger'][data-orientation=horizontal] &": {
        insetInlineEnd: "calc(var(--splitter-thumb-size) * 0.5)",
        insetBlock: "0",
        insetInlineStart: "auto",
        w: "var(--splitter-border-size)"
      },
      "[data-part='resize-trigger'][data-orientation=vertical] &": {
        insetBlockEnd: "calc(var(--splitter-thumb-size) * 0.5)",
        insetInline: "0",
        insetBlockStart: "auto",
        h: "var(--splitter-border-size)"
      }
    },
    resizeTriggerIndicator: {
      position: "relative",
      rounded: "full",
      bg: "var(--splitter-thumb-color)",
      shadow: "xs",
      borderWidth: "1px",
      zIndex: "1",
      "[data-part='resize-trigger'][data-orientation=horizontal] &": {
        w: "full",
        h: "var(--splitter-handle-size)"
      },
      "[data-part='resize-trigger'][data-orientation=vertical] &": {
        w: "var(--splitter-handle-size)",
        h: "full"
      },
      "[data-part='resize-trigger'][data-focus]:focus-visible &": {
        outlineWidth: "2px",
        outlineColor: "colorPalette.focusRing",
        outlineStyle: "solid"
      },
      "[data-part='resize-trigger'][data-disabled] &": {
        visibility: "hidden"
      }
    }
  }
});
const statSlotRecipe = defineSlotRecipe({
  className: "chakra-stat",
  slots: statAnatomy.keys(),
  base: {
    root: {
      display: "flex",
      flexDirection: "column",
      gap: "1",
      position: "relative",
      flex: "1"
    },
    label: {
      display: "inline-flex",
      gap: "1.5",
      alignItems: "center",
      color: "fg.muted",
      textStyle: "sm"
    },
    helpText: {
      color: "fg.muted",
      textStyle: "xs"
    },
    valueUnit: {
      color: "fg.muted",
      textStyle: "xs",
      fontWeight: "initial",
      letterSpacing: "initial"
    },
    valueText: {
      verticalAlign: "baseline",
      fontWeight: "semibold",
      letterSpacing: "tight",
      fontFeatureSettings: "pnum",
      fontVariantNumeric: "proportional-nums",
      display: "inline-flex",
      gap: "1"
    },
    indicator: {
      display: "inline-flex",
      alignItems: "center",
      justifyContent: "center",
      marginEnd: 1,
      "& :where(svg)": {
        w: "1em",
        h: "1em"
      },
      "&[data-type=up]": {
        color: "fg.success"
      },
      "&[data-type=down]": {
        color: "fg.error"
      }
    }
  },
  variants: {
    size: {
      sm: {
        valueText: {
          textStyle: "xl"
        }
      },
      md: {
        valueText: {
          textStyle: "2xl"
        }
      },
      lg: {
        valueText: {
          textStyle: "3xl"
        }
      }
    }
  },
  defaultVariants: {
    size: "md"
  }
});
const statusSlotRecipe = defineSlotRecipe({
  className: "chakra-status",
  slots: statusAnatomy.keys(),
  base: {
    root: {
      display: "inline-flex",
      alignItems: "center",
      gap: "2"
    },
    indicator: {
      width: "0.64em",
      height: "0.64em",
      flexShrink: 0,
      borderRadius: "full",
      forcedColorAdjust: "none",
      bg: "colorPalette.solid"
    }
  },
  variants: {
    size: {
      sm: {
        root: {
          textStyle: "xs"
        }
      },
      md: {
        root: {
          textStyle: "sm"
        }
      },
      lg: {
        root: {
          textStyle: "md"
        }
      }
    }
  },
  defaultVariants: {
    size: "md"
  }
});
const stepsSlotRecipe = defineSlotRecipe({
  className: "chakra-steps",
  slots: stepsAnatomy.keys(),
  base: {
    root: {
      display: "flex",
      width: "full"
    },
    list: {
      display: "flex",
      justifyContent: "space-between",
      "--steps-gutter": "spacing.3",
      "--steps-thickness": "2px"
    },
    title: {
      fontWeight: "medium",
      color: "fg"
    },
    description: {
      color: "fg.muted"
    },
    separator: {
      bg: "border",
      flex: "1"
    },
    indicator: {
      display: "flex",
      justifyContent: "center",
      alignItems: "center",
      flexShrink: "0",
      borderRadius: "full",
      fontWeight: "medium",
      width: "var(--steps-size)",
      height: "var(--steps-size)",
      _icon: {
        flexShrink: "0",
        width: "var(--steps-icon-size)",
        height: "var(--steps-icon-size)"
      }
    },
    item: {
      position: "relative",
      display: "flex",
      gap: "3",
      flex: "1 0 0",
      "&:last-of-type": {
        flex: "initial",
        "& [data-part=separator]": {
          display: "none"
        }
      }
    },
    trigger: {
      display: "flex",
      alignItems: "center",
      gap: "3",
      textAlign: "start",
      focusVisibleRing: "outside",
      borderRadius: "l2"
    },
    content: {
      focusVisibleRing: "outside"
    }
  },
  variants: {
    orientation: {
      vertical: {
        root: {
          flexDirection: "row",
          height: "100%"
        },
        list: {
          flexDirection: "column",
          alignItems: "flex-start"
        },
        separator: {
          position: "absolute",
          width: "var(--steps-thickness)",
          height: "100%",
          maxHeight: "calc(100% - var(--steps-size) - var(--steps-gutter) * 2)",
          top: "calc(var(--steps-size) + var(--steps-gutter))",
          insetStart: "calc(var(--steps-size) / 2 - 1px)"
        },
        item: {
          alignItems: "flex-start"
        }
      },
      horizontal: {
        root: {
          flexDirection: "column",
          width: "100%"
        },
        list: {
          flexDirection: "row",
          alignItems: "center"
        },
        separator: {
          width: "100%",
          height: "var(--steps-thickness)",
          marginX: "var(--steps-gutter)"
        },
        item: {
          alignItems: "center"
        }
      }
    },
    variant: {
      solid: {
        indicator: {
          _incomplete: {
            borderWidth: "var(--steps-thickness)"
          },
          _current: {
            bg: "colorPalette.muted",
            borderWidth: "var(--steps-thickness)",
            borderColor: "colorPalette.solid",
            color: "colorPalette.fg"
          },
          _complete: {
            bg: "colorPalette.solid",
            borderColor: "colorPalette.solid",
            color: "colorPalette.contrast"
          }
        },
        separator: {
          _complete: {
            bg: "colorPalette.solid"
          }
        }
      },
      subtle: {
        indicator: {
          _incomplete: {
            bg: "bg.muted"
          },
          _current: {
            bg: "colorPalette.muted",
            color: "colorPalette.fg"
          },
          _complete: {
            bg: "colorPalette.emphasized",
            color: "colorPalette.fg"
          }
        },
        separator: {
          _complete: {
            bg: "colorPalette.emphasized"
          }
        }
      }
    },
    size: {
      xs: {
        root: {
          gap: "2.5"
        },
        list: {
          "--steps-size": "sizes.6",
          "--steps-icon-size": "sizes.3.5",
          textStyle: "xs"
        },
        title: {
          textStyle: "sm"
        }
      },
      sm: {
        root: {
          gap: "3"
        },
        list: {
          "--steps-size": "sizes.8",
          "--steps-icon-size": "sizes.4",
          textStyle: "xs"
        },
        title: {
          textStyle: "sm"
        }
      },
      md: {
        root: {
          gap: "4"
        },
        list: {
          "--steps-size": "sizes.10",
          "--steps-icon-size": "sizes.4",
          textStyle: "sm"
        },
        title: {
          textStyle: "sm"
        }
      },
      lg: {
        root: {
          gap: "6"
        },
        list: {
          "--steps-size": "sizes.11",
          "--steps-icon-size": "sizes.5",
          textStyle: "md"
        },
        title: {
          textStyle: "md"
        }
      }
    }
  },
  defaultVariants: {
    size: "md",
    variant: "solid",
    orientation: "horizontal"
  }
});
const switchSlotRecipe = defineSlotRecipe({
  slots: switchAnatomy.keys(),
  className: "chakra-switch",
  base: {
    root: {
      display: "inline-flex",
      gap: "2.5",
      alignItems: "center",
      position: "relative",
      verticalAlign: "middle",
      "--switch-diff": "calc(var(--switch-width) - var(--switch-height))",
      "--switch-x": {
        base: "var(--switch-diff)",
        _rtl: "calc(var(--switch-diff) * -1)"
      }
    },
    label: {
      lineHeight: "1",
      userSelect: "none",
      fontSize: "sm",
      fontWeight: "medium",
      _disabled: {
        opacity: "0.5"
      }
    },
    indicator: {
      position: "absolute",
      height: "var(--switch-height)",
      width: "var(--switch-height)",
      fontSize: "var(--switch-indicator-font-size)",
      fontWeight: "medium",
      flexShrink: 0,
      userSelect: "none",
      display: "grid",
      placeContent: "center",
      transition: "inset-inline-start 0.12s ease",
      insetInlineStart: "calc(var(--switch-x) - 2px)",
      _checked: {
        insetInlineStart: "2px"
      }
    },
    control: {
      display: "inline-flex",
      gap: "0.5rem",
      flexShrink: 0,
      justifyContent: "flex-start",
      cursor: "switch",
      borderRadius: "full",
      position: "relative",
      width: "var(--switch-width)",
      height: "var(--switch-height)",
      transition: "backgrounds",
      _disabled: {
        opacity: "0.5",
        cursor: "not-allowed"
      },
      _invalid: {
        outline: "2px solid",
        outlineColor: "border.error",
        outlineOffset: "2px"
      }
    },
    thumb: {
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      flexShrink: 0,
      transitionProperty: "translate",
      transitionDuration: "fast",
      borderRadius: "inherit",
      _checked: {
        translate: "var(--switch-x) 0"
      }
    }
  },
  variants: {
    variant: {
      solid: {
        control: {
          borderRadius: "full",
          bg: "bg.emphasized",
          focusVisibleRing: "outside",
          _checked: {
            bg: "colorPalette.solid"
          }
        },
        thumb: {
          bg: "white",
          width: "var(--switch-height)",
          height: "var(--switch-height)",
          scale: "0.8",
          boxShadow: "sm",
          _checked: {
            bg: "colorPalette.contrast"
          }
        }
      },
      raised: {
        control: {
          borderRadius: "full",
          height: "calc(var(--switch-height) / 2)",
          bg: "bg.muted",
          boxShadow: "inset",
          _checked: {
            bg: "colorPalette.solid/60"
          }
        },
        thumb: {
          width: "var(--switch-height)",
          height: "var(--switch-height)",
          position: "relative",
          top: "calc(var(--switch-height) * -0.25)",
          bg: "white",
          boxShadow: "xs",
          focusVisibleRing: "outside",
          _checked: {
            bg: "colorPalette.solid"
          }
        }
      }
    },
    size: {
      xs: {
        root: {
          "--switch-width": "sizes.6",
          "--switch-height": "sizes.3",
          "--switch-indicator-font-size": "fontSizes.xs"
        }
      },
      sm: {
        root: {
          "--switch-width": "sizes.8",
          "--switch-height": "sizes.4",
          "--switch-indicator-font-size": "fontSizes.xs"
        }
      },
      md: {
        root: {
          "--switch-width": "sizes.10",
          "--switch-height": "sizes.5",
          "--switch-indicator-font-size": "fontSizes.sm"
        }
      },
      lg: {
        root: {
          "--switch-width": "sizes.12",
          "--switch-height": "sizes.6",
          "--switch-indicator-font-size": "fontSizes.md"
        }
      }
    }
  },
  defaultVariants: {
    variant: "solid",
    size: "md"
  }
});
const tableSlotRecipe = defineSlotRecipe({
  className: "chakra-table",
  slots: tableAnatomy.keys(),
  base: {
    root: {
      fontVariantNumeric: "lining-nums tabular-nums",
      borderCollapse: "collapse",
      width: "full",
      textAlign: "start",
      verticalAlign: "top"
    },
    row: {
      _selected: {
        bg: "colorPalette.subtle"
      }
    },
    cell: {
      textAlign: "start",
      alignItems: "center"
    },
    columnHeader: {
      fontWeight: "medium",
      textAlign: "start",
      color: "fg"
    },
    caption: {
      fontWeight: "medium",
      textStyle: "xs"
    },
    footer: {
      fontWeight: "medium"
    }
  },
  variants: {
    interactive: {
      true: {
        body: {
          "& tr": {
            _hover: {
              bg: "colorPalette.subtle"
            }
          }
        }
      }
    },
    stickyHeader: {
      true: {
        header: {
          "& :where(tr)": {
            top: "var(--table-sticky-offset, 0)",
            position: "sticky",
            zIndex: 1
          }
        }
      }
    },
    striped: {
      true: {
        row: {
          "&:nth-of-type(odd) td": {
            bg: "bg.muted"
          }
        }
      }
    },
    showColumnBorder: {
      true: {
        columnHeader: {
          "&:not(:last-of-type)": {
            borderInlineEndWidth: "1px"
          }
        },
        cell: {
          "&:not(:last-of-type)": {
            borderInlineEndWidth: "1px"
          }
        }
      }
    },
    variant: {
      line: {
        columnHeader: {
          borderBottomWidth: "1px"
        },
        cell: {
          borderBottomWidth: "1px"
        },
        row: {
          bg: "bg"
        }
      },
      outline: {
        root: {
          boxShadow: "0 0 0 1px {colors.border}"
        },
        columnHeader: {
          borderBottomWidth: "1px"
        },
        header: {
          bg: "bg.muted"
        },
        row: {
          "&:not(:last-of-type)": {
            borderBottomWidth: "1px"
          }
        },
        footer: {
          borderTopWidth: "1px"
        }
      }
    },
    size: {
      sm: {
        root: {
          textStyle: "sm"
        },
        columnHeader: {
          px: "2",
          py: "2"
        },
        cell: {
          px: "2",
          py: "2"
        }
      },
      md: {
        root: {
          textStyle: "sm"
        },
        columnHeader: {
          px: "3",
          py: "3"
        },
        cell: {
          px: "3",
          py: "3"
        }
      },
      lg: {
        root: {
          textStyle: "md"
        },
        columnHeader: {
          px: "4",
          py: "3"
        },
        cell: {
          px: "4",
          py: "3"
        }
      }
    }
  },
  defaultVariants: {
    variant: "line",
    size: "md"
  }
});
const tabsSlotRecipe = defineSlotRecipe({
  slots: tabsAnatomy.keys(),
  className: "chakra-tabs",
  base: {
    root: {
      "--tabs-trigger-radius": "radii.l2",
      "--tabs-indicator-shadow": "shadows.xs",
      "--tabs-indicator-bg": "colors.bg",
      position: "relative",
      _horizontal: {
        display: "block"
      },
      _vertical: {
        display: "flex"
      }
    },
    list: {
      display: "inline-flex",
      position: "relative",
      isolation: "isolate",
      minH: "var(--tabs-height)",
      _horizontal: {
        flexDirection: "row"
      },
      _vertical: {
        flexDirection: "column"
      }
    },
    trigger: {
      outline: "0",
      minW: "var(--tabs-height)",
      height: "var(--tabs-height)",
      display: "flex",
      alignItems: "center",
      fontWeight: "medium",
      position: "relative",
      cursor: "button",
      gap: "2",
      _focusVisible: {
        zIndex: 1,
        outline: "2px solid",
        outlineColor: "colorPalette.focusRing"
      },
      _disabled: {
        cursor: "not-allowed",
        opacity: 0.5
      }
    },
    content: {
      focusVisibleRing: "inside",
      _horizontal: {
        width: "100%",
        pt: "var(--tabs-content-padding)"
      },
      _vertical: {
        height: "100%",
        ps: "var(--tabs-content-padding)"
      }
    },
    indicator: {
      width: "var(--width)",
      height: "var(--height)",
      borderRadius: "var(--tabs-trigger-radius)",
      bg: "var(--tabs-indicator-bg)",
      shadow: "var(--tabs-indicator-shadow)",
      zIndex: -1
    }
  },
  variants: {
    fitted: {
      true: {
        list: {
          display: "flex"
        },
        trigger: {
          flex: 1,
          textAlign: "center",
          justifyContent: "center"
        }
      }
    },
    justify: {
      start: {
        list: {
          justifyContent: "flex-start"
        }
      },
      center: {
        list: {
          justifyContent: "center"
        }
      },
      end: {
        list: {
          justifyContent: "flex-end"
        }
      }
    },
    size: {
      sm: {
        root: {
          "--tabs-height": "sizes.9",
          "--tabs-content-padding": "spacing.3"
        },
        trigger: {
          py: "1",
          px: "3",
          textStyle: "sm"
        }
      },
      md: {
        root: {
          "--tabs-height": "sizes.10",
          "--tabs-content-padding": "spacing.4"
        },
        trigger: {
          py: "2",
          px: "4",
          textStyle: "sm"
        }
      },
      lg: {
        root: {
          "--tabs-height": "sizes.11",
          "--tabs-content-padding": "spacing.4.5"
        },
        trigger: {
          py: "2",
          px: "4.5",
          textStyle: "md"
        }
      }
    },
    variant: {
      line: {
        list: {
          display: "flex",
          borderColor: "border",
          _horizontal: {
            borderBottomWidth: "1px"
          },
          _vertical: {
            borderEndWidth: "1px"
          }
        },
        trigger: {
          color: "fg.muted",
          _disabled: {
            _active: { bg: "initial" }
          },
          _selected: {
            color: "fg",
            _horizontal: {
              layerStyle: "indicator.bottom",
              "--indicator-offset-y": "-1px",
              "--indicator-color": "colors.colorPalette.solid"
            },
            _vertical: {
              layerStyle: "indicator.end",
              "--indicator-offset-x": "-1px"
            }
          }
        }
      },
      subtle: {
        trigger: {
          borderRadius: "var(--tabs-trigger-radius)",
          color: "fg.muted",
          _selected: {
            bg: "colorPalette.subtle",
            color: "colorPalette.fg"
          }
        }
      },
      enclosed: {
        list: {
          bg: "bg.muted",
          padding: "1",
          borderRadius: "l3",
          minH: "calc(var(--tabs-height) - 4px)"
        },
        trigger: {
          justifyContent: "center",
          color: "fg.muted",
          borderRadius: "var(--tabs-trigger-radius)",
          _selected: {
            bg: "bg",
            color: "colorPalette.fg",
            shadow: "xs"
          }
        }
      },
      outline: {
        list: {
          "--line-thickness": "1px",
          "--line-offset": "calc(var(--line-thickness) * -1)",
          borderColor: "border",
          display: "flex",
          _horizontal: {
            _before: {
              content: '""',
              position: "absolute",
              bottom: "0px",
              width: "100%",
              borderBottomWidth: "var(--line-thickness)",
              borderBottomColor: "border"
            }
          },
          _vertical: {
            _before: {
              content: '""',
              position: "absolute",
              insetInline: "var(--line-offset)",
              height: "calc(100% - calc(var(--line-thickness) * 2))",
              borderEndWidth: "var(--line-thickness)",
              borderEndColor: "border"
            }
          }
        },
        trigger: {
          color: "fg.muted",
          borderWidth: "1px",
          borderColor: "transparent",
          _selected: {
            bg: "currentBg",
            color: "colorPalette.fg"
          },
          _horizontal: {
            borderTopRadius: "var(--tabs-trigger-radius)",
            marginBottom: "var(--line-offset)",
            marginEnd: { _notLast: "var(--line-offset)" },
            _selected: {
              borderColor: "border",
              borderBottomColor: "transparent"
            }
          },
          _vertical: {
            borderStartRadius: "var(--tabs-trigger-radius)",
            marginEnd: "var(--line-offset)",
            marginBottom: { _notLast: "var(--line-offset)" },
            _selected: {
              borderColor: "border",
              borderEndColor: "transparent"
            }
          }
        }
      },
      plain: {
        trigger: {
          color: "fg.muted",
          _selected: {
            color: "colorPalette.fg"
          },
          borderRadius: "var(--tabs-trigger-radius)",
          "&[data-selected][data-ssr]": {
            bg: "var(--tabs-indicator-bg)",
            shadow: "var(--tabs-indicator-shadow)",
            borderRadius: "var(--tabs-trigger-radius)"
          }
        }
      }
    }
  },
  defaultVariants: {
    size: "md",
    variant: "line"
  }
});
const badgeVariant = badgeRecipe.variants?.variant;
const tagSlotRecipe = defineSlotRecipe({
  slots: tagAnatomy.keys(),
  className: "chakra-tag",
  base: {
    root: {
      display: "inline-flex",
      alignItems: "center",
      verticalAlign: "top",
      maxWidth: "100%",
      userSelect: "none",
      borderRadius: "l2",
      focusVisibleRing: "outside"
    },
    label: {
      lineClamp: "1"
    },
    closeTrigger: {
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      outline: "0",
      borderRadius: "l1",
      color: "currentColor",
      focusVisibleRing: "inside",
      focusRingWidth: "2px"
    },
    startElement: {
      flexShrink: 0,
      boxSize: "var(--tag-element-size)",
      ms: "var(--tag-element-offset)",
      "&:has([data-scope=avatar])": {
        boxSize: "var(--tag-avatar-size)",
        ms: "calc(var(--tag-element-offset) * 1.5)"
      },
      _icon: { boxSize: "100%" }
    },
    endElement: {
      flexShrink: 0,
      boxSize: "var(--tag-element-size)",
      me: "var(--tag-element-offset)",
      _icon: { boxSize: "100%" },
      "&:has(button)": {
        ms: "calc(var(--tag-element-offset) * -1)"
      }
    }
  },
  variants: {
    size: {
      sm: {
        root: {
          px: "1.5",
          minH: "4.5",
          gap: "1",
          "--tag-avatar-size": "spacing.3",
          "--tag-element-size": "spacing.3",
          "--tag-element-offset": "-2px"
        },
        label: {
          textStyle: "xs"
        }
      },
      md: {
        root: {
          px: "1.5",
          minH: "5",
          gap: "1",
          "--tag-avatar-size": "spacing.3.5",
          "--tag-element-size": "spacing.3.5",
          "--tag-element-offset": "-2px"
        },
        label: {
          textStyle: "xs"
        }
      },
      lg: {
        root: {
          px: "2",
          minH: "6",
          gap: "1.5",
          "--tag-avatar-size": "spacing.4.5",
          "--tag-element-size": "spacing.4",
          "--tag-element-offset": "-3px"
        },
        label: {
          textStyle: "sm"
        }
      },
      xl: {
        root: {
          px: "2.5",
          minH: "8",
          gap: "1.5",
          "--tag-avatar-size": "spacing.6",
          "--tag-element-size": "spacing.4.5",
          "--tag-element-offset": "-4px"
        },
        label: {
          textStyle: "sm"
        }
      }
    },
    variant: {
      subtle: {
        root: badgeVariant?.subtle
      },
      solid: {
        root: badgeVariant?.solid
      },
      outline: {
        root: badgeVariant?.outline
      },
      surface: {
        root: badgeVariant?.surface
      }
    }
  },
  defaultVariants: {
    size: "md",
    variant: "surface"
  }
});
const tagsInputSlotRecipe = defineSlotRecipe({
  slots: anatomy$l.keys(),
  className: "tags-input",
  base: {
    root: {
      display: "flex",
      flexDirection: "column",
      gap: "1.5",
      width: "full"
    },
    label: {
      fontWeight: "medium",
      textStyle: "sm",
      _disabled: {
        opacity: "0.5"
      }
    },
    control: {
      "--focus-color": "colors.colorPalette.focusRing",
      "--error-color": "colors.border.error",
      minH: "var(--tags-input-height)",
      "--input-height": "var(--tags-input-height)",
      px: "var(--tags-input-px)",
      py: "var(--tags-input-py)",
      gap: "var(--tags-input-gap)",
      display: "flex",
      flexWrap: "wrap",
      alignItems: "center",
      borderRadius: "l2",
      pos: "relative",
      transitionProperty: "border-color, box-shadow",
      transitionDuration: "normal",
      _disabled: {
        opacity: "0.5"
      },
      _invalid: {
        borderColor: "var(--error-color)"
      }
    },
    input: {
      flex: "1",
      minWidth: "20",
      outline: "none",
      bg: "transparent",
      color: "fg",
      px: "calc(var(--tags-input-item-px) / 1.25)",
      height: "var(--tags-input-item-height)",
      _readOnly: {
        display: "none"
      }
    },
    item: {
      maxWidth: "100%",
      minWidth: "0"
    },
    itemText: {
      lineClamp: "1",
      minWidth: "0"
    },
    itemInput: {
      outline: "none",
      bg: "transparent",
      minWidth: "2ch",
      color: "inherit",
      px: "var(--tags-input-item-px)",
      height: "var(--tags-input-item-height)"
    },
    itemPreview: {
      height: "var(--tags-input-item-height)",
      userSelect: "none",
      display: "inline-flex",
      alignItems: "center",
      gap: "1",
      rounded: "l1",
      px: "var(--tags-input-item-px)",
      maxWidth: "100%"
    },
    itemDeleteTrigger: {
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      flexShrink: "0",
      boxSize: "calc(var(--tags-input-item-height) / 1.5)",
      cursor: { base: "button", _disabled: "initial" },
      me: "-1",
      opacity: "0.4",
      _hover: {
        opacity: "1"
      },
      "[data-highlighted] &": {
        opacity: "1"
      },
      _icon: {
        boxSize: "80%"
      }
    },
    clearTrigger: {
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      boxSize: "calc(var(--tags-input-item-height) / 1.5)",
      cursor: { base: "button", _disabled: "initial" },
      color: "fg.muted",
      focusVisibleRing: "inside",
      focusRingWidth: "2px",
      rounded: "l1",
      _icon: {
        boxSize: "5"
      }
    }
  },
  variants: {
    size: {
      xs: {
        root: {
          "--tags-input-height": "sizes.8",
          "--tags-input-px": "spacing.1.5",
          "--tags-input-py": "spacing.1",
          "--tags-input-gap": "spacing.1",
          "--tags-input-item-height": "sizes.6",
          "--tags-input-item-px": "spacing.2",
          textStyle: "xs"
        }
      },
      sm: {
        root: {
          "--tags-input-height": "sizes.9",
          "--tags-input-px": "spacing.1.5",
          "--tags-input-py": "spacing.1",
          "--tags-input-gap": "spacing.1",
          "--tags-input-item-height": "sizes.6",
          "--tags-input-item-px": "spacing.2",
          textStyle: "sm"
        }
      },
      md: {
        root: {
          "--tags-input-height": "sizes.10",
          "--tags-input-px": "spacing.1.5",
          "--tags-input-py": "spacing.1",
          "--tags-input-gap": "spacing.1",
          "--tags-input-item-height": "sizes.7",
          "--tags-input-item-px": "spacing.2",
          textStyle: "sm"
        }
      },
      lg: {
        root: {
          "--tags-input-height": "sizes.11",
          "--tags-input-px": "spacing.1.5",
          "--tags-input-py": "spacing.1",
          "--tags-input-gap": "spacing.1",
          "--tags-input-item-height": "sizes.8",
          "--tags-input-item-px": "spacing.2",
          textStyle: "md"
        }
      }
    },
    variant: {
      outline: {
        control: {
          borderWidth: "1px",
          bg: "bg",
          _focus: {
            outlineWidth: "1px",
            outlineStyle: "solid",
            outlineColor: "var(--focus-color)",
            borderColor: "var(--focus-color)",
            _invalid: {
              outlineColor: "var(--error-color)",
              borderColor: "var(--error-color)"
            }
          }
        },
        itemPreview: {
          bg: "colorPalette.subtle",
          _highlighted: {
            bg: "colorPalette.muted"
          }
        }
      },
      subtle: {
        control: {
          bg: "bg.muted",
          borderWidth: "1px",
          borderColor: "transparent",
          _focus: {
            outlineWidth: "1px",
            outlineStyle: "solid",
            outlineColor: "var(--focus-color)",
            borderColor: "var(--focus-color)",
            _invalid: {
              outlineColor: "var(--error-color)",
              borderColor: "var(--error-color)"
            }
          }
        },
        itemPreview: {
          bg: "bg",
          borderWidth: "1px",
          _highlighted: {
            bg: "colorPalette.subtle",
            borderColor: "colorPalette.emphasized"
          }
        }
      },
      flushed: {
        control: {
          borderRadius: "0",
          px: "0",
          bg: "transparent",
          borderBottomWidth: "1px",
          borderBottomColor: "border",
          _focus: {
            borderColor: "var(--focus-color)",
            boxShadow: "0px 1px 0px 0px var(--focus-color)"
          }
        },
        itemPreview: {
          bg: "colorPalette.subtle",
          _highlighted: {
            bg: "colorPalette.muted"
          }
        }
      }
    }
  },
  defaultVariants: {
    size: "md",
    variant: "outline"
  }
});
const timelineSlotRecipe = defineSlotRecipe({
  slots: timelineAnatomy.keys(),
  className: "chakra-timeline",
  base: {
    root: {
      display: "flex",
      flexDirection: "column",
      width: "full",
      "--timeline-thickness": "1px",
      "--timeline-gutter": "4px"
    },
    item: {
      "--timeline-content-gap": "spacing.6",
      display: "flex",
      position: "relative",
      alignItems: "flex-start",
      flexShrink: 0,
      gap: "4",
      _last: {
        "--timeline-content-gap": "0"
      }
    },
    separator: {
      display: "var(--timeline-separator-display)",
      position: "absolute",
      borderStartWidth: "var(--timeline-thickness)",
      ms: "calc(-1 * var(--timeline-thickness) / 2)",
      insetInlineStart: "calc(var(--timeline-indicator-size) / 2)",
      insetBlock: "0",
      borderColor: "border"
    },
    indicator: {
      outline: "2px solid {colors.bg}",
      position: "relative",
      flexShrink: "0",
      boxSize: "var(--timeline-indicator-size)",
      fontSize: "var(--timeline-font-size)",
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      borderRadius: "full",
      fontWeight: "medium"
    },
    connector: {
      alignSelf: "stretch",
      position: "relative"
    },
    content: {
      pb: "var(--timeline-content-gap)",
      display: "flex",
      flexDirection: "column",
      width: "full",
      gap: "2"
    },
    title: {
      display: "flex",
      fontWeight: "medium",
      flexWrap: "wrap",
      gap: "1.5",
      alignItems: "center",
      mt: "var(--timeline-margin)"
    },
    description: {
      color: "fg.muted",
      textStyle: "xs"
    }
  },
  variants: {
    variant: {
      subtle: {
        indicator: {
          bg: "colorPalette.muted"
        }
      },
      solid: {
        indicator: {
          bg: "colorPalette.solid",
          color: "colorPalette.contrast"
        }
      },
      outline: {
        indicator: {
          bg: "currentBg",
          borderWidth: "1px",
          borderColor: "colorPalette.muted"
        }
      },
      plain: {}
    },
    showLastSeparator: {
      true: {
        item: {
          _last: {
            "--timeline-separator-display": "initial"
          }
        }
      },
      false: {
        item: {
          _last: {
            "--timeline-separator-display": "none"
          }
        }
      }
    },
    size: {
      sm: {
        root: {
          "--timeline-indicator-size": "sizes.4",
          "--timeline-font-size": "fontSizes.2xs"
        },
        title: {
          textStyle: "xs"
        }
      },
      md: {
        root: {
          "--timeline-indicator-size": "sizes.5",
          "--timeline-font-size": "fontSizes.xs"
        },
        title: {
          textStyle: "sm"
        }
      },
      lg: {
        root: {
          "--timeline-indicator-size": "sizes.6",
          "--timeline-font-size": "fontSizes.xs"
        },
        title: {
          mt: "0.5",
          textStyle: "sm"
        }
      },
      xl: {
        root: {
          "--timeline-indicator-size": "sizes.8",
          "--timeline-font-size": "fontSizes.sm"
        },
        title: {
          mt: "1.5",
          textStyle: "sm"
        }
      }
    }
  },
  defaultVariants: {
    size: "md",
    variant: "solid",
    showLastSeparator: false
  }
});
const toastSlotRecipe = defineSlotRecipe({
  slots: toastAnatomy.keys(),
  className: "chakra-toast",
  base: {
    root: {
      width: "full",
      display: "flex",
      alignItems: "flex-start",
      position: "relative",
      gap: "3",
      py: "4",
      ps: "4",
      pe: "6",
      borderRadius: "l2",
      translate: "var(--x) var(--y)",
      scale: "var(--scale)",
      zIndex: "var(--z-index)",
      height: "var(--height)",
      opacity: "var(--opacity)",
      willChange: "translate, opacity, scale",
      transition: "translate 400ms, scale 400ms, opacity 400ms, height 400ms, box-shadow 200ms",
      transitionTimingFunction: "cubic-bezier(0.21, 1.02, 0.73, 1)",
      _closed: {
        transition: "translate 400ms, scale 400ms, opacity 200ms",
        transitionTimingFunction: "cubic-bezier(0.06, 0.71, 0.55, 1)"
      },
      bg: "bg.panel",
      color: "fg",
      boxShadow: "xl",
      "--toast-trigger-bg": "colors.bg.muted",
      "&[data-type=warning]": {
        bg: "orange.solid",
        color: "orange.contrast",
        "--toast-trigger-bg": "{white/10}",
        "--toast-border-color": "{white/40}"
      },
      "&[data-type=success]": {
        bg: "green.solid",
        color: "green.contrast",
        "--toast-trigger-bg": "{white/10}",
        "--toast-border-color": "{white/40}"
      },
      "&[data-type=error]": {
        bg: "red.solid",
        color: "red.contrast",
        "--toast-trigger-bg": "{white/10}",
        "--toast-border-color": "{white/40}"
      }
    },
    title: {
      fontWeight: "medium",
      textStyle: "sm",
      marginEnd: "2"
    },
    description: {
      display: "inline",
      textStyle: "sm",
      opacity: "0.8"
    },
    indicator: {
      flexShrink: "0",
      boxSize: "5"
    },
    actionTrigger: {
      textStyle: "sm",
      fontWeight: "medium",
      height: "8",
      px: "3",
      borderRadius: "l2",
      alignSelf: "center",
      borderWidth: "1px",
      borderColor: "var(--toast-border-color, inherit)",
      transition: "background 200ms",
      _hover: {
        bg: "var(--toast-trigger-bg)"
      }
    },
    closeTrigger: {
      position: "absolute",
      top: "1",
      insetEnd: "1",
      padding: "1",
      display: "inline-flex",
      alignItems: "center",
      justifyContent: "center",
      color: "{currentColor/60}",
      borderRadius: "l2",
      textStyle: "md",
      transition: "background 200ms",
      _icon: {
        boxSize: "1em"
      }
    }
  }
});
const tooltipSlotRecipe = defineSlotRecipe({
  slots: anatomy$m.keys(),
  className: "chakra-tooltip",
  base: {
    content: {
      "--tooltip-bg": "colors.bg.inverted",
      bg: "var(--tooltip-bg)",
      color: "fg.inverted",
      px: "2.5",
      py: "1",
      borderRadius: "l2",
      fontWeight: "medium",
      textStyle: "xs",
      boxShadow: "md",
      maxW: "xs",
      zIndex: "tooltip",
      transformOrigin: "var(--transform-origin)",
      _open: {
        animationStyle: "scale-fade-in",
        animationDuration: "fast"
      },
      _closed: {
        animationStyle: "scale-fade-out",
        animationDuration: "fast"
      }
    },
    arrow: {
      "--arrow-size": "sizes.2",
      "--arrow-background": "var(--tooltip-bg)"
    },
    arrowTip: {
      borderTopWidth: "1px",
      borderLeftWidth: "1px",
      borderColor: "var(--tooltip-bg)"
    }
  }
});
const baseItemStyle = defineStyle({
  display: "flex",
  alignItems: "center",
  gap: "var(--tree-item-gap)",
  rounded: "l2",
  userSelect: "none",
  position: "relative",
  "--tree-depth": "calc(var(--depth) - 1)",
  "--tree-indentation-offset": "calc(var(--tree-indentation) * var(--tree-depth))",
  "--tree-icon-offset": "calc(var(--tree-icon-size) * var(--tree-depth) * 0.5)",
  "--tree-offset": "calc(var(--tree-padding-inline) + var(--tree-indentation-offset) + var(--tree-icon-offset))",
  ps: "var(--tree-offset)",
  pe: "var(--tree-padding-inline)",
  py: "var(--tree-padding-block)",
  focusVisibleRing: "inside",
  focusRingColor: "border.emphasized",
  focusRingWidth: "2px",
  "&:hover, &:focus-visible": {
    bg: "bg.muted"
  },
  _disabled: {
    layerStyle: "disabled"
  }
});
const baseTextStyle = defineStyle({
  flex: "1"
});
const subtleVariantStyle = defineStyle({
  _selected: {
    bg: "colorPalette.subtle",
    color: "colorPalette.fg"
  }
});
const solidVariantStyle = defineStyle({
  _selected: {
    layerStyle: "fill.solid"
  }
});
const treeViewSlotRecipe = defineSlotRecipe({
  slots: anatomy$n.keys(),
  className: "chakra-tree-view",
  base: {
    root: {
      width: "full",
      display: "flex",
      flexDirection: "column",
      gap: "2"
    },
    tree: {
      display: "flex",
      flexDirection: "column",
      "--tree-item-gap": "spacing.2",
      _icon: {
        boxSize: "var(--tree-icon-size)"
      }
    },
    label: {
      fontWeight: "medium",
      textStyle: "sm"
    },
    branch: {
      position: "relative"
    },
    branchContent: {
      position: "relative"
    },
    branchIndentGuide: {
      height: "100%",
      width: "1px",
      bg: "border",
      position: "absolute",
      "--tree-depth": "calc(var(--depth) - 1)",
      "--tree-indentation-offset": "calc(var(--tree-indentation) * var(--tree-depth))",
      "--tree-offset": "calc(var(--tree-padding-inline) + var(--tree-indentation-offset))",
      "--tree-icon-offset": "calc(var(--tree-icon-size) * 0.5 * var(--depth))",
      insetInlineStart: "calc(var(--tree-offset) + var(--tree-icon-offset))",
      zIndex: "1"
    },
    branchIndicator: {
      color: "fg.muted",
      transformOrigin: "center",
      transitionDuration: "normal",
      transitionProperty: "transform",
      transitionTimingFunction: "default",
      _open: {
        transform: "rotate(90deg)"
      }
    },
    branchTrigger: {
      display: "inline-flex",
      alignItems: "center",
      justifyContent: "center"
    },
    branchControl: baseItemStyle,
    item: baseItemStyle,
    itemText: baseTextStyle,
    branchText: baseTextStyle,
    nodeCheckbox: {
      display: "inline-flex"
    }
  },
  variants: {
    size: {
      md: {
        tree: {
          textStyle: "sm",
          "--tree-indentation": "spacing.4",
          "--tree-padding-inline": "spacing.3",
          "--tree-padding-block": "spacing.1.5",
          "--tree-icon-size": "spacing.4"
        }
      },
      sm: {
        tree: {
          textStyle: "sm",
          "--tree-indentation": "spacing.4",
          "--tree-padding-inline": "spacing.3",
          "--tree-padding-block": "spacing.1",
          "--tree-icon-size": "spacing.3"
        }
      },
      xs: {
        tree: {
          textStyle: "xs",
          "--tree-indentation": "spacing.4",
          "--tree-padding-inline": "spacing.2",
          "--tree-padding-block": "spacing.1",
          "--tree-icon-size": "spacing.3"
        }
      }
    },
    variant: {
      subtle: {
        branchControl: subtleVariantStyle,
        item: subtleVariantStyle
      },
      solid: {
        branchControl: solidVariantStyle,
        item: solidVariantStyle
      }
    },
    animateContent: {
      true: {
        branchContent: {
          _open: {
            animationName: "expand-height, fade-in",
            animationDuration: "moderate"
          },
          _closed: {
            animationName: "collapse-height, fade-out",
            animationDuration: "moderate"
          }
        }
      }
    }
  },
  defaultVariants: {
    size: "md",
    variant: "subtle"
  }
});
const slotRecipes = {
  accordion: accordionSlotRecipe,
  actionBar: actionBarSlotRecipe,
  alert: alertSlotRecipe,
  avatar: avatarSlotRecipe,
  blockquote: blockquoteSlotRecipe,
  breadcrumb: breadcrumbSlotRecipe,
  card: cardSlotRecipe,
  carousel: carouselSlotRecipe,
  checkbox: checkboxSlotRecipe,
  checkboxCard: checkboxCardSlotRecipe,
  codeBlock: codeBlockSlotRecipe,
  collapsible: collapsibleSlotRecipe,
  dataList: dataListSlotRecipe,
  dialog: dialogSlotRecipe,
  drawer: drawerSlotRecipe,
  editable: editableSlotRecipe,
  emptyState: emptyStateSlotRecipe,
  field: fieldSlotRecipe,
  fieldset: fieldsetSlotRecipe,
  fileUpload: fileUploadSlotRecipe,
  hoverCard: hoverCardSlotRecipe,
  list: listSlotRecipe,
  listbox: listboxSlotRecipe,
  menu: menuSlotRecipe,
  nativeSelect: nativeSelectSlotRecipe,
  numberInput: numberInputSlotRecipe,
  pinInput: pinInputSlotRecipe,
  popover: popoverSlotRecipe,
  progress: progressSlotRecipe,
  progressCircle: progressCircleSlotRecipe,
  radioCard: radioCardSlotRecipe,
  radioGroup: radioGroupSlotRecipe,
  ratingGroup: ratingGroupSlotRecipe,
  scrollArea: scrollAreaSlotRecipe,
  segmentGroup: segmentGroupSlotRecipe,
  select: selectSlotRecipe,
  combobox: comboboxSlotRecipe,
  slider: sliderSlotRecipe,
  splitter: splitterSlotRecipe,
  stat: statSlotRecipe,
  steps: stepsSlotRecipe,
  switch: switchSlotRecipe,
  table: tableSlotRecipe,
  tabs: tabsSlotRecipe,
  tag: tagSlotRecipe,
  tagsInput: tagsInputSlotRecipe,
  toast: toastSlotRecipe,
  tooltip: tooltipSlotRecipe,
  status: statusSlotRecipe,
  timeline: timelineSlotRecipe,
  colorPicker: colorPickerSlotRecipe,
  qrCode: qrCodeSlotRecipe,
  treeView: treeViewSlotRecipe
};
const textStyles = defineTextStyles({
  "2xs": { value: { fontSize: "2xs", lineHeight: "0.75rem" } },
  xs: { value: { fontSize: "xs", lineHeight: "1rem" } },
  sm: { value: { fontSize: "sm", lineHeight: "1.25rem" } },
  md: { value: { fontSize: "md", lineHeight: "1.5rem" } },
  lg: { value: { fontSize: "lg", lineHeight: "1.75rem" } },
  xl: { value: { fontSize: "xl", lineHeight: "1.875rem" } },
  "2xl": { value: { fontSize: "2xl", lineHeight: "2rem" } },
  "3xl": { value: { fontSize: "3xl", lineHeight: "2.375rem" } },
  "4xl": {
    value: {
      fontSize: "4xl",
      lineHeight: "2.75rem",
      letterSpacing: "-0.025em"
    }
  },
  "5xl": {
    value: {
      fontSize: "5xl",
      lineHeight: "3.75rem",
      letterSpacing: "-0.025em"
    }
  },
  "6xl": {
    value: { fontSize: "6xl", lineHeight: "4.5rem", letterSpacing: "-0.025em" }
  },
  "7xl": {
    value: {
      fontSize: "7xl",
      lineHeight: "5.75rem",
      letterSpacing: "-0.025em"
    }
  },
  none: {
    value: {}
  },
  label: {
    value: {
      fontSize: "sm",
      lineHeight: "1.25rem",
      fontWeight: "medium"
    }
  }
});
const animations = defineTokens.animations({
  spin: { value: "spin 1s linear infinite" },
  ping: { value: "ping 1s cubic-bezier(0, 0, 0.2, 1) infinite" },
  pulse: { value: "pulse 2s cubic-bezier(0.4, 0, 0.6, 1) infinite" },
  bounce: { value: "bounce 1s infinite" }
});
const aspectRatios = defineTokens.aspectRatios({
  square: { value: "1 / 1" },
  landscape: { value: "4 / 3" },
  portrait: { value: "3 / 4" },
  wide: { value: "16 / 9" },
  ultrawide: { value: "18 / 5" },
  golden: { value: "1.618 / 1" }
});
const blurs = defineTokens.blurs({
  none: { value: " " },
  sm: { value: "4px" },
  md: { value: "8px" },
  lg: { value: "12px" },
  xl: { value: "16px" },
  "2xl": { value: "24px" },
  "3xl": { value: "40px" },
  "4xl": { value: "64px" }
});
const borders = defineTokens.borders({
  xs: { value: "0.5px solid" },
  sm: { value: "1px solid" },
  md: { value: "2px solid" },
  lg: { value: "4px solid" },
  xl: { value: "8px solid" }
});
const colors = defineTokens.colors({
  transparent: { value: "transparent" },
  current: { value: "currentColor" },
  black: { value: "#09090B" },
  white: { value: "#FFFFFF" },
  whiteAlpha: {
    50: { value: "rgba(255, 255, 255, 0.04)" },
    100: { value: "rgba(255, 255, 255, 0.06)" },
    200: { value: "rgba(255, 255, 255, 0.08)" },
    300: { value: "rgba(255, 255, 255, 0.16)" },
    400: { value: "rgba(255, 255, 255, 0.24)" },
    500: { value: "rgba(255, 255, 255, 0.36)" },
    600: { value: "rgba(255, 255, 255, 0.48)" },
    700: { value: "rgba(255, 255, 255, 0.64)" },
    800: { value: "rgba(255, 255, 255, 0.80)" },
    900: { value: "rgba(255, 255, 255, 0.92)" },
    950: { value: "rgba(255, 255, 255, 0.95)" }
  },
  blackAlpha: {
    50: { value: "rgba(0, 0, 0, 0.04)" },
    100: { value: "rgba(0, 0, 0, 0.06)" },
    200: { value: "rgba(0, 0, 0, 0.08)" },
    300: { value: "rgba(0, 0, 0, 0.16)" },
    400: { value: "rgba(0, 0, 0, 0.24)" },
    500: { value: "rgba(0, 0, 0, 0.36)" },
    600: { value: "rgba(0, 0, 0, 0.48)" },
    700: { value: "rgba(0, 0, 0, 0.64)" },
    800: { value: "rgba(0, 0, 0, 0.80)" },
    900: { value: "rgba(0, 0, 0, 0.92)" },
    950: { value: "rgba(0, 0, 0, 0.95)" }
  },
  gray: {
    50: { value: "#fafafa" },
    100: { value: "#f4f4f5" },
    200: { value: "#e4e4e7" },
    300: { value: "#d4d4d8" },
    400: { value: "#a1a1aa" },
    500: { value: "#71717a" },
    600: { value: "#52525b" },
    700: { value: "#3f3f46" },
    800: { value: "#27272a" },
    900: { value: "#18181b" },
    950: { value: "#111111" }
  },
  red: {
    50: { value: "#fef2f2" },
    100: { value: "#fee2e2" },
    200: { value: "#fecaca" },
    300: { value: "#fca5a5" },
    400: { value: "#f87171" },
    500: { value: "#ef4444" },
    600: { value: "#dc2626" },
    700: { value: "#991919" },
    800: { value: "#511111" },
    900: { value: "#300c0c" },
    950: { value: "#1f0808" }
  },
  orange: {
    50: { value: "#fff7ed" },
    100: { value: "#ffedd5" },
    200: { value: "#fed7aa" },
    300: { value: "#fdba74" },
    400: { value: "#fb923c" },
    500: { value: "#f97316" },
    600: { value: "#ea580c" },
    700: { value: "#92310a" },
    800: { value: "#6c2710" },
    900: { value: "#3b1106" },
    950: { value: "#220a04" }
  },
  yellow: {
    50: { value: "#fefce8" },
    100: { value: "#fef9c3" },
    200: { value: "#fef08a" },
    300: { value: "#fde047" },
    400: { value: "#facc15" },
    500: { value: "#eab308" },
    600: { value: "#ca8a04" },
    700: { value: "#845209" },
    800: { value: "#713f12" },
    900: { value: "#422006" },
    950: { value: "#281304" }
  },
  green: {
    50: { value: "#f0fdf4" },
    100: { value: "#dcfce7" },
    200: { value: "#bbf7d0" },
    300: { value: "#86efac" },
    400: { value: "#4ade80" },
    500: { value: "#22c55e" },
    600: { value: "#16a34a" },
    700: { value: "#116932" },
    800: { value: "#124a28" },
    900: { value: "#042713" },
    950: { value: "#03190c" }
  },
  teal: {
    50: { value: "#f0fdfa" },
    100: { value: "#ccfbf1" },
    200: { value: "#99f6e4" },
    300: { value: "#5eead4" },
    400: { value: "#2dd4bf" },
    500: { value: "#14b8a6" },
    600: { value: "#0d9488" },
    700: { value: "#0c5d56" },
    800: { value: "#114240" },
    900: { value: "#032726" },
    950: { value: "#021716" }
  },
  blue: {
    50: { value: "#eff6ff" },
    100: { value: "#dbeafe" },
    200: { value: "#bfdbfe" },
    300: { value: "#a3cfff" },
    400: { value: "#60a5fa" },
    500: { value: "#3b82f6" },
    600: { value: "#2563eb" },
    700: { value: "#173da6" },
    800: { value: "#1a3478" },
    900: { value: "#14204a" },
    950: { value: "#0c142e" }
  },
  cyan: {
    50: { value: "#ecfeff" },
    100: { value: "#cffafe" },
    200: { value: "#a5f3fc" },
    300: { value: "#67e8f9" },
    400: { value: "#22d3ee" },
    500: { value: "#06b6d4" },
    600: { value: "#0891b2" },
    700: { value: "#0c5c72" },
    800: { value: "#134152" },
    900: { value: "#072a38" },
    950: { value: "#051b24" }
  },
  purple: {
    50: { value: "#faf5ff" },
    100: { value: "#f3e8ff" },
    200: { value: "#e9d5ff" },
    300: { value: "#d8b4fe" },
    400: { value: "#c084fc" },
    500: { value: "#a855f7" },
    600: { value: "#9333ea" },
    700: { value: "#641ba3" },
    800: { value: "#4a1772" },
    900: { value: "#2f0553" },
    950: { value: "#1a032e" }
  },
  pink: {
    50: { value: "#fdf2f8" },
    100: { value: "#fce7f3" },
    200: { value: "#fbcfe8" },
    300: { value: "#f9a8d4" },
    400: { value: "#f472b6" },
    500: { value: "#ec4899" },
    600: { value: "#db2777" },
    700: { value: "#a41752" },
    800: { value: "#6d0e34" },
    900: { value: "#45061f" },
    950: { value: "#2c0514" }
  }
});
const cursor = defineTokens.cursor({
  button: { value: "pointer" },
  checkbox: { value: "default" },
  disabled: { value: "not-allowed" },
  menuitem: { value: "default" },
  option: { value: "default" },
  radio: { value: "default" },
  slider: { value: "default" },
  switch: { value: "pointer" }
});
const durations = defineTokens.durations({
  fastest: { value: "50ms" },
  faster: { value: "100ms" },
  fast: { value: "150ms" },
  moderate: { value: "200ms" },
  slow: { value: "300ms" },
  slower: { value: "400ms" },
  slowest: { value: "500ms" }
});
const easings = defineTokens.easings({
  "ease-in": { value: "cubic-bezier(0.42, 0, 1, 1)" },
  "ease-out": { value: "cubic-bezier(0, 0, 0.58, 1)" },
  "ease-in-out": { value: "cubic-bezier(0.42, 0, 0.58, 1)" },
  "ease-in-smooth": { value: "cubic-bezier(0.32, 0.72, 0, 1)" }
});
const fontSizes = defineTokens.fontSizes({
  "2xs": { value: "0.625rem" },
  xs: { value: "0.75rem" },
  sm: { value: "0.875rem" },
  md: { value: "1rem" },
  lg: { value: "1.125rem" },
  xl: { value: "1.25rem" },
  "2xl": { value: "1.5rem" },
  "3xl": { value: "1.875rem" },
  "4xl": { value: "2.25rem" },
  "5xl": { value: "3rem" },
  "6xl": { value: "3.75rem" },
  "7xl": { value: "4.5rem" },
  "8xl": { value: "6rem" },
  "9xl": { value: "8rem" }
});
const fontWeights = defineTokens.fontWeights({
  thin: { value: "100" },
  extralight: { value: "200" },
  light: { value: "300" },
  normal: { value: "400" },
  medium: { value: "500" },
  semibold: { value: "600" },
  bold: { value: "700" },
  extrabold: { value: "800" },
  black: { value: "900" }
});
const fallback = `-apple-system, BlinkMacSystemFont, "Segoe UI", Helvetica, Arial, sans-serif, "Apple Color Emoji", "Segoe UI Emoji", "Segoe UI Symbol"`;
const fonts = defineTokens.fonts({
  heading: {
    value: `Inter, ${fallback}`
  },
  body: {
    value: `Inter, ${fallback}`
  },
  mono: {
    value: `SFMono-Regular,Menlo,Monaco,Consolas,"Liberation Mono","Courier New",monospace`
  }
});
const keyframes = defineKeyframes({
  spin: {
    "0%": { transform: "rotate(0deg)" },
    "100%": { transform: "rotate(360deg)" }
  },
  pulse: {
    "50%": { opacity: "0.5" }
  },
  ping: {
    "75%, 100%": {
      transform: "scale(2)",
      opacity: "0"
    }
  },
  bounce: {
    "0%, 100%": {
      transform: "translateY(-25%)",
      animationTimingFunction: "cubic-bezier(0.8,0,1,1)"
    },
    "50%": {
      transform: "none",
      animationTimingFunction: "cubic-bezier(0,0,0.2,1)"
    }
  },
  "bg-position": {
    from: { backgroundPosition: "var(--animate-from, 1rem) 0" },
    to: { backgroundPosition: "var(--animate-to, 0) 0" }
  },
  position: {
    from: {
      insetInlineStart: "var(--animate-from-x)",
      insetBlockStart: "var(--animate-from-y)"
    },
    to: {
      insetInlineStart: "var(--animate-to-x)",
      insetBlockStart: "var(--animate-to-y)"
    }
  },
  "circular-progress": {
    "0%": {
      strokeDasharray: "1, 400",
      strokeDashoffset: "0"
    },
    "50%": {
      strokeDasharray: "400, 400",
      strokeDashoffset: "-100%"
    },
    "100%": {
      strokeDasharray: "400, 400",
      strokeDashoffset: "-260%"
    }
  },
  // collapse
  "expand-height": {
    from: { height: "var(--collapsed-height, 0)" },
    to: { height: "var(--height)" }
  },
  "collapse-height": {
    from: { height: "var(--height)" },
    to: { height: "var(--collapsed-height, 0)" }
  },
  "expand-width": {
    from: { width: "var(--collapsed-width, 0)" },
    to: { width: "var(--width)" }
  },
  "collapse-width": {
    from: { height: "var(--width)" },
    to: { height: "var(--collapsed-width, 0)" }
  },
  // fade
  "fade-in": {
    from: { opacity: 0 },
    to: { opacity: 1 }
  },
  "fade-out": {
    from: { opacity: 1 },
    to: { opacity: 0 }
  },
  // slide from (full)
  "slide-from-left-full": {
    from: { translate: "-100% 0" },
    to: { translate: "0 0" }
  },
  "slide-from-right-full": {
    from: { translate: "100% 0" },
    to: { translate: "0 0" }
  },
  "slide-from-top-full": {
    from: { translate: "0 -100%" },
    to: { translate: "0 0" }
  },
  "slide-from-bottom-full": {
    from: { translate: "0 100%" },
    to: { translate: "0 0" }
  },
  // slide to (full)
  "slide-to-left-full": {
    from: { translate: "0 0" },
    to: { translate: "-100% 0" }
  },
  "slide-to-right-full": {
    from: { translate: "0 0" },
    to: { translate: "100% 0" }
  },
  "slide-to-top-full": {
    from: { translate: "0 0" },
    to: { translate: "0 -100%" }
  },
  "slide-to-bottom-full": {
    from: { translate: "0 0" },
    to: { translate: "0 100%" }
  },
  // slide from
  "slide-from-top": {
    "0%": { translate: "0 -0.5rem" },
    to: { translate: "0" }
  },
  "slide-from-bottom": {
    "0%": { translate: "0 0.5rem" },
    to: { translate: "0" }
  },
  "slide-from-left": {
    "0%": { translate: "-0.5rem 0" },
    to: { translate: "0" }
  },
  "slide-from-right": {
    "0%": { translate: "0.5rem 0" },
    to: { translate: "0" }
  },
  // slide to
  "slide-to-top": {
    "0%": { translate: "0" },
    to: { translate: "0 -0.5rem" }
  },
  "slide-to-bottom": {
    "0%": { translate: "0" },
    to: { translate: "0 0.5rem" }
  },
  "slide-to-left": {
    "0%": { translate: "0" },
    to: { translate: "-0.5rem 0" }
  },
  "slide-to-right": {
    "0%": { translate: "0" },
    to: { translate: "0.5rem 0" }
  },
  // scale
  "scale-in": {
    from: { scale: "0.95" },
    to: { scale: "1" }
  },
  "scale-out": {
    from: { scale: "1" },
    to: { scale: "0.95" }
  }
});
const letterSpacings = defineTokens.letterSpacings({
  tighter: { value: "-0.05em" },
  tight: { value: "-0.025em" },
  wide: { value: "0.025em" },
  wider: { value: "0.05em" },
  widest: { value: "0.1em" }
});
const lineHeights = defineTokens.lineHeights({
  shorter: { value: 1.25 },
  short: { value: 1.375 },
  moderate: { value: 1.5 },
  tall: { value: 1.625 },
  taller: { value: 2 }
});
const radii = defineTokens.radii({
  none: { value: "0" },
  "2xs": { value: "0.0625rem" },
  xs: { value: "0.125rem" },
  sm: { value: "0.25rem" },
  md: { value: "0.375rem" },
  lg: { value: "0.5rem" },
  xl: { value: "0.75rem" },
  "2xl": { value: "1rem" },
  "3xl": { value: "1.5rem" },
  "4xl": { value: "2rem" },
  full: { value: "9999px" }
});
const spacing = defineTokens.spacing({
  0.5: { value: "0.125rem" },
  1: { value: "0.25rem" },
  1.5: { value: "0.375rem" },
  2: { value: "0.5rem" },
  2.5: { value: "0.625rem" },
  3: { value: "0.75rem" },
  3.5: { value: "0.875rem" },
  4: { value: "1rem" },
  4.5: { value: "1.125rem" },
  5: { value: "1.25rem" },
  6: { value: "1.5rem" },
  7: { value: "1.75rem" },
  8: { value: "2rem" },
  9: { value: "2.25rem" },
  10: { value: "2.5rem" },
  11: { value: "2.75rem" },
  12: { value: "3rem" },
  14: { value: "3.5rem" },
  16: { value: "4rem" },
  20: { value: "5rem" },
  24: { value: "6rem" },
  28: { value: "7rem" },
  32: { value: "8rem" },
  36: { value: "9rem" },
  40: { value: "10rem" },
  44: { value: "11rem" },
  48: { value: "12rem" },
  52: { value: "13rem" },
  56: { value: "14rem" },
  60: { value: "15rem" },
  64: { value: "16rem" },
  72: { value: "18rem" },
  80: { value: "20rem" },
  96: { value: "24rem" }
});
const largeSizes = defineTokens.sizes({
  "3xs": { value: "14rem" },
  "2xs": { value: "16rem" },
  xs: { value: "20rem" },
  sm: { value: "24rem" },
  md: { value: "28rem" },
  lg: { value: "32rem" },
  xl: { value: "36rem" },
  "2xl": { value: "42rem" },
  "3xl": { value: "48rem" },
  "4xl": { value: "56rem" },
  "5xl": { value: "64rem" },
  "6xl": { value: "72rem" },
  "7xl": { value: "80rem" },
  "8xl": { value: "90rem" }
});
const namedSizes = defineTokens.sizes({
  max: { value: "max-content" },
  min: { value: "min-content" },
  fit: { value: "fit-content" },
  prose: { value: "60ch" },
  full: { value: "100%" },
  dvh: { value: "100dvh" },
  svh: { value: "100svh" },
  lvh: { value: "100lvh" },
  dvw: { value: "100dvw" },
  svw: { value: "100svw" },
  lvw: { value: "100lvw" },
  vw: { value: "100vw" },
  vh: { value: "100vh" }
});
const fractionalSizes = defineTokens.sizes({
  "1/2": { value: "50%" },
  "1/3": { value: "33.333333%" },
  "2/3": { value: "66.666667%" },
  "1/4": { value: "25%" },
  "3/4": { value: "75%" },
  "1/5": { value: "20%" },
  "2/5": { value: "40%" },
  "3/5": { value: "60%" },
  "4/5": { value: "80%" },
  "1/6": { value: "16.666667%" },
  "2/6": { value: "33.333333%" },
  "3/6": { value: "50%" },
  "4/6": { value: "66.666667%" },
  "5/6": { value: "83.333333%" },
  "1/12": { value: "8.333333%" },
  "2/12": { value: "16.666667%" },
  "3/12": { value: "25%" },
  "4/12": { value: "33.333333%" },
  "5/12": { value: "41.666667%" },
  "6/12": { value: "50%" },
  "7/12": { value: "58.333333%" },
  "8/12": { value: "66.666667%" },
  "9/12": { value: "75%" },
  "10/12": { value: "83.333333%" },
  "11/12": { value: "91.666667%" }
});
const sizes = defineTokens.sizes({
  ...largeSizes,
  ...spacing,
  ...fractionalSizes,
  ...namedSizes
});
const zIndices = defineTokens.zIndex({
  hide: { value: -1 },
  base: { value: 0 },
  docked: { value: 10 },
  dropdown: { value: 1e3 },
  sticky: { value: 1100 },
  banner: { value: 1200 },
  overlay: { value: 1300 },
  modal: { value: 1400 },
  popover: { value: 1500 },
  skipNav: { value: 1600 },
  toast: { value: 1700 },
  tooltip: { value: 1800 },
  max: { value: 2147483647 }
});
const tokens = {
  aspectRatios,
  animations,
  blurs,
  borders,
  colors,
  durations,
  easings,
  fonts,
  fontSizes,
  fontWeights,
  letterSpacings,
  lineHeights,
  radii,
  spacing,
  sizes,
  zIndex: zIndices,
  cursor
};
const semanticTokens = {
  colors: semanticColors,
  shadows: semanticShadows,
  radii: semanticRadii
};
const cssVarsPrefix = "chakra";
const cssVarsRoot = ":where(html, .chakra-theme)";
const defaultThemeConfig = defineConfig({
  preflight: true,
  cssVarsPrefix,
  cssVarsRoot,
  globalCss,
  theme: {
    breakpoints,
    keyframes,
    tokens,
    semanticTokens,
    recipes,
    slotRecipes,
    textStyles,
    layerStyles,
    animationStyles
  }
});
const defaultConfig = mergeConfigs(defaultBaseConfig, defaultThemeConfig);
const defaultSystem = createSystem(defaultConfig);
function useSlotRecipe(options) {
  const { key, recipe: recipeProp } = options;
  const sys = useChakraContext();
  return reactExports.useMemo(() => {
    const recipe = recipeProp || (key != null ? sys.getSlotRecipe(key) : {});
    return sys.sva(structuredClone(recipe));
  }, [key, recipeProp, sys]);
}
const upperFirst = (str) => str.charAt(0).toUpperCase() + str.slice(1);
const createSlotRecipeContext = (options) => {
  const { key: recipeKey, recipe: recipeConfig } = options;
  const contextName = upperFirst(
    recipeKey || recipeConfig.className || "Component"
  );
  const [StylesProvider, useStyles] = createContext({
    name: `${contextName}StylesContext`,
    errorMessage: `use${contextName}Styles returned is 'undefined'. Seems you forgot to wrap the components in "<${contextName}.Root />" `
  });
  const [ClassNamesProvider, useClassNames] = createContext({
    name: `${contextName}ClassNameContext`,
    errorMessage: `use${contextName}ClassNames returned is 'undefined'. Seems you forgot to wrap the components in "<${contextName}.Root />" `,
    strict: false
  });
  const [PropsProvider, usePropsContext2] = createContext({
    strict: false,
    name: `${contextName}PropsContext`,
    providerName: `${contextName}PropsContext`,
    defaultValue: {}
  });
  function useRecipeResult2(props) {
    const { unstyled, ...restProps } = props;
    const slotRecipe = useSlotRecipe({
      key: recipeKey,
      recipe: restProps.recipe || recipeConfig
    });
    const [variantProps, otherProps] = reactExports.useMemo(
      () => slotRecipe.splitVariantProps(restProps),
      [restProps, slotRecipe]
    );
    const styles = reactExports.useMemo(
      () => unstyled ? EMPTY_SLOT_STYLES : slotRecipe(variantProps),
      [unstyled, variantProps, slotRecipe]
    );
    return {
      styles,
      classNames: slotRecipe.classNameMap,
      props: otherProps
    };
  }
  function withRootProvider2(Component, options2 = {}) {
    const { defaultProps } = options2;
    const StyledComponent = (inProps) => {
      const propsContext = usePropsContext2();
      const props = reactExports.useMemo(
        () => mergeProps(defaultProps, propsContext, inProps),
        [propsContext, inProps]
      );
      const { styles, classNames, props: rootProps } = useRecipeResult2(props);
      return /* @__PURE__ */ jsxRuntimeExports.jsx(StylesProvider, { value: styles, children: /* @__PURE__ */ jsxRuntimeExports.jsx(ClassNamesProvider, { value: classNames, children: /* @__PURE__ */ jsxRuntimeExports.jsx(Component, { ...rootProps }) }) });
    };
    StyledComponent.displayName = Component.displayName || Component.name;
    return StyledComponent;
  }
  const withProvider2 = (Component, slot, options2) => {
    const { defaultProps, ...restOptions } = options2 ?? {};
    const SuperComponent = chakra(Component, {}, restOptions);
    const StyledComponent = reactExports.forwardRef((inProps, ref) => {
      const propsContext = usePropsContext2();
      const props = reactExports.useMemo(
        () => mergeProps(defaultProps ?? {}, propsContext, inProps),
        [propsContext, inProps]
      );
      const { styles, props: rootProps, classNames } = useRecipeResult2(props);
      const className = classNames[slot];
      const element = /* @__PURE__ */ jsxRuntimeExports.jsx(StylesProvider, { value: styles, children: /* @__PURE__ */ jsxRuntimeExports.jsx(ClassNamesProvider, { value: classNames, children: /* @__PURE__ */ jsxRuntimeExports.jsx(
        SuperComponent,
        {
          ref,
          ...rootProps,
          css: [styles[slot], props.css],
          className: cx(props.className, className)
        }
      ) }) });
      return options2?.wrapElement?.(element, props) ?? element;
    });
    StyledComponent.displayName = Component.displayName || Component.name;
    return StyledComponent;
  };
  const withContext2 = (Component, slot, options2) => {
    const SuperComponent = chakra(Component, {}, options2);
    const StyledComponent = reactExports.forwardRef((props, ref) => {
      const { unstyled, ...restProps } = props;
      const styles = useStyles();
      const classNames = useClassNames();
      const className = classNames?.[slot];
      return /* @__PURE__ */ jsxRuntimeExports.jsx(
        SuperComponent,
        {
          ...restProps,
          css: [!unstyled && slot ? styles[slot] : void 0, props.css],
          ref,
          className: cx(props.className, className)
        }
      );
    });
    StyledComponent.displayName = Component.displayName || Component.name;
    return StyledComponent;
  };
  return {
    StylesProvider,
    ClassNamesProvider,
    PropsProvider,
    usePropsContext: usePropsContext2,
    useRecipeResult: useRecipeResult2,
    withProvider: withProvider2,
    withContext: withContext2,
    withRootProvider: withRootProvider2,
    useStyles,
    useClassNames
  };
};
const AbsoluteCenter = chakra("div", {
  base: {
    position: "absolute",
    display: "flex",
    alignItems: "center",
    justifyContent: "center"
  },
  variants: {
    axis: {
      horizontal: {
        insetStart: "50%",
        translate: "-50%",
        _rtl: {
          translate: "50%"
        }
      },
      vertical: {
        top: "50%",
        translate: "0 -50%"
      },
      both: {
        insetStart: "50%",
        top: "50%",
        translate: "-50% -50%",
        _rtl: {
          translate: "50% -50%"
        }
      }
    }
  },
  defaultVariants: {
    axis: "both"
  }
});
AbsoluteCenter.displayName = "AbsoluteCenter";
const dataAttr = (condition) => condition ? "" : void 0;
const { withContext: withContext$6 } = createRecipeContext({
  key: "spinner"
});
const Spinner = withContext$6("span");
Spinner.displayName = "Spinner";
const Loader = reactExports.forwardRef(
  function Loader2(props, ref) {
    const {
      spinner = /* @__PURE__ */ jsxRuntimeExports.jsx(Spinner, { size: "inherit", borderWidth: "0.125em", color: "inherit" }),
      spinnerPlacement = "start",
      children,
      text,
      visible = true,
      ...rest
    } = props;
    if (!visible) return children;
    if (text) {
      return /* @__PURE__ */ jsxRuntimeExports.jsxs(Span, { ref, display: "contents", ...rest, children: [
        spinnerPlacement === "start" && spinner,
        text,
        spinnerPlacement === "end" && spinner
      ] });
    }
    if (spinner) {
      return /* @__PURE__ */ jsxRuntimeExports.jsxs(Span, { ref, display: "contents", ...rest, children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(AbsoluteCenter, { display: "inline-flex", children: spinner }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(Span, { visibility: "hidden", display: "contents", children })
      ] });
    }
    return /* @__PURE__ */ jsxRuntimeExports.jsx(Span, { ref, display: "contents", ...rest, children });
  }
);
Loader.displayName = "Loader";
const { useRecipeResult, usePropsContext } = createRecipeContext(
  { key: "button" }
);
const Button = reactExports.forwardRef(
  function Button2(inProps, ref) {
    const propsContext = usePropsContext();
    const props = reactExports.useMemo(
      () => mergeProps(propsContext, inProps),
      [propsContext, inProps]
    );
    const result = useRecipeResult(props);
    const {
      loading,
      loadingText,
      children,
      spinner,
      spinnerPlacement,
      ...rest
    } = result.props;
    return /* @__PURE__ */ jsxRuntimeExports.jsx(
      chakra.button,
      {
        type: "button",
        ref,
        ...rest,
        "data-loading": dataAttr(loading),
        disabled: loading || rest.disabled,
        className: cx(result.className, props.className),
        css: [result.styles, props.css],
        children: !props.asChild && loading ? /* @__PURE__ */ jsxRuntimeExports.jsx(
          Loader,
          {
            spinner,
            text: loadingText,
            spinnerPlacement,
            children
          }
        ) : children
      }
    );
  }
);
Button.displayName = "Button";
const IconButton = reactExports.forwardRef(
  function IconButton2(props, ref) {
    return /* @__PURE__ */ jsxRuntimeExports.jsx(
      Button,
      {
        px: "0",
        py: "0",
        _icon: { fontSize: "1.2em" },
        ref,
        ...props
      }
    );
  }
);
IconButton.displayName = "IconButton";
const Checkmark = reactExports.forwardRef(
  function Checkmark2(props, ref) {
    const recipe = useRecipe({ key: "checkmark", recipe: props.recipe });
    const [variantProps, restProps] = recipe.splitVariantProps(props);
    const { checked, indeterminate, disabled, unstyled, children, ...rest } = restProps;
    const styles = unstyled ? EMPTY_STYLES : recipe(variantProps);
    return /* @__PURE__ */ jsxRuntimeExports.jsx(
      chakra.svg,
      {
        ref,
        viewBox: "0 0 24 24",
        fill: "none",
        stroke: "currentColor",
        strokeWidth: "3px",
        strokeLinecap: "round",
        strokeLinejoin: "round",
        "data-state": indeterminate ? "indeterminate" : checked ? "checked" : "unchecked",
        "data-disabled": dataAttr(disabled),
        css: [styles, props.css],
        ...rest,
        children: indeterminate ? /* @__PURE__ */ jsxRuntimeExports.jsx("path", { d: "M5 12h14" }) : checked ? /* @__PURE__ */ jsxRuntimeExports.jsx("polyline", { points: "20 6 9 17 4 12" }) : null
      }
    );
  }
);
Checkmark.displayName = "Checkmark";
const {
  withProvider,
  withContext: withContext$5,
  useStyles: useCheckboxStyles
} = createSlotRecipeContext({ key: "checkbox" });
withProvider(CheckboxRootProvider, "root", { forwardAsChild: true });
const CheckboxRoot = withProvider(
  CheckboxRoot$1,
  "root",
  { forwardAsChild: true }
);
const CheckboxLabel = withContext$5(
  CheckboxLabel$1,
  "label",
  { forwardAsChild: true }
);
const CheckboxIndicator = reactExports.forwardRef(function CheckboxIndicator2(props, ref) {
  const { checked, indeterminate, ...rest } = props;
  const api = useCheckboxContext();
  const styles = useCheckboxStyles();
  if (checked && api.checked) {
    return /* @__PURE__ */ jsxRuntimeExports.jsx(
      chakra.svg,
      {
        ref,
        asChild: true,
        ...rest,
        css: [styles.indicator, props.css],
        children: checked
      }
    );
  }
  if (indeterminate && api.indeterminate) {
    return /* @__PURE__ */ jsxRuntimeExports.jsx(
      chakra.svg,
      {
        ref,
        asChild: true,
        ...rest,
        css: [styles.indicator, props.css],
        children: indeterminate
      }
    );
  }
  return /* @__PURE__ */ jsxRuntimeExports.jsx(
    Checkmark,
    {
      ref,
      checked: api.checked,
      indeterminate: api.indeterminate,
      disabled: api.disabled,
      unstyled: true,
      ...rest,
      css: [styles.indicator, props.css]
    }
  );
});
const CheckboxControl = withContext$5(
  CheckboxControl$1,
  "control",
  {
    forwardAsChild: true,
    defaultProps: { children: /* @__PURE__ */ jsxRuntimeExports.jsx(CheckboxIndicator, {}) }
  }
);
chakra(
  CheckboxGroup,
  {
    base: {
      display: "flex",
      flexDirection: "column",
      gap: "1.5"
    }
  },
  { forwardAsChild: true }
);
const CheckboxHiddenInput = CheckboxHiddenInput$1;
function Show(props) {
  const { when, fallback: fallback2, children } = props;
  let result;
  if (!when) {
    result = fallback2;
  } else {
    result = typeof children === "function" ? children(when) : children;
  }
  return reactExports.isValidElement(result) ? result : /* @__PURE__ */ jsxRuntimeExports.jsx(jsxRuntimeExports.Fragment, { children: result });
}
const ClientOnly = (props) => {
  const { children, fallback: fallback2 } = props;
  const [hasMounted, setHasMounted] = reactExports.useState(false);
  reactExports.useEffect(() => {
    setHasMounted(true);
  }, []);
  return /* @__PURE__ */ jsxRuntimeExports.jsx(Show, { when: hasMounted, fallback: fallback2, children });
};
function getSeparatorStyles(options) {
  const { gap, direction } = options;
  const styles = {
    column: {
      marginY: gap,
      marginX: 0,
      borderInlineStartWidth: 0,
      borderTopWidth: "1px"
    },
    "column-reverse": {
      marginY: gap,
      marginX: 0,
      borderInlineStartWidth: 0,
      borderTopWidth: "1px"
    },
    row: {
      marginX: gap,
      marginY: 0,
      borderInlineStartWidth: "1px",
      borderTopWidth: 0
    },
    "row-reverse": {
      marginX: gap,
      marginY: 0,
      borderInlineStartWidth: "1px",
      borderTopWidth: 0
    }
  };
  return {
    "&": mapObject(direction, (value) => styles[value])
  };
}
function getValidChildren(children) {
  return reactExports.Children.toArray(children).filter(
    (child) => reactExports.isValidElement(child)
  );
}
const Stack = reactExports.forwardRef(
  function Stack2(props, ref) {
    const {
      direction = "column",
      align,
      justify,
      gap = "0.5rem",
      wrap: wrap2,
      children,
      separator,
      className,
      ...rest
    } = props;
    const separatorStyle = reactExports.useMemo(
      () => getSeparatorStyles({ gap, direction }),
      [gap, direction]
    );
    const clones = reactExports.useMemo(() => {
      if (!reactExports.isValidElement(separator)) return children;
      return getValidChildren(children).map((child, index, arr) => {
        const key = typeof child.key !== "undefined" ? child.key : index;
        const typedSep = separator;
        const sep = reactExports.cloneElement(typedSep, {
          css: [separatorStyle, typedSep.props.css]
        });
        return /* @__PURE__ */ jsxRuntimeExports.jsxs(reactExports.Fragment, { children: [
          child,
          index === arr.length - 1 ? null : sep
        ] }, key);
      });
    }, [children, separator, separatorStyle]);
    return /* @__PURE__ */ jsxRuntimeExports.jsx(
      chakra.div,
      {
        ref,
        display: "flex",
        alignItems: align,
        justifyContent: justify,
        flexDirection: direction,
        flexWrap: wrap2,
        gap: separator ? void 0 : gap,
        className: cx("chakra-stack", className),
        ...rest,
        children: clones
      }
    );
  }
);
Stack.displayName = "Stack";
const Flex = reactExports.forwardRef(
  function Flex2(props, ref) {
    const {
      direction,
      align,
      justify,
      wrap: wrap2,
      basis,
      grow,
      shrink,
      inline,
      ...rest
    } = props;
    return /* @__PURE__ */ jsxRuntimeExports.jsx(
      chakra.div,
      {
        ref,
        ...rest,
        css: {
          display: inline ? "inline-flex" : "flex",
          flexDirection: direction,
          alignItems: align,
          justifyContent: justify,
          flexWrap: wrap2,
          flexBasis: basis,
          flexGrow: grow,
          flexShrink: shrink,
          ...props.css
        }
      }
    );
  }
);
Flex.displayName = "Flex";
const { withContext: withContext$4 } = createRecipeContext({
  key: "input"
});
const Input = withContext$4(FieldInput);
const { withContext: withContext$3 } = createRecipeContext({
  key: "link"
});
const Link = withContext$3("a");
Link.displayName = "Link";
const { withContext: withContext$2 } = createRecipeContext({
  key: "skeleton"
});
const Skeleton = withContext$2("div");
Skeleton.displayName = "Skeleton";
const SkeletonCircle = reactExports.forwardRef(function SkeletonCircle2(props, ref) {
  const { size, ...rest } = props;
  return /* @__PURE__ */ jsxRuntimeExports.jsx(Circle, { size, asChild: true, ref, children: /* @__PURE__ */ jsxRuntimeExports.jsx(Skeleton, { ...rest }) });
});
SkeletonCircle.displayName = "SkeletonCircle";
const SkeletonText = reactExports.forwardRef(
  function SkeletonText2(props, ref) {
    const { loading = true, noOfLines = 3, gap, rootProps, ...rest } = props;
    return /* @__PURE__ */ jsxRuntimeExports.jsx(Stack, { gap, width: "full", ref, ...rootProps, children: Array.from({ length: loading ? noOfLines : 1 }).map((_, index) => /* @__PURE__ */ jsxRuntimeExports.jsx(
      Skeleton,
      {
        loading,
        height: loading ? "4" : void 0,
        maxW: loading ? index === noOfLines - 1 && noOfLines > 1 ? "80%" : "100%" : void 0,
        ...rest
      },
      index
    )) });
  }
);
SkeletonText.displayName = "SkeletonText";
const { withContext: withContext$1 } = createRecipeContext({
  key: "textarea"
});
const Textarea = withContext$1(
  FieldTextarea
);
Textarea.displayName = "Textarea";
const {
  withRootProvider,
  withContext
} = createSlotRecipeContext({ key: "tooltip" });
withRootProvider(
  TooltipRootProvider
);
const TooltipRoot = withRootProvider(TooltipRoot$1, {
  defaultProps: { lazyMount: true, unmountOnExit: true }
});
const TooltipTrigger = withContext(TooltipTrigger$1, "trigger", { forwardAsChild: true });
const TooltipPositioner = withContext(TooltipPositioner$1, "positioner", { forwardAsChild: true });
const TooltipContent = withContext(
  TooltipContent$1,
  "content",
  { forwardAsChild: true }
);
const TooltipArrowTip = withContext(TooltipArrowTip$1, "arrowTip", { forwardAsChild: true });
const TooltipArrow = withContext(
  TooltipArrow$1,
  "arrow",
  { forwardAsChild: true, defaultProps: { children: /* @__PURE__ */ jsxRuntimeExports.jsx(TooltipArrowTip, {}) } }
);
export {
  Box as B,
  ChakraProvider as C,
  Flex as F,
  IconButton as I,
  Link as L,
  Skeleton as S,
  Text as T,
  ClientOnly as a,
  Span as b,
  Button as c,
  defaultSystem as d,
  Input as e,
  CheckboxRoot as f,
  CheckboxHiddenInput as g,
  CheckboxControl as h,
  CheckboxIndicator as i,
  CheckboxLabel as j,
  Textarea as k,
  TooltipRoot as l,
  TooltipTrigger as m,
  TooltipPositioner as n,
  TooltipContent as o,
  TooltipArrow as p,
  TooltipArrowTip as q,
  useBreakpointValue as u
};
