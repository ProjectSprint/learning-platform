import { c as createAnatomy } from "./anatomy.mjs";
import { c as createProps } from "./types.mjs";
var anatomy = createAnatomy("collapsible").parts("root", "trigger", "content", "indicator");
anatomy.build();
createProps()([
  "dir",
  "disabled",
  "getRootNode",
  "id",
  "ids",
  "collapsedHeight",
  "collapsedWidth",
  "onExitComplete",
  "onOpenChange",
  "defaultOpen",
  "open"
]);
export {
  anatomy as a
};
