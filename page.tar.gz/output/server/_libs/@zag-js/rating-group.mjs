import { c as createAnatomy } from "./anatomy.mjs";
import { c as createProps } from "./types.mjs";
var anatomy = createAnatomy("rating-group").parts("root", "label", "item", "control");
anatomy.build();
createProps()([
  "allowHalf",
  "autoFocus",
  "count",
  "dir",
  "disabled",
  "form",
  "getRootNode",
  "id",
  "ids",
  "name",
  "onHoverChange",
  "onValueChange",
  "required",
  "readOnly",
  "translations",
  "value",
  "defaultValue"
]);
createProps()(["index"]);
export {
  anatomy as a
};
