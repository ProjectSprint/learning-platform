import { c as createAnatomy } from "./anatomy.mjs";
import { c as createProps } from "./types.mjs";
var anatomy = createAnatomy("scroll-area").parts("root", "viewport", "content", "scrollbar", "thumb", "corner");
anatomy.build();
createProps()(["dir", "getRootNode", "ids", "id"]);
export {
  anatomy as a
};
