function createNormalizer(fn) {
  return new Proxy({}, {
    get(_target, key) {
      if (key === "style")
        return (props) => {
          return fn({ style: props }).style;
        };
      return fn;
    }
  });
}
var createProps = () => (props) => Array.from(new Set(props));
export {
  createNormalizer as a,
  createProps as c
};
