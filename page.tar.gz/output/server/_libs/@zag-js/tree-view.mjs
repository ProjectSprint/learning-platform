import { c as createAnatomy } from "./anatomy.mjs";
import { T as TreeCollection } from "./collection.mjs";
import { m as setElementValue, P as getByTypeahead, r as raf } from "./dom-query.mjs";
import { n as addOrRemove, f as first, K as uniq, N as diff, O as isArray, J as toArray, r as remove, l as last, b as isEqual, a as add, P as partition, H as ensure } from "./utils.mjs";
import { c as createMachine, a as createGuards } from "./core.mjs";
import { c as createProps } from "./types.mjs";
var anatomy = createAnatomy("tree-view").parts(
  "branch",
  "branchContent",
  "branchControl",
  "branchIndentGuide",
  "branchIndicator",
  "branchText",
  "branchTrigger",
  "item",
  "itemIndicator",
  "itemText",
  "label",
  "nodeCheckbox",
  "nodeRenameInput",
  "root",
  "tree"
);
anatomy.build();
var collection = (options) => {
  return new TreeCollection(options);
};
collection.empty = () => {
  return new TreeCollection({ rootNode: { children: [] } });
};
var getNodeId = (ctx, value) => ctx.ids?.node?.(value) ?? `tree:${ctx.id}:node:${value}`;
var focusNode = (ctx, value) => {
  if (value == null) return;
  ctx.getById(getNodeId(ctx, value))?.focus();
};
var getRenameInputId = (ctx, value) => `tree:${ctx.id}:rename-input:${value}`;
var getRenameInputEl = (ctx, value) => {
  return ctx.getById(getRenameInputId(ctx, value));
};
function toggleBranchChecked(collection2, value, checkedValue) {
  const childValues = collection2.getDescendantValues(value);
  const allChecked = childValues.every((child) => checkedValue.includes(child));
  return uniq(allChecked ? remove(checkedValue, ...childValues) : add(checkedValue, ...childValues));
}
function expandBranches(params, values) {
  const { context, prop, refs } = params;
  if (!prop("loadChildren")) {
    context.set("expandedValue", (prev) => uniq(add(prev, ...values)));
    return;
  }
  const loadingStatus = context.get("loadingStatus");
  const [loadedValues, loadingValues] = partition(values, (value) => loadingStatus[value] === "loaded");
  if (loadedValues.length > 0) {
    context.set("expandedValue", (prev) => uniq(add(prev, ...loadedValues)));
  }
  if (loadingValues.length === 0) return;
  const collection2 = prop("collection");
  const [nodeWithChildren, nodeWithoutChildren] = partition(loadingValues, (id) => {
    const node = collection2.findNode(id);
    return collection2.getNodeChildren(node).length > 0;
  });
  if (nodeWithChildren.length > 0) {
    context.set("expandedValue", (prev) => uniq(add(prev, ...nodeWithChildren)));
  }
  if (nodeWithoutChildren.length === 0) return;
  context.set("loadingStatus", (prev) => ({
    ...prev,
    ...nodeWithoutChildren.reduce((acc, id) => ({ ...acc, [id]: "loading" }), {})
  }));
  const nodesToLoad = nodeWithoutChildren.map((id) => {
    const indexPath = collection2.getIndexPath(id);
    const valuePath = collection2.getValuePath(indexPath);
    const node = collection2.findNode(id);
    return { id, indexPath, valuePath, node };
  });
  const pendingAborts = refs.get("pendingAborts");
  const loadChildren = prop("loadChildren");
  ensure(loadChildren, () => "[zag-js/tree-view] `loadChildren` is required for async expansion");
  const proms = nodesToLoad.map(({ id, indexPath, valuePath, node }) => {
    const existingAbort = pendingAborts.get(id);
    if (existingAbort) {
      existingAbort.abort();
      pendingAborts.delete(id);
    }
    const abortController = new AbortController();
    pendingAborts.set(id, abortController);
    return loadChildren({
      valuePath,
      indexPath,
      node,
      signal: abortController.signal
    });
  });
  Promise.allSettled(proms).then((results) => {
    const loadedValues2 = [];
    const nodeWithErrors = [];
    const nextLoadingStatus = context.get("loadingStatus");
    let collection3 = prop("collection");
    results.forEach((result, index) => {
      const { id, indexPath, node, valuePath } = nodesToLoad[index];
      if (result.status === "fulfilled") {
        nextLoadingStatus[id] = "loaded";
        loadedValues2.push(id);
        collection3 = collection3.replace(indexPath, { ...node, children: result.value });
      } else {
        pendingAborts.delete(id);
        Reflect.deleteProperty(nextLoadingStatus, id);
        nodeWithErrors.push({ node, error: result.reason, indexPath, valuePath });
      }
    });
    context.set("loadingStatus", nextLoadingStatus);
    if (loadedValues2.length) {
      context.set("expandedValue", (prev) => uniq(add(prev, ...loadedValues2)));
      prop("onLoadChildrenComplete")?.({ collection: collection3 });
    }
    if (nodeWithErrors.length) {
      prop("onLoadChildrenError")?.({ nodes: nodeWithErrors });
    }
  });
}
function skipFn(params) {
  const { prop, context } = params;
  return function skip({ indexPath }) {
    const paths = prop("collection").getValuePath(indexPath).slice(0, -1);
    return paths.some((value) => !context.get("expandedValue").includes(value));
  };
}
var { and } = createGuards();
createMachine({
  props({ props: props2 }) {
    return {
      selectionMode: "single",
      collection: collection.empty(),
      typeahead: true,
      expandOnClick: true,
      defaultExpandedValue: [],
      defaultSelectedValue: [],
      ...props2
    };
  },
  initialState() {
    return "idle";
  },
  context({ prop, bindable, getContext }) {
    return {
      expandedValue: bindable(() => ({
        defaultValue: prop("defaultExpandedValue"),
        value: prop("expandedValue"),
        isEqual,
        onChange(expandedValue) {
          const ctx = getContext();
          const focusedValue = ctx.get("focusedValue");
          prop("onExpandedChange")?.({
            expandedValue,
            focusedValue,
            get expandedNodes() {
              return prop("collection").findNodes(expandedValue);
            }
          });
        }
      })),
      selectedValue: bindable(() => ({
        defaultValue: prop("defaultSelectedValue"),
        value: prop("selectedValue"),
        isEqual,
        onChange(selectedValue) {
          const ctx = getContext();
          const focusedValue = ctx.get("focusedValue");
          prop("onSelectionChange")?.({
            selectedValue,
            focusedValue,
            get selectedNodes() {
              return prop("collection").findNodes(selectedValue);
            }
          });
        }
      })),
      focusedValue: bindable(() => ({
        defaultValue: prop("defaultFocusedValue") || null,
        value: prop("focusedValue"),
        onChange(focusedValue) {
          prop("onFocusChange")?.({
            focusedValue,
            get focusedNode() {
              return focusedValue ? prop("collection").findNode(focusedValue) : null;
            }
          });
        }
      })),
      loadingStatus: bindable(() => ({
        defaultValue: {}
      })),
      checkedValue: bindable(() => ({
        defaultValue: prop("defaultCheckedValue") || [],
        value: prop("checkedValue"),
        isEqual,
        onChange(value) {
          prop("onCheckedChange")?.({ checkedValue: value });
        }
      })),
      renamingValue: bindable(() => ({
        sync: true,
        defaultValue: null
      }))
    };
  },
  refs() {
    return {
      typeaheadState: { ...getByTypeahead.defaultOptions },
      pendingAborts: /* @__PURE__ */ new Map()
    };
  },
  computed: {
    isMultipleSelection: ({ prop }) => prop("selectionMode") === "multiple",
    isTypingAhead: ({ refs }) => refs.get("typeaheadState").keysSoFar.length > 0,
    visibleNodes: ({ prop, context }) => {
      const nodes = [];
      prop("collection").visit({
        skip: skipFn({ prop, context }),
        onEnter: (node, indexPath) => {
          nodes.push({ node, indexPath });
        }
      });
      return nodes;
    }
  },
  on: {
    "EXPANDED.SET": {
      actions: ["setExpanded"]
    },
    "EXPANDED.CLEAR": {
      actions: ["clearExpanded"]
    },
    "EXPANDED.ALL": {
      actions: ["expandAllBranches"]
    },
    "BRANCH.EXPAND": {
      actions: ["expandBranches"]
    },
    "BRANCH.COLLAPSE": {
      actions: ["collapseBranches"]
    },
    "SELECTED.SET": {
      actions: ["setSelected"]
    },
    "SELECTED.ALL": [
      {
        guard: and("isMultipleSelection", "moveFocus"),
        actions: ["selectAllNodes", "focusTreeLastNode"]
      },
      {
        guard: "isMultipleSelection",
        actions: ["selectAllNodes"]
      }
    ],
    "SELECTED.CLEAR": {
      actions: ["clearSelected"]
    },
    "NODE.SELECT": {
      actions: ["selectNode"]
    },
    "NODE.DESELECT": {
      actions: ["deselectNode"]
    },
    "CHECKED.TOGGLE": {
      actions: ["toggleChecked"]
    },
    "CHECKED.SET": {
      actions: ["setChecked"]
    },
    "CHECKED.CLEAR": {
      actions: ["clearChecked"]
    },
    "NODE.FOCUS": {
      actions: ["setFocusedNode"]
    },
    "NODE.ARROW_DOWN": [
      {
        guard: and("isShiftKey", "isMultipleSelection"),
        actions: ["focusTreeNextNode", "extendSelectionToNextNode"]
      },
      {
        actions: ["focusTreeNextNode"]
      }
    ],
    "NODE.ARROW_UP": [
      {
        guard: and("isShiftKey", "isMultipleSelection"),
        actions: ["focusTreePrevNode", "extendSelectionToPrevNode"]
      },
      {
        actions: ["focusTreePrevNode"]
      }
    ],
    "NODE.ARROW_LEFT": {
      actions: ["focusBranchNode"]
    },
    "BRANCH_NODE.ARROW_LEFT": [
      {
        guard: "isBranchExpanded",
        actions: ["collapseBranch"]
      },
      {
        actions: ["focusBranchNode"]
      }
    ],
    "BRANCH_NODE.ARROW_RIGHT": [
      {
        guard: and("isBranchFocused", "isBranchExpanded"),
        actions: ["focusBranchFirstNode"]
      },
      {
        actions: ["expandBranch"]
      }
    ],
    "SIBLINGS.EXPAND": {
      actions: ["expandSiblingBranches"]
    },
    "NODE.HOME": [
      {
        guard: and("isShiftKey", "isMultipleSelection"),
        actions: ["extendSelectionToFirstNode", "focusTreeFirstNode"]
      },
      {
        actions: ["focusTreeFirstNode"]
      }
    ],
    "NODE.END": [
      {
        guard: and("isShiftKey", "isMultipleSelection"),
        actions: ["extendSelectionToLastNode", "focusTreeLastNode"]
      },
      {
        actions: ["focusTreeLastNode"]
      }
    ],
    "NODE.CLICK": [
      {
        guard: and("isCtrlKey", "isMultipleSelection"),
        actions: ["toggleNodeSelection"]
      },
      {
        guard: and("isShiftKey", "isMultipleSelection"),
        actions: ["extendSelectionToNode"]
      },
      {
        actions: ["selectNode"]
      }
    ],
    "BRANCH_NODE.CLICK": [
      {
        guard: and("isCtrlKey", "isMultipleSelection"),
        actions: ["toggleNodeSelection"]
      },
      {
        guard: and("isShiftKey", "isMultipleSelection"),
        actions: ["extendSelectionToNode"]
      },
      {
        guard: "expandOnClick",
        actions: ["selectNode", "toggleBranchNode"]
      },
      {
        actions: ["selectNode"]
      }
    ],
    "BRANCH_TOGGLE.CLICK": {
      actions: ["toggleBranchNode"]
    },
    "TREE.TYPEAHEAD": {
      actions: ["focusMatchedNode"]
    }
  },
  exit: ["clearPendingAborts"],
  states: {
    idle: {
      on: {
        "NODE.RENAME": {
          target: "renaming",
          actions: ["setRenamingValue"]
        }
      }
    },
    renaming: {
      entry: ["syncRenameInput", "focusRenameInput"],
      on: {
        "RENAME.SUBMIT": {
          guard: "isRenameLabelValid",
          target: "idle",
          actions: ["submitRenaming"]
        },
        "RENAME.CANCEL": {
          target: "idle",
          actions: ["cancelRenaming"]
        }
      }
    }
  },
  implementations: {
    guards: {
      isBranchFocused: ({ context, event }) => context.get("focusedValue") === event.id,
      isBranchExpanded: ({ context, event }) => context.get("expandedValue").includes(event.id),
      isShiftKey: ({ event }) => event.shiftKey,
      isCtrlKey: ({ event }) => event.ctrlKey,
      hasSelectedItems: ({ context }) => context.get("selectedValue").length > 0,
      isMultipleSelection: ({ prop }) => prop("selectionMode") === "multiple",
      moveFocus: ({ event }) => !!event.moveFocus,
      expandOnClick: ({ prop }) => !!prop("expandOnClick"),
      isRenameLabelValid: ({ event }) => event.label.trim() !== ""
    },
    actions: {
      selectNode({ context, event }) {
        const value = event.id || event.value;
        context.set("selectedValue", (prev) => {
          if (value == null) return prev;
          if (!event.isTrusted && isArray(value)) return prev.concat(...value);
          return [isArray(value) ? last(value) : value].filter(Boolean);
        });
      },
      deselectNode({ context, event }) {
        const value = toArray(event.id || event.value);
        context.set("selectedValue", (prev) => remove(prev, ...value));
      },
      setFocusedNode({ context, event }) {
        context.set("focusedValue", event.id);
      },
      clearFocusedNode({ context }) {
        context.set("focusedValue", null);
      },
      clearSelectedItem({ context }) {
        context.set("selectedValue", []);
      },
      toggleBranchNode({ context, event, action }) {
        const isExpanded = context.get("expandedValue").includes(event.id);
        action(isExpanded ? ["collapseBranch"] : ["expandBranch"]);
      },
      expandBranch(params) {
        const { event } = params;
        expandBranches(params, [event.id]);
      },
      expandBranches(params) {
        const { context, event } = params;
        const valuesToExpand = toArray(event.value);
        expandBranches(params, diff(valuesToExpand, context.get("expandedValue")));
      },
      collapseBranch({ context, event }) {
        context.set("expandedValue", (prev) => remove(prev, event.id));
      },
      collapseBranches(params) {
        const { context, event } = params;
        const value = toArray(event.value);
        context.set("expandedValue", (prev) => remove(prev, ...value));
      },
      setExpanded({ context, event }) {
        if (!isArray(event.value)) return;
        context.set("expandedValue", event.value);
      },
      clearExpanded({ context }) {
        context.set("expandedValue", []);
      },
      setSelected({ context, event }) {
        if (!isArray(event.value)) return;
        context.set("selectedValue", event.value);
      },
      clearSelected({ context }) {
        context.set("selectedValue", []);
      },
      focusTreeFirstNode(params) {
        const { prop, scope } = params;
        const collection2 = prop("collection");
        const firstNode = collection2.getFirstNode();
        const firstValue = collection2.getNodeValue(firstNode);
        const scrolled = scrollToNode(params, firstValue);
        if (scrolled) raf(() => focusNode(scope, firstValue));
        else focusNode(scope, firstValue);
      },
      focusTreeLastNode(params) {
        const { prop, scope } = params;
        const collection2 = prop("collection");
        const lastNode = collection2.getLastNode(void 0, { skip: skipFn(params) });
        const lastValue = collection2.getNodeValue(lastNode);
        const scrolled = scrollToNode(params, lastValue);
        if (scrolled) raf(() => focusNode(scope, lastValue));
        else focusNode(scope, lastValue);
      },
      focusBranchFirstNode(params) {
        const { event, prop, scope } = params;
        const collection2 = prop("collection");
        const branchNode = collection2.findNode(event.id);
        const firstNode = collection2.getFirstNode(branchNode);
        const firstValue = collection2.getNodeValue(firstNode);
        const scrolled = scrollToNode(params, firstValue);
        if (scrolled) raf(() => focusNode(scope, firstValue));
        else focusNode(scope, firstValue);
      },
      focusTreeNextNode(params) {
        const { event, prop, scope } = params;
        const collection2 = prop("collection");
        const nextNode = collection2.getNextNode(event.id, { skip: skipFn(params) });
        if (!nextNode) return;
        const nextValue = collection2.getNodeValue(nextNode);
        const scrolled = scrollToNode(params, nextValue);
        if (scrolled) raf(() => focusNode(scope, nextValue));
        else focusNode(scope, nextValue);
      },
      focusTreePrevNode(params) {
        const { event, prop, scope } = params;
        const collection2 = prop("collection");
        const prevNode = collection2.getPreviousNode(event.id, { skip: skipFn(params) });
        if (!prevNode) return;
        const prevValue = collection2.getNodeValue(prevNode);
        const scrolled = scrollToNode(params, prevValue);
        if (scrolled) raf(() => focusNode(scope, prevValue));
        else focusNode(scope, prevValue);
      },
      focusBranchNode(params) {
        const { event, prop, scope } = params;
        const collection2 = prop("collection");
        const parentNode = collection2.getParentNode(event.id);
        const parentValue = parentNode ? collection2.getNodeValue(parentNode) : void 0;
        if (!parentValue) return;
        const scrolled = scrollToNode(params, parentValue);
        if (scrolled) raf(() => focusNode(scope, parentValue));
        else focusNode(scope, parentValue);
      },
      selectAllNodes({ context, prop }) {
        context.set("selectedValue", prop("collection").getValues());
      },
      focusMatchedNode(params) {
        const { context, prop, refs, event, scope, computed } = params;
        const nodes = computed("visibleNodes");
        const elements = nodes.map(({ node: node2 }) => ({
          textContent: prop("collection").stringifyNode(node2),
          id: prop("collection").getNodeValue(node2)
        }));
        const node = getByTypeahead(elements, {
          state: refs.get("typeaheadState"),
          activeId: context.get("focusedValue"),
          key: event.key
        });
        if (!node?.id) return;
        const scrolled = scrollToNode(params, node.id);
        if (scrolled) raf(() => focusNode(scope, node.id));
        else focusNode(scope, node.id);
      },
      toggleNodeSelection({ context, event }) {
        const selectedValue = addOrRemove(context.get("selectedValue"), event.id);
        context.set("selectedValue", selectedValue);
      },
      expandAllBranches(params) {
        const { context, prop } = params;
        const branchValues = prop("collection").getBranchValues();
        const valuesToExpand = diff(branchValues, context.get("expandedValue"));
        expandBranches(params, valuesToExpand);
      },
      expandSiblingBranches(params) {
        const { context, event, prop } = params;
        const collection2 = prop("collection");
        const indexPath = collection2.getIndexPath(event.id);
        if (!indexPath) return;
        const nodes = collection2.getSiblingNodes(indexPath);
        const values = nodes.map((node) => collection2.getNodeValue(node));
        const valuesToExpand = diff(values, context.get("expandedValue"));
        expandBranches(params, valuesToExpand);
      },
      extendSelectionToNode(params) {
        const { context, event, prop, computed } = params;
        const collection2 = prop("collection");
        const anchorValue = first(context.get("selectedValue")) || collection2.getNodeValue(collection2.getFirstNode());
        const targetValue = event.id;
        let values = [anchorValue, targetValue];
        let hits = 0;
        const visibleNodes = computed("visibleNodes");
        visibleNodes.forEach(({ node }) => {
          const nodeValue = collection2.getNodeValue(node);
          if (hits === 1) values.push(nodeValue);
          if (nodeValue === anchorValue || nodeValue === targetValue) hits++;
        });
        context.set("selectedValue", uniq(values));
      },
      extendSelectionToNextNode(params) {
        const { context, event, prop } = params;
        const collection2 = prop("collection");
        const nextNode = collection2.getNextNode(event.id, { skip: skipFn(params) });
        if (!nextNode) return;
        const values = new Set(context.get("selectedValue"));
        const nextValue = collection2.getNodeValue(nextNode);
        if (nextValue == null) return;
        if (values.has(event.id) && values.has(nextValue)) {
          values.delete(event.id);
        } else if (!values.has(nextValue)) {
          values.add(nextValue);
        }
        context.set("selectedValue", Array.from(values));
      },
      extendSelectionToPrevNode(params) {
        const { context, event, prop } = params;
        const collection2 = prop("collection");
        const prevNode = collection2.getPreviousNode(event.id, { skip: skipFn(params) });
        if (!prevNode) return;
        const values = new Set(context.get("selectedValue"));
        const prevValue = collection2.getNodeValue(prevNode);
        if (prevValue == null) return;
        if (values.has(event.id) && values.has(prevValue)) {
          values.delete(event.id);
        } else if (!values.has(prevValue)) {
          values.add(prevValue);
        }
        context.set("selectedValue", Array.from(values));
      },
      extendSelectionToFirstNode(params) {
        const { context, prop } = params;
        const collection2 = prop("collection");
        const currentSelection = first(context.get("selectedValue"));
        const values = [];
        collection2.visit({
          skip: skipFn(params),
          onEnter: (node) => {
            const nodeValue = collection2.getNodeValue(node);
            values.push(nodeValue);
            if (nodeValue === currentSelection) {
              return "stop";
            }
          }
        });
        context.set("selectedValue", values);
      },
      extendSelectionToLastNode(params) {
        const { context, prop } = params;
        const collection2 = prop("collection");
        const currentSelection = first(context.get("selectedValue"));
        const values = [];
        let current = false;
        collection2.visit({
          skip: skipFn(params),
          onEnter: (node) => {
            const nodeValue = collection2.getNodeValue(node);
            if (nodeValue === currentSelection) current = true;
            if (current) values.push(nodeValue);
          }
        });
        context.set("selectedValue", values);
      },
      clearPendingAborts({ refs }) {
        const aborts = refs.get("pendingAborts");
        aborts.forEach((abort) => abort.abort());
        aborts.clear();
      },
      toggleChecked({ context, event, prop }) {
        const collection2 = prop("collection");
        context.set(
          "checkedValue",
          (prev) => event.isBranch ? toggleBranchChecked(collection2, event.value, prev) : addOrRemove(prev, event.value)
        );
      },
      setChecked({ context, event }) {
        context.set("checkedValue", event.value);
      },
      clearChecked({ context }) {
        context.set("checkedValue", []);
      },
      setRenamingValue({ context, event, prop }) {
        context.set("renamingValue", event.value);
        const onRenameStartFn = prop("onRenameStart");
        if (onRenameStartFn) {
          const collection2 = prop("collection");
          const indexPath = collection2.getIndexPath(event.value);
          if (indexPath) {
            const node = collection2.at(indexPath);
            if (node) {
              onRenameStartFn({
                value: event.value,
                node,
                indexPath
              });
            }
          }
        }
      },
      submitRenaming({ context, event, prop, scope }) {
        const renamingValue = context.get("renamingValue");
        if (!renamingValue) return;
        const collection2 = prop("collection");
        const indexPath = collection2.getIndexPath(renamingValue);
        if (!indexPath) return;
        const trimmedLabel = event.label.trim();
        const onBeforeRenameFn = prop("onBeforeRename");
        if (onBeforeRenameFn) {
          const details = {
            value: renamingValue,
            label: trimmedLabel,
            indexPath
          };
          const shouldRename = onBeforeRenameFn(details);
          if (!shouldRename) {
            context.set("renamingValue", null);
            focusNode(scope, renamingValue);
            return;
          }
        }
        prop("onRenameComplete")?.({
          value: renamingValue,
          label: trimmedLabel,
          indexPath
        });
        context.set("renamingValue", null);
        focusNode(scope, renamingValue);
      },
      cancelRenaming({ context, scope }) {
        const renamingValue = context.get("renamingValue");
        context.set("renamingValue", null);
        if (renamingValue) {
          focusNode(scope, renamingValue);
        }
      },
      syncRenameInput({ context, scope, prop }) {
        const renamingValue = context.get("renamingValue");
        if (!renamingValue) return;
        const collection2 = prop("collection");
        const node = collection2.findNode(renamingValue);
        if (!node) return;
        const label = collection2.stringifyNode(node);
        const inputEl = getRenameInputEl(scope, renamingValue);
        setElementValue(inputEl, label);
      },
      focusRenameInput({ context, scope }) {
        const renamingValue = context.get("renamingValue");
        if (!renamingValue) return;
        const inputEl = getRenameInputEl(scope, renamingValue);
        if (!inputEl) return;
        inputEl.focus();
        inputEl.select();
      }
    }
  }
});
function scrollToNode(params, value) {
  const { prop, scope, computed } = params;
  const scrollToIndexFn = prop("scrollToIndexFn");
  if (!scrollToIndexFn) return false;
  const collection2 = prop("collection");
  const visibleNodes = computed("visibleNodes");
  for (let i = 0; i < visibleNodes.length; i++) {
    const { node, indexPath } = visibleNodes[i];
    if (collection2.getNodeValue(node) !== value) continue;
    scrollToIndexFn({
      index: i,
      node,
      indexPath,
      getElement: () => scope.getById(getNodeId(scope, value))
    });
    return true;
  }
  return false;
}
createProps()([
  "ids",
  "collection",
  "dir",
  "expandedValue",
  "expandOnClick",
  "defaultFocusedValue",
  "focusedValue",
  "getRootNode",
  "id",
  "onExpandedChange",
  "onFocusChange",
  "onSelectionChange",
  "checkedValue",
  "selectedValue",
  "selectionMode",
  "typeahead",
  "defaultExpandedValue",
  "defaultSelectedValue",
  "defaultCheckedValue",
  "onCheckedChange",
  "onLoadChildrenComplete",
  "onLoadChildrenError",
  "loadChildren",
  "canRename",
  "onRenameStart",
  "onBeforeRename",
  "onRenameComplete",
  "scrollToIndexFn"
]);
createProps()(["node", "indexPath"]);
export {
  anatomy as a
};
