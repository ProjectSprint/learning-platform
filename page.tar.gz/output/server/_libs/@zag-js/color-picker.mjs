import { c as createAnatomy } from "./anatomy.mjs";
import { p as parseColor } from "./color-utils.mjs";
import { r as raf, h as getInitialFocus, j as dispatchInputValueEvent, k as disableTextSelection, l as trackPointerMove, t as trackFormControl, m as setElementValue, o as getRelativePoint, q as queryAll } from "./dom-query.mjs";
import { g as getPlacement } from "./popper.mjs";
import { c as createMachine, a as createGuards } from "./core.mjs";
import { t as trackDismissableElement } from "./dismissable.mjs";
import { t as tryCatch } from "./utils.mjs";
import { c as createProps } from "./types.mjs";
var anatomy = createAnatomy("color-picker", [
  "root",
  "label",
  "control",
  "trigger",
  "positioner",
  "content",
  "area",
  "areaThumb",
  "valueText",
  "areaBackground",
  "channelSlider",
  "channelSliderLabel",
  "channelSliderTrack",
  "channelSliderThumb",
  "channelSliderValueText",
  "channelInput",
  "transparencyGrid",
  "swatchGroup",
  "swatchTrigger",
  "swatchIndicator",
  "swatch",
  "eyeDropperTrigger",
  "formatTrigger",
  "formatSelect"
]);
anatomy.build();
var getHiddenInputId = (ctx) => ctx.ids?.hiddenInput ?? `color-picker:${ctx.id}:hidden-input`;
var getControlId = (ctx) => ctx.ids?.control ?? `color-picker:${ctx.id}:control`;
var getTriggerId = (ctx) => ctx.ids?.trigger ?? `color-picker:${ctx.id}:trigger`;
var getContentId = (ctx) => ctx.ids?.content ?? `color-picker:${ctx.id}:content`;
var getPositionerId = (ctx) => ctx.ids?.positioner ?? `color-picker:${ctx.id}:positioner`;
var getFormatSelectId = (ctx) => ctx.ids?.formatSelect ?? `color-picker:${ctx.id}:format-select`;
var getAreaId = (ctx) => ctx.ids?.area ?? `color-picker:${ctx.id}:area`;
var getAreaThumbId = (ctx) => ctx.ids?.areaThumb ?? `color-picker:${ctx.id}:area-thumb`;
var getChannelSliderTrackId = (ctx, channel) => ctx.ids?.channelSliderTrack?.(channel) ?? `color-picker:${ctx.id}:slider-track:${channel}`;
var getChannelSliderThumbId = (ctx, channel) => ctx.ids?.channelSliderThumb?.(channel) ?? `color-picker:${ctx.id}:slider-thumb:${channel}`;
var getContentEl = (ctx) => ctx.getById(getContentId(ctx));
var getAreaThumbEl = (ctx) => ctx.getById(getAreaThumbId(ctx));
var getChannelSliderThumbEl = (ctx, channel) => ctx.getById(getChannelSliderThumbId(ctx, channel));
var getFormatSelectEl = (ctx) => ctx.getById(getFormatSelectId(ctx));
var getHiddenInputEl = (ctx) => ctx.getById(getHiddenInputId(ctx));
var getAreaEl = (ctx) => ctx.getById(getAreaId(ctx));
var getAreaValueFromPoint = (ctx, point, dir) => {
  const areaEl = getAreaEl(ctx);
  if (!areaEl) return;
  const { getPercentValue } = getRelativePoint(point, areaEl);
  return {
    x: getPercentValue({ dir, orientation: "horizontal" }),
    y: getPercentValue({ orientation: "vertical" })
  };
};
var getControlEl = (ctx) => ctx.getById(getControlId(ctx));
var getTriggerEl = (ctx) => ctx.getById(getTriggerId(ctx));
var getPositionerEl = (ctx) => ctx.getById(getPositionerId(ctx));
var getChannelSliderTrackEl = (ctx, channel) => ctx.getById(getChannelSliderTrackId(ctx, channel));
var getChannelSliderValueFromPoint = (ctx, point, channel, dir) => {
  const trackEl = getChannelSliderTrackEl(ctx, channel);
  if (!trackEl) return;
  const { getPercentValue } = getRelativePoint(point, trackEl);
  return {
    x: getPercentValue({ dir, orientation: "horizontal" }),
    y: getPercentValue({ orientation: "vertical" })
  };
};
var getChannelInputEls = (ctx) => {
  return [
    ...queryAll(getContentEl(ctx), "input[data-channel]"),
    ...queryAll(getControlEl(ctx), "input[data-channel]")
  ];
};
function getChannelValue(color, channel) {
  if (channel == null) return "";
  if (channel === "hex") {
    return color.toString("hex");
  }
  if (channel === "css") {
    return color.toString("css");
  }
  if (channel in color) {
    return color.getChannelValue(channel).toString();
  }
  const isHSL = color.getFormat() === "hsla";
  switch (channel) {
    case "hue":
      return isHSL ? color.toFormat("hsla").getChannelValue("hue").toString() : color.toFormat("hsba").getChannelValue("hue").toString();
    case "saturation":
      return isHSL ? color.toFormat("hsla").getChannelValue("saturation").toString() : color.toFormat("hsba").getChannelValue("saturation").toString();
    case "lightness":
      return color.toFormat("hsla").getChannelValue("lightness").toString();
    case "brightness":
      return color.toFormat("hsba").getChannelValue("brightness").toString();
    case "red":
    case "green":
    case "blue":
      return color.toFormat("rgba").getChannelValue(channel).toString();
    default:
      return color.getChannelValue(channel).toString();
  }
}
var parse = (colorString) => {
  return parseColor(colorString);
};
var HEX_REGEX = /^[0-9a-fA-F]{3,8}$/;
function isValidHex(value) {
  return HEX_REGEX.test(value);
}
function prefixHex(value) {
  if (value.startsWith("#")) return value;
  if (isValidHex(value)) return `#${value}`;
  return value;
}
var { and } = createGuards();
createMachine({
  props({ props: props2 }) {
    return {
      dir: "ltr",
      defaultValue: parse("#000000"),
      defaultFormat: "rgba",
      openAutoFocus: true,
      ...props2,
      positioning: {
        placement: "bottom",
        ...props2.positioning
      }
    };
  },
  initialState({ prop }) {
    const open = prop("open") || prop("defaultOpen") || prop("inline");
    return open ? "open" : "idle";
  },
  context({ prop, bindable, getContext }) {
    return {
      value: bindable(() => ({
        defaultValue: prop("defaultValue"),
        value: prop("value"),
        isEqual(a, b) {
          return a.toString("css") === b?.toString("css");
        },
        hash(a) {
          return a.toString("css");
        },
        onChange(value) {
          const ctx = getContext();
          const valueAsString = value.toString(ctx.get("format"));
          prop("onValueChange")?.({ value, valueAsString });
        }
      })),
      format: bindable(() => ({
        defaultValue: prop("defaultFormat"),
        value: prop("format"),
        onChange(format) {
          prop("onFormatChange")?.({ format });
        }
      })),
      activeId: bindable(() => ({ defaultValue: null })),
      activeChannel: bindable(() => ({ defaultValue: null })),
      activeOrientation: bindable(() => ({ defaultValue: null })),
      fieldsetDisabled: bindable(() => ({ defaultValue: false })),
      restoreFocus: bindable(() => ({ defaultValue: true })),
      currentPlacement: bindable(() => ({
        defaultValue: void 0
      }))
    };
  },
  computed: {
    rtl: ({ prop }) => prop("dir") === "rtl",
    disabled: ({ prop, context }) => !!prop("disabled") || context.get("fieldsetDisabled"),
    interactive: ({ prop }) => !(prop("disabled") || prop("readOnly")),
    valueAsString: ({ context }) => context.get("value").toString(context.get("format")),
    areaValue: ({ context }) => {
      const format = context.get("format").startsWith("hsl") ? "hsla" : "hsba";
      return context.get("value").toFormat(format);
    }
  },
  effects: ["trackFormControl"],
  watch({ prop, context, action, track }) {
    track([() => context.hash("value")], () => {
      action(["syncInputElements", "dispatchChangeEvent"]);
    });
    track([() => context.get("format")], () => {
      action(["syncFormatSelectElement"]);
    });
    track([() => prop("open")], () => {
      action(["toggleVisibility"]);
    });
  },
  on: {
    "VALUE.SET": {
      actions: ["setValue"]
    },
    "FORMAT.SET": {
      actions: ["setFormat"]
    },
    "CHANNEL_INPUT.CHANGE": {
      actions: ["setChannelColorFromInput"]
    },
    "EYEDROPPER.CLICK": {
      actions: ["openEyeDropper"]
    },
    "SWATCH_TRIGGER.CLICK": {
      actions: ["setValue"]
    }
  },
  states: {
    idle: {
      tags: ["closed"],
      on: {
        "CONTROLLED.OPEN": {
          target: "open",
          actions: ["setInitialFocus"]
        },
        OPEN: [
          {
            guard: "isOpenControlled",
            actions: ["invokeOnOpen"]
          },
          {
            target: "open",
            actions: ["invokeOnOpen", "setInitialFocus"]
          }
        ],
        "TRIGGER.CLICK": [
          {
            guard: "isOpenControlled",
            actions: ["invokeOnOpen"]
          },
          {
            target: "open",
            actions: ["invokeOnOpen", "setInitialFocus"]
          }
        ],
        "CHANNEL_INPUT.FOCUS": {
          target: "focused",
          actions: ["setActiveChannel"]
        }
      }
    },
    focused: {
      tags: ["closed", "focused"],
      on: {
        "CONTROLLED.OPEN": {
          target: "open",
          actions: ["setInitialFocus"]
        },
        OPEN: [
          {
            guard: "isOpenControlled",
            actions: ["invokeOnOpen"]
          },
          {
            target: "open",
            actions: ["invokeOnOpen", "setInitialFocus"]
          }
        ],
        "TRIGGER.CLICK": [
          {
            guard: "isOpenControlled",
            actions: ["invokeOnOpen"]
          },
          {
            target: "open",
            actions: ["invokeOnOpen", "setInitialFocus"]
          }
        ],
        "CHANNEL_INPUT.FOCUS": {
          actions: ["setActiveChannel"]
        },
        "CHANNEL_INPUT.BLUR": {
          target: "idle",
          actions: ["setChannelColorFromInput"]
        },
        "TRIGGER.BLUR": {
          target: "idle"
        }
      }
    },
    open: {
      tags: ["open"],
      effects: ["trackPositioning", "trackDismissableElement"],
      on: {
        "CONTROLLED.CLOSE": [
          {
            guard: "shouldRestoreFocus",
            target: "focused",
            actions: ["setReturnFocus"]
          },
          {
            target: "idle"
          }
        ],
        "TRIGGER.CLICK": [
          {
            guard: "isOpenControlled",
            actions: ["invokeOnClose"]
          },
          {
            target: "idle",
            actions: ["invokeOnClose"]
          }
        ],
        "AREA.POINTER_DOWN": {
          target: "open:dragging",
          actions: ["setActiveChannel", "setAreaColorFromPoint", "focusAreaThumb"]
        },
        "AREA.FOCUS": {
          actions: ["setActiveChannel"]
        },
        "CHANNEL_SLIDER.POINTER_DOWN": {
          target: "open:dragging",
          actions: ["setActiveChannel", "setChannelColorFromPoint", "focusChannelThumb"]
        },
        "CHANNEL_SLIDER.FOCUS": {
          actions: ["setActiveChannel"]
        },
        "AREA.ARROW_LEFT": {
          actions: ["decrementAreaXChannel"]
        },
        "AREA.ARROW_RIGHT": {
          actions: ["incrementAreaXChannel"]
        },
        "AREA.ARROW_UP": {
          actions: ["incrementAreaYChannel"]
        },
        "AREA.ARROW_DOWN": {
          actions: ["decrementAreaYChannel"]
        },
        "AREA.PAGE_UP": {
          actions: ["incrementAreaXChannel"]
        },
        "AREA.PAGE_DOWN": {
          actions: ["decrementAreaXChannel"]
        },
        "CHANNEL_SLIDER.ARROW_LEFT": {
          actions: ["decrementChannel"]
        },
        "CHANNEL_SLIDER.ARROW_RIGHT": {
          actions: ["incrementChannel"]
        },
        "CHANNEL_SLIDER.ARROW_UP": {
          actions: ["incrementChannel"]
        },
        "CHANNEL_SLIDER.ARROW_DOWN": {
          actions: ["decrementChannel"]
        },
        "CHANNEL_SLIDER.PAGE_UP": {
          actions: ["incrementChannel"]
        },
        "CHANNEL_SLIDER.PAGE_DOWN": {
          actions: ["decrementChannel"]
        },
        "CHANNEL_SLIDER.HOME": {
          actions: ["setChannelToMin"]
        },
        "CHANNEL_SLIDER.END": {
          actions: ["setChannelToMax"]
        },
        "CHANNEL_INPUT.BLUR": {
          actions: ["setChannelColorFromInput"]
        },
        INTERACT_OUTSIDE: [
          {
            guard: "isOpenControlled",
            actions: ["invokeOnClose"]
          },
          {
            guard: "shouldRestoreFocus",
            target: "focused",
            actions: ["invokeOnClose", "setReturnFocus"]
          },
          {
            target: "idle",
            actions: ["invokeOnClose"]
          }
        ],
        CLOSE: [
          {
            guard: "isOpenControlled",
            actions: ["invokeOnClose"]
          },
          {
            target: "idle",
            actions: ["invokeOnClose"]
          }
        ],
        "SWATCH_TRIGGER.CLICK": [
          {
            guard: and("isOpenControlled", "closeOnSelect"),
            actions: ["setValue", "invokeOnClose"]
          },
          {
            guard: "closeOnSelect",
            target: "focused",
            actions: ["setValue", "invokeOnClose", "setReturnFocus"]
          },
          {
            actions: ["setValue"]
          }
        ]
      }
    },
    "open:dragging": {
      tags: ["open"],
      exit: ["clearActiveChannel"],
      effects: ["trackPointerMove", "disableTextSelection", "trackPositioning", "trackDismissableElement"],
      on: {
        "CONTROLLED.CLOSE": [
          {
            guard: "shouldRestoreFocus",
            target: "focused",
            actions: ["setReturnFocus"]
          },
          {
            target: "idle"
          }
        ],
        "AREA.POINTER_MOVE": {
          actions: ["setAreaColorFromPoint", "focusAreaThumb"]
        },
        "AREA.POINTER_UP": {
          target: "open",
          actions: ["invokeOnChangeEnd"]
        },
        "CHANNEL_SLIDER.POINTER_MOVE": {
          actions: ["setChannelColorFromPoint", "focusChannelThumb"]
        },
        "CHANNEL_SLIDER.POINTER_UP": {
          target: "open",
          actions: ["invokeOnChangeEnd"]
        },
        INTERACT_OUTSIDE: [
          {
            guard: "isOpenControlled",
            actions: ["invokeOnClose"]
          },
          {
            guard: "shouldRestoreFocus",
            target: "focused",
            actions: ["invokeOnClose", "setReturnFocus"]
          },
          {
            target: "idle",
            actions: ["invokeOnClose"]
          }
        ],
        CLOSE: [
          {
            guard: "isOpenControlled",
            actions: ["invokeOnClose"]
          },
          {
            target: "idle",
            actions: ["invokeOnClose"]
          }
        ]
      }
    }
  },
  implementations: {
    guards: {
      closeOnSelect: ({ prop }) => !!prop("closeOnSelect"),
      isOpenControlled: ({ prop }) => prop("open") != null || !!prop("inline"),
      shouldRestoreFocus: ({ context }) => !!context.get("restoreFocus")
    },
    effects: {
      trackPositioning({ context, prop, scope }) {
        if (prop("inline")) return;
        if (!context.get("currentPlacement")) {
          context.set("currentPlacement", prop("positioning")?.placement);
        }
        const anchorEl = getTriggerEl(scope);
        const getPositionerEl2 = () => getPositionerEl(scope);
        return getPlacement(anchorEl, getPositionerEl2, {
          ...prop("positioning"),
          defer: true,
          onComplete(data) {
            context.set("currentPlacement", data.placement);
          }
        });
      },
      trackDismissableElement({ context, scope, prop, send }) {
        if (prop("inline")) return;
        const getContentEl2 = () => getContentEl(scope);
        return trackDismissableElement(getContentEl2, {
          type: "popover",
          exclude: getTriggerEl(scope),
          defer: true,
          onInteractOutside(event) {
            prop("onInteractOutside")?.(event);
            if (event.defaultPrevented) return;
            context.set("restoreFocus", !(event.detail.focusable || event.detail.contextmenu));
          },
          onPointerDownOutside: prop("onPointerDownOutside"),
          onFocusOutside: prop("onFocusOutside"),
          onDismiss() {
            send({ type: "INTERACT_OUTSIDE" });
          }
        });
      },
      trackFormControl({ context, scope, send }) {
        const inputEl = getHiddenInputEl(scope);
        return trackFormControl(inputEl, {
          onFieldsetDisabledChange(disabled) {
            context.set("fieldsetDisabled", disabled);
          },
          onFormReset() {
            send({ type: "VALUE.SET", value: context.initial("value"), src: "form.reset" });
          }
        });
      },
      trackPointerMove({ context, scope, event, send }) {
        return trackPointerMove(scope.getDoc(), {
          onPointerMove({ point }) {
            const type = context.get("activeId") === "area" ? "AREA.POINTER_MOVE" : "CHANNEL_SLIDER.POINTER_MOVE";
            send({ type, point, format: event.format });
          },
          onPointerUp() {
            const type = context.get("activeId") === "area" ? "AREA.POINTER_UP" : "CHANNEL_SLIDER.POINTER_UP";
            send({ type });
          }
        });
      },
      disableTextSelection({ scope }) {
        return disableTextSelection({
          doc: scope.getDoc(),
          target: getContentEl(scope)
        });
      }
    },
    actions: {
      openEyeDropper({ scope, context }) {
        const win = scope.getWin();
        const isSupported = "EyeDropper" in win;
        if (!isSupported) return;
        const picker = new win.EyeDropper();
        picker.open().then(({ sRGBHex }) => {
          const format = context.get("value").getFormat();
          const color = parseColor(sRGBHex).toFormat(format);
          context.set("value", color);
        }).catch(() => void 0);
      },
      setActiveChannel({ context, event }) {
        context.set("activeId", event.id);
        if (event.channel) context.set("activeChannel", event.channel);
        if (event.orientation) context.set("activeOrientation", event.orientation);
      },
      clearActiveChannel({ context }) {
        context.set("activeChannel", null);
        context.set("activeId", null);
        context.set("activeOrientation", null);
      },
      setAreaColorFromPoint({ context, event, computed, scope, prop }) {
        const v = event.format ? context.get("value").toFormat(event.format) : computed("areaValue");
        const { xChannel, yChannel } = event.channel || context.get("activeChannel");
        const percent = getAreaValueFromPoint(scope, event.point, prop("dir"));
        if (!percent) return;
        const xValue = v.getChannelPercentValue(xChannel, percent.x);
        const yValue = v.getChannelPercentValue(yChannel, 1 - percent.y);
        const color = v.withChannelValue(xChannel, xValue).withChannelValue(yChannel, yValue);
        context.set("value", color);
      },
      setChannelColorFromPoint({ context, event, computed, scope, prop }) {
        const channel = event.channel || context.get("activeId");
        const normalizedValue = event.format ? context.get("value").toFormat(event.format) : computed("areaValue");
        const percent = getChannelSliderValueFromPoint(scope, event.point, channel, prop("dir"));
        if (!percent) return;
        const orientation = context.get("activeOrientation") || "horizontal";
        const channelPercent = orientation === "horizontal" ? percent.x : percent.y;
        const value = normalizedValue.getChannelPercentValue(channel, channelPercent);
        const color = normalizedValue.withChannelValue(channel, value);
        context.set("value", color);
      },
      setValue({ context, event }) {
        context.set("value", event.value);
      },
      setFormat({ context, event }) {
        context.set("format", event.format);
      },
      dispatchChangeEvent({ scope, computed }) {
        dispatchInputValueEvent(getHiddenInputEl(scope), { value: computed("valueAsString") });
      },
      syncInputElements({ context, scope }) {
        syncChannelInputs(scope, context.get("value"));
      },
      invokeOnChangeEnd({ context, prop, computed }) {
        prop("onValueChangeEnd")?.({
          value: context.get("value"),
          valueAsString: computed("valueAsString")
        });
      },
      setChannelColorFromInput({ context, event, scope, prop }) {
        const { channel, isTextField, value } = event;
        const currentAlpha = context.get("value").getChannelValue("alpha");
        let color;
        if (channel === "alpha") {
          let valueAsNumber = parseFloat(value);
          valueAsNumber = Number.isNaN(valueAsNumber) ? currentAlpha : valueAsNumber;
          color = context.get("value").withChannelValue("alpha", valueAsNumber);
        } else if (isTextField) {
          color = tryCatch(
            () => {
              const parseValue = channel === "hex" ? prefixHex(value) : value;
              return parse(parseValue).withChannelValue("alpha", currentAlpha);
            },
            () => context.get("value")
          );
        } else {
          const current = context.get("value").toFormat(context.get("format"));
          const valueAsNumber = Number.isNaN(value) ? current.getChannelValue(channel) : value;
          color = current.withChannelValue(channel, valueAsNumber);
        }
        syncChannelInputs(scope, context.get("value"), color);
        context.set("value", color);
        prop("onValueChangeEnd")?.({
          value: color,
          valueAsString: color.toString(context.get("format"))
        });
      },
      incrementChannel({ context, event }) {
        const color = context.get("value").incrementChannel(event.channel, event.step);
        context.set("value", color);
      },
      decrementChannel({ context, event }) {
        const color = context.get("value").decrementChannel(event.channel, event.step);
        context.set("value", color);
      },
      incrementAreaXChannel({ context, event, computed }) {
        const { xChannel } = event.channel;
        const color = computed("areaValue").incrementChannel(xChannel, event.step);
        context.set("value", color);
      },
      decrementAreaXChannel({ context, event, computed }) {
        const { xChannel } = event.channel;
        const color = computed("areaValue").decrementChannel(xChannel, event.step);
        context.set("value", color);
      },
      incrementAreaYChannel({ context, event, computed }) {
        const { yChannel } = event.channel;
        const color = computed("areaValue").incrementChannel(yChannel, event.step);
        context.set("value", color);
      },
      decrementAreaYChannel({ context, event, computed }) {
        const { yChannel } = event.channel;
        const color = computed("areaValue").decrementChannel(yChannel, event.step);
        context.set("value", color);
      },
      setChannelToMax({ context, event }) {
        const value = context.get("value");
        const range = value.getChannelRange(event.channel);
        const color = value.withChannelValue(event.channel, range.maxValue);
        context.set("value", color);
      },
      setChannelToMin({ context, event }) {
        const value = context.get("value");
        const range = value.getChannelRange(event.channel);
        const color = value.withChannelValue(event.channel, range.minValue);
        context.set("value", color);
      },
      focusAreaThumb({ scope }) {
        raf(() => {
          getAreaThumbEl(scope)?.focus({ preventScroll: true });
        });
      },
      focusChannelThumb({ event, scope }) {
        raf(() => {
          getChannelSliderThumbEl(scope, event.channel)?.focus({ preventScroll: true });
        });
      },
      setInitialFocus({ prop, scope }) {
        if (!prop("openAutoFocus")) return;
        raf(() => {
          const element = getInitialFocus({
            root: getContentEl(scope),
            getInitialEl: prop("initialFocusEl")
          });
          element?.focus({ preventScroll: true });
        });
      },
      setReturnFocus({ scope }) {
        raf(() => {
          getTriggerEl(scope)?.focus({ preventScroll: true });
        });
      },
      syncFormatSelectElement({ context, scope }) {
        syncFormatSelect(scope, context.get("format"));
      },
      invokeOnOpen({ prop, context }) {
        if (prop("inline")) return;
        prop("onOpenChange")?.({ open: true, value: context.get("value") });
      },
      invokeOnClose({ prop, context }) {
        if (prop("inline")) return;
        prop("onOpenChange")?.({ open: false, value: context.get("value") });
      },
      toggleVisibility({ prop, event, send }) {
        send({ type: prop("open") ? "CONTROLLED.OPEN" : "CONTROLLED.CLOSE", previousEvent: event });
      }
    }
  }
});
function syncChannelInputs(scope, currentValue, nextValue) {
  const channelInputEls = getChannelInputEls(scope);
  raf(() => {
    channelInputEls.forEach((inputEl) => {
      const channel = inputEl.dataset.channel;
      setElementValue(inputEl, getChannelValue(nextValue || currentValue, channel));
    });
  });
}
function syncFormatSelect(scope, format) {
  const selectEl = getFormatSelectEl(scope);
  if (!selectEl) return;
  raf(() => setElementValue(selectEl, format));
}
createProps()([
  "closeOnSelect",
  "dir",
  "disabled",
  "format",
  "defaultFormat",
  "getRootNode",
  "id",
  "ids",
  "initialFocusEl",
  "inline",
  "name",
  "positioning",
  "onFocusOutside",
  "onFormatChange",
  "onInteractOutside",
  "onOpenChange",
  "onPointerDownOutside",
  "onValueChange",
  "onValueChangeEnd",
  "defaultOpen",
  "open",
  "positioning",
  "required",
  "readOnly",
  "value",
  "defaultValue",
  "invalid",
  "openAutoFocus"
]);
createProps()(["xChannel", "yChannel"]);
createProps()(["channel", "orientation"]);
createProps()(["value", "disabled"]);
createProps()(["value", "respectAlpha"]);
createProps()(["size"]);
export {
  anatomy as a
};
