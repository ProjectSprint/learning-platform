import { c as createAnatomy } from "./anatomy.mjs";
import { c as createProps } from "./types.mjs";
var anatomy = createAnatomy("avatar").parts("root", "image", "fallback");
anatomy.build();
createProps()(["dir", "id", "ids", "onStatusChange", "getRootNode"]);
export {
  anatomy as a
};
