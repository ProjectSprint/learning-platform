import { c as createAnatomy } from "./anatomy.mjs";
import { c as createProps } from "./types.mjs";
var anatomy = createAnatomy("switch").parts("root", "label", "control", "thumb");
anatomy.build();
createProps()([
  "checked",
  "defaultChecked",
  "dir",
  "disabled",
  "form",
  "getRootNode",
  "id",
  "ids",
  "invalid",
  "label",
  "name",
  "onCheckedChange",
  "readOnly",
  "required",
  "value"
]);
export {
  anatomy as a
};
