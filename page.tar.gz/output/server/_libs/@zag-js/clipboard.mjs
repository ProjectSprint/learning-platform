import { c as createAnatomy } from "./anatomy.mjs";
import { c as createProps } from "./types.mjs";
var anatomy = createAnatomy("clipboard").parts("root", "control", "trigger", "indicator", "input", "label");
anatomy.build();
createProps()([
  "getRootNode",
  "id",
  "ids",
  "value",
  "defaultValue",
  "timeout",
  "onStatusChange",
  "onValueChange"
]);
createProps()(["copied"]);
export {
  anatomy as a
};
