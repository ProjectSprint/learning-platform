import { a as anatomy } from "../@zag-js/carousel.mjs";
import { r as reactExports, j as jsxRuntimeExports } from "../react.mjs";
import { m as mergeProps } from "../@zag-js/core.mjs";
import { a as anatomy$1, c as connect$1, m as machine$1 } from "../@zag-js/checkbox.mjs";
import { u as useMachine, n as normalizeProps } from "../@zag-js/react.mjs";
import { a as anatomy$2 } from "../@zag-js/color-picker.mjs";
import { a as anatomy$3 } from "../@zag-js/combobox.mjs";
import { c as createAnatomy } from "../@zag-js/anatomy.mjs";
import { a as autoresizeTextarea } from "../@zag-js/auto-resize.mjs";
import { a as anatomy$4 } from "../@zag-js/listbox.mjs";
import { i as isShadowRoot, g as getDocument } from "../@zag-js/dom-query.mjs";
import { r as reactDomExports } from "../react-dom.mjs";
import { a as anatomy$5 } from "../@zag-js/radio-group.mjs";
import { c as connect$2, m as machine$2 } from "../@zag-js/tooltip.mjs";
import { c as connect, m as machine } from "../@zag-js/presence.mjs";
import { h as hasProp, i as isFunction } from "../@zag-js/utils.mjs";
function getErrorMessage(hook, provider) {
  return `${hook} returned \`undefined\`. Seems you forgot to wrap component within ${provider}`;
}
function createContext(options = {}) {
  const {
    name,
    strict = true,
    hookName = "useContext",
    providerName = "Provider",
    errorMessage,
    defaultValue
  } = options;
  const Context = reactExports.createContext(defaultValue);
  Context.displayName = name;
  function useContext$1() {
    const context = reactExports.useContext(Context);
    if (!context && strict) {
      const error = new Error(errorMessage ?? getErrorMessage(hookName, providerName));
      error.name = "ContextError";
      if (hasProp(Error, "captureStackTrace") && isFunction(Error.captureStackTrace)) {
        Error.captureStackTrace(error, useContext$1);
      }
      throw error;
    }
    return context;
  }
  return [Context.Provider, useContext$1, Context];
}
const [EnvironmentContextProvider, useEnvironmentContext] = createContext({
  name: "EnvironmentContext",
  hookName: "useEnvironmentContext",
  providerName: "<EnvironmentProvider />",
  strict: false,
  defaultValue: {
    getRootNode: () => document,
    getDocument: () => document,
    getWindow: () => window
  }
});
function composeRefs(...refs) {
  return (node) => {
    const cleanUps = [];
    for (const ref of refs) {
      if (typeof ref === "function") {
        const cb = ref(node);
        if (typeof cb === "function") {
          cleanUps.push(cb);
        }
      } else if (ref) {
        ref.current = node;
      }
    }
    if (cleanUps.length) {
      return () => {
        for (const cleanUp of cleanUps) {
          cleanUp();
        }
      };
    }
  };
}
function getRef(element) {
  let getter = Object.getOwnPropertyDescriptor(element.props, "ref")?.get;
  let mayWarn = getter && "isReactWarning" in getter && getter.isReactWarning;
  if (mayWarn) {
    return element.ref;
  }
  getter = Object.getOwnPropertyDescriptor(element, "ref")?.get;
  mayWarn = getter && "isReactWarning" in getter && getter.isReactWarning;
  if (mayWarn) {
    return element.props.ref;
  }
  return element.props.ref || element.ref;
}
const withAsChild = (Component) => {
  const Comp = reactExports.memo(
    reactExports.forwardRef((props, ref) => {
      const { asChild, children, ...restProps } = props;
      if (!asChild) {
        return reactExports.createElement(Component, { ...restProps, ref }, children);
      }
      if (!reactExports.isValidElement(children)) {
        return null;
      }
      const onlyChild = reactExports.Children.only(children);
      const childRef = getRef(onlyChild);
      return reactExports.cloneElement(onlyChild, {
        ...mergeProps(restProps, onlyChild.props),
        ref: ref ? composeRefs(ref, childRef) : childRef
      });
    })
  );
  Comp.displayName = Component.displayName || Component.name;
  return Comp;
};
const jsxFactory = () => {
  const cache = /* @__PURE__ */ new Map();
  return new Proxy(withAsChild, {
    apply(_target, _thisArg, argArray) {
      return withAsChild(argArray[0]);
    },
    get(_, element) {
      const asElement = element;
      if (!cache.has(asElement)) {
        cache.set(asElement, withAsChild(asElement));
      }
      return cache.get(asElement);
    }
  });
};
const ark = jsxFactory();
const [LocaleContextProvider, useLocaleContext] = createContext({
  name: "LocaleContext",
  hookName: "useLocaleContext",
  providerName: "<LocaleProvider />",
  strict: false,
  defaultValue: { dir: "ltr", locale: "en-US" }
});
const createSplitProps = () => (props, keys) => keys.reduce(
  (previousValue, currentValue) => {
    const [target, source] = previousValue;
    const key = currentValue;
    if (source[key] !== void 0) {
      target[key] = source[key];
    }
    delete source[key];
    return [target, source];
  },
  [{}, { ...props }]
);
const splitPresenceProps = (props) => createSplitProps()(props, [
  "immediate",
  "lazyMount",
  "onExitComplete",
  "present",
  "skipAnimationOnMount",
  "unmountOnExit"
]);
function useEvent(callback, opts = {}) {
  const { sync = false } = opts;
  const callbackRef = useLatestRef(callback);
  return reactExports.useCallback(
    (...args) => {
      if (sync) return queueMicrotask(() => callbackRef.current?.(...args));
      return callbackRef.current?.(...args);
    },
    [sync, callbackRef]
  );
}
function useLatestRef(value) {
  const ref = reactExports.useRef(value);
  ref.current = value;
  return ref;
}
const usePresence = (props = {}) => {
  const { lazyMount, unmountOnExit, present, skipAnimationOnMount = false, ...rest } = props;
  const wasEverPresent = reactExports.useRef(false);
  const machineProps = {
    ...rest,
    present,
    onExitComplete: useEvent(props.onExitComplete)
  };
  const service = useMachine(machine, machineProps);
  const api = connect(service);
  if (api.present) {
    wasEverPresent.current = true;
  }
  const unmounted = !api.present && !wasEverPresent.current && lazyMount || unmountOnExit && !api.present && wasEverPresent.current;
  const getPresenceProps = () => ({
    "data-state": api.skip && skipAnimationOnMount ? void 0 : present ? "open" : "closed",
    hidden: !api.present
  });
  return {
    ref: api.setNode,
    getPresenceProps,
    present: api.present,
    unmounted
  };
};
const [PresenceProvider, usePresenceContext] = createContext({
  name: "PresenceContext",
  hookName: "usePresenceContext",
  providerName: "<PresenceProvider />"
});
const carouselAnatomy = anatomy.extendWith("progressText", "autoplayIndicator");
const [CheckboxProvider, useCheckboxContext] = createContext({
  name: "CheckboxContext",
  hookName: "useCheckboxContext",
  providerName: "<CheckboxProvider />"
});
const CheckboxControl = reactExports.forwardRef((props, ref) => {
  const checkbox = useCheckboxContext();
  const mergedProps = mergeProps(checkbox.getControlProps(), props);
  return /* @__PURE__ */ jsxRuntimeExports.jsx(ark.div, { ...mergedProps, ref });
});
CheckboxControl.displayName = "CheckboxControl";
const checkboxAnatomy = anatomy$1.extendWith("group");
function useControllableState(props) {
  const { value, onChange, defaultValue } = props;
  const [uncontrolledValue, setUncontrolledValue] = reactExports.useState(defaultValue);
  const controlled = value !== void 0;
  const currentValue = controlled ? value : uncontrolledValue;
  const setValue = reactExports.useCallback(
    (value2) => {
      if (controlled) {
        return onChange?.(value2);
      }
      setUncontrolledValue(value2);
      return onChange?.(value2);
    },
    [controlled, onChange]
  );
  return [currentValue, setValue];
}
const [FieldsetProvider, useFieldsetContext] = createContext({
  name: "FieldsetContext",
  hookName: "useFieldsetContext",
  providerName: "<FieldsetProvider />",
  strict: false
});
function useCheckboxGroup(props = {}) {
  const fieldset = useFieldsetContext();
  const {
    defaultValue,
    value: controlledValue,
    onValueChange,
    disabled = fieldset?.disabled,
    readOnly,
    name,
    invalid = fieldset?.invalid
  } = props;
  const interactive = !(disabled || readOnly);
  const onChangeProp = useEvent(onValueChange, { sync: true });
  const [value, setValue] = useControllableState({
    value: controlledValue,
    defaultValue: defaultValue || [],
    onChange: onChangeProp
  });
  const isChecked = (val) => {
    return value.some((v) => String(v) === String(val));
  };
  const toggleValue = (val) => {
    isChecked(val) ? removeValue(val) : addValue(val);
  };
  const addValue = (val) => {
    if (!interactive) return;
    if (isChecked(val)) return;
    setValue(value.concat(val));
  };
  const removeValue = (val) => {
    if (!interactive) return;
    setValue(value.filter((v) => String(v) !== String(val)));
  };
  const getItemProps = (props2) => {
    return {
      checked: props2.value != null ? isChecked(props2.value) : void 0,
      onCheckedChange() {
        if (props2.value != null) {
          toggleValue(props2.value);
        }
      },
      name,
      disabled,
      readOnly,
      invalid
    };
  };
  return {
    isChecked,
    value,
    name,
    disabled: !!disabled,
    readOnly: !!readOnly,
    invalid: !!invalid,
    setValue,
    addValue,
    toggleValue,
    getItemProps
  };
}
const [CheckboxGroupContextProvider, useCheckboxGroupContext] = createContext({
  name: "CheckboxGroupContext",
  hookName: "useCheckboxGroupContext",
  providerName: "<CheckboxGroupProvider />",
  strict: false
});
const splitGroupProps = createSplitProps();
const CheckboxGroup = reactExports.forwardRef((props, ref) => {
  const [checkboxGroupProps, localProps] = splitGroupProps(props, [
    "defaultValue",
    "value",
    "onValueChange",
    "disabled",
    "invalid",
    "readOnly",
    "name"
  ]);
  const checkboxGroup = useCheckboxGroup(checkboxGroupProps);
  return /* @__PURE__ */ jsxRuntimeExports.jsx(CheckboxGroupContextProvider, { value: checkboxGroup, children: /* @__PURE__ */ jsxRuntimeExports.jsx(ark.div, { ref, role: "group", ...localProps, ...checkboxAnatomy.build().group.attrs }) });
});
CheckboxGroup.displayName = "CheckboxGroup";
const [FieldProvider, useFieldContext] = createContext({
  name: "FieldContext",
  hookName: "useFieldContext",
  providerName: "<FieldProvider />",
  strict: false
});
const CheckboxHiddenInput = reactExports.forwardRef((props, ref) => {
  const checkbox = useCheckboxContext();
  const mergedProps = mergeProps(checkbox.getHiddenInputProps(), props);
  const field = useFieldContext();
  return /* @__PURE__ */ jsxRuntimeExports.jsx(ark.input, { "aria-describedby": field?.ariaDescribedby, ...mergedProps, ref });
});
CheckboxHiddenInput.displayName = "CheckboxHiddenInput";
const CheckboxLabel = reactExports.forwardRef((props, ref) => {
  const checkbox = useCheckboxContext();
  const mergedProps = mergeProps(checkbox.getLabelProps(), props);
  return /* @__PURE__ */ jsxRuntimeExports.jsx(ark.span, { ...mergedProps, ref });
});
CheckboxLabel.displayName = "CheckboxLabel";
const useCheckbox = (ownProps = {}) => {
  const checkboxGroup = useCheckboxGroupContext();
  const field = useFieldContext();
  const props = reactExports.useMemo(() => {
    return mergeProps(ownProps, checkboxGroup?.getItemProps({ value: ownProps.value }) ?? {});
  }, [ownProps, checkboxGroup]);
  const id = reactExports.useId();
  const { getRootNode } = useEnvironmentContext();
  const { dir } = useLocaleContext();
  const machineProps = {
    id,
    ids: {
      label: field?.ids.label,
      hiddenInput: field?.ids.control
    },
    dir,
    disabled: field?.disabled,
    readOnly: field?.readOnly,
    invalid: field?.invalid,
    required: field?.required,
    getRootNode,
    ...props
  };
  const service = useMachine(machine$1, machineProps);
  return connect$1(service, normalizeProps);
};
const splitRootProps = createSplitProps();
const CheckboxRoot = reactExports.forwardRef((props, ref) => {
  const [useCheckboxProps, localProps] = splitRootProps(props, [
    "checked",
    "defaultChecked",
    "disabled",
    "form",
    "id",
    "ids",
    "invalid",
    "name",
    "onCheckedChange",
    "readOnly",
    "required",
    "value"
  ]);
  const checkbox = useCheckbox(useCheckboxProps);
  const mergedProps = mergeProps(checkbox.getRootProps(), localProps);
  return /* @__PURE__ */ jsxRuntimeExports.jsx(CheckboxProvider, { value: checkbox, children: /* @__PURE__ */ jsxRuntimeExports.jsx(ark.label, { ...mergedProps, ref }) });
});
CheckboxRoot.displayName = "CheckboxRoot";
const splitRootProviderProps = createSplitProps();
const CheckboxRootProvider = reactExports.forwardRef((props, ref) => {
  const [{ value: checkbox }, localProps] = splitRootProviderProps(props, ["value"]);
  const mergedProps = mergeProps(checkbox.getRootProps(), localProps);
  return /* @__PURE__ */ jsxRuntimeExports.jsx(CheckboxProvider, { value: checkbox, children: /* @__PURE__ */ jsxRuntimeExports.jsx(ark.label, { ...mergedProps, ref }) });
});
CheckboxRootProvider.displayName = "CheckboxRootProvider";
const colorPickerAnatomy = anatomy$2.extendWith("view");
const comboboxAnatomy = anatomy$3.extendWith("empty");
const FieldInput = reactExports.forwardRef((props, ref) => {
  const field = useFieldContext();
  const mergedProps = mergeProps(field?.getInputProps(), props);
  return /* @__PURE__ */ jsxRuntimeExports.jsx(ark.input, { ...mergedProps, ref });
});
FieldInput.displayName = "FieldInput";
const fieldAnatomy = createAnatomy("field").parts(
  "root",
  "errorText",
  "helperText",
  "input",
  "label",
  "select",
  "textarea",
  "requiredIndicator"
);
fieldAnatomy.build();
const FieldTextarea = reactExports.forwardRef((props, ref) => {
  const { autoresize, ...textareaProps } = props;
  const textareaRef = reactExports.useRef(null);
  const field = useFieldContext();
  const mergedProps = mergeProps(
    field?.getTextareaProps(),
    { style: { resize: autoresize ? "none" : void 0 } },
    textareaProps
  );
  reactExports.useEffect(() => {
    if (!autoresize) return;
    return autoresizeTextarea(textareaRef.current);
  }, [autoresize]);
  return /* @__PURE__ */ jsxRuntimeExports.jsx(ark.textarea, { ...mergedProps, ref: composeRefs(ref, textareaRef) });
});
FieldTextarea.displayName = "FieldTextarea";
const fieldsetAnatomy = createAnatomy("fieldset").parts("root", "errorText", "helperText", "legend");
fieldsetAnatomy.build();
const listboxAnatomy = anatomy$4.extendWith("empty");
const Portal = (props) => {
  const { children, disabled } = props;
  const [container, setContainer] = reactExports.useState(props.container?.current);
  const isServer = reactExports.useSyncExternalStore(
    subscribe,
    () => false,
    () => true
  );
  const { getRootNode } = useEnvironmentContext();
  reactExports.useEffect(() => {
    setContainer(() => props.container?.current);
  }, [props.container]);
  if (isServer || disabled) return /* @__PURE__ */ jsxRuntimeExports.jsx(jsxRuntimeExports.Fragment, { children });
  const mountNode = container ?? getPortalNode(getRootNode);
  return /* @__PURE__ */ jsxRuntimeExports.jsx(jsxRuntimeExports.Fragment, { children: reactExports.Children.map(children, (child) => reactDomExports.createPortal(child, mountNode)) });
};
const getPortalNode = (cb) => {
  const node = cb?.();
  const rootNode = node.getRootNode();
  if (isShadowRoot(rootNode)) return rootNode;
  return getDocument(node).body;
};
const subscribe = () => () => {
};
const segmentGroupAnatomy = anatomy$5.rename("segment-group");
segmentGroupAnatomy.build();
const [TooltipProvider, useTooltipContext] = createContext({
  name: "TooltipContext",
  hookName: "useTooltipContext",
  providerName: "<TooltipProvider />"
});
const TooltipArrow = reactExports.forwardRef((props, ref) => {
  const tooltip = useTooltipContext();
  const mergedProps = mergeProps(tooltip.getArrowProps(), props);
  return /* @__PURE__ */ jsxRuntimeExports.jsx(ark.div, { ...mergedProps, ref });
});
TooltipArrow.displayName = "TooltipArrow";
const TooltipArrowTip = reactExports.forwardRef((props, ref) => {
  const tooltip = useTooltipContext();
  const mergedProps = mergeProps(tooltip.getArrowTipProps(), props);
  return /* @__PURE__ */ jsxRuntimeExports.jsx(ark.div, { ...mergedProps, ref });
});
TooltipArrowTip.displayName = "TooltipArrowTip";
const TooltipContent = reactExports.forwardRef((props, ref) => {
  const tooltip = useTooltipContext();
  const presence = usePresenceContext();
  const mergedProps = mergeProps(tooltip.getContentProps(), presence.getPresenceProps(), props);
  if (presence.unmounted) {
    return null;
  }
  return /* @__PURE__ */ jsxRuntimeExports.jsx(ark.div, { ...mergedProps, ref: composeRefs(presence.ref, ref) });
});
TooltipContent.displayName = "TooltipContent";
const TooltipPositioner = reactExports.forwardRef((props, ref) => {
  const tooltip = useTooltipContext();
  const mergedProps = mergeProps(tooltip.getPositionerProps(), props);
  const presence = usePresenceContext();
  if (presence.unmounted) {
    return null;
  }
  return /* @__PURE__ */ jsxRuntimeExports.jsx(ark.div, { ...mergedProps, ref });
});
TooltipPositioner.displayName = "TooltipPositioner";
const useTooltip = (props) => {
  const id = reactExports.useId();
  const { getRootNode } = useEnvironmentContext();
  const { dir } = useLocaleContext();
  const machineProps = {
    id,
    dir,
    getRootNode,
    ...props
  };
  const service = useMachine(machine$2, machineProps);
  return connect$2(service, normalizeProps);
};
const TooltipRoot = (props) => {
  const [presenceProps, { children, ...localProps }] = splitPresenceProps(props);
  const tooltip = useTooltip(localProps);
  const presence = usePresence(mergeProps({ present: tooltip.open }, presenceProps));
  return /* @__PURE__ */ jsxRuntimeExports.jsx(TooltipProvider, { value: tooltip, children: /* @__PURE__ */ jsxRuntimeExports.jsx(PresenceProvider, { value: presence, children }) });
};
const TooltipRootProvider = (props) => {
  const [presenceProps, { value: tooltip, children }] = splitPresenceProps(props);
  const presence = usePresence(mergeProps({ present: tooltip.open }, presenceProps));
  return /* @__PURE__ */ jsxRuntimeExports.jsx(TooltipProvider, { value: tooltip, children: /* @__PURE__ */ jsxRuntimeExports.jsx(PresenceProvider, { value: presence, children }) });
};
const TooltipTrigger = reactExports.forwardRef((props, ref) => {
  const tooltip = useTooltipContext();
  const mergedProps = mergeProps(tooltip.getTriggerProps(), props);
  return /* @__PURE__ */ jsxRuntimeExports.jsx(ark.button, { ...mergedProps, ref });
});
TooltipTrigger.displayName = "TooltipTrigger";
export {
  CheckboxHiddenInput as C,
  FieldInput as F,
  Portal as P,
  TooltipRoot as T,
  comboboxAnatomy as a,
  fieldAnatomy as b,
  colorPickerAnatomy as c,
  carouselAnatomy as d,
  checkboxAnatomy as e,
  fieldsetAnatomy as f,
  CheckboxRoot as g,
  CheckboxControl as h,
  CheckboxLabel as i,
  CheckboxRootProvider as j,
  CheckboxGroup as k,
  listboxAnatomy as l,
  FieldTextarea as m,
  TooltipTrigger as n,
  TooltipPositioner as o,
  TooltipContent as p,
  TooltipArrow as q,
  TooltipArrowTip as r,
  segmentGroupAnatomy as s,
  TooltipRootProvider as t,
  useCheckboxContext as u
};
