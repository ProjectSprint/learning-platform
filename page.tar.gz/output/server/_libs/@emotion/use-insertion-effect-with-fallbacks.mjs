import { R as React, r as reactExports } from "../react.mjs";
var isBrowser = typeof document !== "undefined";
var syncFallback = function syncFallback2(create) {
  return create();
};
var useInsertionEffect = React["useInsertionEffect"] ? React["useInsertionEffect"] : false;
var useInsertionEffectAlwaysWithSyncFallback = !isBrowser ? syncFallback : useInsertionEffect || syncFallback;
var useInsertionEffectWithLayoutFallback = useInsertionEffect || reactExports.useLayoutEffect;
export {
  useInsertionEffectWithLayoutFallback as a,
  useInsertionEffectAlwaysWithSyncFallback as u
};
