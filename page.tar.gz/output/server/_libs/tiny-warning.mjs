function warning(condition, message) {
}
export {
  warning as w
};
